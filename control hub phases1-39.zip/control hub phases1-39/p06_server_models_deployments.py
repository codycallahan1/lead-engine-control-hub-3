"""
Lead Engine Control Hub - Deployment Models
Phase: 6
Purpose: Add SQLAlchemy Deployment model for tracking site deployment operations
Key Responsibilities:
- Deployment model with site relationship
- Status tracking (pending, running, completed, failed)
- Timestamps and metadata storage
- Foreign key relationships with Site model
"""

import logging
from datetime import datetime
from typing import Optional

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

# Import Base from database module
try:
    from p02__server_db import Base
    from p02__server_models import Site
except ImportError:
    # Fallback for standalone testing
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()
    logging.warning("Using fallback Base class - ensure p02__server-db.py and p02__server-models.py are available")

logger = logging.getLogger(__name__)

class Deployment(Base):
    """
    Deployment model representing site deployment operations.
    
    Attributes:
        id: Primary key
        site_id: Foreign key to Site table
        status: Deployment status (pending, running, completed, failed)
        created_at: Timestamp when deployment was created
        started_at: Timestamp when deployment started processing
        completed_at: Timestamp when deployment finished
        log_output: Text field for storing deployment logs
        error_message: Error message if deployment failed
        metadata: JSON-serializable metadata about the deployment
    """
    __tablename__ = "deployments"
    
    id = Column(Integer, primary_key=True, index=True)
    site_id = Column(Integer, ForeignKey("sites.id"), nullable=False, index=True)
    status = Column(String(50), default="pending", nullable=False, index=True)
    created_at = Column(
        DateTime(timezone=True), 
        server_default=func.now(),
        nullable=False
    )
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    log_output = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)
    metadata = Column(Text, nullable=True)  # JSON-serializable deployment metadata
    
    # Relationship to Site
    site = relationship("Site", back_populates="deployments")
    
    def __repr__(self):
        return f"<Deployment(id={self.id}, site_id={self.site_id}, status='{self.status}')>"
    
    def to_dict(self):
        """Convert model instance to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "site_id": self.site_id,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "log_output": self.log_output,
            "error_message": self.error_message,
            "metadata": self.metadata
        }
    
    def get_duration_seconds(self) -> Optional[float]:
        """
        Calculate deployment duration in seconds.
        
        Returns:
            Duration in seconds or None if not started/completed
        """
        if not self.started_at:
            return None
        
        end_time = self.completed_at or datetime.utcnow()
        return (end_time - self.started_at).total_seconds()
    
    def is_running(self) -> bool:
        """Check if deployment is currently running"""
        return self.status == "running"
    
    def is_completed(self) -> bool:
        """Check if deployment completed successfully"""
        return self.status == "completed"
    
    def is_failed(self) -> bool:
        """Check if deployment failed"""
        return self.status == "failed"
    
    def is_pending(self) -> bool:
        """Check if deployment is pending"""
        return self.status == "pending"

# Update Site model to include deployment relationship
# Note: This requires the Site model to be imported and extended
try:
    # Add back_populates to Site model if not already present
    if hasattr(Site, '__table__') and not hasattr(Site, 'deployments'):
        Site.deployments = relationship("Deployment", back_populates="site")
        logger.info("Added deployments relationship to Site model")
except Exception as e:
    logger.warning(f"Could not add deployments relationship to Site model: {e}")

# Deployment status constants
class DeploymentStatus:
    """Constants for deployment status values"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    
    @classmethod
    def all_statuses(cls):
        """Get all valid deployment statuses"""
        return [cls.PENDING, cls.RUNNING, cls.COMPLETED, cls.FAILED]
    
    @classmethod
    def is_valid_status(cls, status: str) -> bool:
        """Check if status is valid"""
        return status.lower() in cls.all_statuses()
    
    @classmethod
    def is_terminal_status(cls, status: str) -> bool:
        """Check if status is terminal (completed or failed)"""
        return status.lower() in [cls.COMPLETED, cls.FAILED]

def create_deployment_record(site_id: int, metadata: str = None) -> dict:
    """
    Helper function to create a deployment record dictionary.
    Used for creating new deployment instances.
    
    Args:
        site_id: ID of the site to deploy
        metadata: Optional metadata string
        
    Returns:
        Dictionary with deployment data
    """
    return {
        "site_id": site_id,
        "status": DeploymentStatus.PENDING,
        "metadata": metadata
    }

def get_deployment_summary(deployment: Deployment) -> dict:
    """
    Get a summary of deployment information for display.
    
    Args:
        deployment: Deployment instance
        
    Returns:
        Dictionary with summary information
    """
    duration = deployment.get_duration_seconds()
    duration_str = f"{duration:.2f}s" if duration else "N/A"
    
    return {
        "id": deployment.id,
        "site_id": deployment.site_id,
        "site_name": deployment.site.name if deployment.site else "Unknown",
        "site_domain": deployment.site.domain if deployment.site else "Unknown",
        "status": deployment.status,
        "duration": duration_str,
        "created_at": deployment.created_at.strftime("%Y-%m-%d %H:%M:%S") if deployment.created_at else "N/A",
        "has_logs": bool(deployment.log_output),
        "has_error": bool(deployment.error_message)
    }

# Model registry update
DEPLOYMENT_MODELS = {
    "Deployment": Deployment
}

def get_deployment_model_by_name(model_name: str):
    """
    Get deployment model class by name.
    
    Args:
        model_name: Name of the model ("Deployment")
        
    Returns:
        Model class or None if not found
    """
    return DEPLOYMENT_MODELS.get(model_name)

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Deployment Models Module Test ===")
    
    # Test deployment creation
    deployment = Deployment(
        site_id=1,
        status=DeploymentStatus.PENDING,
        metadata='{"version": "1.0.0"}'
    )
    
    logger.info(f"Created deployment: {deployment}")
    logger.info(f"Deployment dict: {deployment.to_dict()}")
    logger.info(f"Is pending: {deployment.is_pending()}")
    logger.info(f"Is running: {deployment.is_running()}")
    
    # Test status constants
    logger.info(f"All statuses: {DeploymentStatus.all_statuses()}")
    logger.info(f"Valid status 'pending': {DeploymentStatus.is_valid_status('pending')}")
    logger.info(f"Valid status 'invalid': {DeploymentStatus.is_valid_status('invalid')}")
    
    # Test helper functions
    deployment_data = create_deployment_record(1, '{"test": true}')
    logger.info(f"Deployment record data: {deployment_data}")
    
    logger.info("✅ Deployment models module test completed")