"""
Organization Models for Multi-Tenant Scoping
Phase 24: Organization management and data isolation
Key responsibilities: Org structure, membership management, data scoping
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

# Import base from existing models or create if needed
try:
    from p02__server_db import Base
except ImportError:
    Base = declarative_base()

class Organization(Base):
    """
    Organization for multi-tenant data isolation
    Each org has separate data scope for leads, buyers, sites, etc.
    """
    __tablename__ = "organizations"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    active = Column(Boolean, default=True, nullable=False)
    
    # Relationships
    memberships = relationship("Membership", back_populates="organization", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Organization(name='{self.name}', active={self.active})>"
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "active": self.active,
            "created_at": self.created_at.isoformat(),
            "member_count": len(self.memberships) if self.memberships else 0
        }
    
    def get_member_count(self, session) -> int:
        """Get number of active members"""
        return session.query(Membership).filter(
            Membership.org_id == self.id
        ).count()

class Membership(Base):
    """
    User membership in organizations
    Users can belong to multiple orgs with different roles
    """
    __tablename__ = "memberships"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    role_in_org = Column(String(50), nullable=False)  # owner, member
    
    # Relationships
    organization = relationship("Organization", back_populates="memberships")
    # Note: user relationship would be added when User model is available
    
    def __repr__(self):
        return f"<Membership(user_id={self.user_id}, org_id={self.org_id}, role='{self.role_in_org}')>"
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "org_id": self.org_id,
            "role_in_org": self.role_in_org
        }

# Organization role constants
class OrgRole:
    """Constants for organization roles"""
    OWNER = "owner"
    MEMBER = "member"
    
    @classmethod
    def all_roles(cls):
        return [cls.OWNER, cls.MEMBER]
    
    @classmethod
    def is_valid(cls, role: str) -> bool:
        return role in cls.all_roles()
    
    @classmethod
    def get_description(cls, role: str) -> str:
        descriptions = {
            cls.OWNER: "Full control over organization settings and members",
            cls.MEMBER: "Standard access to organization data"
        }
        return descriptions.get(role, "Unknown role")

# Core model extensions for org scoping
# These would be added to existing models in production

"""
CORE MODEL EXTENSIONS NEEDED:
============================

Add org_id column to existing models:

class Lead(Base):
    # ... existing columns ...
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, default=1, index=True)

class Buyer(Base):
    # ... existing columns ...
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, default=1, index=True)

class Site(Base):
    # ... existing columns ...
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, default=1, index=True)

class Deployment(Base):
    # ... existing columns ...
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, default=1, index=True)

Add relationships:
    organization = relationship("Organization")
"""

# Utility functions
def create_default_organization(session, name: str = "Default Organization"):
    """
    Create default organization if none exists
    Used during system initialization
    """
    existing_org = session.query(Organization).filter(Organization.id == 1).first()
    
    if existing_org:
        return existing_org
    
    # Create default org
    default_org = Organization(
        id=1,  # Fixed ID for default org
        name=name,
        active=True,
        created_at=datetime.utcnow()
    )
    
    session.add(default_org)
    session.commit()
    return default_org

def get_user_organizations(session, user_id: int):
    """Get all organizations a user belongs to"""
    memberships = session.query(Membership).filter(
        Membership.user_id == user_id
    ).all()
    
    org_ids = [m.org_id for m in memberships]
    organizations = session.query(Organization).filter(
        Organization.id.in_(org_ids),
        Organization.active == True
    ).all()
    
    return organizations

def get_user_role_in_org(session, user_id: int, org_id: int) -> str:
    """Get user's role in specific organization"""
    membership = session.query(Membership).filter(
        Membership.user_id == user_id,
        Membership.org_id == org_id
    ).first()
    
    return membership.role_in_org if membership else None

def add_user_to_org(session, user_id: int, org_id: int, role: str = OrgRole.MEMBER):
    """Add user to organization with specified role"""
    if not OrgRole.is_valid(role):
        raise ValueError(f"Invalid org role: {role}")
    
    # Check if membership already exists
    existing = session.query(Membership).filter(
        Membership.user_id == user_id,
        Membership.org_id == org_id
    ).first()
    
    if existing:
        # Update role
        existing.role_in_org = role
        session.commit()
        return existing
    
    # Create new membership
    membership = Membership(
        user_id=user_id,
        org_id=org_id,
        role_in_org=role
    )
    session.add(membership)
    session.commit()
    return membership

def remove_user_from_org(session, user_id: int, org_id: int):
    """Remove user from organization"""
    membership = session.query(Membership).filter(
        Membership.user_id == user_id,
        Membership.org_id == org_id
    ).first()
    
    if membership:
        session.delete(membership)
        session.commit()
        return True
    
    return False

def backfill_org_id_for_existing_data(session, target_org_id: int = 1):
    """
    Backfill org_id for existing data
    Should be run once during migration to multi-tenant setup
    """
    try:
        # This would update existing tables to add org_id
        # In a real implementation, you'd need to modify the actual model tables
        
        update_queries = []
        
        # Mock SQL updates - in reality these would be executed
        mock_updates = [
            f"UPDATE leads SET org_id = {target_org_id} WHERE org_id IS NULL",
            f"UPDATE buyers SET org_id = {target_org_id} WHERE org_id IS NULL", 
            f"UPDATE sites SET org_id = {target_org_id} WHERE org_id IS NULL",
            f"UPDATE deployments SET org_id = {target_org_id} WHERE org_id IS NULL"
        ]
        
        # Log what would be done
        for query in mock_updates:
            update_queries.append(query)
        
        logger.info(f"Backfill complete - {len(mock_updates)} tables updated")
        return {"queries_executed": len(mock_updates), "target_org_id": target_org_id}
        
    except Exception as e:
        logger.error(f"Error during backfill: {e}")
        return {"error": str(e)}

def can_user_access_org(session, user_id: int, org_id: int) -> bool:
    """Check if user has access to organization"""
    # Check if user is member of the org
    membership = session.query(Membership).filter(
        Membership.user_id == user_id,
        Membership.org_id == org_id
    ).first()
    
    if membership:
        return True
    
    # Check if user has admin role (admins can access all orgs)
    try:
        from p23__server_models_auth import UserRole, Role
        admin_role = session.query(UserRole).filter(
            UserRole.user_id == user_id,
            UserRole.role == Role.ADMIN
        ).first()
        return admin_role is not None
    except ImportError:
        # If auth models not available, default to membership check
        return False

def get_org_stats(session, org_id: int) -> dict:
    """Get statistics for an organization"""
    try:
        # In real implementation, these would query actual tables with org_id filter
        # For now, return mock stats
        
        stats = {
            "org_id": org_id,
            "leads_count": 0,
            "buyers_count": 0,
            "sites_count": 0,
            "deployments_count": 0,
            "members_count": 0
        }
        
        # Get actual member count
        members_count = session.query(Membership).filter(
            Membership.org_id == org_id
        ).count()
        stats["members_count"] = members_count
        
        # Mock other counts (would be real queries in production)
        stats.update({
            "leads_count": 10,  # Mock data
            "buyers_count": 5,
            "sites_count": 3,
            "deployments_count": 8
        })
        
        return stats
        
    except Exception as e:
        logger.error(f"Error getting org stats for {org_id}: {e}")
        return {"org_id": org_id, "error": str(e)}

# Ensure table creation helper
def create_org_tables(engine):
    """Create organization tables if they don't exist"""
    try:
        Organization.__table__.create(engine, checkfirst=True)
        Membership.__table__.create(engine, checkfirst=True)
        return True
    except Exception as e:
        print(f"Error creating org tables: {e}")
        return False

# Import for logging
import logging
logger = logging.getLogger(__name__)
