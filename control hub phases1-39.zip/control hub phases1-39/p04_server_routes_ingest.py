"""
Lead Engine Control Hub - Public Ingest Routes
Phase: 4
Purpose: Public-facing routes for lead ingestion via web form
Key Responsibilities:
- Serve public lead ingestion form
- Process form submissions with validation
- Create leads from public form data
- Return JSON responses for AJAX handling
"""

import logging
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

# Import services and schemas
try:
    from p03__server_services_leads import LeadService
    from p02__server_schemas import LeadIn
except ImportError as e:
    logging.warning(f"Import error in ingest routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 and 3 files are available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/ingest", tags=["ingest"])

# Initialize templates
try:
    templates_path = Path(__file__).parent / "templates"
    templates_path.mkdir(exist_ok=True)
    templates = Jinja2Templates(directory=str(templates_path))
    logger.info("Templates initialized for ingest routes")
except Exception as e:
    logger.warning(f"Could not initialize templates: {e}")
    templates = None

# =============================================================================
# PUBLIC INGEST ENDPOINTS
# =============================================================================

@router.get("/form", response_class=HTMLResponse)
async def get_ingest_form(request: Request):
    """
    Serve the public lead ingestion form.
    
    Args:
        request: FastAPI request object
        
    Returns:
        HTML response with the lead ingestion form
    """
    try:
        logger.info("GET /ingest/form - serving public lead form")
        
        if not templates:
            # Fallback HTML if templates not available
            fallback_html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Lead Ingest Form</title>
                <style>
                    body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
                    .form-group { margin-bottom: 15px; }
                    label { display: block; margin-bottom: 5px; font-weight: bold; }
                    input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
                    button { background: #007bff; color: white; padding: 12px 24px; border: none; border-radius: 4px; cursor: pointer; }
                    .required { color: red; }
                </style>
            </head>
            <body>
                <h1>Submit Your Information</h1>
                <form action="/ingest/lead" method="POST">
                    <div class="form-group">
                        <label>Name <span class="required">*</span></label>
                        <input type="text" name="name" required minlength="2">
                    </div>
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Phone (optional)</label>
                        <input type="tel" name="phone">
                    </div>
                    <button type="submit">Submit</button>
                </form>
            </body>
            </html>
            """
            return HTMLResponse(fallback_html, status_code=200)
        
        # Try to render the proper template
        try:
            context = {
                "request": request,
                "title": "Lead Ingest Form"
            }
            return templates.TemplateResponse("ingest_form.html", context)
            
        except Exception as template_error:
            logger.warning(f"Template not found, trying p04 prefixed name: {template_error}")
            
            # Try with the phase-prefixed name
            try:
                return templates.TemplateResponse("p04__server-templates-ingest-form.html", context)
            except Exception as e2:
                logger.error(f"Could not load any ingest form template: {e2}")
                # Return the fallback HTML
                return HTMLResponse(
                    "<h1>Lead Ingest Form</h1><p>Template not available. Please contact support.</p>",
                    status_code=200
                )
        
    except Exception as e:
        logger.error(f"Failed to serve ingest form: {e}")
        return HTMLResponse(
            f"<h1>Error</h1><p>Failed to load form: {e}</p>",
            status_code=500
        )

@router.post("/lead")
async def submit_lead(
    name: str = Form(..., min_length=2, max_length=255),
    email: str = Form(..., max_length=255),
    phone: str = Form("", max_length=50)
):
    """
    Process lead submission from public form.
    
    Args:
        name: Lead's full name (required, min 2 chars)
        email: Lead's email address (required, must contain @)
        phone: Lead's phone number (optional)
        
    Returns:
        JSON response with success status and lead ID
        
    Raises:
        400: If validation fails
        500: If lead creation fails
    """
    try:
        logger.info(f"POST /ingest/lead - processing submission for: {email}")
        
        # Validate name
        if not name or len(name.strip()) < 2:
            logger.warning(f"Invalid name submitted: '{name}'")
            return JSONResponse(
                status_code=400,
                content={"status": "error", "detail": "Name must be at least 2 characters long"}
            )
        
        # Validate email (basic check)
        if not email or "@" not in email:
            logger.warning(f"Invalid email submitted: '{email}'")
            return JSONResponse(
                status_code=400,
                content={"status": "error", "detail": "Please provide a valid email address"}
            )
        
        # Clean up inputs
        name = name.strip()
        email = email.strip().lower()
        phone = phone.strip() if phone else None
        
        # Convert empty phone to None
        if phone == "":
            phone = None
        
        # Create LeadIn object for validation
        try:
            lead_data = LeadIn(
                name=name,
                email=email,
                phone=phone
            )
        except Exception as validation_error:
            logger.warning(f"Pydantic validation failed: {validation_error}")
            return JSONResponse(
                status_code=400,
                content={"status": "error", "detail": f"Validation error: {str(validation_error)}"}
            )
        
        # Create the lead
        try:
            lead = LeadService.create_lead(lead_data)
            logger.info(f"Lead ingested via public form: {email} (ID: {lead.id})")
            
            return JSONResponse(
                status_code=200,
                content={
                    "status": "success",
                    "lead_id": lead.id,
                    "message": "Your information has been submitted successfully!"
                }
            )
            
        except ValueError as e:
            # Email already exists
            logger.warning(f"Lead creation failed: {e}")
            return JSONResponse(
                status_code=400,
                content={"status": "error", "detail": str(e)}
            )
            
    except Exception as e:
        logger.error(f"Failed to process lead submission: {e}")
        return JSONResponse(
            status_code=500,
            content={"status": "error", "detail": "Internal server error. Please try again later."}
        )

# =============================================================================
# UTILITY ENDPOINTS
# =============================================================================

@router.get("/stats")
async def get_ingest_stats():
    """
    Get statistics about lead ingestion.
    
    Returns:
        JSON object with ingestion statistics
    """
    try:
        logger.info("GET /ingest/stats")
        
        # Get total leads count
        total_leads = LeadService.get_leads_count()
        
        return {
            "total_leads": total_leads,
            "endpoint": "/ingest/lead",
            "form_endpoint": "/ingest/form",
            "status": "operational"
        }
        
    except Exception as e:
        logger.error(f"Failed to get ingest stats: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/health")
async def ingest_health_check():
    """
    Health check for ingestion endpoints.
    
    Returns:
        JSON object with health status
    """
    try:
        logger.info("GET /ingest/health")
        
        # Test database connectivity by getting lead count
        LeadService.get_leads_count()
        
        return {
            "status": "healthy",
            "service": "lead_ingestion",
            "endpoints": {
                "form": "/ingest/form",
                "submit": "/ingest/lead",
                "stats": "/ingest/stats"
            }
        }
        
    except Exception as e:
        logger.error(f"Ingest health check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "service": "lead_ingestion",
                "error": str(e)
            }
        )

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Ingest Routes Module Test ===")
    logger.info("✅ Ingest routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET  /ingest/form   - Public lead form")
    logger.info("  POST /ingest/lead   - Submit lead data")
    logger.info("  GET  /ingest/stats  - Ingestion statistics")
    logger.info("  GET  /ingest/health - Health check")
