"""
Theme models for organization branding.
Phase 39: Theming & Branding per Org
Purpose: per-Org logo/colors; inject into base template + public ingest form
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean
from sqlalchemy.sql import func
from datetime import datetime
import logging

# Import base from existing models
try:
    from p02__server_models import Base
except ImportError:
    # Fallback for when files are reorganized
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()
    logging.warning("Could not import Base from models - using fallback declarative_base")

logger = logging.getLogger(__name__)


class OrgTheme(Base):
    """
    Organization theme configuration for branding customization.
    Stores colors, logo, and other visual elements per organization.
    """
    __tablename__ = "org_themes"
    
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, nullable=False, index=True, default=1)
    
    # Color scheme (hex values)
    primary_hex = Column(String(7), nullable=True)  # e.g., "#0ea5e9"
    secondary_hex = Column(String(7), nullable=True)  # e.g., "#22c55e"
    accent_hex = Column(String(7), nullable=True)  # e.g., "#f59e0b"
    background_hex = Column(String(7), nullable=True)  # e.g., "#0f172a"
    text_hex = Column(String(7), nullable=True)  # e.g., "#e2e8f0"
    
    # Logo and branding
    logo_path = Column(String(255), nullable=True)  # Path to uploaded logo file
    logo_alt_text = Column(String(255), nullable=True, default="Logo")
    
    # Organization name override
    display_name = Column(String(255), nullable=True)  # Override org name in UI
    
    # Custom CSS overrides
    custom_css = Column(Text, nullable=True)  # Additional CSS rules
    
    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<OrgTheme(id={self.id}, org_id={self.org_id}, primary={self.primary_hex})>"
    
    def to_dict(self):
        """Convert theme to dictionary for template use."""
        return {
            "id": self.id,
            "org_id": self.org_id,
            "primary_hex": self.primary_hex,
            "secondary_hex": self.secondary_hex,
            "accent_hex": self.accent_hex,
            "background_hex": self.background_hex,
            "text_hex": self.text_hex,
            "logo_path": self.logo_path,
            "logo_alt_text": self.logo_alt_text or "Logo",
            "display_name": self.display_name,
            "custom_css": self.custom_css,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
    
    def get_css_vars(self):
        """Generate CSS custom properties for this theme."""
        vars_dict = {}
        
        # Default colors (dark theme fallbacks)
        defaults = {
            "primary": self.primary_hex or "#0ea5e9",
            "secondary": self.secondary_hex or "#22c55e", 
            "accent": self.accent_hex or "#f59e0b",
            "background": self.background_hex or "#0f172a",
            "surface": "#1e293b",  # Derived from background
            "text": self.text_hex or "#e2e8f0",
            "text-muted": "#94a3b8",  # Derived from text
            "border": "#334155"  # Derived colors
        }
        
        # Generate CSS custom properties
        for key, value in defaults.items():
            vars_dict[f"--color-{key}"] = value
        
        # Derived colors for UI elements
        vars_dict["--color-primary-hover"] = self._darken_color(defaults["primary"])
        vars_dict["--color-secondary-hover"] = self._darken_color(defaults["secondary"])
        
        return vars_dict
    
    def _darken_color(self, hex_color: str, factor: float = 0.1) -> str:
        """
        Darken a hex color by a given factor.
        Simple implementation without external dependencies.
        """
        if not hex_color or not hex_color.startswith('#'):
            return hex_color
        
        try:
            # Remove # and convert to RGB
            hex_color = hex_color.lstrip('#')
            if len(hex_color) != 6:
                return f"#{hex_color}"  # Return original if invalid
            
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            
            # Darken by factor
            r = max(0, int(r * (1 - factor)))
            g = max(0, int(g * (1 - factor)))
            b = max(0, int(b * (1 - factor)))
            
            # Convert back to hex
            return f"#{r:02x}{g:02x}{b:02x}"
            
        except (ValueError, IndexError):
            logger.warning(f"Could not darken invalid color: {hex_color}")
            return f"#{hex_color}"


class ThemeAsset(Base):
    """
    Track uploaded theme assets like logos and custom images.
    """
    __tablename__ = "theme_assets"
    
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, nullable=False, index=True, default=1)
    theme_id = Column(Integer, nullable=True)  # FK to OrgTheme, but nullable for flexibility
    
    # File information
    filename = Column(String(255), nullable=False)
    original_filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)  # Full path to stored file
    file_size_bytes = Column(Integer, nullable=False, default=0)
    mime_type = Column(String(100), nullable=True)
    
    # Asset type and usage
    asset_type = Column(String(50), nullable=False, default="logo")  # logo, icon, background, etc.
    alt_text = Column(String(255), nullable=True)
    
    # Status
    active = Column(Boolean, nullable=False, default=True)
    
    # Metadata
    uploaded_by = Column(String(255), nullable=True)  # User who uploaded
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    def __repr__(self):
        return f"<ThemeAsset(id={self.id}, org_id={self.org_id}, type={self.asset_type}, filename={self.filename})>"
    
    def to_dict(self):
        """Convert asset to dictionary."""
        return {
            "id": self.id,
            "org_id": self.org_id,
            "theme_id": self.theme_id,
            "filename": self.filename,
            "original_filename": self.original_filename,
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "mime_type": self.mime_type,
            "asset_type": self.asset_type,
            "alt_text": self.alt_text,
            "active": self.active,
            "uploaded_by": self.uploaded_by,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }
    
    def get_public_url(self, base_url: str = "") -> str:
        """
        Generate public URL for accessing this asset.
        Assumes assets are served via /static or similar route.
        """
        if not self.file_path:
            return ""
        
        # Extract relative path from full path
        # Assumes uploads are stored under ./server/uploads/
        if "uploads/" in self.file_path:
            relative_path = self.file_path.split("uploads/", 1)[1]
            return f"{base_url}/static/uploads/{relative_path}"
        else:
            return f"{base_url}/static/{self.filename}"


# Default theme values for new organizations
DEFAULT_THEME = {
    "primary_hex": "#0ea5e9",      # Sky blue
    "secondary_hex": "#22c55e",     # Green
    "accent_hex": "#f59e0b",        # Amber
    "background_hex": "#0f172a",    # Dark slate
    "text_hex": "#e2e8f0",         # Light gray
    "display_name": None,           # Use org name
    "custom_css": None
}


def create_default_theme(org_id: int) -> dict:
    """
    Create default theme configuration for an organization.
    Returns dict that can be used to create OrgTheme instance.
    """
    theme_data = DEFAULT_THEME.copy()
    theme_data["org_id"] = org_id
    
    logger.info(f"Creating default theme for org_id={org_id}")
    return theme_data


def validate_hex_color(color: str) -> bool:
    """
    Validate that a string is a valid hex color.
    Returns True if valid, False otherwise.
    """
    if not color:
        return True  # Allow null/empty colors
    
    if not color.startswith('#'):
        return False
    
    if len(color) != 7:
        return False
    
    try:
        int(color[1:], 16)  # Try to parse as hex
        return True
    except ValueError:
        return False


def sanitize_css(css_text: str) -> str:
    """
    Basic CSS sanitization to prevent XSS.
    Removes dangerous CSS properties and JavaScript.
    """
    if not css_text:
        return ""
    
    # Remove script-related content
    dangerous_patterns = [
        'javascript:',
        'expression(',
        'eval(',
        'import',
        '@import',
        'behavior:',
        '-moz-binding',
        '<script',
        '</script'
    ]
    
    sanitized = css_text
    
    for pattern in dangerous_patterns:
        sanitized = sanitized.replace(pattern.lower(), '')
        sanitized = sanitized.replace(pattern.upper(), '')
        sanitized = sanitized.replace(pattern.title(), '')
    
    # Limit length to prevent abuse
    if len(sanitized) > 10000:  # 10KB limit
        sanitized = sanitized[:10000]
        logger.warning("Custom CSS was truncated due to length limit")
    
    return sanitized.strip()
