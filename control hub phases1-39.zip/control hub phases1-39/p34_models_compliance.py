"""
Lead Engine Control Hub - Compliance Models
Phase 34: Consent flags and PII redaction utilities
Purpose: Track lead consent and compliance settings per organization
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Text, JSON
from sqlalchemy.orm import relationship

# Import base from existing models (would be consolidated in final structure)
try:
    from p02__server_models import Base
except ImportError:
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()


class ComplianceSetting(Base):
    """
    Organization-level compliance and privacy settings.
    
    Controls how PII is handled in exports, logs, and UI display.
    Settings are applied globally within an organization.
    """
    __tablename__ = "compliance_settings"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, unique=True, index=True)
    
    # PII masking settings
    mask_email = Column(Boolean, nullable=False, default=False)
    mask_phone = Column(Boolean, nullable=False, default=False)
    export_mask = Column(Boolean, nullable=False, default=False)
    
    # Audit trail settings
    log_pii_access = Column(Boolean, nullable=False, default=True)
    require_consent = Column(Boolean, nullable=False, default=False)
    
    # Data retention settings
    retention_days = Column(Integer, nullable=True)  # null = no automatic deletion
    
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = Column(String(100), nullable=True)
    
    # Relationships
    organization = relationship("Organization")
    
    def __repr__(self):
        return f"<ComplianceSetting org_id={self.org_id} mask_email={self.mask_email} mask_phone={self.mask_phone}>"
    
    def to_dict(self):
        """Convert to dictionary for API responses."""
        return {
            "org_id": self.org_id,
            "mask_email": self.mask_email,
            "mask_phone": self.mask_phone,
            "export_mask": self.export_mask,
            "log_pii_access": self.log_pii_access,
            "require_consent": self.require_consent,
            "retention_days": self.retention_days,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by
        }


# Extension to Lead model - these fields would be added to existing Lead model
class LeadCompliance:
    """
    Compliance-related fields that would be added to the existing Lead model.
    
    In the final implementation, these would be additional columns on the Lead table.
    """
    
    # Consent tracking
    consent_opt_in = Column(Boolean, nullable=True)  # null = unknown, True = opted in, False = opted out
    consent_date = Column(DateTime, nullable=True)
    consent_source = Column(String(50), nullable=True)  # web, phone, email, etc.
    
    # Lead source and classification
    source = Column(String(100), nullable=True)  # website, referral, campaign, etc.
    tags = Column(JSON, nullable=True)  # flexible metadata as JSON array
    
    # Privacy flags
    do_not_contact = Column(Boolean, nullable=False, default=False)
    suppressed = Column(Boolean, nullable=False, default=False)
    suppression_reason = Column(String(200), nullable=True)
    
    def update_consent(self, opt_in: bool, source: str = None):
        """Update consent status with timestamp."""
        self.consent_opt_in = opt_in
        self.consent_date = datetime.utcnow()
        self.consent_source = source


class ConsentLog(Base):
    """
    Immutable log of all consent changes for audit purposes.
    
    Tracks every modification to consent status with full context.
    """
    __tablename__ = "consent_logs"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False, index=True)
    
    # Consent details
    old_consent = Column(Boolean, nullable=True)  # Previous consent state
    new_consent = Column(Boolean, nullable=True)  # New consent state
    source = Column(String(50), nullable=True)
    
    # Metadata
    tags_added = Column(JSON, nullable=True)
    tags_removed = Column(JSON, nullable=True)
    notes = Column(Text, nullable=True)
    
    # Audit fields
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    created_by = Column(String(100), nullable=True)
    ip_address = Column(String(45), nullable=True)  # IPv4 or IPv6
    user_agent = Column(Text, nullable=True)
    
    # Relationships
    lead = relationship("Lead")
    
    def __repr__(self):
        return f"<ConsentLog lead_id={self.lead_id} {self.old_consent}->{self.new_consent} by={self.created_by}>"
    
    @property
    def consent_action(self):
        """Human-readable consent action."""
        if self.old_consent is None and self.new_consent is True:
            return "opted_in"
        elif self.old_consent is None and self.new_consent is False:
            return "opted_out"
        elif self.old_consent is True and self.new_consent is False:
            return "withdrew_consent"
        elif self.old_consent is False and self.new_consent is True:
            return "granted_consent"
        elif self.old_consent is True and self.new_consent is True:
            return "consent_updated"
        elif self.old_consent is False and self.new_consent is False:
            return "opt_out_updated"
        else:
            return "unknown"


class DataProcessingLog(Base):
    """
    Log of data processing activities for GDPR compliance.
    
    Records when PII is accessed, exported, or processed.
    """
    __tablename__ = "data_processing_logs"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=True, index=True)
    
    # Processing details
    activity = Column(String(50), nullable=False, index=True)  # view, export, delete, etc.
    purpose = Column(String(100), nullable=True)  # business purpose
    data_categories = Column(JSON, nullable=True)  # types of data accessed
    
    # Legal basis (GDPR Article 6)
    legal_basis = Column(String(50), nullable=True)  # consent, contract, legitimate_interest, etc.
    
    # Context
    endpoint = Column(String(200), nullable=True)
    method = Column(String(10), nullable=True)  # GET, POST, etc.
    
    # Audit fields
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    user_id = Column(String(100), nullable=True)
    ip_address = Column(String(45), nullable=True)
    
    def __repr__(self):
        return f"<DataProcessingLog activity={self.activity} lead_id={self.lead_id} user={self.user_id}>"


# Migration helpers for extending existing models
def add_compliance_fields_to_lead():
    """
    Migration function to add compliance fields to existing Lead model.
    In a real application, this would be handled by Alembic or similar.
    """
    # This would add the LeadCompliance fields to the existing Lead table:
    # ALTER TABLE leads ADD COLUMN consent_opt_in BOOLEAN;
    # ALTER TABLE leads ADD COLUMN consent_date DATETIME;
    # ALTER TABLE leads ADD COLUMN consent_source VARCHAR(50);
    # ALTER TABLE leads ADD COLUMN source VARCHAR(100);
    # ALTER TABLE leads ADD COLUMN tags JSON;
    # ALTER TABLE leads ADD COLUMN do_not_contact BOOLEAN DEFAULT FALSE;
    # ALTER TABLE leads ADD COLUMN suppressed BOOLEAN DEFAULT FALSE;
    # ALTER TABLE leads ADD COLUMN suppression_reason VARCHAR(200);
    pass


# Indexes for performance
# CREATE INDEX idx_compliance_settings_org ON compliance_settings(org_id);
# CREATE INDEX idx_consent_logs_org_lead ON consent_logs(org_id, lead_id);
# CREATE INDEX idx_consent_logs_created ON consent_logs(created_at);
# CREATE INDEX idx_data_processing_logs_org_activity ON data_processing_logs(org_id, activity);
# CREATE INDEX idx_data_processing_logs_created ON data_processing_logs(created_at);
