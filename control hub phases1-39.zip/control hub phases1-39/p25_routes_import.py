"""
Import routes for bulk CSV lead processing.

Phase: 25
Purpose: Handle CSV uploads, staging, and batch commit workflows.
Key responsibilities:
- Accept multipart CSV files for lead import
- Create staging batches with validation
- Trigger background import jobs
"""

from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, Request
from pydantic import BaseModel
import csv
import io
import uuid
import logging
from typing import List, Dict, Any

try:
    from p02__server_db import get_session
    from p25__server_models_import import LeadStaging, create_staging_tables
    from p24__server_services_scope import current_org
    from p07__server_services_queue import enqueue
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Import routes: missing dependency {e}")

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/import", tags=["import"])


class BatchResponse(BaseModel):
    batch_id: str
    total_rows: int
    valid_rows: int
    invalid_rows: int
    errors: List[Dict[str, Any]]


class CommitResponse(BaseModel):
    success: bool
    batch_id: str
    job_id: str
    message: str


def require_ops_admin():
    """Placeholder for ops/admin role requirement."""
    # In actual implementation, would check roles from Phase 23
    return True


@router.post("/leads", response_model=BatchResponse)
async def upload_leads_csv(
    request: Request,
    file: UploadFile = File(...),
    org_id: int = Depends(current_org),
    _auth: bool = Depends(require_ops_admin)
):
    """Upload CSV file and create staging batch."""
    
    if not file.filename or not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="CSV file required")
    
    # Read file content
    try:
        content = await file.read()
        csv_text = content.decode('utf-8')
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="Invalid UTF-8 encoding")
    
    # Parse CSV
    batch_id = str(uuid.uuid4())
    staging_rows = []
    errors = []
    
    try:
        csv_reader = csv.DictReader(io.StringIO(csv_text))
        
        # Validate headers
        required_headers = {'name', 'email'}
        if not required_headers.issubset(set(csv_reader.fieldnames or [])):
            raise HTTPException(
                status_code=400, 
                detail=f"CSV must have headers: {', '.join(required_headers)}"
            )
        
        row_num = 1
        for row in csv_reader:
            row_num += 1
            
            # Clean whitespace
            name = (row.get('name') or '').strip()
            email = (row.get('email') or '').strip().lower()
            phone = (row.get('phone') or '').strip()
            
            if not name and not email:  # Skip completely empty rows
                continue
            
            staging_row = LeadStaging(
                org_id=org_id,
                name=name,
                email=email,
                phone=phone,
                batch_id=batch_id
            )
            
            # Validate row
            staging_row.validate_row()
            
            if not staging_row.valid:
                errors.append({
                    'row': row_num,
                    'data': {'name': name, 'email': email, 'phone': phone},
                    'errors': staging_row.errors
                })
            
            staging_rows.append(staging_row)
    
    except csv.Error as e:
        raise HTTPException(status_code=400, detail=f"CSV parsing error: {str(e)}")
    
    if not staging_rows:
        raise HTTPException(status_code=400, detail="No valid rows found in CSV")
    
    # Save to staging table
    try:
        with get_session() as db:
            create_staging_tables()  # Ensure table exists
            db.add_all(staging_rows)
            db.commit()
            
            valid_count = sum(1 for row in staging_rows if row.valid)
            invalid_count = len(staging_rows) - valid_count
            
            logger.info(f"Created import batch {batch_id}: {valid_count} valid, {invalid_count} invalid rows")
            
            # Audit log
            audit(
                kind="import_batch_created",
                message=f"CSV batch uploaded: {len(staging_rows)} rows",
                meta={
                    "batch_id": batch_id,
                    "filename": file.filename,
                    "org_id": org_id,
                    "total_rows": len(staging_rows),
                    "valid_rows": valid_count
                }
            )
            
            return BatchResponse(
                batch_id=batch_id,
                total_rows=len(staging_rows),
                valid_rows=valid_count,
                invalid_rows=invalid_count,
                errors=errors[:10]  # Limit error preview
            )
    
    except Exception as e:
        logger.error(f"Failed to save staging batch: {e}")
        raise HTTPException(status_code=500, detail="Database error during staging")


@router.get("/batches")
async def list_import_batches(
    request: Request,
    org_id: int = Depends(current_org),
    _auth: bool = Depends(require_ops_admin)
):
    """List recent import batches with summary counts."""
    
    try:
        with get_session() as db:
            # Get batch summaries from last 30 days
            from sqlalchemy import func, desc
            from datetime import datetime, timedelta
            
            cutoff = datetime.utcnow() - timedelta(days=30)
            
            batch_summary = db.query(
                LeadStaging.batch_id,
                func.min(LeadStaging.created_at).label('created_at'),
                func.count(LeadStaging.id).label('total_rows'),
                func.sum(func.cast(LeadStaging.valid, int)).label('valid_rows')
            ).filter(
                LeadStaging.org_id == org_id,
                LeadStaging.created_at >= cutoff
            ).group_by(
                LeadStaging.batch_id
            ).order_by(
                desc('created_at')
            ).limit(50).all()
            
            batches = []
            for batch in batch_summary:
                batches.append({
                    'batch_id': batch.batch_id,
                    'created_at': batch.created_at.isoformat(),
                    'total_rows': batch.total_rows,
                    'valid_rows': batch.valid_rows or 0,
                    'invalid_rows': batch.total_rows - (batch.valid_rows or 0)
                })
            
            return {'batches': batches}
    
    except Exception as e:
        logger.error(f"Failed to list import batches: {e}")
        raise HTTPException(status_code=500, detail="Database error")


@router.post("/batches/{batch_id}/commit", response_model=CommitResponse)
async def commit_import_batch(
    batch_id: str,
    request: Request,
    org_id: int = Depends(current_org),
    _auth: bool = Depends(require_ops_admin)
):
    """Commit a staging batch to final leads table via background job."""
    
    try:
        with get_session() as db:
            # Verify batch exists and has valid rows
            batch_check = db.query(
                func.count(LeadStaging.id).label('total'),
                func.sum(func.cast(LeadStaging.valid, int)).label('valid')
            ).filter(
                LeadStaging.batch_id == batch_id,
                LeadStaging.org_id == org_id
            ).first()
            
            if not batch_check or batch_check.total == 0:
                raise HTTPException(status_code=404, detail="Batch not found")
            
            valid_count = batch_check.valid or 0
            if valid_count == 0:
                raise HTTPException(status_code=400, detail="No valid rows to commit")
            
            # Enqueue background job
            job_id = enqueue("import_leads", {
                "batch_id": batch_id,
                "org_id": org_id
            })
            
            logger.info(f"Enqueued import job {job_id} for batch {batch_id}")
            
            # Audit log
            audit(
                kind="import_committed",
                message=f"Import batch committed: {valid_count} valid rows",
                meta={
                    "batch_id": batch_id,
                    "job_id": job_id,
                    "org_id": org_id,
                    "valid_rows": valid_count
                }
            )
            
            return CommitResponse(
                success=True,
                batch_id=batch_id,
                job_id=job_id,
                message=f"Import job queued for {valid_count} leads"
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to commit batch {batch_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to queue import job")
