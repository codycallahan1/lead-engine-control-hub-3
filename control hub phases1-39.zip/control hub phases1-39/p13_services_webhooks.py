"""
Webhook service for managing outbound webhook delivery.

Phase: 13
Purpose: Service layer for webhook registration and triggering
Key responsibilities: register webhooks, list webhooks, trigger events
"""

import logging
import json
from typing import List, Dict, Any, Optional
from datetime import datetime

# Import attempt with graceful fallback
try:
    from p02__server_db import get_session
    from p13__server_models_webhooks import Webhook, WebhookDelivery
    from p07__server_services_queue import enqueue
except ImportError as e:
    logging.warning(f"Import issue in webhook services: {e}")
    # Fallback for development
    def get_session():
        return None
    class Webhook:
        pass
    class WebhookDelivery:
        pass
    def enqueue(kind, payload):
        return "mock-job-id"

logger = logging.getLogger(__name__)

def register(url: str, event: str, active: bool = True) -> int:
    """
    Register a new webhook endpoint for an event.
    
    Args:
        url: The webhook URL to POST to
        event: Event type (lead_ingested, leads_exported, etc.)
        active: Whether the webhook is active
        
    Returns:
        ID of the created webhook
    """
    logger.info(f"Registering webhook: {url} for event: {event}")
    
    with get_session() as session:
        webhook = Webhook(
            url=url,
            event=event,
            active=active
        )
        session.add(webhook)
        session.commit()
        
        webhook_id = webhook.id
        logger.info(f"Webhook registered with ID: {webhook_id}")
        return webhook_id

def list_webhooks(event: Optional[str] = None, active_only: bool = False) -> List[Dict[str, Any]]:
    """
    List registered webhooks, optionally filtered by event or active status.
    
    Args:
        event: Filter by specific event type
        active_only: Only return active webhooks
        
    Returns:
        List of webhook dictionaries
    """
    logger.info(f"Listing webhooks (event={event}, active_only={active_only})")
    
    with get_session() as session:
        query = session.query(Webhook)
        
        if event:
            query = query.filter(Webhook.event == event)
        if active_only:
            query = query.filter(Webhook.active == True)
            
        webhooks = query.order_by(Webhook.created_at.desc()).all()
        
        result = []
        for webhook in webhooks:
            result.append({
                'id': webhook.id,
                'url': webhook.url,
                'event': webhook.event,
                'active': webhook.active,
                'created_at': webhook.created_at,
                'last_status': webhook.last_status,
                'last_response_ms': webhook.last_response_ms
            })
        
        logger.info(f"Found {len(result)} webhooks")
        return result

def disable(webhook_id: int) -> bool:
    """
    Disable a webhook by setting active=False.
    
    Args:
        webhook_id: ID of webhook to disable
        
    Returns:
        True if webhook was found and disabled
    """
    logger.info(f"Disabling webhook: {webhook_id}")
    
    with get_session() as session:
        webhook = session.query(Webhook).filter(Webhook.id == webhook_id).first()
        if not webhook:
            logger.warning(f"Webhook not found: {webhook_id}")
            return False
            
        webhook.active = False
        session.commit()
        
        logger.info(f"Webhook {webhook_id} disabled")
        return True

def trigger(event: str, payload: Dict[str, Any]) -> int:
    """
    Trigger webhook deliveries for all active webhooks subscribed to an event.
    
    Args:
        event: Event type that occurred
        payload: Data to send to webhooks
        
    Returns:
        Number of webhooks that will be triggered
    """
    logger.info(f"Triggering webhooks for event: {event}")
    
    # Get all active webhooks for this event
    active_webhooks = list_webhooks(event=event, active_only=True)
    
    triggered_count = 0
    for webhook in active_webhooks:
        # Create delivery record
        with get_session() as session:
            delivery = WebhookDelivery(
                webhook_id=webhook['id'],
                event=event,
                payload_json=json.dumps(payload),
                status='queued'
            )
            session.add(delivery)
            session.commit()
            delivery_id = delivery.id
        
        # Enqueue webhook job
        job_payload = {
            'webhook_id': webhook['id'],
            'delivery_id': delivery_id,
            'url': webhook['url'],
            'event': event,
            'payload': payload
        }
        
        job_id = enqueue('webhook', job_payload)
        logger.info(f"Enqueued webhook job {job_id} for webhook {webhook['id']}")
        triggered_count += 1
    
    logger.info(f"Triggered {triggered_count} webhooks for event: {event}")
    return triggered_count

def get_deliveries(event: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    """
    Get recent webhook deliveries, optionally filtered by event.
    
    Args:
        event: Filter by specific event type
        limit: Maximum number of deliveries to return
        
    Returns:
        List of delivery dictionaries with webhook info
    """
    logger.info(f"Getting webhook deliveries (event={event}, limit={limit})")
    
    with get_session() as session:
        query = session.query(WebhookDelivery)
        
        if event:
            query = query.filter(WebhookDelivery.event == event)
            
        deliveries = query.order_by(WebhookDelivery.created_at.desc()).limit(limit).all()
        
        result = []
        for delivery in deliveries:
            webhook = delivery.webhook
            result.append({
                'id': delivery.id,
                'webhook_id': delivery.webhook_id,
                'webhook_url': webhook.url if webhook else 'Unknown',
                'event': delivery.event,
                'status': delivery.status,
                'response_code': delivery.response_code,
                'response_ms': delivery.response_ms,
                'created_at': delivery.created_at,
                'payload_preview': delivery.payload_json[:100] + '...' if len(delivery.payload_json) > 100 else delivery.payload_json
            })
        
        logger.info(f"Found {len(result)} webhook deliveries")
        return result

# Log service initialization
logger.info("Webhook service initialized with functions: register, list_webhooks, disable, trigger, get_deliveries")
