"""
Organization Management Routes
Phase 24: Organization CRUD operations and membership management
Key responsibilities: Org creation, member management, org switching
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p24__server_models_orgs import Organization, Membership, OrgRole, add_user_to_org, remove_user_from_org, get_org_stats
    from p23__server_security_auth import require_role, Role, get_current_user_context
    from p24__server_services_scope import get_user_org_context, validate_org_access
    from p21__server_models_audit import log_audit_event, AuditKind
except ImportError:
    logger.warning("Org management modules not found - using mock implementations")
    def get_session():
        return None
    
    class Organization:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
            self.id = getattr(self, 'id', 1)
        
        def to_dict(self):
            return {"id": self.id, "name": getattr(self, 'name', 'Mock Org'), "active": True}
    
    class Membership:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
        
        def to_dict(self):
            return {"id": 1, "user_id": 1, "org_id": 1, "role_in_org": "member"}
    
    class OrgRole:
        OWNER = 'owner'
        MEMBER = 'member'
        @classmethod
        def all_roles(cls):
            return [cls.OWNER, cls.MEMBER]
    
    class Role:
        ADMIN = 'admin'
    
    def require_role(*roles):
        def wrapper(request):
            return type('MockUser', (), {'id': 1, 'email': 'mock@example.com'})()
        return wrapper
    
    def add_user_to_org(session, user_id, org_id, role):
        return Membership(user_id=user_id, org_id=org_id, role_in_org=role)
    
    def get_org_stats(session, org_id):
        return {"org_id": org_id, "members_count": 1, "leads_count": 5}
    
    def log_audit_event(session, kind, message, meta=None):
        logger.info(f"AUDIT: {kind} - {message}")

router = APIRouter(prefix="/orgs", tags=["organizations"])

# Pydantic models
class OrganizationCreateRequest(BaseModel):
    name: str
    
    class Config:
        schema_extra = {
            "example": {
                "name": "Acme Corporation"
            }
        }

class MembershipCreateRequest(BaseModel):
    user_id: int
    role_in_org: str = OrgRole.MEMBER
    
    class Config:
        schema_extra = {
            "example": {
                "user_id": 2,
                "role_in_org": "member"
            }
        }

class OrganizationResponse(BaseModel):
    id: int
    name: str
    active: bool
    created_at: str
    member_count: int

class MembershipResponse(BaseModel):
    id: int
    user_id: int
    org_id: int
    role_in_org: str

@router.post("/", response_model=OrganizationResponse)
async def create_organization(
    request: OrganizationCreateRequest,
    admin_user = Depends(require_role(Role.ADMIN))
) -> JSONResponse:
    """
    Create a new organization
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_org = Organization(
                id=2,
                name=request.name,
                active=True,
                created_at="2024-01-01T00:00:00",
                member_count=0
            )
            logger.info(f"Mock organization created: {request.name}")
            return JSONResponse(mock_org.to_dict())
        
        with session:
            # Check if org name already exists
            existing_org = session.query(Organization).filter(
                Organization.name == request.name
            ).first()
            
            if existing_org:
                raise HTTPException(status_code=409, detail="Organization name already exists")
            
            # Create organization
            org = Organization(
                name=request.name,
                active=True
            )
            
            session.add(org)
            session.commit()
            session.refresh(org)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.AUTH_LOGIN,  # Reusing existing kind
                f"Organization created: {org.name}",
                {
                    "org_id": org.id,
                    "org_name": org.name,
                    "created_by": admin_user.email if hasattr(admin_user, 'email') else 'admin'
                }
            )
            
            logger.info(f"Organization created: {org.name} (ID: {org.id})")
            
            response_data = org.to_dict()
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating organization: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create organization: {str(e)}")

@router.get("/", response_model=List[OrganizationResponse])
async def list_organizations(
    admin_user = Depends(require_role(Role.ADMIN))
) -> List[Dict[str, Any]]:
    """
    List all organizations
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            return [
                {
                    "id": 1,
                    "name": "Default Organization",
                    "active": True,
                    "created_at": "2024-01-01T00:00:00",
                    "member_count": 1
                },
                {
                    "id": 2,
                    "name": "Acme Corporation",
                    "active": True,
                    "created_at": "2024-01-01T01:00:00",
                    "member_count": 3
                }
            ]
        
        with session:
            orgs = session.query(Organization).order_by(Organization.created_at.desc()).all()
            
            result = []
            for org in orgs:
                org_data = org.to_dict()
                # Add actual member count
                org_data["member_count"] = org.get_member_count(session)
                result.append(org_data)
            
            logger.info(f"Listed {len(result)} organizations")
            return result
    
    except Exception as e:
        logger.error(f"Error listing organizations: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list organizations: {str(e)}")

@router.post("/{org_id}/members", response_model=MembershipResponse)
async def add_organization_member(
    org_id: int,
    request: MembershipCreateRequest,
    admin_user = Depends(require_role(Role.ADMIN))
) -> JSONResponse:
    """
    Add member to organization
    Admin access required (could be extended to allow org owners)
    """
    try:
        # Validate role
        if request.role_in_org not in OrgRole.all_roles():
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid role. Must be one of: {', '.join(OrgRole.all_roles())}"
            )
        
        session = get_session()
        if not session:
            # Mock response
            mock_membership = {
                "id": 1,
                "user_id": request.user_id,
                "org_id": org_id,
                "role_in_org": request.role_in_org
            }
            logger.info(f"Mock membership created: user {request.user_id} -> org {org_id}")
            return JSONResponse(mock_membership)
        
        with session:
            # Verify organization exists
            org = session.query(Organization).filter(Organization.id == org_id).first()
            if not org:
                raise HTTPException(status_code=404, detail="Organization not found")
            
            # Verify user exists (assuming we have access to User model)
            try:
                from p23__server_models_auth import User
                user = session.query(User).filter(User.id == request.user_id).first()
                if not user:
                    raise HTTPException(status_code=404, detail="User not found")
            except ImportError:
                # Can't verify user exists, proceed anyway
                logger.warning("Cannot verify user exists - User model not available")
            
            # Add membership
            membership = add_user_to_org(session, request.user_id, org_id, request.role_in_org)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.AUTH_LOGIN,  # Reusing existing kind
                f"User {request.user_id} added to organization {org.name}",
                {
                    "user_id": request.user_id,
                    "org_id": org_id,
                    "org_name": org.name,
                    "role_in_org": request.role_in_org,
                    "added_by": admin_user.email if hasattr(admin_user, 'email') else 'admin'
                }
            )
            
            logger.info(f"User {request.user_id} added to org {org_id} as {request.role_in_org}")
            
            response_data = membership.to_dict()
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding member to org {org_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to add member: {str(e)}")

@router.get("/{org_id}/members", response_model=List[MembershipResponse])
async def list_organization_members(
    org_id: int,
    request: Request,
    admin_user = Depends(require_role(Role.ADMIN))  # Could allow org owners too
) -> List[Dict[str, Any]]:
    """
    List organization members
    Admin access required (could be extended to allow org members)
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            return [
                {
                    "id": 1,
                    "user_id": 1,
                    "org_id": org_id,
                    "role_in_org": "owner",
                    "user_email": "owner@example.com",
                    "user_name": "Organization Owner"
                },
                {
                    "id": 2,
                    "user_id": 2,
                    "org_id": org_id,
                    "role_in_org": "member",
                    "user_email": "member@example.com",
                    "user_name": "Team Member"
                }
            ]
        
        with session:
            # Verify organization exists
            org = session.query(Organization).filter(Organization.id == org_id).first()
            if not org:
                raise HTTPException(status_code=404, detail="Organization not found")
            
            # Get memberships
            memberships = session.query(Membership).filter(
                Membership.org_id == org_id
            ).all()
            
            result = []
            for membership in memberships:
                member_data = membership.to_dict()
                
                # Add user details if available
                try:
                    from p23__server_models_auth import User
                    user = session.query(User).filter(User.id == membership.user_id).first()
                    if user:
                        member_data["user_email"] = user.email
                        member_data["user_name"] = user.name
                except ImportError:
                    # User model not available
                    member_data["user_email"] = f"user_{membership.user_id}@example.com"
                    member_data["user_name"] = f"User {membership.user_id}"
                
                result.append(member_data)
            
            logger.info(f"Listed {len(result)} members for org {org_id}")
            return result
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing members for org {org_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list members: {str(e)}")

@router.delete("/{org_id}/members/{user_id}")
async def remove_organization_member(
    org_id: int,
    user_id: int,
    admin_user = Depends(require_role(Role.ADMIN))
) -> JSONResponse:
    """
    Remove member from organization
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            logger.info(f"Mock removal: user {user_id} from org {org_id}")
            return JSONResponse({"message": f"User {user_id} removed from organization {org_id}"})
        
        with session:
            # Verify organization exists
            org = session.query(Organization).filter(Organization.id == org_id).first()
            if not org:
                raise HTTPException(status_code=404, detail="Organization not found")
            
            # Remove membership
            removed = remove_user_from_org(session, user_id, org_id)
            
            if not removed:
                raise HTTPException(status_code=404, detail="Membership not found")
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.AUTH_LOGOUT,  # Reusing existing kind for removal
                f"User {user_id} removed from organization {org.name}",
                {
                    "user_id": user_id,
                    "org_id": org_id,
                    "org_name": org.name,
                    "removed_by": admin_user.email if hasattr(admin_user, 'email') else 'admin'
                }
            )
            
            logger.info(f"User {user_id} removed from org {org_id}")
            
            return JSONResponse({"message": f"User {user_id} removed from organization {org.name}"})
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error removing user {user_id} from org {org_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to remove member: {str(e)}")

@router.get("/{org_id}/stats")
async def get_organization_stats(
    org_id: int,
    admin_user = Depends(require_role(Role.ADMIN))
) -> Dict[str, Any]:
    """
    Get organization statistics
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            return {
                "org_id": org_id,
                "name": f"Organization {org_id}",
                "members_count": 2,
                "leads_count": 15,
                "buyers_count": 8,
                "sites_count": 5,
                "deployments_count": 12
            }
        
        with session:
            # Verify organization exists
            org = session.query(Organization).filter(Organization.id == org_id).first()
            if not org:
                raise HTTPException(status_code=404, detail="Organization not found")
            
            # Get stats
            stats = get_org_stats(session, org_id)
            stats["name"] = org.name
            stats["active"] = org.active
            
            logger.info(f"Retrieved stats for org {org_id}")
            return stats
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting stats for org {org_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get organization stats: {str(e)}")

@router.get("/me")
async def get_my_organizations(
    request: Request
) -> Dict[str, Any]:
    """
    Get current user's organizations
    Requires authentication
    """
    try:
        # Import here to avoid circular dependency
        from p23__server_security_auth import optional_user_from_key
        
        user = optional_user_from_key(request)
        if not user:
            raise HTTPException(status_code=401, detail="Authentication required")
        
        org_context = get_user_org_context(request)
        
        logger.debug(f"Retrieved org context for user {user.id if hasattr(user, 'id') else 'unknown'}")
        
        return {
            "current_org_id": org_context.get("current_org_id"),
            "available_orgs": org_context.get("available_orgs", []),
            "can_switch_orgs": org_context.get("can_switch_orgs", False),
            "is_admin_override": org_context.get("is_admin_override", False)
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user organizations: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get organizations: {str(e)}")

@router.post("/switch/{org_id}")
async def switch_organization(
    org_id: int,
    request: Request
) -> JSONResponse:
    """
    Switch to different organization context
    User must have access to target organization
    """
    try:
        from p23__server_security_auth import optional_user_from_key
        from p24__server_services_scope import switch_org_context
        
        user = optional_user_from_key(request)
        if not user:
            raise HTTPException(status_code=401, detail="Authentication required")
        
        # Validate access to target org
        if not validate_org_access(request, org_id):
            raise HTTPException(status_code=403, detail=f"Access denied to organization {org_id}")
        
        # Perform switch
        result = switch_org_context(request, org_id)
        
        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error", "Failed to switch organization"))
        
        logger.info(f"User {user.id if hasattr(user, 'id') else 'unknown'} switched to org {org_id}")
        
        return JSONResponse(result)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error switching to org {org_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to switch organization: {str(e)}")

@router.get("/roles")
async def list_organization_roles() -> Dict[str, Any]:
    """
    List available organization roles
    Public endpoint for reference
    """
    return {
        "roles": [
            {
                "name": OrgRole.OWNER,
                "description": "Full control over organization settings and members"
            },
            {
                "name": OrgRole.MEMBER,
                "description": "Standard access to organization data"
            }
        ]
    }

@router.patch("/{org_id}")
async def update_organization(
    org_id: int,
    request: Dict[str, Any],
    admin_user = Depends(require_role(Role.ADMIN))
) -> JSONResponse:
    """
    Update organization details
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_org = {
                "id": org_id,
                "name": request.get("name", f"Updated Org {org_id}"),
                "active": request.get("active", True),
                "updated": True
            }
            return JSONResponse(mock_org)
        
        with session:
            org = session.query(Organization).filter(Organization.id == org_id).first()
            if not org:
                raise HTTPException(status_code=404, detail="Organization not found")
            
            # Update fields
            changes = []
            if "name" in request:
                old_name = org.name
                org.name = request["name"]
                changes.append(f"name: {old_name} -> {request['name']}")
            
            if "active" in request:
                old_active = org.active
                org.active = request["active"]
                changes.append(f"active: {old_active} -> {request['active']}")
            
            session.commit()
            session.refresh(org)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.AUTH_LOGIN,  # Reusing existing kind
                f"Organization updated: {org.name}",
                {
                    "org_id": org_id,
                    "changes": changes,
                    "updated_by": admin_user.email if hasattr(admin_user, 'email') else 'admin'
                }
            )
            
            logger.info(f"Organization {org_id} updated: {'; '.join(changes)}")
            
            response_data = org.to_dict()
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating organization {org_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update organization: {str(e)}")

                