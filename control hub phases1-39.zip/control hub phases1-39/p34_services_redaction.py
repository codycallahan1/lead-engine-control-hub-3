"""
Lead Engine Control Hub - PII Redaction Service
Phase 34: Consent flags and PII redaction utilities
Purpose: Mask sensitive data based on compliance policies
"""

import re
import logging
from typing import Any, Dict, Optional, Union

# Import compliance models and settings
try:
    from p34__server_models_compliance import ComplianceSetting
    from p02__server_db import get_session
except ImportError:
    # Fallback for development
    class ComplianceSetting:
        def __init__(self):
            self.mask_email = False
            self.mask_phone = False
            self.export_mask = False
    
    def get_session():
        pass

logger = logging.getLogger(__name__)


def redact_email(email: str, pattern: str = "partial") -> str:
    """
    Redact email address based on specified pattern.
    
    Args:
        email: Email address to redact
        pattern: Redaction pattern ("partial", "domain", "full")
    
    Returns:
        Redacted email string
    """
    if not email or "@" not in email:
        return email
    
    try:
        local, domain = email.split("@", 1)
        
        if pattern == "full":
            return "***@***.***"
        elif pattern == "domain":
            # Keep first char of local part, mask domain
            return f"{local[0]}***@***.***" if local else "***@***.***"
        else:  # partial (default)
            # Keep first and last char of local, first char of domain
            if len(local) <= 2:
                masked_local = local[0] + "*" if local else "*"
            else:
                masked_local = local[0] + "*" * (len(local) - 2) + local[-1]
            
            domain_parts = domain.split(".")
            if domain_parts:
                masked_domain = domain_parts[0][0] + "***" if domain_parts[0] else "***"
                if len(domain_parts) > 1:
                    masked_domain += "." + domain_parts[-1]
                else:
                    masked_domain += ".***"
            else:
                masked_domain = "***"
            
            return f"{masked_local}@{masked_domain}"
            
    except Exception as e:
        logger.warning(f"Failed to redact email {email}: {str(e)}")
        return "***@***.***"


def redact_phone(phone: str, pattern: str = "partial") -> str:
    """
    Redact phone number based on specified pattern.
    
    Args:
        phone: Phone number to redact
        pattern: Redaction pattern ("partial", "last4", "full")
    
    Returns:
        Redacted phone string
    """
    if not phone:
        return phone
    
    # Clean phone number (remove non-digits for processing)
    digits_only = re.sub(r'\D', '', phone)
    
    if not digits_only:
        return phone
    
    try:
        if pattern == "full":
            return "***-***-****"
        elif pattern == "last4":
            # Show only last 4 digits
            if len(digits_only) >= 4:
                return "***-***-" + digits_only[-4:]
            else:
                return "***-" + digits_only
        else:  # partial (default)
            # Show first 3 and last 4 digits for US numbers
            if len(digits_only) >= 10:
                return f"{digits_only[:3]}-***-{digits_only[-4:]}"
            elif len(digits_only) >= 7:
                return f"***-{digits_only[-4:]}"
            elif len(digits_only) >= 4:
                return f"***-{digits_only[-4:]}"
            else:
                return "***-" + digits_only
                
    except Exception as e:
        logger.warning(f"Failed to redact phone {phone}: {str(e)}")
        return "***-***-****"


def redact_name(name: str, pattern: str = "partial") -> str:
    """
    Redact name based on specified pattern.
    
    Args:
        name: Name to redact
        pattern: Redaction pattern ("partial", "first_only", "full")
    
    Returns:
        Redacted name string
    """
    if not name:
        return name
    
    try:
        if pattern == "full":
            return "*** ***"
        elif pattern == "first_only":
            # Keep only first name
            parts = name.split()
            if parts:
                return parts[0] + " ***"
            return "***"
        else:  # partial (default)
            # Keep first char of each name part
            parts = name.split()
            redacted_parts = []
            for part in parts:
                if len(part) > 1:
                    redacted_parts.append(part[0] + "*" * (len(part) - 1))
                else:
                    redacted_parts.append(part)
            return " ".join(redacted_parts)
            
    except Exception as e:
        logger.warning(f"Failed to redact name {name}: {str(e)}")
        return "***"


def get_compliance_policy(org_id: int) -> ComplianceSetting:
    """
    Get compliance settings for an organization.
    
    Args:
        org_id: Organization identifier
    
    Returns:
        ComplianceSetting instance with current policy
    """
    try:
        with get_session() as session:
            policy = session.query(ComplianceSetting).filter_by(org_id=org_id).first()
            
            if policy:
                return policy
            
            # Return default policy if none exists
            default = ComplianceSetting()
            default.org_id = org_id
            default.mask_email = False
            default.mask_phone = False
            default.export_mask = False
            default.log_pii_access = True
            default.require_consent = False
            
            return default
            
    except Exception as e:
        logger.error(f"Failed to get compliance policy for org {org_id}: {str(e)}")
        # Return safe default
        default = ComplianceSetting()
        default.mask_email = True  # Safe default
        default.mask_phone = True
        default.export_mask = True
        return default


def apply_redaction_policy(data: Dict[str, Any], org_id: int, 
                          context: str = "display") -> Dict[str, Any]:
    """
    Apply organization's redaction policy to data.
    
    Args:
        data: Dictionary containing potentially sensitive data
        org_id: Organization identifier
        context: Context for redaction ("display", "export", "log")
    
    Returns:
        Dictionary with redacted data according to policy
    """
    if not isinstance(data, dict):
        return data
    
    policy = get_compliance_policy(org_id)
    redacted_data = data.copy()
    
    try:
        # Determine if redaction should be applied based on context
        should_redact_email = False
        should_redact_phone = False
        
        if context == "export":
            should_redact_email = policy.export_mask
            should_redact_phone = policy.export_mask
        elif context in ["display", "log"]:
            should_redact_email = policy.mask_email
            should_redact_phone = policy.mask_phone
        
        # Apply email redaction
        if should_redact_email:
            for key in ["email", "email_address", "contact_email"]:
                if key in redacted_data and redacted_data[key]:
                    redacted_data[key] = redact_email(str(redacted_data[key]))
        
        # Apply phone redaction
        if should_redact_phone:
            for key in ["phone", "phone_number", "contact_phone", "mobile"]:
                if key in redacted_data and redacted_data[key]:
                    redacted_data[key] = redact_phone(str(redacted_data[key]))
        
        # Apply name redaction (conservative - only for exports if explicitly enabled)
        if context == "export" and policy.export_mask:
            for key in ["name", "full_name", "contact_name"]:
                if key in redacted_data and redacted_data[key]:
                    redacted_data[key] = redact_name(str(redacted_data[key]))
        
        logger.debug(f"Applied redaction policy for org {org_id} in context {context}")
        
    except Exception as e:
        logger.error(f"Error applying redaction policy: {str(e)}")
        # On error, return original data but log the issue
        return data
    
    return redacted_data


def apply_list_redaction(data_list: list, org_id: int, context: str = "display") -> list:
    """
    Apply redaction policy to a list of data items.
    
    Args:
        data_list: List of dictionaries to redact
        org_id: Organization identifier
        context: Redaction context
    
    Returns:
        List with redacted data
    """
    if not isinstance(data_list, list):
        return data_list
    
    return [
        apply_redaction_policy(item, org_id, context) 
        if isinstance(item, dict) else item
        for item in data_list
    ]


def create_redaction_preview(sample_data: Dict[str, Any], org_id: int) -> Dict[str, Any]:
    """
    Create a preview showing how data would look with current redaction settings.
    
    Args:
        sample_data: Sample data to demonstrate redaction
        org_id: Organization identifier
    
    Returns:
        Dictionary showing original vs redacted versions
    """
    policy = get_compliance_policy(org_id)
    
    preview = {
        "policy": {
            "mask_email": policy.mask_email,
            "mask_phone": policy.mask_phone,
            "export_mask": policy.export_mask
        },
        "examples": {}
    }
    
    # Create examples for different contexts
    contexts = ["display", "export"]
    
    for context in contexts:
        preview["examples"][context] = {
            "original": sample_data.copy(),
            "redacted": apply_redaction_policy(sample_data, org_id, context)
        }
    
    return preview


def validate_redaction_settings(settings: Dict[str, Any]) -> Dict[str, str]:
    """
    Validate redaction settings before applying.
    
    Args:
        settings: Dictionary of settings to validate
    
    Returns:
        Dictionary of validation errors (empty if valid)
    """
    errors = {}
    
    # Check boolean fields
    boolean_fields = ["mask_email", "mask_phone", "export_mask", "log_pii_access", "require_consent"]
    for field in boolean_fields:
        if field in settings and not isinstance(settings[field], bool):
            errors[field] = f"{field} must be a boolean value"
    
    # Check retention days
    if "retention_days" in settings:
        if settings["retention_days"] is not None:
            try:
                days = int(settings["retention_days"])
                if days < 1 or days > 3650:  # 1 day to 10 years
                    errors["retention_days"] = "Retention days must be between 1 and 3650"
            except (ValueError, TypeError):
                errors["retention_days"] = "Retention days must be a valid number"
    
    return errors


# Utility functions for testing redaction
def test_redaction_patterns():
    """
    Test redaction patterns with sample data.
    Used for development and testing.
    """
    test_data = {
        "emails": [
            "john.doe@example.com",
            "alice@domain.co.uk", 
            "bob@x.org",
            "longusername@verylongdomain.com"
        ],
        "phones": [
            "555-123-4567",
            "(555) 123-4567",
            "15551234567",
            "555.123.4567"
        ],
        "names": [
            "John Doe",
            "Alice Smith-Johnson", 
            "Bob",
            "Mary Jane Watson"
        ]
    }
    
    print("=== Email Redaction Tests ===")
    for email in test_data["emails"]:
        print(f"Original: {email}")
        print(f"Partial:  {redact_email(email, 'partial')}")
        print(f"Domain:   {redact_email(email, 'domain')}")
        print(f"Full:     {redact_email(email, 'full')}")
        print()
    
    print("=== Phone Redaction Tests ===")
    for phone in test_data["phones"]:
        print(f"Original: {phone}")
        print(f"Partial:  {redact_phone(phone, 'partial')}")
        print(f"Last4:    {redact_phone(phone, 'last4')}")
        print(f"Full:     {redact_phone(phone, 'full')}")
        print()
    
    print("=== Name Redaction Tests ===")
    for name in test_data["names"]:
        print(f"Original:    {name}")
        print(f"Partial:     {redact_name(name, 'partial')}")
        print(f"First Only:  {redact_name(name, 'first_only')}")
        print(f"Full:        {redact_name(name, 'full')}")
        print()


if __name__ == "__main__":
    # Run tests when executed directly
    test_redaction_patterns()
