"""
Lead-to-Buyer matching service with rule evaluation and scoring.

Phase: 28
Purpose: Core matching logic for routing leads to buyers based on configurable rules.
Key responsibilities:
- Score leads against active matching rules
- Select best buyer based on deterministic tie-breaking
- Record match decisions in audit log
"""

import logging
from typing import List, Tuple, Optional, Dict, Any
from datetime import datetime

try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer
    from p28__server_models_matching import MatchingRule, MatchLog, create_matching_tables
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Matching service: missing dependency {e}")

logger = logging.getLogger(__name__)


def score_lead(lead, org_id: int) -> List[Tuple[MatchingRule, float]]:
    """
    Score a lead against all active matching rules for an organization.
    
    Args:
        lead: Lead object or dict with name, email, phone
        org_id: Organization ID for rule scoping
    
    Returns:
        List of (rule, score) tuples, sorted by score descending
    """
    try:
        with get_session() as db:
            # Get active rules for this org
            rules = db.query(MatchingRule).filter(
                MatchingRule.org_id == org_id,
                MatchingRule.active == True
            ).all()
            
            if not rules:
                logger.info(f"No active matching rules found for org {org_id}")
                return []
            
            # Score each rule
            scored_rules = []
            for rule in rules:
                try:
                    score = rule.evaluate_lead(lead)
                    if score > 0:
                        scored_rules.append((rule, score))
                        logger.debug(f"Rule {rule.id} '{rule.name}' scored {score} for lead")
                except Exception as e:
                    logger.error(f"Error evaluating rule {rule.id}: {e}")
            
            # Sort by score descending, then by weight descending, then by priority ascending
            scored_rules.sort(key=lambda x: (x[1], x[0].weight, -x[0].priority), reverse=True)
            
            logger.info(f"Scored {len(scored_rules)} matching rules for org {org_id}")
            return scored_rules
    
    except Exception as e:
        logger.error(f"Error scoring lead: {e}")
        return []


def pick_best(scored_rules: List[Tuple[MatchingRule, float]]) -> Optional[Tuple[MatchingRule, float]]:
    """
    Pick the best rule from scored results using deterministic tie-breaking.
    
    Args:
        scored_rules: List of (rule, score) tuples from score_lead()
    
    Returns:
        Best (rule, score) tuple or None if no matches
    """
    if not scored_rules:
        return None
    
    # Already sorted by score_lead(), so first item is best
    best_rule, best_score = scored_rules[0]
    
    logger.info(f"Selected rule {best_rule.id} '{best_rule.name}' with score {best_score}")
    return (best_rule, best_score)


def match_and_record(lead_id: int, org_id: int) -> Optional[MatchLog]:
    """
    Execute full matching workflow and record the result.
    
    Args:
        lead_id: ID of lead to match
        org_id: Organization ID for scoping
    
    Returns:
        MatchLog record or None if lead not found
    """
    try:
        with get_session() as db:
            # Get the lead
            lead = db.query(Lead).filter(
                Lead.id == lead_id,
                Lead.org_id == org_id
            ).first()
            
            if not lead:
                logger.warning(f"Lead {lead_id} not found in org {org_id}")
                return None
            
            # Ensure matching tables exist
            create_matching_tables()
            
            # Score the lead
            scored_rules = score_lead(lead, org_id)
            
            # Pick best match
            best_match = pick_best(scored_rules)
            
            # Create match log
            if best_match:
                rule, score = best_match
                
                # Verify buyer exists
                buyer = db.query(Buyer).filter(
                    Buyer.id == rule.buyer_id,
                    Buyer.org_id == org_id
                ).first()
                
                if not buyer:
                    logger.error(f"Buyer {rule.buyer_id} not found for rule {rule.id}")
                    match_log = MatchLog(
                        org_id=org_id,
                        lead_id=lead_id,
                        buyer_id=None,
                        rule_id=rule.id,
                        score=score,
                        status="failed",
                        metadata={"error": "buyer_not_found", "rule_name": rule.name}
                    )
                else:
                    match_log = MatchLog(
                        org_id=org_id,
                        lead_id=lead_id,
                        buyer_id=rule.buyer_id,
                        rule_id=rule.id,
                        score=score,
                        status="matched",
                        metadata={
                            "rule_name": rule.name,
                            "buyer_name": buyer.name,
                            "conditions_summary": rule.get_summary()
                        }
                    )
            else:
                # No matching rules
                match_log = MatchLog(
                    org_id=org_id,
                    lead_id=lead_id,
                    buyer_id=None,
                    rule_id=None,
                    score=0.0,
                    status="no_match",
                    metadata={"total_rules_evaluated": len(scored_rules)}
                )
            
            db.add(match_log)
            db.commit()
            
            # Audit the match decision
            audit(
                kind="lead_matched",
                message=f"Lead {lead_id} matched: {match_log.get_status_display()}",
                meta={
                    "lead_id": lead_id,
                    "buyer_id": match_log.buyer_id,
                    "rule_id": match_log.rule_id,
                    "score": match_log.score,
                    "status": match_log.status,
                    "org_id": org_id
                }
            )
            
            logger.info(f"Match recorded: {match_log}")
            return match_log
    
    except Exception as e:
        logger.error(f"Error in match_and_record for lead {lead_id}: {e}")
        
        # Try to create error log
        try:
            with get_session() as db:
                error_log = MatchLog(
                    org_id=org_id,
                    lead_id=lead_id,
                    buyer_id=None,
                    rule_id=None,
                    score=0.0,
                    status="failed",
                    metadata={"error": str(e)}
                )
                db.add(error_log)
                db.commit()
                return error_log
        except:
            pass
        
        return None


def preview_match(lead_data: Dict[str, Any], org_id: int) -> Dict[str, Any]:
    """
    Preview matching results for a lead without saving to database.
    
    Args:
        lead_data: Dict with 'name', 'email', 'phone' keys
        org_id: Organization ID for rule scoping
    
    Returns:
        Dict with scoring results and recommendation
    """
    # Create temporary lead-like object
    class TempLead:
        def __init__(self, data):
            self.name = data.get('name', '')
            self.email = data.get('email', '')
            self.phone = data.get('phone', '')
    
    temp_lead = TempLead(lead_data)
    
    try:
        # Score against rules
        scored_rules = score_lead(temp_lead, org_id)
        
        # Get buyer names for display
        rule_details = []
        buyer_names = {}
        
        if scored_rules:
            with get_session() as db:
                buyer_ids = [rule.buyer_id for rule, _ in scored_rules]
                buyers = db.query(Buyer).filter(
                    Buyer.id.in_(buyer_ids),
                    Buyer.org_id == org_id
                ).all()
                buyer_names = {b.id: b.name for b in buyers}
        
        for rule, score in scored_rules:
            rule_details.append({
                "rule_id": rule.id,
                "rule_name": rule.name,
                "buyer_id": rule.buyer_id,
                "buyer_name": buyer_names.get(rule.buyer_id, f"Unknown Buyer {rule.buyer_id}"),
                "score": score,
                "weight": rule.weight,
                "priority": rule.priority,
                "conditions_summary": rule.get_summary()
            })
        
        # Pick best match
        best_match = pick_best(scored_rules)
        
        recommendation = None
        if best_match:
            rule, score = best_match
            recommendation = {
                "rule_id": rule.id,
                "rule_name": rule.name,
                "buyer_id": rule.buyer_id,
                "buyer_name": buyer_names.get(rule.buyer_id, f"Unknown Buyer {rule.buyer_id}"),
                "score": score,
                "confidence": "high" if score >= 2.0 else "medium" if score >= 1.0 else "low"
            }
        
        return {
            "lead_data": lead_data,
            "total_rules_evaluated": len(rule_details),
            "matching_rules": rule_details,
            "recommendation": recommendation,
            "preview_time": datetime.utcnow().isoformat()
        }
    
    except Exception as e:
        logger.error(f"Error previewing match: {e}")
        return {
            "lead_data": lead_data,
            "error": str(e),
            "total_rules_evaluated": 0,
            "matching_rules": [],
            "recommendation": None
        }


def get_match_history(lead_id: Optional[int] = None, buyer_id: Optional[int] = None, 
                     org_id: int = 1, limit: int = 50) -> List[MatchLog]:
    """
    Get match history with optional filtering.
    
    Args:
        lead_id: Filter by specific lead
        buyer_id: Filter by specific buyer
        org_id: Organization ID for scoping
        limit: Maximum number of records to return
    
    Returns:
        List of MatchLog records
    """
    try:
        with get_session() as db:
            query = db.query(MatchLog).filter(MatchLog.org_id == org_id)
            
            if lead_id:
                query = query.filter(MatchLog.lead_id == lead_id)
            
            if buyer_id:
                query = query.filter(MatchLog.buyer_id == buyer_id)
            
            matches = query.order_by(MatchLog.created_at.desc()).limit(limit).all()
            
            logger.info(f"Retrieved {len(matches)} match records")
            return matches
    
    except Exception as e:
        logger.error(f"Error getting match history: {e}")
        return []


def validate_rule_conditions(conditions: Dict[str, Any]) -> List[str]:
    """
    Validate rule conditions format.
    
    Args:
        conditions: Conditions dictionary to validate
    
    Returns:
        List of validation error messages (empty if valid)
    """
    errors = []
    
    if not isinstance(conditions, dict):
        errors.append("Conditions must be a dictionary")
        return errors
    
    valid_keys = {"email_domain", "phone_prefix", "name_contains"}
    for key in conditions.keys():
        if key not in valid_keys:
            errors.append(f"Unknown condition type: {key}")
    
    for key, value in conditions.items():
        if not isinstance(value, list):
            errors.append(f"Condition '{key}' must be a list")
        elif not value:
            errors.append(f"Condition '{key}' cannot be empty")
        elif not all(isinstance(item, str) for item in value):
            errors.append(f"All items in condition '{key}' must be strings")
    
    return errors
