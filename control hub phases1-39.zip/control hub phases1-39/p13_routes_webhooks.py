"""
Webhook management routes with admin authentication.

Phase: 13
Purpose: REST endpoints for webhook CRUD operations and delivery logs
Key responsibilities: webhook registration, listing, management, delivery history
"""

import logging
from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Request, HTTPException, Header, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, HttpUrl

# Import attempt with graceful fallback
try:
    from p13__server_services_webhooks import register, list_webhooks, disable, get_deliveries
except ImportError as e:
    logging.warning(f"Import issue in webhook routes: {e}")
    # Fallback for development
    def register(url, event, active=True):
        return 1
    def list_webhooks(event=None, active_only=False):
        return []
    def disable(webhook_id):
        return True
    def get_deliveries(event=None, limit=50):
        return []

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/webhooks", tags=["webhooks"])

# Template setup - would be wired from main app
templates = Jinja2Templates(directory=".")

# Pydantic models for request/response
class WebhookCreate(BaseModel):
    url: str
    event: str
    active: bool = True

class WebhookUpdate(BaseModel):
    active: Optional[bool] = None
    url: Optional[str] = None

def verify_admin_token(admin_token: Optional[str] = Header(None)):
    """
    Simple admin token verification.
    
    In production, this should be a proper JWT or API key system.
    """
    if admin_token != "change-me":
        raise HTTPException(status_code=401, detail="Invalid or missing Admin-Token header")
    return True

@router.post("", response_model=Dict[str, Any], dependencies=[verify_admin_token])
async def create_webhook(webhook: WebhookCreate):
    """
    Register a new webhook endpoint.
    
    Requires Admin-Token header for authorization.
    """
    logger.info(f"Creating webhook: {webhook.url} for event: {webhook.event}")
    
    try:
        webhook_id = register(webhook.url, webhook.event, webhook.active)
        
        result = {
            "id": webhook_id,
            "url": webhook.url,
            "event": webhook.event,
            "active": webhook.active,
            "message": "Webhook created successfully"
        }
        
        logger.info(f"Webhook created with ID: {webhook_id}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to create webhook: {e}")
        raise HTTPException(status_code=500, detail="Failed to create webhook")

@router.get("", response_model=List[Dict[str, Any]])
async def list_webhooks_endpoint(
    event: Optional[str] = Query(None, description="Filter by event type"),
    active_only: bool = Query(False, description="Only return active webhooks")
):
    """
    List registered webhooks.
    
    Optionally filter by event type or active status.
    """
    logger.info(f"Listing webhooks (event={event}, active_only={active_only})")
    
    try:
        webhooks = list_webhooks(event=event, active_only=active_only)
        logger.info(f"Returned {len(webhooks)} webhooks")
        return webhooks
        
    except Exception as e:
        logger.error(f"Failed to list webhooks: {e}")
        raise HTTPException(status_code=500, detail="Failed to list webhooks")

@router.patch("/{webhook_id}", response_model=Dict[str, Any], dependencies=[verify_admin_token])
async def update_webhook(webhook_id: int, update: WebhookUpdate):
    """
    Update webhook settings.
    
    Currently supports updating active status and URL.
    Requires Admin-Token header for authorization.
    """
    logger.info(f"Updating webhook {webhook_id}: {update.dict(exclude_unset=True)}")
    
    if update.active is False:
        success = disable(webhook_id)
        if not success:
            raise HTTPException(status_code=404, detail="Webhook not found")
            
        return {
            "id": webhook_id,
            "message": "Webhook updated successfully",
            "changes": update.dict(exclude_unset=True)
        }
    
    # For other updates, we'd need additional service methods
    # For now, just handle the disable case
    return {
        "id": webhook_id,
        "message": "Update not implemented for this field combination"
    }

@router.get("/deliveries", response_model=List[Dict[str, Any]])
async def list_webhook_deliveries(
    event: Optional[str] = Query(None, description="Filter by event type"),
    limit: int = Query(50, ge=1, le=200, description="Maximum number of deliveries")
):
    """
    List recent webhook deliveries with status and timing info.
    """
    logger.info(f"Listing webhook deliveries (event={event}, limit={limit})")
    
    try:
        deliveries = get_deliveries(event=event, limit=limit)
        logger.info(f"Returned {len(deliveries)} webhook deliveries")
        return deliveries
        
    except Exception as e:
        logger.error(f"Failed to list webhook deliveries: {e}")
        raise HTTPException(status_code=500, detail="Failed to list webhook deliveries")

@router.get("-page", response_class=HTMLResponse)
async def webhooks_page(request: Request):
    """
    Server-side rendered webhooks management page.
    """
    logger.info("GET /webhooks-page - HTML page requested")
    
    try:
        # Get webhooks and recent deliveries
        webhooks = list_webhooks()
        recent_deliveries = get_deliveries(limit=20)
        
        # Calculate some stats
        active_count = len([w for w in webhooks if w['active']])
        total_deliveries = len(recent_deliveries)
        success_deliveries = len([d for d in recent_deliveries if d['status'] == 'success'])
        
        context = {
            "request": request,
            "webhooks": webhooks,
            "recent_deliveries": recent_deliveries,
            "stats": {
                "total_webhooks": len(webhooks),
                "active_webhooks": active_count,
                "total_deliveries": total_deliveries,
                "success_rate": round(success_deliveries / max(total_deliveries, 1) * 100, 1)
            }
        }
        
        try:
            return templates.TemplateResponse("p13__server-templates-webhooks.html", context)
        except Exception as e:
            logger.error(f"Template error: {e}")
            return f"<html><body><h1>Webhooks</h1><p>{len(webhooks)} webhooks, {len(recent_deliveries)} recent deliveries</p></body></html>"
            
    except Exception as e:
        logger.error(f"Failed to load webhooks page: {e}")
        raise HTTPException(status_code=500, detail="Failed to load webhooks page")

# Log router initialization
logger.info("Webhook routes initialized: POST /, GET /, PATCH /{id}, GET /deliveries, GET /-page")
