"""
Lead-buyer matching routes with admin authentication.

Phase: 14
Purpose: REST endpoints for testing and executing lead-buyer matches
Key responsibilities: match testing, sale assignment, admin-only access
"""

import logging
from typing import Dict, Any, Optional
from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel

# Import attempt with graceful fallback
try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer
    from p14__server_services_matching import match_lead, create_sale, get_sale_preview
    from p07__server_services_queue import enqueue
except ImportError as e:
    logging.warning(f"Import issue in matching routes: {e}")
    # Fallback for development
    def get_session():
        return None
    class Lead:
        pass
    class Buyer:
        pass
    def match_lead(lead):
        return None
    def create_sale(lead, buyer, price):
        return {"id": 1}
    def get_sale_preview(lead_id):
        return None
    def enqueue(kind, payload):
        return "mock-job-id"

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/matching", tags=["matching"])

def verify_admin_token(admin_token: Optional[str] = Header(None)):
    """
    Simple admin token verification.
    
    In production, this should be a proper JWT or API key system.
    """
    if admin_token != "change-me":
        raise HTTPException(status_code=401, detail="Invalid or missing Admin-Token header")
    return True

class MatchResponse(BaseModel):
    success: bool
    lead_id: int
    buyer_id: Optional[int] = None
    buyer_name: Optional[str] = None
    price_cents: Optional[int] = None
    price_dollars: Optional[float] = None
    message: str

class AssignResponse(BaseModel):
    success: bool
    lead_id: int
    sale_id: Optional[int] = None
    buyer_id: Optional[int] = None
    job_id: Optional[str] = None
    message: str

@router.post("/test/{lead_id}", response_model=MatchResponse, dependencies=[verify_admin_token])
async def test_lead_match(lead_id: int):
    """
    Preview which buyer would be matched to a lead without creating a sale.
    
    Requires Admin-Token header for authorization.
    This is useful for testing matching rules before committing to sales.
    """
    logger.info(f"Testing match for lead {lead_id}")
    
    with get_session() as session:
        # Verify lead exists
        lead = session.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            logger.warning(f"Lead {lead_id} not found")
            raise HTTPException(status_code=404, detail=f"Lead {lead_id} not found")
        
        # Get match preview
        preview = get_sale_preview(lead_id)
        
        if preview:
            logger.info(f"Lead {lead_id} would match buyer {preview['buyer_id']}")
            return MatchResponse(
                success=True,
                lead_id=lead_id,
                buyer_id=preview['buyer_id'],
                buyer_name=preview['buyer_name'],
                price_cents=preview['price_cents'],
                price_dollars=preview['price_dollars'],
                message=f"Lead would be matched to buyer {preview['buyer_name']} for ${preview['price_dollars']:.2f}"
            )
        else:
            logger.info(f"No match found for lead {lead_id}")
            return MatchResponse(
                success=False,
                lead_id=lead_id,
                message="No matching buyer found for this lead"
            )

@router.post("/assign/{lead_id}", response_model=AssignResponse, dependencies=[verify_admin_token])
async def assign_lead_to_buyer(lead_id: int):
    """
    Create a sale by assigning a lead to the best matching buyer.
    
    Requires Admin-Token header for authorization.
    This creates the sale record and enqueues a delivery job.
    """
    logger.info(f"Assigning lead {lead_id} to buyer")
    
    with get_session() as session:
        # Verify lead exists
        lead = session.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            logger.warning(f"Lead {lead_id} not found")
            raise HTTPException(status_code=404, detail=f"Lead {lead_id} not found")
        
        # Find matching buyer
        match_result = match_lead(lead)
        
        if not match_result:
            logger.info(f"No match found for lead {lead_id}")
            return AssignResponse(
                success=False,
                lead_id=lead_id,
                message="No matching buyer found for this lead"
            )
        
        buyer, price_cents = match_result
        
        try:
            # Create the sale
            sale = create_sale(lead, buyer, price_cents)
            
            # Enqueue delivery job
            job_payload = {
                'sale_id': sale.id,
                'lead_id': lead.id,
                'buyer_id': buyer.id,
                'price_cents': price_cents
            }
            
            job_id = enqueue('deliver_sale', job_payload)
            
            logger.info(f"Lead {lead_id} assigned to buyer {buyer.id}, sale {sale.id}, job {job_id}")
            
            return AssignResponse(
                success=True,
                lead_id=lead_id,
                sale_id=sale.id,
                buyer_id=buyer.id,
                job_id=job_id,
                message=f"Lead assigned to buyer {buyer.name} for ${price_cents/100:.2f}. Delivery job queued."
            )
            
        except Exception as e:
            logger.error(f"Failed to create sale for lead {lead_id}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to create sale: {str(e)}")

@router.get("/sales", response_model=Dict[str, Any])
async def list_sales(
    limit: int = 50,
    status: Optional[str] = None
):
    """
    List recent sales with buyer and lead information.
    
    Optionally filter by status (created, delivered, refunded).
    """
    logger.info(f"Listing sales (limit={limit}, status={status})")
    
    try:
        from p14__server_models_sales import LeadSale
        
        with get_session() as session:
            query = session.query(LeadSale)
            
            if status:
                query = query.filter(LeadSale.status == status)
            
            sales = query.order_by(LeadSale.created_at.desc()).limit(limit).all()
            
            # Build response with additional details
            sales_data = []
            for sale in sales:
                # Try to get lead and buyer details
                lead = session.query(Lead).filter(Lead.id == sale.lead_id).first()
                buyer = session.query(Buyer).filter(Buyer.id == sale.buyer_id).first()
                
                sale_data = {
                    'id': sale.id,
                    'lead_id': sale.lead_id,
                    'buyer_id': sale.buyer_id,
                    'price_cents': sale.price_cents,
                    'price_dollars': sale.price_dollars,
                    'status': sale.status,
                    'created_at': sale.created_at,
                    'lead_email': lead.email if lead else 'Unknown',
                    'lead_name': lead.name if lead else 'Unknown',
                    'buyer_name': buyer.name if buyer else 'Unknown',
                    'buyer_email': buyer.email if buyer else 'Unknown'
                }
                sales_data.append(sale_data)
            
            logger.info(f"Returned {len(sales_data)} sales")
            
            return {
                'sales': sales_data,
                'count': len(sales_data),
                'filter_status': status
            }
            
    except Exception as e:
        logger.error(f"Failed to list sales: {e}")
        raise HTTPException(status_code=500, detail="Failed to list sales")

# Log router initialization
logger.info("Matching routes initialized: POST /test/{id}, POST /assign/{id}, GET /sales")