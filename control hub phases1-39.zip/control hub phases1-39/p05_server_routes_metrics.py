"""
Lead Engine Control Hub - Metrics Routes
Phase: 5
Purpose: Metrics and analytics endpoints for dashboard and monitoring
Key Responsibilities:
- Provide summary metrics for leads, buyers, and sites
- Database statistics and health monitoring
- Dashboard data aggregation
- Performance metrics collection
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, Any

from fastapi import APIRouter, HTTPException

# Import services and database
try:
    from p03__server_services_leads import LeadService
    from p03__server_services_buyers import BuyerService
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer, Site
except ImportError as e:
    logging.warning(f"Import error in metrics routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 and 3 files are available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/metrics", tags=["metrics"])

# =============================================================================
# SUMMARY METRICS ENDPOINTS
# =============================================================================

@router.get("/summary")
async def get_metrics_summary():
    """
    Get comprehensive metrics summary including counts of all entities.
    
    Returns:
        JSON object with entity counts and timestamp
    """
    try:
        logger.info("GET /metrics/summary - fetching comprehensive metrics")
        
        # Get counts for all entities
        leads_count = LeadService.get_leads_count()
        buyers_count = BuyerService.get_buyers_count()
        
        # Get sites count directly (since we don't have a SiteService yet)
        sites_count = 0
        try:
            with get_session() as db:
                sites_count = db.query(Site).count()
        except Exception as e:
            logger.warning(f"Could not get sites count: {e}")
            sites_count = 0
        
        logger.info(f"Metrics summary - Leads: {leads_count}, Buyers: {buyers_count}, Sites: {sites_count}")
        
        return {
            "counts": {
                "leads": leads_count,
                "buyers": buyers_count,
                "sites": sites_count
            },
            "timestamp": datetime.utcnow().isoformat(),
            "status": "success"
        }
        
    except Exception as e:
        logger.error(f"Failed to fetch metrics summary: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch metrics summary")

@router.get("/dashboard")
async def get_dashboard_metrics():
    """
    Get metrics specifically formatted for dashboard display.
    
    Returns:
        JSON object with formatted metrics for dashboard
    """
    try:
        logger.info("GET /metrics/dashboard - fetching dashboard metrics")
        
        # Get basic counts
        leads_count = LeadService.get_leads_count()
        buyers_count = BuyerService.get_buyers_count()
        
        # Get sites count
        sites_count = 0
        try:
            with get_session() as db:
                sites_count = db.query(Site).count()
        except Exception as e:
            logger.warning(f"Could not get sites count: {e}")
        
        # Calculate recent activity (last 7 days)
        recent_leads = 0
        try:
            with get_session() as db:
                seven_days_ago = datetime.utcnow() - timedelta(days=7)
                recent_leads = db.query(Lead).filter(Lead.created_at >= seven_days_ago).count()
        except Exception as e:
            logger.warning(f"Could not get recent leads count: {e}")
        
        # Calculate recent buyers (last 7 days)
        recent_buyers = 0
        try:
            with get_session() as db:
                seven_days_ago = datetime.utcnow() - timedelta(days=7)
                recent_buyers = db.query(Buyer).filter(Buyer.created_at >= seven_days_ago).count()
        except Exception as e:
            logger.warning(f"Could not get recent buyers count: {e}")
        
        dashboard_data = {
            "totals": {
                "leads": leads_count,
                "buyers": buyers_count,
                "sites": sites_count
            },
            "recent_activity": {
                "leads_this_week": recent_leads,
                "buyers_this_week": recent_buyers
            },
            "ratios": {
                "buyers_per_100_leads": round((buyers_count / max(leads_count, 1)) * 100, 1)
            },
            "timestamp": datetime.utcnow().isoformat(),
            "period": "last_7_days"
        }
        
        logger.info(f"Dashboard metrics prepared: {dashboard_data['totals']}")
        return dashboard_data
        
    except Exception as e:
        logger.error(f"Failed to fetch dashboard metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch dashboard metrics")

# =============================================================================
# DETAILED METRICS ENDPOINTS
# =============================================================================

@router.get("/leads")
async def get_lead_metrics():
    """
    Get detailed metrics about leads.
    
    Returns:
        JSON object with lead-specific metrics
    """
    try:
        logger.info("GET /metrics/leads - fetching lead metrics")
        
        with get_session() as db:
            total_leads = db.query(Lead).count()
            
            # Leads with phone numbers
            leads_with_phone = db.query(Lead).filter(Lead.phone.isnot(None), Lead.phone != '').count()
            
            # Recent leads (last 30 days)
            thirty_days_ago = datetime.utcnow() - timedelta(days=30)
            recent_leads = db.query(Lead).filter(Lead.created_at >= thirty_days_ago).count()
            
            # Leads by day (last 7 days)
            daily_counts = {}
            for i in range(7):
                day_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=i)
                day_end = day_start + timedelta(days=1)
                day_count = db.query(Lead).filter(
                    Lead.created_at >= day_start,
                    Lead.created_at < day_end
                ).count()
                daily_counts[day_start.strftime("%Y-%m-%d")] = day_count
        
        return {
            "total_leads": total_leads,
            "leads_with_phone": leads_with_phone,
            "leads_without_phone": total_leads - leads_with_phone,
            "recent_leads_30_days": recent_leads,
            "phone_completion_rate": round((leads_with_phone / max(total_leads, 1)) * 100, 1),
            "daily_counts_last_7_days": daily_counts,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to fetch lead metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch lead metrics")

@router.get("/buyers")
async def get_buyer_metrics():
    """
    Get detailed metrics about buyers.
    
    Returns:
        JSON object with buyer-specific metrics
    """
    try:
        logger.info("GET /metrics/buyers - fetching buyer metrics")
        
        with get_session() as db:
            total_buyers = db.query(Buyer).count()
            
            # Recent buyers (last 30 days)
            thirty_days_ago = datetime.utcnow() - timedelta(days=30)
            recent_buyers = db.query(Buyer).filter(Buyer.created_at >= thirty_days_ago).count()
            
            # Buyers by day (last 7 days)
            daily_counts = {}
            for i in range(7):
                day_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=i)
                day_end = day_start + timedelta(days=1)
                day_count = db.query(Buyer).filter(
                    Buyer.created_at >= day_start,
                    Buyer.created_at < day_end
                ).count()
                daily_counts[day_start.strftime("%Y-%m-%d")] = day_count
        
        return {
            "total_buyers": total_buyers,
            "recent_buyers_30_days": recent_buyers,
            "daily_counts_last_7_days": daily_counts,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to fetch buyer metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch buyer metrics")

@router.get("/sites")
async def get_site_metrics():
    """
    Get detailed metrics about sites.
    
    Returns:
        JSON object with site-specific metrics
    """
    try:
        logger.info("GET /metrics/sites - fetching site metrics")
        
        with get_session() as db:
            total_sites = db.query(Site).count()
            
            # Sites by status
            active_sites = db.query(Site).filter(Site.status == 'active').count()
            inactive_sites = db.query(Site).filter(Site.status == 'inactive').count()
            other_sites = total_sites - active_sites - inactive_sites
        
        return {
            "total_sites": total_sites,
            "active_sites": active_sites,
            "inactive_sites": inactive_sites,
            "other_status_sites": other_sites,
            "active_percentage": round((active_sites / max(total_sites, 1)) * 100, 1),
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to fetch site metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch site metrics")

# =============================================================================
# SYSTEM METRICS ENDPOINTS
# =============================================================================

@router.get("/system")
async def get_system_metrics():
    """
    Get system-level metrics and health information.
    
    Returns:
        JSON object with system metrics
    """
    try:
        logger.info("GET /metrics/system - fetching system metrics")
        
        # Database health check
        db_healthy = True
        db_error = None
        try:
            with get_session() as db:
                db.execute("SELECT 1").fetchone()
        except Exception as e:
            db_healthy = False
            db_error = str(e)
        
        # Get database file size
        db_size = 0
        try:
            from pathlib import Path
            db_file = Path("./controlhub.db")
            if db_file.exists():
                db_size = db_file.stat().st_size
        except Exception as e:
            logger.warning(f"Could not get database size: {e}")
        
        return {
            "database": {
                "healthy": db_healthy,
                "error": db_error,
                "size_bytes": db_size,
                "size_mb": round(db_size / (1024 * 1024), 2)
            },
            "application": {
                "phase": 5,
                "name": "Lead Engine Control Hub",
                "version": "1.0.0"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to fetch system metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch system metrics")

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Metrics Routes Module Test ===")
    logger.info("✅ Metrics routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET  /metrics/summary   - Overall counts summary")
    logger.info("  GET  /metrics/dashboard - Dashboard metrics")
    logger.info("  GET  /metrics/leads     - Detailed lead metrics")
    logger.info("  GET  /metrics/buyers    - Detailed buyer metrics")
    logger.info("  GET  /metrics/sites     - Detailed site metrics")
    logger.info("  GET  /metrics/system    - System health metrics")