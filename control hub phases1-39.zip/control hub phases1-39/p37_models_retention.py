"""
Lead Engine Control Hub - Data Retention Models
Phase 37: Data retention, archiving & soft delete
Purpose: Track retention policies and soft deletion status
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Text
from sqlalchemy.orm import relationship

# Import base from existing models (would be consolidated in final structure)
try:
    from p02__server_models import Base
except ImportError:
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()


class RetentionPolicy(Base):
    """
    Organization-level data retention policies.
    
    Defines how long different types of data should be kept
    before archiving and eventual deletion.
    """
    __tablename__ = "retention_policies"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, unique=True, index=True)
    
    # Retention periods in days
    leads_days = Column(Integer, nullable=True, default=365)  # 1 year default
    buyers_days = Column(Integer, nullable=True, default=1095)  # 3 years default
    logs_days = Column(Integer, nullable=True, default=90)  # 90 days default
    audit_days = Column(Integer, nullable=True, default=2555)  # 7 years for compliance
    
    # Archive settings
    archive_enabled = Column(Boolean, nullable=False, default=True)
    archive_path = Column(String(500), nullable=True)  # Custom archive location
    
    # Retention behavior
    hard_delete_after_days = Column(Integer, nullable=True)  # null = never hard delete
    require_manual_approval = Column(Boolean, nullable=False, default=False)
    
    # Status tracking
    last_sweep_at = Column(DateTime, nullable=True, index=True)
    next_sweep_at = Column(DateTime, nullable=True, index=True)
    
    # Audit fields
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = Column(String(100), nullable=True)
    
    # Relationships
    organization = relationship("Organization")
    sweep_logs = relationship("RetentionSweepLog", back_populates="policy", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<RetentionPolicy org_id={self.org_id} leads={self.leads_days}d logs={self.logs_days}d>"
    
    @property
    def is_sweep_due(self):
        """Check if a retention sweep is due."""
        if not self.next_sweep_at:
            return True
        return datetime.utcnow() >= self.next_sweep_at
    
    def to_dict(self):
        """Convert to dictionary for API responses."""
        return {
            "org_id": self.org_id,
            "leads_days": self.leads_days,
            "buyers_days": self.buyers_days,
            "logs_days": self.logs_days,
            "audit_days": self.audit_days,
            "archive_enabled": self.archive_enabled,
            "archive_path": self.archive_path,
            "hard_delete_after_days": self.hard_delete_after_days,
            "require_manual_approval": self.require_manual_approval,
            "last_sweep_at": self.last_sweep_at.isoformat() if self.last_sweep_at else None,
            "next_sweep_at": self.next_sweep_at.isoformat() if self.next_sweep_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by
        }


class RetentionSweepLog(Base):
    """
    Log of retention sweep operations.
    
    Records when sweeps are run, what data was processed,
    and results of archive/deletion operations.
    """
    __tablename__ = "retention_sweep_logs"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    policy_id = Column(Integer, ForeignKey("retention_policies.id"), nullable=False, index=True)
    
    # Sweep details
    sweep_type = Column(String(50), nullable=False, index=True)  # manual, scheduled, test
    target_before_date = Column(DateTime, nullable=False, index=True)
    
    # Results
    leads_processed = Column(Integer, nullable=False, default=0)
    buyers_processed = Column(Integer, nullable=False, default=0)
    logs_processed = Column(Integer, nullable=False, default=0)
    audit_records_processed = Column(Integer, nullable=False, default=0)
    
    # Archive results
    archive_files_created = Column(Integer, nullable=False, default=0)
    archive_size_bytes = Column(Integer, nullable=False, default=0)
    archive_paths = Column(Text, nullable=True)  # JSON list of created archive files
    
    # Status
    status = Column(String(20), nullable=False, default="running", index=True)  # running, completed, failed
    error_message = Column(Text, nullable=True)
    
    # Timing
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    completed_at = Column(DateTime, nullable=True, index=True)
    duration_seconds = Column(Integer, nullable=True)
    
    # Audit fields
    initiated_by = Column(String(100), nullable=True)
    
    # Relationships
    policy = relationship("RetentionPolicy", back_populates="sweep_logs")
    
    def __repr__(self):
        return f"<RetentionSweepLog org_id={self.org_id} type={self.sweep_type} status={self.status}>"
    
    @property
    def total_records_processed(self):
        """Total number of records processed in this sweep."""
        return (self.leads_processed + self.buyers_processed + 
                self.logs_processed + self.audit_records_processed)
    
    @property
    def archive_size_mb(self):
        """Archive size in megabytes."""
        return self.archive_size_bytes / (1024 * 1024) if self.archive_size_bytes else 0
    
    def to_dict(self):
        """Convert to dictionary for API responses."""
        return {
            "id": self.id,
            "org_id": self.org_id,
            "sweep_type": self.sweep_type,
            "target_before_date": self.target_before_date.isoformat(),
            "results": {
                "leads_processed": self.leads_processed,
                "buyers_processed": self.buyers_processed,
                "logs_processed": self.logs_processed,
                "audit_records_processed": self.audit_records_processed,
                "total_records": self.total_records_processed
            },
            "archive": {
                "files_created": self.archive_files_created,
                "size_bytes": self.archive_size_bytes,
                "size_mb": round(self.archive_size_mb, 2),
                "paths": self.archive_paths
            },
            "status": self.status,
            "error_message": self.error_message,
            "timing": {
                "started_at": self.started_at.isoformat(),
                "completed_at": self.completed_at.isoformat() if self.completed_at else None,
                "duration_seconds": self.duration_seconds
            },
            "initiated_by": self.initiated_by
        }


# Soft delete extension fields for existing models
class SoftDeleteMixin:
    """
    Mixin to add soft delete functionality to existing models.
    
    These fields would be added to Lead, Buyer, MatchLog, DispatchLog, etc.
    """
    
    # Soft delete fields
    deleted_at = Column(DateTime, nullable=True, index=True)
    deleted_by = Column(String(100), nullable=True)
    deletion_reason = Column(String(200), nullable=True)
    
    # Archive tracking
    archived_at = Column(DateTime, nullable=True, index=True)
    archive_path = Column(String(500), nullable=True)
    
    @property
    def is_deleted(self):
        """Check if record is soft deleted."""
        return self.deleted_at is not None
    
    @property
    def is_archived(self):
        """Check if record is archived."""
        return self.archived_at is not None
    
    def soft_delete(self, deleted_by: str = None, reason: str = None):
        """Mark record as soft deleted."""
        self.deleted_at = datetime.utcnow()
        self.deleted_by = deleted_by
        self.deletion_reason = reason
    
    def restore(self):
        """Restore soft deleted record."""
        self.deleted_at = None
        self.deleted_by = None
        self.deletion_reason = None


class ArchiveManifest(Base):
    """
    Manifest of archived data files.
    
    Tracks what data was archived where and when,
    allowing for data recovery if needed.
    """
    __tablename__ = "archive_manifests"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    sweep_log_id = Column(Integer, ForeignKey("retention_sweep_logs.id"), nullable=False, index=True)
    
    # File details
    file_path = Column(String(500), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    file_hash = Column(String(64), nullable=True)  # SHA-256 for integrity
    
    # Content details
    data_type = Column(String(50), nullable=False, index=True)  # leads, buyers, logs, audit
    record_count = Column(Integer, nullable=False)
    date_range_start = Column(DateTime, nullable=True)
    date_range_end = Column(DateTime, nullable=True)
    
    # Metadata
    compression_type = Column(String(20), nullable=True)  # gzip, none
    format_type = Column(String(20), nullable=False, default="jsonl")  # jsonl, csv
    
    # Status
    verified_at = Column(DateTime, nullable=True)
    verification_status = Column(String(20), nullable=True)  # verified, failed, pending
    
    # Audit fields
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    
    # Relationships
    sweep_log = relationship("RetentionSweepLog")
    
    def __repr__(self):
        return f"<ArchiveManifest {self.data_type} {self.file_name} ({self.record_count} records)>"
    
    @property
    def file_size_mb(self):
        """File size in megabytes."""
        return self.file_size_bytes / (1024 * 1024)
    
    def to_dict(self):
        """Convert to dictionary for API responses."""
        return {
            "id": self.id,
            "file_name": self.file_name,
            "file_size_bytes": self.file_size_bytes,
            "file_size_mb": round(self.file_size_mb, 2),
            "data_type": self.data_type,
            "record_count": self.record_count,
            "date_range": {
                "start": self.date_range_start.isoformat() if self.date_range_start else None,
                "end": self.date_range_end.isoformat() if self.date_range_end else None
            },
            "format": {
                "type": self.format_type,
                "compression": self.compression_type
            },
            "verification": {
                "status": self.verification_status,
                "verified_at": self.verified_at.isoformat() if self.verified_at else None
            },
            "created_at": self.created_at.isoformat()
        }


# Migration helpers for adding soft delete fields to existing models
def add_soft_delete_fields_to_existing_models():
    """
    Migration function to add soft delete fields to existing models.
    In a real application, this would be handled by Alembic or similar.
    """
    # This would add to existing models:
    # ALTER TABLE leads ADD COLUMN deleted_at DATETIME;
    # ALTER TABLE leads ADD COLUMN deleted_by VARCHAR(100);
    # ALTER TABLE leads ADD COLUMN deletion_reason VARCHAR(200);
    # ALTER TABLE leads ADD COLUMN archived_at DATETIME;
    # ALTER TABLE leads ADD COLUMN archive_path VARCHAR(500);
    
    # Similar for buyers, match_logs, dispatch_logs, etc.
    pass


# Indexes for performance
# CREATE INDEX idx_retention_policies_org ON retention_policies(org_id);
# CREATE INDEX idx_retention_policies_next_sweep ON retention_policies(next_sweep_at);
# CREATE INDEX idx_retention_sweep_logs_org_started ON retention_sweep_logs(org_id, started_at);
# CREATE INDEX idx_retention_sweep_logs_status ON retention_sweep_logs(status, started_at);
# CREATE INDEX idx_archive_manifests_org_type ON archive_manifests(org_id, data_type);
# CREATE INDEX idx_archive_manifests_created ON archive_manifests(created_at);

# Soft delete indexes for existing models:
# CREATE INDEX idx_leads_deleted_at ON leads(deleted_at);
# CREATE INDEX idx_leads_archived_at ON leads(archived_at);
# CREATE INDEX idx_buyers_deleted_at ON buyers(deleted_at);
# CREATE INDEX idx_buyers_archived_at ON buyers(archived_at);
