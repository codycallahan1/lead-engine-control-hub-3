"""
Authentication and User Management Routes
Phase 23: User CRUD, API key management, role assignment
Key responsibilities: User account management, API key generation, role-based operations
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p23__server_models_auth import User, ApiKey, UserRole, Role, assign_role_to_user, remove_role_from_user, get_user_by_email
    from p23__server_security_auth import hash_password, verify_password, validate_password, require_role, require_admin, optional_user_from_key, get_current_user_context
    from p21__server_models_audit import log_audit_event, AuditKind
except ImportError:
    logger.warning("Auth modules not found - using mock implementations")
    def get_session():
        return None
    
    class User:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
            self.id = getattr(self, 'id', 1)
        
        def to_dict(self, include_sensitive=False):
            return {"id": self.id, "email": getattr(self, 'email', 'mock@example.com'), 
                   "name": getattr(self, 'name', 'Mock User'), "roles": ["admin"]}
    
    class ApiKey:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
            self.id = 1
        
        def to_dict(self, include_key=False):
            return {"id": 1, "label": "mock key", "active": True}
        
        @classmethod
        def create_key(cls, user_id, label):
            key = cls()
            key._plain_key = "mock_api_key_123"
            return key
    
    class Role:
        ADMIN = 'admin'
        OPS = 'ops'
        VIEWER = 'viewer'
        @classmethod
        def all_roles(cls):
            return [cls.ADMIN, cls.OPS, cls.VIEWER]
    
    def hash_password(pw):
        return "mock_hash"
    
    def require_admin(request):
        return User(id=1, email="admin@example.com")
    
    def optional_user_from_key(request):
        return User(id=1) if request.headers.get("X-API-Key") else None
    
    def assign_role_to_user(session, user_id, role):
        pass
    
    def get_user_by_email(session, email):
        return User(email=email) if email == "test@example.com" else None
    
    def log_audit_event(session, kind, message, meta=None):
        logger.info(f"AUDIT: {kind} - {message}")

router = APIRouter(prefix="/auth", tags=["authentication"])

# Pydantic models
class UserCreateRequest(BaseModel):
    email: EmailStr
    name: str
    password: str
    roles: List[str] = []
    
    class Config:
        schema_extra = {
            "example": {
                "email": "ops@example.com",
                "name": "Operations User",
                "password": "secure123",
                "roles": ["ops"]
            }
        }

class UserUpdateRequest(BaseModel):
    name: Optional[str] = None
    active: Optional[bool] = None
    roles: Optional[List[str]] = None
    
    class Config:
        schema_extra = {
            "example": {
                "active": True,
                "roles": ["ops", "viewer"]
            }
        }

class ApiKeyCreateRequest(BaseModel):
    label: str
    
    class Config:
        schema_extra = {
            "example": {
                "label": "CLI Access Key"
            }
        }

class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    active: bool
    roles: List[str]
    created_at: str

class ApiKeyResponse(BaseModel):
    id: int
    user_id: int
    label: str
    active: bool
    created_at: str
    key_preview: str
    key: Optional[str] = None  # Only included on creation

@router.post("/users", response_model=UserResponse)
async def create_user(
    request: UserCreateRequest,
    admin_user: User = Depends(require_admin)
) -> JSONResponse:
    """
    Create a new user account
    Admin access required
    """
    try:
        # Validate password
        is_valid, error_msg = validate_password(request.password)
        if not is_valid:
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Validate roles
        invalid_roles = [role for role in request.roles if role not in Role.all_roles()]
        if invalid_roles:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid roles: {', '.join(invalid_roles)}. Valid roles: {', '.join(Role.all_roles())}"
            )
        
        session = get_session()
        if not session:
            # Mock response
            mock_user = User(
                id=1,
                email=request.email,
                name=request.name,
                active=True,
                roles=request.roles,
                created_at="2024-01-01T00:00:00"
            )
            logger.info(f"Mock user created: {request.email}")
            return JSONResponse(mock_user.to_dict())
        
        with session:
            # Check if user already exists
            existing_user = get_user_by_email(session, request.email)
            if existing_user:
                raise HTTPException(status_code=409, detail="User with this email already exists")
            
            # Create user
            user = User(
                email=request.email.lower(),
                name=request.name,
                password_hash=hash_password(request.password),
                active=True
            )
            
            session.add(user)
            session.flush()  # Get user ID
            
            # Assign roles
            for role in request.roles:
                assign_role_to_user(session, user.id, role)
            
            session.commit()
            session.refresh(user)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.AUTH_LOGIN,  # Reusing existing kind
                f"User created: {user.email}",
                {
                    "user_id": user.id,
                    "email": user.email,
                    "roles": request.roles,
                    "created_by": admin_user.email if hasattr(admin_user, 'email') else 'admin'
                }
            )
            
            logger.info(f"User created: {user.email} with roles: {request.roles}")
            
            response_data = user.to_dict(include_sensitive=True)
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create user: {str(e)}")

@router.get("/users", response_model=List[UserResponse])
async def list_users(
    admin_user: User = Depends(require_admin)
) -> List[Dict[str, Any]]:
    """
    List all users
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            return [
                {
                    "id": 1,
                    "email": "admin@example.com",
                    "name": "Admin User",
                    "active": True,
                    "roles": ["admin"],
                    "created_at": "2024-01-01T00:00:00"
                },
                {
                    "id": 2,
                    "email": "ops@example.com",
                    "name": "Operations User",
                    "active": True,
                    "roles": ["ops"],
                    "created_at": "2024-01-01T01:00:00"
                }
            ]
        
        with session:
            users = session.query(User).order_by(User.created_at.desc()).all()
            
            result = [user.to_dict(include_sensitive=True) for user in users]
            
            logger.info(f"Listed {len(result)} users")
            return result
    
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list users: {str(e)}")

@router.patch("/users/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: int,
    request: UserUpdateRequest,
    admin_user: User = Depends(require_admin)
) -> JSONResponse:
    """
    Update user account
    Admin access required
    """
    try:
        # Validate roles if provided
        if request.roles:
            invalid_roles = [role for role in request.roles if role not in Role.all_roles()]
            if invalid_roles:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Invalid roles: {', '.join(invalid_roles)}"
                )
        
        session = get_session()
        if not session:
            # Mock response
            mock_user = {
                "id": user_id,
                "email": "updated@example.com",
                "name": request.name or "Updated User",
                "active": request.active if request.active is not None else True,
                "roles": request.roles or ["viewer"],
                "created_at": "2024-01-01T00:00:00"
            }
            return JSONResponse(mock_user)
        
        with session:
            user = session.query(User).filter(User.id == user_id).first()
            if not user:
                raise HTTPException(status_code=404, detail="User not found")
            
            # Update fields
            changes = []
            if request.name is not None:
                old_name = user.name
                user.name = request.name
                changes.append(f"name: {old_name} -> {request.name}")
            
            if request.active is not None:
                old_active = user.active
                user.active = request.active
                changes.append(f"active: {old_active} -> {request.active}")
            
            # Update roles
            if request.roles is not None:
                # Remove existing roles
                session.query(UserRole).filter(UserRole.user_id == user_id).delete()
                
                # Add new roles
                for role in request.roles:
                    assign_role_to_user(session, user_id, role)
                
                changes.append(f"roles updated to: {', '.join(request.roles)}")
            
            session.commit()
            session.refresh(user)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.AUTH_LOGIN,  # Reusing existing kind
                f"User updated: {user.email}",
                {
                    "user_id": user.id,
                    "email": user.email,
                    "changes": changes,
                    "updated_by": admin_user.email if hasattr(admin_user, 'email') else 'admin'
                }
            )
            
            logger.info(f"User {user.email} updated: {'; '.join(changes)}")
            
            response_data = user.to_dict(include_sensitive=True)
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user {user_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update user: {str(e)}")

@router.post("/users/{user_id}/apikeys", response_model=ApiKeyResponse)
async def create_api_key(
    user_id: int,
    request: ApiKeyCreateRequest,
    current_user: User = Depends(require_admin)  # Admin or self access
) -> JSONResponse:
    """
    Create API key for user
    Admin access required (could be extended to allow self-service)
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_key = {
                "id": 1,
                "user_id": user_id,
                "label": request.label,
                "active": True,
                "created_at": "2024-01-01T00:00:00",
                "key_preview": "mock_key...",
                "key": "mock_api_key_123456789"
            }
            logger.info(f"Mock API key created for user {user_id}")
            return JSONResponse(mock_key)
        
        with session:
            # Verify user exists
            user = session.query(User).filter(User.id == user_id).first()
            if not user:
                raise HTTPException(status_code=404, detail="User not found")
            
            # Check if label already exists for this user
            existing_key = session.query(ApiKey).filter(
                ApiKey.user_id == user_id,
                ApiKey.label == request.label
            ).first()
            
            if existing_key:
                raise HTTPException(status_code=409, detail="API key with this label already exists")
            
            # Create API key
            api_key = ApiKey.create_key(user_id, request.label)
            session.add(api_key)
            session.commit()
            session.refresh(api_key)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.TOKEN_CREATED,  # From phase 20
                f"API key created for user {user.email}",
                {
                    "user_id": user_id,
                    "user_email": user.email,
                    "key_id": api_key.id,
                    "key_label": request.label,
                    "created_by": current_user.email if hasattr(current_user, 'email') else 'admin'
                }
            )
            
            logger.info(f"API key '{request.label}' created for user {user.email}")
            
            # Return key data including plain key (only time it's shown)
            response_data = api_key.to_dict(include_key=True)
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating API key for user {user_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create API key: {str(e)}")

@router.get("/me")
async def get_current_user(
    request: Request
) -> Dict[str, Any]:
    """
    Get current user information
    Requires valid API key
    """
    try:
        user = optional_user_from_key(request)
        if not user:
            raise HTTPException(status_code=401, detail="Valid API key required (X-API-Key header)")
        
        user_context = get_current_user_context(request)
        
        logger.debug(f"Current user info requested: {user.email if hasattr(user, 'email') else 'unknown'}")
        
        return {
            "user": user.to_dict() if hasattr(user, 'to_dict') else {
                "id": getattr(user, 'id', None),
                "email": getattr(user, 'email', None),
                "name": getattr(user, 'name', None),
                "roles": user.get_roles() if hasattr(user, 'get_roles') else []
            },
            "context": user_context,
            "permissions": {
                "can_read": True,
                "can_write": any(role in ['admin', 'ops'] for role in user_context.get('roles', [])),
                "can_admin": 'admin' in user_context.get('roles', [])
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting current user: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get user information: {str(e)}")

@router.get("/roles")
async def list_roles() -> Dict[str, Any]:
    """
    List available roles and their descriptions
    Public endpoint for reference
    """
    return {
        "roles": [
            {
                "name": Role.ADMIN,
                "description": "Full system access including user management"
            },
            {
                "name": Role.OPS,
                "description": "Operational access to exports, deployments, and data management"
            },
            {
                "name": Role.VIEWER,
                "description": "Read-only access to data and metrics"
            }
        ]
    }

@router.get("/status")
async def get_auth_status(
    admin_user: User = Depends(require_admin)
) -> Dict[str, Any]:
    """
    Get authentication system status
    Admin access required
    """
    try:
        from p23__server_security_auth import get_auth_status
        status = get_auth_status()
        
        return {
            "authentication_system": status,
            "legacy_admin_token": "supported",
            "api_key_authentication": "active",
            "rbac_enabled": True
        }
    
    except Exception as e:
        logger.error(f"Error getting auth status: {e}")
        return {
            "authentication_system": {"status": "error", "error": str(e)},
            "legacy_admin_token": "supported",
            "api_key_authentication": "unknown",
            "rbac_enabled": True
        }
