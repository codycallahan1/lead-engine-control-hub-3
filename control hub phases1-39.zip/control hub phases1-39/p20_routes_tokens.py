"""
API Token Management Routes
Phase 20: CRUD operations for API tokens with role management
Key responsibilities: Create, list, update tokens; admin-only operations
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p20__server_models_api_tokens import ApiToken, TokenRole, validate_token_data
    from p20__server_middleware_auth import require_admin, get_current_user_info
except ImportError:
    logger.warning("Token management modules not found - using mock implementations")
    def get_session():
        return None
    
    class ApiToken:
        def __init__(self, **kwargs):
            self.id = 1
            self.name = kwargs.get('name', 'Mock Token')
            self.role = kwargs.get('role', 'admin')
            self.active = True
            self.token = 'mock_token_123'
        
        def to_dict(self, include_token=False):
            return {
                "id": self.id,
                "name": self.name,
                "role": self.role,
                "active": self.active,
                "token": self.token if include_token else None,
                "token_preview": "mock_tok..."
            }
        
        @classmethod
        def create_token(cls, name, role):
            return cls(name=name, role=role)
    
    class TokenRole:
        ADMIN = 'admin'
        VIEWER = 'viewer'
        @classmethod
        def all_roles(cls):
            return [cls.ADMIN, cls.VIEWER]
    
    def validate_token_data(name, role):
        return True, None
    
    def require_admin(request):
        return {"role": "admin", "valid": True}
    
    def get_current_user_info(request):
        return {"role": "admin", "valid": True}

router = APIRouter(prefix="/tokens", tags=["tokens"])

# Pydantic models for request/response
class TokenCreateRequest(BaseModel):
    name: str
    role: str
    
    class Config:
        schema_extra = {
            "example": {
                "name": "Operations Team Token",
                "role": "viewer"
            }
        }

class TokenUpdateRequest(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None
    active: Optional[bool] = None
    
    class Config:
        schema_extra = {
            "example": {
                "active": False
            }
        }

class TokenResponse(BaseModel):
    id: int
    name: str
    role: str
    active: bool
    token_preview: str
    created_at: str
    token: Optional[str] = None  # Only included on creation

@router.post("/", response_model=TokenResponse)
async def create_token(
    request: TokenCreateRequest,
    _: dict = Depends(require_admin)
) -> JSONResponse:
    """
    Create a new API token
    Admin access required
    """
    try:
        # Validate input
        is_valid, error_msg = validate_token_data(request.name.strip(), request.role)
        if not is_valid:
            raise HTTPException(status_code=400, detail=error_msg)
        
        session = get_session()
        if not session:
            # Mock response for testing
            mock_token = ApiToken.create_token(request.name, request.role)
            response_data = mock_token.to_dict(include_token=True)
            response_data["created_at"] = "2024-01-01T00:00:00"
            logger.info(f"Created mock token: {request.name} ({request.role})")
            return JSONResponse(response_data)
        
        with session:
            # Check for duplicate names
            existing = session.query(ApiToken).filter(
                ApiToken.name == request.name.strip()
            ).first()
            
            if existing:
                raise HTTPException(status_code=400, detail="Token name already exists")
            
            # Create new token
            api_token = ApiToken.create_token(request.name.strip(), request.role)
            session.add(api_token)
            session.commit()
            session.refresh(api_token)
            
            # Return token data including the actual token (only time it's shown)
            response_data = api_token.to_dict(include_token=True)
            
            logger.info(f"Created API token: {api_token.name} ({api_token.role})")
            
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating token: {e}")
        raise HTTPException(status_code=500, detail="Failed to create token")

@router.get("/", response_model=List[TokenResponse])
async def list_tokens(
    _: dict = Depends(require_admin)
) -> List[dict]:
    """
    List all API tokens
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_tokens = [
                {
                    "id": 1,
                    "name": "Mock Admin Token",
                    "role": "admin",
                    "active": True,
                    "token_preview": "mock_adm...",
                    "created_at": "2024-01-01T00:00:00"
                },
                {
                    "id": 2,
                    "name": "Mock Viewer Token",
                    "role": "viewer",
                    "active": True,
                    "token_preview": "mock_vie...",
                    "created_at": "2024-01-01T01:00:00"
                }
            ]
            logger.info("Returned mock token list")
            return mock_tokens
        
        with session:
            tokens = session.query(ApiToken).order_by(ApiToken.created_at.desc()).all()
            
            result = [token.to_dict(include_token=False) for token in tokens]
            
            logger.info(f"Listed {len(result)} API tokens")
            return result
    
    except Exception as e:
        logger.error(f"Error listing tokens: {e}")
        raise HTTPException(status_code=500, detail="Failed to list tokens")

@router.patch("/{token_id}", response_model=TokenResponse)
async def update_token(
    token_id: int,
    request: TokenUpdateRequest,
    _: dict = Depends(require_admin)
) -> JSONResponse:
    """
    Update an API token
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_token = {
                "id": token_id,
                "name": request.name or "Updated Mock Token",
                "role": request.role or "viewer",
                "active": request.active if request.active is not None else True,
                "token_preview": "mock_upd...",
                "created_at": "2024-01-01T00:00:00"
            }
            logger.info(f"Updated mock token: {token_id}")
            return JSONResponse(mock_token)
        
        with session:
            api_token = session.query(ApiToken).filter(ApiToken.id == token_id).first()
            
            if not api_token:
                raise HTTPException(status_code=404, detail="Token not found")
            
            # Update fields if provided
            if request.name is not None:
                # Validate name
                name = request.name.strip()
                if len(name) < 3:
                    raise HTTPException(status_code=400, detail="Name must be at least 3 characters")
                
                # Check for duplicate (excluding current token)
                existing = session.query(ApiToken).filter(
                    ApiToken.name == name,
                    ApiToken.id != token_id
                ).first()
                
                if existing:
                    raise HTTPException(status_code=400, detail="Token name already exists")
                
                api_token.name = name
            
            if request.role is not None:
                if request.role not in TokenRole.all_roles():
                    raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {', '.join(TokenRole.all_roles())}")
                api_token.role = request.role
            
            if request.active is not None:
                api_token.active = request.active
            
            session.commit()
            session.refresh(api_token)
            
            response_data = api_token.to_dict(include_token=False)
            
            logger.info(f"Updated API token: {api_token.name} (ID: {token_id})")
            
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating token {token_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to update token")

@router.delete("/{token_id}")
async def delete_token(
    token_id: int,
    _: dict = Depends(require_admin)
) -> JSONResponse:
    """
    Delete an API token
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            logger.info(f"Deleted mock token: {token_id}")
            return JSONResponse({"message": "Token deleted successfully"})
        
        with session:
            api_token = session.query(ApiToken).filter(ApiToken.id == token_id).first()
            
            if not api_token:
                raise HTTPException(status_code=404, detail="Token not found")
            
            token_name = api_token.name
            session.delete(api_token)
            session.commit()
            
            logger.info(f"Deleted API token: {token_name} (ID: {token_id})")
            
            return JSONResponse({"message": f"Token '{token_name}' deleted successfully"})
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting token {token_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete token")

@router.get("/roles")
async def list_roles(
    _: dict = Depends(require_admin)
) -> dict:
    """
    List available token roles
    Admin access required
    """
    return {
        "roles": TokenRole.all_roles(),
        "descriptions": {
            TokenRole.ADMIN: "Full access to all endpoints and operations",
            TokenRole.VIEWER: "Read-only access to data and metrics"
        }
    }

@router.get("/current")
async def get_current_token_info(
    request: Request
) -> dict:
    """
    Get information about the current token being used
    Available to any authenticated user
    """
    try:
        token_info = get_current_user_info(request)
        
        if not token_info.get('valid'):
            raise HTTPException(status_code=401, detail="No valid token found")
        
        # Return safe token information
        return {
            "token_name": token_info.get('token_name'),
            "role": token_info.get('role'),
            "source": token_info.get('source'),
            "permissions": {
                "can_read": True,
                "can_write": token_info.get('role') == TokenRole.ADMIN,
                "can_admin": token_info.get('role') == TokenRole.ADMIN
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting current token info: {e}")
        raise HTTPException(status_code=500, detail="Failed to get token information")
