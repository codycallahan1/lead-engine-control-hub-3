"""
Deployment Steps Database Model
Phase 22: Track individual deployment pipeline steps with detailed logging
Key responsibilities: Store step execution history, status tracking, retry information
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import json

# Import base from existing models or create if needed
try:
    from p02__server_db import Base
    from p06__server_models_deployments import Deployment
except ImportError:
    Base = declarative_base()
    
    class Deployment:
        """Mock Deployment class for reference"""
        pass

class DeploymentStep(Base):
    """
    Individual step within a deployment pipeline
    Tracks execution details, timing, and retry attempts
    """
    __tablename__ = "deployment_steps"
    
    id = Column(Integer, primary_key=True, index=True)
    deployment_id = Column(Integer, ForeignKey("deployments.id"), nullable=False, index=True)
    step = Column(String(50), nullable=False, index=True)  # Step type/name
    status = Column(String(20), nullable=False, index=True)  # pending, running, completed, failed, retrying
    detail_json = Column(Text)  # JSON with step parameters and results
    started_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    finished_at = Column(DateTime)  # Null until step completes/fails
    
    # Relationship to deployment (if model exists)
    try:
        deployment = relationship("Deployment", back_populates="steps")
    except:
        pass  # Relationship will be established when models are properly imported
    
    def __repr__(self):
        duration = ""
        if self.finished_at and self.started_at:
            delta = self.finished_at - self.started_at
            duration = f", duration={delta.total_seconds():.1f}s"
        
        return f"<DeploymentStep(deployment_id={self.deployment_id}, step='{self.step}', status='{self.status}'{duration})>"
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        result = {
            "id": self.id,
            "deployment_id": self.deployment_id,
            "step": self.step,
            "status": self.status,
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None
        }
        
        # Parse detail JSON
        if self.detail_json:
            try:
                result["details"] = json.loads(self.detail_json)
            except json.JSONDecodeError:
                result["details"] = {"raw": self.detail_json}
        else:
            result["details"] = {}
        
        # Calculate duration if both timestamps exist
        if self.started_at and self.finished_at:
            duration = (self.finished_at - self.started_at).total_seconds()
            result["duration_seconds"] = duration
        
        return result
    
    def get_details(self) -> dict:
        """Get parsed detail information"""
        if not self.detail_json:
            return {}
        
        try:
            return json.loads(self.detail_json)
        except json.JSONDecodeError:
            return {"raw": self.detail_json}
    
    def set_details(self, details: dict):
        """Set detail information as JSON"""
        try:
            self.detail_json = json.dumps(details)
        except (TypeError, ValueError):
            self.detail_json = json.dumps({"error": "Failed to serialize details"})
    
    def get_duration(self) -> float:
        """Get step duration in seconds"""
        if not self.started_at or not self.finished_at:
            return None
        
        return (self.finished_at - self.started_at).total_seconds()
    
    def is_completed(self) -> bool:
        """Check if step is completed (successfully or failed)"""
        return self.status in ["completed", "failed"]
    
    def is_successful(self) -> bool:
        """Check if step completed successfully"""
        return self.status == "completed"
    
    def get_attempt_count(self) -> int:
        """Get number of attempts from details"""
        details = self.get_details()
        return details.get("attempts", 1)
    
    def get_error_message(self) -> str:
        """Get error message if step failed"""
        if self.status != "failed":
            return None
        
        details = self.get_details()
        return details.get("error", "Unknown error")

# Step status constants
class StepStatus:
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"
    
    @classmethod
    def all_statuses(cls):
        return [cls.PENDING, cls.RUNNING, cls.COMPLETED, cls.FAILED, cls.RETRYING]
    
    @classmethod
    def is_terminal(cls, status: str) -> bool:
        """Check if status is terminal (won't change)"""
        return status in [cls.COMPLETED, cls.FAILED]
    
    @classmethod
    def is_active(cls, status: str) -> bool:
        """Check if status indicates active processing"""
        return status in [cls.RUNNING, cls.RETRYING]

# Step type constants
class StepType:
    PURCHASE_DOMAIN = "purchase_domain"
    CREATE_DNS = "create_dns"
    DEPLOY_HOSTING = "deploy_hosting"
    VALIDATE_DEPLOYMENT = "validate_deployment"
    CONFIGURE_SSL = "configure_ssl"
    SEND_NOTIFICATION = "send_notification"
    
    @classmethod
    def all_types(cls):
        return [
            cls.PURCHASE_DOMAIN,
            cls.CREATE_DNS,
            cls.DEPLOY_HOSTING,
            cls.VALIDATE_DEPLOYMENT,
            cls.CONFIGURE_SSL,
            cls.SEND_NOTIFICATION
        ]
    
    @classmethod
    def get_display_name(cls, step_type: str) -> str:
        """Get human-readable display name for step type"""
        display_names = {
            cls.PURCHASE_DOMAIN: "Purchase Domain",
            cls.CREATE_DNS: "Create DNS Records",
            cls.DEPLOY_HOSTING: "Deploy to Hosting",
            cls.VALIDATE_DEPLOYMENT: "Validate Deployment",
            cls.CONFIGURE_SSL: "Configure SSL Certificate",
            cls.SEND_NOTIFICATION: "Send Notification"
        }
        return display_names.get(step_type, step_type.replace("_", " ").title())

# Utility functions for step management
def create_step(deployment_id: int, step_type: str, details: dict = None) -> DeploymentStep:
    """
    Create a new deployment step
    
    Args:
        deployment_id: ID of parent deployment
        step_type: Type of step (use StepType constants)
        details: Optional step parameters/details
    
    Returns:
        New DeploymentStep instance
    """
    step = DeploymentStep(
        deployment_id=deployment_id,
        step=step_type,
        status=StepStatus.PENDING,
        started_at=datetime.utcnow()
    )
    
    if details:
        step.set_details(details)
    
    return step

def get_deployment_steps(session, deployment_id: int) -> list:
    """
    Get all steps for a deployment, ordered by start time
    
    Args:
        session: Database session
        deployment_id: ID of deployment
    
    Returns:
        List of DeploymentStep objects
    """
    return session.query(DeploymentStep)\
                 .filter(DeploymentStep.deployment_id == deployment_id)\
                 .order_by(DeploymentStep.started_at)\
                 .all()

def get_step_summary(session, deployment_id: int) -> dict:
    """
    Get summary statistics for deployment steps
    
    Args:
        session: Database session
        deployment_id: ID of deployment
    
    Returns:
        Dictionary with step summary
    """
    steps = get_deployment_steps(session, deployment_id)
    
    if not steps:
        return {
            "total_steps": 0,
            "completed_steps": 0,
            "failed_steps": 0,
            "pending_steps": 0,
            "total_duration": 0,
            "status": "no_steps"
        }
    
    total_steps = len(steps)
    completed_steps = sum(1 for step in steps if step.status == StepStatus.COMPLETED)
    failed_steps = sum(1 for step in steps if step.status == StepStatus.FAILED)
    pending_steps = sum(1 for step in steps if step.status in [StepStatus.PENDING, StepStatus.RUNNING, StepStatus.RETRYING])
    
    # Calculate total duration for completed steps
    total_duration = 0
    for step in steps:
        if step.get_duration():
            total_duration += step.get_duration()
    
    # Determine overall status
    if failed_steps > 0:
        overall_status = "failed"
    elif pending_steps > 0:
        overall_status = "in_progress"
    elif completed_steps == total_steps:
        overall_status = "completed"
    else:
        overall_status = "unknown"
    
    return {
        "total_steps": total_steps,
        "completed_steps": completed_steps,
        "failed_steps": failed_steps,
        "pending_steps": pending_steps,
        "total_duration": total_duration,
        "status": overall_status,
        "progress_percentage": (completed_steps / total_steps * 100) if total_steps > 0 else 0
    }

# Ensure table creation helper
def create_deployment_steps_table(engine):
    """Create deployment steps table if it doesn't exist"""
    try:
        DeploymentStep.__table__.create(engine, checkfirst=True)
        return True
    except Exception as e:
        print(f"Error creating deployment steps table: {e}")
        return False
