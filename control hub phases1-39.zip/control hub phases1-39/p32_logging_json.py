"""
Lead Engine Control Hub - JSON Logging Configuration
Phase 32: Observability infrastructure
Purpose: Structured JSON logging with request correlation
"""

import json
import logging
import os
from datetime import datetime
from typing import Any, Dict


class JsonLogFormatter(logging.Formatter):
    """
    Custom formatter that outputs logs in JSON format for better parsing.
    Falls back gracefully if JSON serialization fails.
    """
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON with standard fields."""
        
        # Base log entry
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "line": record.lineno,
        }
        
        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields from LogRecord
        extra_fields = {}
        
        # Standard extra fields we care about
        for field in ["request_id", "org_id", "user_id", "event", "duration_ms", 
                     "status_code", "method", "path", "error"]:
            if hasattr(record, field):
                extra_fields[field] = getattr(record, field)
        
        # Add any other extra fields that aren't standard LogRecord attributes
        for key, value in record.__dict__.items():
            if key not in ["name", "msg", "args", "levelname", "levelno", "pathname",
                          "filename", "module", "lineno", "funcName", "created", 
                          "msecs", "relativeCreated", "thread", "threadName",
                          "processName", "process", "getMessage", "exc_info", 
                          "exc_text", "stack_info"] and key not in extra_fields:
                extra_fields[key] = value
        
        if extra_fields:
            log_entry.update(extra_fields)
        
        # Serialize to JSON with fallback
        try:
            return json.dumps(log_entry, default=str, separators=(",", ":"))
        except (TypeError, ValueError) as e:
            # Fallback to simple format if JSON fails
            fallback = {
                "timestamp": log_entry["timestamp"],
                "level": log_entry["level"],
                "message": f"JSON_ENCODE_ERROR: {str(e)} | Original: {record.getMessage()}",
                "logger": record.name
            }
            return json.dumps(fallback, separators=(",", ":"))


class TextLogFormatter(logging.Formatter):
    """
    Traditional text formatter with request ID support.
    Used when JSON logging is disabled.
    """
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as human-readable text."""
        
        # Base format
        base_format = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        
        # Add request ID if present
        if hasattr(record, 'request_id'):
            base_format = f"%(asctime)s [%(levelname)s] [%(request_id)s] %(name)s: %(message)s"
        
        formatter = logging.Formatter(base_format)
        return formatter.format(record)


def setup_logging(log_format: str = None):
    """
    Configure application logging with JSON or text format.
    
    Args:
        log_format: 'json' or 'text'. If None, reads from LOG_FORMAT env var.
    """
    
    if log_format is None:
        log_format = os.getenv("LOG_FORMAT", "text").lower()
    
    # Determine formatter
    if log_format == "json":
        formatter = JsonLogFormatter()
    else:
        formatter = TextLogFormatter()
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    
    # Remove existing handlers to avoid duplicates
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # File handler if LOG_FILE env var is set
    log_file = os.getenv("LOG_FILE")
    if log_file:
        try:
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            root_logger.addHandler(file_handler)
        except (OSError, IOError) as e:
            logging.warning(f"Could not setup file logging to {log_file}: {e}")
    
    logging.info(f"Logging configured with format: {log_format}")


def get_logger_with_context(name: str, **context) -> logging.LoggerAdapter:
    """
    Get a logger adapter that automatically includes context in all log calls.
    
    Args:
        name: Logger name
        **context: Key-value pairs to include in all log calls
    
    Returns:
        LoggerAdapter with context
    """
    logger = logging.getLogger(name)
    return logging.LoggerAdapter(logger, context)


# Auto-setup logging on import if not in test environment
if not os.getenv("TESTING"):
    setup_logging()
