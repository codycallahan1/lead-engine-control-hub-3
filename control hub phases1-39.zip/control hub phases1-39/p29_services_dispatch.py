"""
Lead dispatch service for delivering leads to buyer webhooks.

Phase: 29
Purpose: Handle secure delivery of leads to buyer endpoints with retry logic.
Key responsibilities:
- Build signed webhook payloads
- Execute HTTP delivery with timeouts
- Handle retry logic with exponential backoff
"""

import logging
import json
import hmac
import hashlib
import time
from datetime import datetime
from typing import Dict, Any, Tuple, Optional
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from urllib.parse import urlparse

try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer
    from p29__server_models_webhooks import BuyerEndpoint, DispatchLog, create_webhook_tables
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Dispatch service: missing dependency {e}")

logger = logging.getLogger(__name__)


def build_payload(lead, buyer, matching_info: Optional[Dict] = None) -> Dict[str, Any]:
    """
    Build webhook payload for lead delivery.
    
    Args:
        lead: Lead object
        buyer: Buyer object
        matching_info: Optional dict with rule_id, rule_name, score
    
    Returns:
        Dict payload for webhook delivery
    """
    payload = {
        "event": "lead.matched",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "lead": {
            "id": lead.id,
            "name": lead.name,
            "email": lead.email,
            "phone": lead.phone,
            "created_at": lead.created_at.isoformat() + "Z" if lead.created_at else None
        },
        "buyer": {
            "id": buyer.id,
            "name": buyer.name
        },
        "organization": {
            "id": getattr(lead, 'org_id', 1)
        }
    }
    
    # Add matching information if provided
    if matching_info:
        payload["matching"] = matching_info
    
    # Add metadata
    payload["metadata"] = {
        "delivery_attempt": 1,
        "source": "lead_engine_control_hub",
        "version": "1.0"
    }
    
    return payload


def sign_payload(payload: Dict[str, Any], secret: str) -> str:
    """
    Create HMAC-SHA256 signature for payload.
    
    Args:
        payload: Payload dictionary
        secret: Webhook secret for signing
    
    Returns:
        Hex-encoded HMAC signature
    """
    # Create canonical JSON string (sorted keys, no spaces)
    canonical_json = json.dumps(payload, sort_keys=True, separators=(',', ':'))
    
    # Create HMAC signature
    signature = hmac.new(
        secret.encode('utf-8'),
        canonical_json.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return signature


def dispatch_once(endpoint: BuyerEndpoint, payload: Dict[str, Any]) -> Tuple[bool, Optional[str], Optional[int], Optional[float]]:
    """
    Perform single dispatch attempt to endpoint.
    
    Args:
        endpoint: BuyerEndpoint to deliver to
        payload: Payload dictionary
    
    Returns:
        Tuple of (success, error_message, response_code, response_time_ms)
    """
    start_time = time.time()
    
    try:
        # Validate URL
        parsed_url = urlparse(endpoint.url)
        if not parsed_url.scheme or not parsed_url.netloc:
            return False, "Invalid URL format", None, None
        
        if parsed_url.scheme not in ['http', 'https']:
            return False, "URL must use HTTP or HTTPS", None, None
        
        # Sign the payload
        signature = sign_payload(payload, endpoint.secret)
        
        # Prepare request
        json_data = json.dumps(payload).encode('utf-8')
        
        request = Request(
            endpoint.url,
            data=json_data,
            headers={
                'Content-Type': 'application/json',
                'X-Signature': signature,
                'User-Agent': 'LeadEngine/1.0',
                'X-Delivery-Attempt': str(payload.get('metadata', {}).get('delivery_attempt', 1))
            }
        )
        
        # Execute request with timeout
        with urlopen(request, timeout=endpoint.timeout_s) as response:
            response_code = response.getcode()
            response_time_ms = (time.time() - start_time) * 1000
            
            # Read response body (limited to 1KB for logging)
            response_body = response.read(1024).decode('utf-8', errors='ignore')
            
            # Consider 2xx responses as success
            success = 200 <= response_code < 300
            
            if success:
                logger.info(f"Dispatch success to {endpoint.url}: HTTP {response_code} in {response_time_ms:.1f}ms")
                return True, None, response_code, response_time_ms
            else:
                error_msg = f"HTTP {response_code}: {response_body[:200]}"
                logger.warning(f"Dispatch failed to {endpoint.url}: {error_msg}")
                return False, error_msg, response_code, response_time_ms
    
    except HTTPError as e:
        response_time_ms = (time.time() - start_time) * 1000
        error_msg = f"HTTP {e.code}: {e.reason}"
        logger.warning(f"Dispatch HTTP error to {endpoint.url}: {error_msg}")
        return False, error_msg, e.code, response_time_ms
    
    except URLError as e:
        response_time_ms = (time.time() - start_time) * 1000
        error_msg = f"Network error: {str(e.reason)}"
        logger.warning(f"Dispatch network error to {endpoint.url}: {error_msg}")
        return False, error_msg, None, response_time_ms
    
    except Exception as e:
        response_time_ms = (time.time() - start_time) * 1000
        error_msg = f"Dispatch error: {str(e)}"
        logger.error(f"Dispatch exception to {endpoint.url}: {error_msg}")
        return False, error_msg, None, response_time_ms


def dispatch_with_retries(lead_id: int, endpoint_id: int) -> DispatchLog:
    """
    Dispatch lead to endpoint with retry logic and logging.
    
    Args:
        lead_id: ID of lead to dispatch
        endpoint_id: ID of endpoint to deliver to
    
    Returns:
        DispatchLog record with final status
    """
    try:
        with get_session() as db:
            create_webhook_tables()
            
            # Get lead, buyer, and endpoint
            lead = db.query(Lead).filter(Lead.id == lead_id).first()
            if not lead:
                raise ValueError(f"Lead {lead_id} not found")
            
            endpoint = db.query(BuyerEndpoint).filter(
                BuyerEndpoint.id == endpoint_id,
                BuyerEndpoint.active == True
            ).first()
            if not endpoint:
                raise ValueError(f"Active endpoint {endpoint_id} not found")
            
            buyer = db.query(Buyer).filter(Buyer.id == endpoint.buyer_id).first()
            if not buyer:
                raise ValueError(f"Buyer {endpoint.buyer_id} not found")
            
            # Create initial dispatch log
            dispatch_log = DispatchLog(
                org_id=getattr(lead, 'org_id', 1),
                lead_id=lead_id,
                buyer_id=buyer.id,
                endpoint_id=endpoint_id,
                status="pending"
            )
            db.add(dispatch_log)
            db.commit()
            db.refresh(dispatch_log)
            
            # Get matching info if available
            matching_info = None
            try:
                from p28__server_models_matching import MatchLog
                recent_match = db.query(MatchLog).filter(
                    MatchLog.lead_id == lead_id,
                    MatchLog.buyer_id == buyer.id,
                    MatchLog.status == "matched"
                ).order_by(MatchLog.created_at.desc()).first()
                
                if recent_match:
                    matching_info = {
                        "rule_id": recent_match.rule_id,
                        "score": recent_match.score
                    }
                    if recent_match.metadata:
                        matching_info["rule_name"] = recent_match.metadata.get("rule_name")
            except ImportError:
                pass
            
            # Build payload
            payload = build_payload(lead, buyer, matching_info)
            
            # Retry loop
            max_attempts = min(endpoint.retry_max, 5)  # Cap at 5 attempts
            backoff_delay = 1  # Start with 1 second
            
            for attempt in range(1, max_attempts + 1):
                # Update payload with current attempt
                payload["metadata"]["delivery_attempt"] = attempt
                
                # Perform dispatch
                success, error, response_code, response_time_ms = dispatch_once(endpoint, payload)
                
                # Record attempt
                dispatch_log.add_attempt(response_code, error, response_time_ms)
                
                if success:
                    # Update endpoint last used time
                    endpoint.last_used_at = func.now()
                    break
                
                # Check if we should retry
                if attempt < max_attempts and dispatch_log.is_retryable():
                    logger.info(f"Retrying dispatch to {endpoint.url} in {backoff_delay}s (attempt {attempt + 1}/{max_attempts})")
                    time.sleep(backoff_delay)
                    backoff_delay *= 2  # Exponential backoff
                else:
                    break
            
            # Save final state
            db.commit()
            
            # Audit the dispatch
            audit(
                kind="lead_dispatched",
                message=f"Lead {lead_id} dispatch to {endpoint.name}: {dispatch_log.get_status_display()}",
                meta={
                    "lead_id": lead_id,
                    "buyer_id": buyer.id,
                    "endpoint_id": endpoint_id,
                    "status": dispatch_log.status,
                    "attempts": dispatch_log.attempts,
                    "response_code": dispatch_log.response_code,
                    "org_id": dispatch_log.org_id
                }
            )
            
            logger.info(f"Dispatch completed: {dispatch_log}")
            return dispatch_log
    
    except Exception as e:
        logger.error(f"Error in dispatch_with_retries: {e}")
        
        # Try to create error log
        try:
            with get_session() as db:
                error_log = DispatchLog(
                    org_id=1,  # Default org
                    lead_id=lead_id,
                    buyer_id=0,  # Unknown
                    endpoint_id=endpoint_id,
                    status="failed",
                    last_error=str(e)
                )
                error_log.add_attempt(error=str(e))
                db.add(error_log)
                db.commit()
                return error_log
        except:
            pass
        
        raise


def on_match_created(match_log_id: int) -> Optional[DispatchLog]:
    """
    Hook called when a new match is created to trigger dispatch.
    
    Args:
        match_log_id: ID of MatchLog that was created
    
    Returns:
        DispatchLog if dispatch was triggered, None otherwise
    """
    try:
        from p28__server_models_matching import MatchLog
        from p07__server_services_queue import enqueue
        
        with get_session() as db:
            match_log = db.query(MatchLog).filter(MatchLog.id == match_log_id).first()
            
            if not match_log or match_log.status != "matched":
                logger.debug(f"Match {match_log_id} not eligible for dispatch")
                return None
            
            # Find active endpoint for this buyer
            endpoint = db.query(BuyerEndpoint).filter(
                BuyerEndpoint.buyer_id == match_log.buyer_id,
                BuyerEndpoint.org_id == match_log.org_id,
                BuyerEndpoint.active == True
            ).first()
            
            if not endpoint:
                logger.warning(f"No active endpoint found for buyer {match_log.buyer_id}")
                return None
            
            # Enqueue dispatch job
            job_id = enqueue("dispatch_lead", {
                "lead_id": match_log.lead_id,
                "endpoint_id": endpoint.id,
                "match_log_id": match_log_id
            })
            
            logger.info(f"Enqueued dispatch job {job_id} for lead {match_log.lead_id}")
            
            # Return placeholder log (actual log created by worker)
            return DispatchLog(
                org_id=match_log.org_id,
                lead_id=match_log.lead_id,
                buyer_id=match_log.buyer_id,
                endpoint_id=endpoint.id,
                status="pending"
            )
    
    except Exception as e:
        logger.error(f"Error in on_match_created: {e}")
        return None


def get_dispatch_history(lead_id: Optional[int] = None, buyer_id: Optional[int] = None, 
                        endpoint_id: Optional[int] = None, org_id: int = 1, 
                        limit: int = 50) -> List[DispatchLog]:
    """
    Get dispatch history with optional filtering.
    
    Args:
        lead_id: Filter by specific lead
        buyer_id: Filter by specific buyer
        endpoint_id: Filter by specific endpoint
        org_id: Organization ID for scoping
        limit: Maximum number of records to return
    
    Returns:
        List of DispatchLog records
    """
    try:
        with get_session() as db:
            query = db.query(DispatchLog).filter(DispatchLog.org_id == org_id)
            
            if lead_id:
                query = query.filter(DispatchLog.lead_id == lead_id)
            
            if buyer_id:
                query = query.filter(DispatchLog.buyer_id == buyer_id)
            
            if endpoint_id:
                query = query.filter(DispatchLog.endpoint_id == endpoint_id)
            
            logs = query.order_by(DispatchLog.created_at.desc()).limit(limit).all()
            
            logger.info(f"Retrieved {len(logs)} dispatch records")
            return logs
    
    except Exception as e:
        logger.error(f"Error getting dispatch history: {e}")
        return []
