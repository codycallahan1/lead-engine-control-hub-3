"""
Lead Engine Control Hub - Audit Service
Phase: 8
Purpose: Lightweight audit logging for tracking user actions and system events
Key Responsibilities:
- Structured audit logging with consistent format
- Action tracking with metadata support
- Audit log parsing and analysis utilities
- Integration with existing logging infrastructure
"""

import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional

# Configure audit logger with specific format
audit_logger = logging.getLogger("audit")
audit_logger.setLevel(logging.INFO)

# Create audit formatter for structured logging
class AuditFormatter(logging.Formatter):
    """Custom formatter for audit logs with structured JSON output"""
    
    def format(self, record):
        # Create audit record structure
        audit_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "kind": getattr(record, 'audit_kind', 'unknown'),
            "message": record.getMessage(),
            "meta": getattr(record, 'audit_meta', None)
        }
        
        # Add structured prefix for easy parsing
        return f"AUDIT: {json.dumps(audit_record)}"

# Set up audit handler if not already configured
if not audit_logger.handlers:
    audit_handler = logging.StreamHandler()
    audit_handler.setFormatter(AuditFormatter())
    audit_logger.addHandler(audit_handler)
    audit_logger.propagate = False  # Prevent duplicate logging

def audit(kind: str, message: str, meta: Optional[Dict[str, Any]] = None) -> None:
    """
    Log an audit event with structured information.
    
    Args:
        kind: Type/category of audit event (e.g., "leads_exported", "user_login", "deployment_triggered")
        message: Human-readable description of the event
        meta: Optional metadata dictionary with additional context
        
    Example:
        audit("leads_exported", "User exported leads to CSV", {"format": "csv", "count": 150, "user_id": "admin"})
    """
    try:
        # Create log record with custom attributes
        record = audit_logger.makeRecord(
            name=audit_logger.name,
            level=logging.INFO,
            fn="",
            lno=0,
            msg=message,
            args=(),
            exc_info=None
        )
        
        # Add audit-specific attributes
        record.audit_kind = kind
        record.audit_meta = meta
        
        # Emit the log record
        audit_logger.handle(record)
        
    except Exception as e:
        # Fallback to regular logging if audit logging fails
        logging.error(f"Audit logging failed: {e}")
        logging.info(f"AUDIT_FALLBACK: {kind} - {message} - {meta}")

def audit_action(action: str, details: str, **kwargs) -> None:
    """
    Convenience function for auditing user actions.
    
    Args:
        action: Action name (e.g., "create", "update", "delete", "export")
        details: Action details
        **kwargs: Additional metadata as keyword arguments
    """
    audit(f"action_{action}", f"Action performed: {details}", kwargs)

def audit_system_event(event: str, details: str, **kwargs) -> None:
    """
    Convenience function for auditing system events.
    
    Args:
        event: Event name (e.g., "startup", "shutdown", "error", "deployment")
        details: Event details
        **kwargs: Additional metadata as keyword arguments
    """
    audit(f"system_{event}", f"System event: {details}", kwargs)

def audit_data_access(operation: str, resource: str, count: Optional[int] = None, **kwargs) -> None:
    """
    Convenience function for auditing data access operations.
    
    Args:
        operation: Operation type (e.g., "read", "export", "import")
        resource: Resource accessed (e.g., "leads", "buyers", "sites")
        count: Number of records involved
        **kwargs: Additional metadata as keyword arguments
    """
    meta = kwargs.copy()
    if count is not None:
        meta["count"] = count
    
    audit(f"data_{operation}", f"Data access: {operation} {resource}", meta)

def audit_security_event(event: str, details: str, severity: str = "info", **kwargs) -> None:
    """
    Convenience function for auditing security-related events.
    
    Args:
        event: Security event type (e.g., "login", "logout", "failed_auth", "permission_denied")
        details: Event details
        severity: Event severity ("info", "warning", "critical")
        **kwargs: Additional metadata as keyword arguments
    """
    meta = kwargs.copy()
    meta["severity"] = severity
    
    audit(f"security_{event}", f"Security event: {details}", meta)

class AuditContext:
    """
    Context manager for auditing operations with automatic timing and error handling.
    
    Example:
        with AuditContext("leads_export", "Exporting leads to CSV") as ctx:
            # Perform export operation
            ctx.add_meta("format", "csv")
            ctx.add_meta("user_id", "admin")
            # Operation completed successfully
    """
    
    def __init__(self, kind: str, message: str, meta: Optional[Dict[str, Any]] = None):
        self.kind = kind
        self.message = message
        self.meta = meta or {}
        self.start_time = None
        self.success = True
        
    def __enter__(self):
        self.start_time = datetime.utcnow()
        audit(f"{self.kind}_started", f"Started: {self.message}", self.meta)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = datetime.utcnow()
        duration = (end_time - self.start_time).total_seconds()
        
        final_meta = self.meta.copy()
        final_meta["duration_seconds"] = duration
        
        if exc_type is not None:
            # Operation failed
            final_meta["error"] = str(exc_val)
            final_meta["error_type"] = exc_type.__name__
            audit(f"{self.kind}_failed", f"Failed: {self.message}", final_meta)
        else:
            # Operation succeeded
            audit(f"{self.kind}_completed", f"Completed: {self.message}", final_meta)
    
    def add_meta(self, key: str, value: Any) -> None:
        """Add metadata to the audit context"""
        self.meta[key] = value

def parse_audit_log_line(line: str) -> Optional[Dict[str, Any]]:
    """
    Parse a structured audit log line into a dictionary.
    
    Args:
        line: Log line string
        
    Returns:
        Parsed audit record or None if not a valid audit line
    """
    try:
        if line.startswith("AUDIT: "):
            json_part = line[7:]  # Remove "AUDIT: " prefix
            return json.loads(json_part)
    except (json.JSONDecodeError, IndexError):
        pass
    
    return None

def get_audit_statistics(log_lines: list) -> Dict[str, Any]:
    """
    Analyze audit log lines and return statistics.
    
    Args:
        log_lines: List of log line strings
        
    Returns:
        Dictionary with audit statistics
    """
    stats = {
        "total_events": 0,
        "events_by_kind": {},
        "events_by_hour": {},
        "failed_operations": 0,
        "successful_operations": 0,
        "data_export_events": 0,
        "security_events": 0
    }
    
    for line in log_lines:
        audit_record = parse_audit_log_line(line)
        if not audit_record:
            continue
        
        stats["total_events"] += 1
        
        # Count by kind
        kind = audit_record.get("kind", "unknown")
        stats["events_by_kind"][kind] = stats["events_by_kind"].get(kind, 0) + 1
        
        # Count by hour
        timestamp = audit_record.get("timestamp", "")
        if timestamp:
            try:
                hour = datetime.fromisoformat(timestamp.replace('Z', '+00:00')).strftime("%Y-%m-%d %H:00")
                stats["events_by_hour"][hour] = stats["events_by_hour"].get(hour, 0) + 1
            except ValueError:
                pass
        
        # Count operation results
        if "_failed" in kind:
            stats["failed_operations"] += 1
        elif "_completed" in kind:
            stats["successful_operations"] += 1
        
        # Count specific event types
        if "export" in kind.lower():
            stats["data_export_events"] += 1
        
        if "security" in kind.lower():
            stats["security_events"] += 1
    
    return stats

# Pre-defined audit event types for consistency
class AuditEvents:
    """Constants for common audit event types"""
    
    # Data operations
    LEADS_EXPORTED = "leads_exported"
    BUYERS_EXPORTED = "buyers_exported"
    SITES_EXPORTED = "sites_exported"
    DATA_IMPORTED = "data_imported"
    
    # User actions
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    USER_CREATED = "user_created"
    USER_UPDATED = "user_updated"
    USER_DELETED = "user_deleted"
    
    # System events
    SYSTEM_STARTUP = "system_startup"
    SYSTEM_SHUTDOWN = "system_shutdown"
    DEPLOYMENT_TRIGGERED = "deployment_triggered"
    DEPLOYMENT_COMPLETED = "deployment_completed"
    DEPLOYMENT_FAILED = "deployment_failed"
    
    # Security events
    AUTH_FAILED = "auth_failed"
    PERMISSION_DENIED = "permission_denied"
    SUSPICIOUS_ACTIVITY = "suspicious_activity"

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    print("=== Audit Service Module Test ===")
    
    # Test basic audit logging
    audit("test_event", "Testing audit logging system", {"test": True, "count": 1})
    
    # Test convenience functions
    audit_action("create", "Created new test record", entity="test", id=123)
    audit_system_event("startup", "Application started", version="1.0.0")
    audit_data_access("export", "leads", count=150, format="csv")
    audit_security_event("login", "User logged in", severity="info", user="admin")
    
    # Test audit context
    with AuditContext("test_operation", "Testing context manager") as ctx:
        ctx.add_meta("step", 1)
        ctx.add_meta("status", "processing")
    
    # Test with exception
    try:
        with AuditContext("test_failure", "Testing failure handling") as ctx:
            raise ValueError("Test error")
    except ValueError:
        pass  # Expected
    
    print("✅ Audit service module test completed")
    print("Check logs above for AUDIT: entries")