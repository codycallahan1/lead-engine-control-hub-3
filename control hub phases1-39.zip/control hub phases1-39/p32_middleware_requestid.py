"""
Lead Engine Control Hub - Request ID Middleware
Phase 32: Observability infrastructure
Purpose: Assign unique request IDs and log request lifecycle
"""

import logging
import time
import uuid
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """
    Middleware to assign unique request IDs and log request lifecycle.
    Adds X-Request-ID header to all responses and logs start/stop timing.
    """
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Generate unique request ID
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        # Extract context for logging
        method = request.method
        path = request.url.path
        org_id = getattr(request.state, 'org_id', None)
        user_id = getattr(request.state, 'user_id', None)
        
        # Log request start
        start_time = time.time()
        logger.info(
            "Request started",
            extra={
                "request_id": request_id,
                "method": method,
                "path": path,
                "org_id": org_id,
                "user_id": user_id,
                "event": "request_start"
            }
        )
        
        # Process request
        try:
            response = await call_next(request)
            status_code = response.status_code
        except Exception as e:
            # Log error and re-raise
            duration_ms = (time.time() - start_time) * 1000
            logger.error(
                f"Request failed: {str(e)}",
                extra={
                    "request_id": request_id,
                    "method": method,
                    "path": path,
                    "org_id": org_id,
                    "user_id": user_id,
                    "duration_ms": round(duration_ms, 2),
                    "event": "request_error",
                    "error": str(e)
                }
            )
            raise
        
        # Calculate duration
        duration_ms = (time.time() - start_time) * 1000
        
        # Add request ID to response headers
        response.headers["X-Request-ID"] = request_id
        
        # Log request completion
        logger.info(
            "Request completed",
            extra={
                "request_id": request_id,
                "method": method,
                "path": path,
                "org_id": org_id,
                "user_id": user_id,
                "status_code": status_code,
                "duration_ms": round(duration_ms, 2),
                "event": "request_end"
            }
        )
        
        return response


def get_request_id(request: Request) -> str:
    """Helper to get current request ID from request state."""
    return getattr(request.state, 'request_id', 'unknown')


def add_request_id_middleware(app):
    """Add request ID middleware to FastAPI app."""
    app.add_middleware(RequestIDMiddleware)
    logger.info("Request ID middleware enabled")
