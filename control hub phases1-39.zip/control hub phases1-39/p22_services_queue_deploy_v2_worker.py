"""
Queue Worker for V2 Deployment Pipeline
Phase 22: Enhanced deployment worker with pipeline orchestration
Key responsibilities: Execute v2 deployment jobs, handle pipeline failures, logging
"""

import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p22__server_services_deploy_pipeline import execute_deployment
    from p21__server_models_audit import log_audit_event, AuditKind
    from p02__server_db import get_session
except ImportError:
    logger.warning("Deploy v2 worker modules not found - using mock implementations")
    def execute_deployment(site_id, deployment_id):
        return {"success": True, "status": "completed", "mock": True}
    
    def log_audit_event(session, kind, message, meta=None):
        logger.info(f"AUDIT: {kind} - {message}")
    
    def get_session():
        return None
    
    class AuditKind:
        DEPLOYMENT_COMPLETED = "deployment_completed"
        DEPLOYMENT_FAILED = "deployment_failed"

def deploy_v2_worker(payload: Dict[str, Any]) -> str:
    """
    Worker function for v2 deployment jobs
    Executes the deployment pipeline and handles results
    
    Args:
        payload: Job payload containing site_id, deployment_id, and options
    
    Returns:
        Status string indicating job completion
    """
    try:
        site_id = payload.get("site_id")
        deployment_id = payload.get("deployment_id")
        is_retry = payload.get("retry", False)
        
        if not site_id or not deployment_id:
            error_msg = "Missing required payload fields: site_id and deployment_id"
            logger.error(f"Deploy v2 worker error: {error_msg}")
            return f"error: {error_msg}"
        
        action = "retry" if is_retry else "deployment"
        logger.info(f"Starting v2 {action} worker: site_id={site_id}, deployment_id={deployment_id}")
        
        # Execute the deployment pipeline
        result = execute_deployment(site_id, deployment_id)
        
        # Log results
        session = get_session()
        if session:
            with session:
                if result.get("success"):
                    # Successful deployment
                    audit_message = f"V2 deployment completed successfully: site_id={site_id}, deployment_id={deployment_id}"
                    if is_retry:
                        audit_message = f"V2 deployment retry completed successfully: site_id={site_id}, deployment_id={deployment_id}"
                    
                    audit_meta = {
                        "site_id": site_id,
                        "deployment_id": deployment_id,
                        "pipeline_version": "v2",
                        "action": action,
                        "steps_completed": result.get("steps_completed", 0),
                        "total_steps": result.get("total_steps", 0),
                        "duration_seconds": result.get("duration_seconds", 0)
                    }
                    
                    log_audit_event(session, AuditKind.DEPLOYMENT_COMPLETED, audit_message, audit_meta)
                    
                    logger.info(f"V2 {action} completed successfully: {result}")
                    return f"completed: {result.get('status', 'unknown')}"
                
                else:
                    # Failed deployment
                    error = result.get("error", "Unknown error")
                    audit_message = f"V2 deployment failed: site_id={site_id}, deployment_id={deployment_id}, error={error}"
                    if is_retry:
                        audit_message = f"V2 deployment retry failed: site_id={site_id}, deployment_id={deployment_id}, error={error}"
                    
                    audit_meta = {
                        "site_id": site_id,
                        "deployment_id": deployment_id,
                        "pipeline_version": "v2",
                        "action": action,
                        "error": error,
                        "steps_completed": result.get("steps_completed", 0),
                        "total_steps": result.get("total_steps", 0)
                    }
                    
                    log_audit_event(session, AuditKind.DEPLOYMENT_FAILED, audit_message, audit_meta)
                    
                    logger.error(f"V2 {action} failed: {result}")
                    return f"failed: {error}"
        else:
            # No database session, just log locally
            if result.get("success"):
                logger.info(f"Mock v2 {action} completed: {result}")
                return f"completed: {result.get('status', 'mock')}"
            else:
                logger.error(f"Mock v2 {action} failed: {result}")
                return f"failed: {result.get('error', 'mock error')}"
    
    except Exception as e:
        error_msg = f"V2 deployment worker exception: {str(e)}"
        logger.error(error_msg)
        
        # Try to log the error
        try:
            session = get_session()
            if session:
                with session:
                    log_audit_event(
                        session,
                        AuditKind.DEPLOYMENT_FAILED,
                        f"V2 deployment worker crashed: site_id={payload.get('site_id')}, error={str(e)}",
                        {
                            "site_id": payload.get("site_id"),
                            "deployment_id": payload.get("deployment_id"),
                            "error": str(e),
                            "worker_crash": True
                        }
                    )
        except:
            pass  # Don't let logging errors prevent error reporting
        
        return f"error: {str(e)}"

# Worker registration function for queue service
def register_deploy_v2_worker(queue_service):
    """
    Register the v2 deployment worker with the queue service
    Should be called during application startup
    
    Args:
        queue_service: The queue service instance
    """
    try:
        queue_service.register("deploy_v2", deploy_v2_worker)
        logger.info("V2 deployment worker registered with queue service")
    except Exception as e:
        logger.error(f"Failed to register v2 deployment worker: {e}")

# Enhanced worker with more detailed logging
def deploy_v2_worker_enhanced(payload: Dict[str, Any]) -> str:
    """
    Enhanced version of the v2 deployment worker with detailed step logging
    
    Args:
        payload: Job payload containing deployment parameters
    
    Returns:
        Detailed status string with step information
    """
    site_id = payload.get("site_id")
    deployment_id = payload.get("deployment_id")
    
    logger.info(f"Enhanced v2 worker starting: site_id={site_id}, deployment_id={deployment_id}")
    logger.info(f"Payload: {payload}")
    
    try:
        # Execute deployment with enhanced logging
        result = execute_deployment(site_id, deployment_id)
        
        # Log detailed results
        steps_info = f"{result.get('steps_completed', 0)}/{result.get('total_steps', 0)} steps"
        duration_info = f"{result.get('duration_seconds', 0):.1f}s"
        
        if result.get("success"):
            status_msg = f"V2 deployment completed: {steps_info} in {duration_info}"
            logger.info(status_msg)
            return f"completed: {steps_info}, {duration_info}"
        else:
            error = result.get("error", "Unknown error")
            status_msg = f"V2 deployment failed: {steps_info}, error={error}"
            logger.error(status_msg)
            return f"failed: {steps_info}, error={error}"
    
    except Exception as e:
        logger.error(f"Enhanced v2 worker exception: {e}")
        return f"worker_error: {str(e)}"

# Worker status and monitoring functions
def get_deploy_worker_stats() -> Dict[str, Any]:
    """
    Get statistics about deployment worker performance
    Useful for monitoring and debugging
    """
    try:
        # This would typically query job history from the queue service
        # For now, return mock stats
        return {
            "worker_type": "deploy_v2",
            "total_jobs_processed": 50,  # Mock data
            "successful_jobs": 45,
            "failed_jobs": 5,
            "average_duration_seconds": 120.5,
            "last_job_timestamp": "2024-01-01T12:00:00Z",
            "worker_status": "active"
        }
    except Exception as e:
        logger.error(f"Error getting worker stats: {e}")
        return {"error": str(e)}

def validate_deploy_payload(payload: Dict[str, Any]) -> tuple:
    """
    Validate deployment job payload
    
    Args:
        payload: Job payload to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    required_fields = ["site_id", "deployment_id"]
    
    for field in required_fields:
        if field not in payload:
            return False, f"Missing required field: {field}"
        
        if not isinstance(payload[field], int):
            return False, f"Field {field} must be an integer"
        
        if payload[field] <= 0:
            return False, f"Field {field} must be positive"
    
    # Optional fields validation
    if "pipeline_version" in payload and payload["pipeline_version"] != "v2":
        return False, "Invalid pipeline_version, must be 'v2'"
    
    if "retry" in payload and not isinstance(payload["retry"], bool):
        return False, "Field 'retry' must be boolean"
    
    return True, None

# Queue service integration helper
def setup_deployment_workers(queue_service):
    """
    Complete setup for all deployment-related workers
    
    Args:
        queue_service: Queue service instance
    """
    try:
        # Register v2 deployment worker
        register_deploy_v2_worker(queue_service)
        
        # Register enhanced worker (if needed for debugging)
        queue_service.register("deploy_v2_enhanced", deploy_v2_worker_enhanced)
        
        logger.info("All deployment workers registered successfully")
        
    except Exception as e:
        logger.error(f"Failed to setup deployment workers: {e}")
        raise

# Worker health check
def check_deploy_worker_health() -> Dict[str, Any]:
    """
    Check health of deployment workers and dependencies
    
    Returns:
        Health check results
    """
    health_status = {
        "worker_available": True,
        "dependencies": {},
        "last_check": logger.manager.start_time if hasattr(logger.manager, 'start_time') else None
    }
    
    try:
        # Check database connectivity
        session = get_session()
        health_status["dependencies"]["database"] = session is not None
        
        # Check pipeline service
        try:
            from p22__server_services_deploy_pipeline import create_deployment_pipeline
            pipeline = create_deployment_pipeline()
            health_status["dependencies"]["pipeline"] = pipeline is not None
        except ImportError:
            health_status["dependencies"]["pipeline"] = False
        
        # Check provider services
        try:
            from p10__server_providers_domains_mock import purchase
            from p10__server_providers_dns_mock import create_record
            from p10__server_providers_hosting_mock import deploy
            health_status["dependencies"]["providers"] = True
        except ImportError:
            health_status["dependencies"]["providers"] = False
        
        # Overall health
        all_healthy = all(health_status["dependencies"].values())
        health_status["status"] = "healthy" if all_healthy else "degraded"
        
    except Exception as e:
        health_status["status"] = "unhealthy"
        health_status["error"] = str(e)
    
    return health_status
