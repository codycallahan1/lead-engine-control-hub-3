"""
Mock email provider for notification system.

Phase: 16
Purpose: Simulate email sending with realistic latency and failure rates
Key responsibilities: send_email function with mock responses and timing
"""

import logging
import time
import random
import uuid
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

def send_email(to: str, subject: str, body: str, from_email: Optional[str] = None) -> Dict[str, Any]:
    """
    Mock email sending function.
    
    Simulates sending an email with realistic latency and occasional failures.
    No actual emails are sent - this is for testing and development.
    
    Args:
        to: Recipient email address
        subject: Email subject line
        body: Email body content
        from_email: Sender email (optional, uses default)
        
    Returns:
        Dict with success status, provider_id, latency_ms, and error info
    """
    start_time = time.time()
    
    # Validate inputs
    if not to or '@' not in to:
        logger.error(f"Invalid recipient email: {to}")
        return {
            'success': False,
            'provider_id': None,
            'latency_ms': 0,
            'error': 'Invalid recipient email address',
            'to': to,
            'subject': subject
        }
    
    if not subject.strip():
        logger.error("Empty email subject")
        return {
            'success': False,
            'provider_id': None,
            'latency_ms': 0,
            'error': 'Email subject cannot be empty',
            'to': to,
            'subject': subject
        }
    
    # Generate unique provider ID for tracking
    provider_id = f"mock_{uuid.uuid4().hex[:8]}"
    
    logger.info(f"Sending mock email to {to}: '{subject}' (ID: {provider_id})")
    
    # Simulate realistic email provider latency (200ms to 2s)
    latency_seconds = random.uniform(0.2, 2.0)
    time.sleep(latency_seconds)
    
    end_time = time.time()
    actual_latency_ms = int((end_time - start_time) * 1000)
    
    # Simulate random failures (~10% failure rate)
    success_rate = 0.9
    
    # Some email addresses are more likely to fail (simulate bounces, etc.)
    if any(domain in to.lower() for domain in ['invalid.', 'bounce.', 'fail.']):
        success_rate = 0.3
    elif any(domain in to.lower() for domain in ['temp', 'disposable']):
        success_rate = 0.7
    
    success = random.random() < success_rate
    
    result = {
        'success': success,
        'provider_id': provider_id,
        'latency_ms': actual_latency_ms,
        'to': to,
        'subject': subject,
        'body_length': len(body),
        'from_email': from_email or 'noreply@leadengine.example'
    }
    
    if success:
        logger.info(f"Mock email sent successfully to {to} in {actual_latency_ms}ms (ID: {provider_id})")
        result.update({
            'message_id': f"msg_{uuid.uuid4().hex[:12]}",
            'status': 'sent'
        })
    else:
        # Simulate different types of failures
        error_types = [
            'Recipient mailbox full',
            'Invalid recipient domain',
            'Rate limit exceeded',
            'Temporary service unavailable',
            'Recipient blocked sender'
        ]
        error_message = random.choice(error_types)
        
        logger.warning(f"Mock email failed to {to} after {actual_latency_ms}ms: {error_message} (ID: {provider_id})")
        result.update({
            'error': error_message,
            'error_code': random.choice(['MAILBOX_FULL', 'INVALID_DOMAIN', 'RATE_LIMITED', 'SERVICE_ERROR', 'BLOCKED']),
            'status': 'failed',
            'retry_after': random.randint(60, 3600) if 'rate limit' in error_message.lower() else None
        })
    
    return result

def get_provider_status() -> Dict[str, Any]:
    """
    Get mock provider status information.
    
    Returns:
        Dict with provider health and configuration info
    """
    # Simulate occasional provider issues
    is_healthy = random.random() > 0.05  # 95% uptime
    
    status = {
        'provider_name': 'Mock Email Service',
        'healthy': is_healthy,
        'api_version': '1.0',
        'rate_limit_remaining': random.randint(500, 1000),
        'rate_limit_reset': int(time.time()) + 3600,
        'last_check': time.time()
    }
    
    if not is_healthy:
        status.update({
            'error': 'Temporary service degradation',
            'estimated_recovery': int(time.time()) + random.randint(300, 1800)
        })
    
    logger.info(f"Email provider status check: {'healthy' if is_healthy else 'degraded'}")
    return status

def validate_email_template(template_name: str, variables: Dict[str, str]) -> Dict[str, Any]:
    """
    Validate email template and variables.
    
    Args:
        template_name: Name of the email template
        variables: Template variables to validate
        
    Returns:
        Dict with validation results
    """
    logger.info(f"Validating email template: {template_name}")
    
    # Mock template validation
    known_templates = [
        'new_lead_notification',
        'sale_delivered_notification',
        'system_alert',
        'weekly_summary'
    ]
    
    if template_name not in known_templates:
        return {
            'valid': False,
            'error': f'Unknown template: {template_name}',
            'available_templates': known_templates
        }
    
    # Mock variable validation
    required_vars = {
        'new_lead_notification': ['lead_name', 'lead_email'],
        'sale_delivered_notification': ['buyer_name', 'sale_id', 'price'],
        'system_alert': ['alert_type', 'message'],
        'weekly_summary': ['period_start', 'period_end', 'stats']
    }
    
    missing_vars = []
    if template_name in required_vars:
        for var in required_vars[template_name]:
            if var not in variables:
                missing_vars.append(var)
    
    if missing_vars:
        return {
            'valid': False,
            'error': f'Missing required variables: {", ".join(missing_vars)}',
            'required_variables': required_vars[template_name]
        }
    
    return {
        'valid': True,
        'template_name': template_name,
        'variables_count': len(variables)
    }

# Log provider initialization
logger.info("Mock email provider initialized with functions: send_email, get_provider_status, validate_email_template")
