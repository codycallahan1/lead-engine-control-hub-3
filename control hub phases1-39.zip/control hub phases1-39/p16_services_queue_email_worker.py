"""
Email worker extension for the job queue system with retry logic.

Phase: 16
Purpose: Register and handle email delivery jobs with retry and audit logging
Key responsibilities: email job handler with retry backoff and audit trail
"""

import logging
import time
from typing import Dict, Any

# Import attempt with graceful fallback
try:
    from p16__server_providers_email_mock import send_email
    from p16__server_services_audit import audit_email
    from p07__server_services_queue import register as register_handler
except ImportError as e:
    logging.warning(f"Import issue in email worker: {e}")
    # Fallback for development
    def send_email(to, subject, body):
        return {"success": True, "provider_id": "mock", "latency_ms": 100}
    def audit_email(kind, to, subject, success, attempts, error=None):
        pass
    def register_handler(kind, handler_fn):
        pass

logger = logging.getLogger(__name__)

# Retry configuration
MAX_RETRIES = 3
RETRY_DELAYS = [30, 300, 1800]  # 30s, 5min, 30min

def email_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process email delivery job with retry logic.
    
    Handles email sending with exponential backoff retry for failures.
    Records audit logs for all attempts and final outcomes.
    
    Args:
        payload: Job payload containing email details and retry info
        
    Returns:
        Result dict with delivery status and metrics
    """
    to = payload.get('to', '')
    subject = payload.get('subject', '')
    body = payload.get('body', '')
    template = payload.get('template', 'generic')
    event_type = payload.get('event_type', 'unknown')
    
    # Track retry attempts
    attempt = payload.get('attempt', 1)
    max_attempts = payload.get('max_attempts', MAX_RETRIES)
    
    logger.info(f"Processing email job to {to} (attempt {attempt}/{max_attempts}): '{subject[:50]}...'")
    
    # Validate required fields
    if not to or not subject:
        error_msg = "Missing required email fields (to/subject)"
        logger.error(f"Email job validation failed: {error_msg}")
        
        audit_email(
            kind=f"email_{event_type}",
            to=to,
            subject=subject,
            success=False,
            attempts=attempt,
            error=error_msg
        )
        
        return {
            'success': False,
            'error': error_msg,
            'final_attempt': True,
            'to': to,
            'subject': subject
        }
    
    # Attempt to send email
    start_time = time.time()
    try:
        result = send_email(to=to, subject=subject, body=body)
        end_time = time.time()
        
        total_time_ms = int((end_time - start_time) * 1000)
        provider_latency = result.get('latency_ms', 0)
        
        if result['success']:
            # Success - log audit and return
            logger.info(f"Email sent successfully to {to} in {total_time_ms}ms (provider: {provider_latency}ms)")
            
            audit_email(
                kind=f"email_{event_type}",
                to=to,
                subject=subject,
                success=True,
                attempts=attempt,
                error=None
            )
            
            return {
                'success': True,
                'provider_id': result.get('provider_id'),
                'message_id': result.get('message_id'),
                'latency_ms': total_time_ms,
                'provider_latency_ms': provider_latency,
                'attempts': attempt,
                'to': to,
                'subject': subject,
                'template': template
            }
        else:
            # Email provider reported failure
            error_msg = result.get('error', 'Unknown email provider error')
            error_code = result.get('error_code', 'UNKNOWN')
            
            logger.warning(f"Email provider failed for {to}: {error_msg} (code: {error_code})")
            
            # Check if we should retry
            should_retry = attempt < max_attempts and _should_retry_error(error_code)
            
            if should_retry:
                # Schedule retry with backoff
                retry_delay = RETRY_DELAYS[min(attempt - 1, len(RETRY_DELAYS) - 1)]
                logger.info(f"Scheduling email retry for {to} in {retry_delay}s (attempt {attempt + 1})")
                
                # Don't audit yet - wait for final result
                return {
                    'success': False,
                    'error': error_msg,
                    'error_code': error_code,
                    'retry_after': retry_delay,
                    'final_attempt': False,
                    'attempts': attempt,
                    'to': to,
                    'subject': subject
                }
            else:
                # Final failure - audit and return
                logger.error(f"Email finally failed to {to} after {attempt} attempts: {error_msg}")
                
                audit_email(
                    kind=f"email_{event_type}",
                    to=to,
                    subject=subject,
                    success=False,
                    attempts=attempt,
                    error=f"{error_msg} (code: {error_code})"
                )
                
                return {
                    'success': False,
                    'error': error_msg,
                    'error_code': error_code,
                    'final_attempt': True,
                    'attempts': attempt,
                    'to': to,
                    'subject': subject
                }
                
    except Exception as e:
        # Unexpected error during email sending
        error_msg = f"Email worker exception: {str(e)}"
        logger.error(f"Email worker error for {to}: {error_msg}")
        
        # Always treat exceptions as final failures
        audit_email(
            kind=f"email_{event_type}",
            to=to,
            subject=subject,
            success=False,
            attempts=attempt,
            error=error_msg
        )
        
        return {
            'success': False,
            'error': error_msg,
            'final_attempt': True,
            'attempts': attempt,
            'to': to,
            'subject': subject
        }

def _should_retry_error(error_code: str) -> bool:
    """
    Determine if an email error should be retried.
    
    Args:
        error_code: Error code from email provider
        
    Returns:
        True if the error is retryable
    """
    # Retryable errors (temporary issues)
    retryable_codes = {
        'RATE_LIMITED',      # Rate limit - wait and retry
        'SERVICE_ERROR',     # Temporary service issue
        'TIMEOUT',           # Network timeout
        'UNKNOWN'            # Unknown errors might be temporary
    }
    
    # Non-retryable errors (permanent failures)
    permanent_codes = {
        'INVALID_DOMAIN',    # Bad email domain
        'MAILBOX_FULL',      # Recipient mailbox full
        'BLOCKED',           # Sender blocked by recipient
        'INVALID_EMAIL'      # Malformed email address
    }
    
    if error_code in permanent_codes:
        return False
    elif error_code in retryable_codes:
        return True
    else:
        # Default to retry for unknown error codes
        return True

def bulk_email_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process bulk email delivery job.
    
    Handles sending the same email to multiple recipients efficiently.
    
    Args:
        payload: Job payload containing recipient list and email content
        
    Returns:
        Result dict with bulk delivery status
    """
    recipients = payload.get('recipients', [])
    subject = payload.get('subject', '')
    body = payload.get('body', '')
    template = payload.get('template', 'bulk')
    
    logger.info(f"Processing bulk email job to {len(recipients)} recipients: '{subject[:50]}...'")
    
    if not recipients:
        logger.error("Bulk email job has no recipients")
        return {
            'success': False,
            'error': 'No recipients provided',
            'sent_count': 0,
            'failed_count': 0
        }
    
    sent_count = 0
    failed_count = 0
    results = []
    
    for to in recipients:
        try:
            result = send_email(to=to, subject=subject, body=body)
            
            if result['success']:
                sent_count += 1
                logger.debug(f"Bulk email sent to {to}")
            else:
                failed_count += 1
                logger.warning(f"Bulk email failed to {to}: {result.get('error', 'Unknown')}")
            
            results.append({
                'to': to,
                'success': result['success'],
                'provider_id': result.get('provider_id'),
                'error': result.get('error')
            })
            
            # Small delay between sends to avoid overwhelming the provider
            time.sleep(0.1)
            
        except Exception as e:
            failed_count += 1
            logger.error(f"Bulk email exception for {to}: {e}")
            results.append({
                'to': to,
                'success': False,
                'error': str(e)
            })
    
    logger.info(f"Bulk email completed: {sent_count} sent, {failed_count} failed")
    
    return {
        'success': failed_count == 0,
        'sent_count': sent_count,
        'failed_count': failed_count,
        'total_recipients': len(recipients),
        'results': results,
        'template': template
    }

def init_email_queue():
    """
    Register the email workers with the queue system.
    
    This should be called during application startup to ensure
    email jobs can be processed.
    """
    logger.info("Initializing email queue workers")
    
    try:
        register_handler('email', email_worker)
        register_handler('bulk_email', bulk_email_worker)
        logger.info("Email workers registered successfully")
    except Exception as e:
        logger.error(f"Failed to register email workers: {e}")

# Auto-initialize when module is imported
init_email_queue()

# Log worker initialization
logger.info("Email queue worker module loaded and initialized with retry logic")
