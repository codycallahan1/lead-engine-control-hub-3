"""
Theme service for organization branding management.
Phase 39: Theming & Branding per Org
Purpose: per-Org logo/colors; inject into base template + public ingest form
"""

import os
import shutil
import uuid
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
from datetime import datetime
import logging

# Import models and database
try:
    from p39__server_models_theme import OrgTheme, ThemeAsset, create_default_theme, validate_hex_color, sanitize_css
    from p02__server_db import get_session
except ImportError:
    # Fallback for when files are reorganized
    logging.warning("Could not import theme models/db - imports may need adjustment during packaging")
    class OrgTheme:
        def __init__(self, **kwargs): pass
        def to_dict(self): return {}
        def get_css_vars(self): return {}
    class ThemeAsset:
        def __init__(self, **kwargs): pass
        def to_dict(self): return {}
    def create_default_theme(org_id): return {}
    def validate_hex_color(color): return True
    def sanitize_css(css): return css or ""
    def get_session(): 
        class MockSession:
            def add(self, obj): pass
            def commit(self): pass
            def query(self, model): return self
            def filter(self, *args): return self
            def first(self): return None
            def all(self): return []
        return MockSession()

logger = logging.getLogger(__name__)

# File upload configuration
UPLOAD_DIR = Path("./server/uploads/logos")
ALLOWED_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB


def ensure_upload_dir():
    """Ensure upload directory exists."""
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def get_theme(org_id: int) -> Optional[OrgTheme]:
    """
    Get theme for an organization.
    Creates default theme if none exists.
    """
    with get_session() as session:
        theme = session.query(OrgTheme).filter(OrgTheme.org_id == org_id).first()
        
        if not theme:
            # Create default theme
            logger.info(f"Creating default theme for org_id={org_id}")
            theme_data = create_default_theme(org_id)
            theme = OrgTheme(**theme_data)
            session.add(theme)
            session.commit()
            
            # Refresh to get the ID
            session.refresh(theme)
        
        return theme


def update_theme(org_id: int, updates: Dict[str, Any]) -> Tuple[bool, str, Optional[OrgTheme]]:
    """
    Update theme for an organization.
    Returns (success, message, theme).
    """
    try:
        with get_session() as session:
            theme = session.query(OrgTheme).filter(OrgTheme.org_id == org_id).first()
            
            if not theme:
                # Create new theme
                theme_data = create_default_theme(org_id)
                theme_data.update(updates)
                theme = OrgTheme(**theme_data)
                session.add(theme)
            else:
                # Update existing theme
                for key, value in updates.items():
                    if hasattr(theme, key):
                        # Validate colors
                        if key.endswith('_hex') and value:
                            if not validate_hex_color(value):
                                return False, f"Invalid hex color: {value}", None
                        
                        # Sanitize CSS
                        if key == 'custom_css' and value:
                            value = sanitize_css(value)
                        
                        setattr(theme, key, value)
            
            theme.updated_at = datetime.utcnow()
            session.commit()
            session.refresh(theme)
            
            logger.info(f"Updated theme for org_id={org_id}")
            return True, "Theme updated successfully", theme
            
    except Exception as e:
        logger.error(f"Failed to update theme for org_id={org_id}: {e}")
        return False, f"Failed to update theme: {str(e)}", None


def upload_logo(org_id: int, file_content: bytes, filename: str, uploaded_by: str = None) -> Tuple[bool, str, Optional[str]]:
    """
    Upload and store a logo file for an organization.
    Returns (success, message, file_path).
    """
    try:
        ensure_upload_dir()
        
        # Validate file
        if len(file_content) > MAX_FILE_SIZE:
            return False, "File too large. Maximum size is 5MB.", None
        
        if len(file_content) < 100:
            return False, "File too small to be a valid image.", None
        
        # Check extension
        file_ext = Path(filename).suffix.lower()
        if file_ext not in ALLOWED_EXTENSIONS:
            return False, f"Invalid file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}", None
        
        # Generate unique filename
        unique_id = str(uuid.uuid4())[:8]
        safe_filename = f"logo_{org_id}_{unique_id}{file_ext}"
        file_path = UPLOAD_DIR / safe_filename
        
        # Write file
        with open(file_path, 'wb') as f:
            f.write(file_content)
        
        # Update theme with logo path
        with get_session() as session:
            theme = session.query(OrgTheme).filter(OrgTheme.org_id == org_id).first()
            
            if not theme:
                # Create theme with logo
                theme_data = create_default_theme(org_id)
                theme_data['logo_path'] = str(file_path)
                theme = OrgTheme(**theme_data)
                session.add(theme)
            else:
                # Remove old logo if exists
                if theme.logo_path and os.path.exists(theme.logo_path):
                    try:
                        os.remove(theme.logo_path)
                        logger.info(f"Removed old logo: {theme.logo_path}")
                    except Exception as e:
                        logger.warning(f"Could not remove old logo: {e}")
                
                theme.logo_path = str(file_path)
                theme.updated_at = datetime.utcnow()
            
            session.commit()
        
        # Create asset record
        with get_session() as session:
            asset = ThemeAsset(
                org_id=org_id,
                filename=safe_filename,
                original_filename=filename,
                file_path=str(file_path),
                file_size_bytes=len(file_content),
                asset_type="logo",
                alt_text=f"Logo for organization {org_id}",
                uploaded_by=uploaded_by,
                active=True
            )
            session.add(asset)
            session.commit()
        
        logger.info(f"Uploaded logo for org_id={org_id}: {safe_filename}")
        return True, "Logo uploaded successfully", str(file_path)
        
    except Exception as e:
        logger.error(f"Failed to upload logo for org_id={org_id}: {e}")
        return False, f"Failed to upload logo: {str(e)}", None


def get_logo_url(org_id: int, base_url: str = "") -> Optional[str]:
    """
    Get public URL for organization logo.
    """
    theme = get_theme(org_id)
    if not theme or not theme.logo_path:
        return None
    
    # Convert file path to URL
    if os.path.exists(theme.logo_path):
        # Extract filename from path
        filename = Path(theme.logo_path).name
        return f"{base_url}/static/uploads/logos/{filename}"
    
    return None


def css_vars(theme: OrgTheme) -> Dict[str, str]:
    """
    Generate CSS custom properties for template injection.
    """
    if not theme:
        return {}
    
    return theme.get_css_vars()


def get_theme_preview(org_id: int) -> Dict[str, Any]:
    """
    Get theme data formatted for preview display.
    """
    theme = get_theme(org_id)
    if not theme:
        return {}
    
    theme_dict = theme.to_dict()
    theme_dict['css_vars'] = css_vars(theme)
    theme_dict['logo_url'] = get_logo_url(org_id)
    
    return theme_dict


def delete_logo(org_id: int) -> Tuple[bool, str]:
    """
    Remove logo for an organization.
    """
    try:
        with get_session() as session:
            theme = session.query(OrgTheme).filter(OrgTheme.org_id == org_id).first()
            
            if not theme or not theme.logo_path:
                return True, "No logo to remove"
            
            # Remove file
            if os.path.exists(theme.logo_path):
                os.remove(theme.logo_path)
                logger.info(f"Removed logo file: {theme.logo_path}")
            
            # Update theme
            theme.logo_path = None
            theme.updated_at = datetime.utcnow()
            session.commit()
            
            # Mark asset as inactive
            asset = session.query(ThemeAsset).filter(
                ThemeAsset.org_id == org_id,
                ThemeAsset.asset_type == "logo",
                ThemeAsset.active == True
            ).first()
            
            if asset:
                asset.active = False
                session.commit()
            
            return True, "Logo removed successfully"
            
    except Exception as e:
        logger.error(f"Failed to delete logo for org_id={org_id}: {e}")
        return False, f"Failed to delete logo: {str(e)}"


def list_theme_assets(org_id: int) -> list:
    """
    List all theme assets for an organization.
    """
    try:
        with get_session() as session:
            assets = session.query(ThemeAsset).filter(
                ThemeAsset.org_id == org_id,
                ThemeAsset.active == True
            ).all()
            
            return [asset.to_dict() for asset in assets]
            
    except Exception as e:
        logger.error(f"Failed to list assets for org_id={org_id}: {e}")
        return []


def reset_theme(org_id: int) -> Tuple[bool, str]:
    """
    Reset theme to default values for an organization.
    """
    try:
        # First, remove any uploaded logos
        delete_logo(org_id)
        
        # Reset theme to defaults
        default_data = create_default_theme(org_id)
        success, message, theme = update_theme(org_id, default_data)
        
        if success:
            logger.info(f"Reset theme to defaults for org_id={org_id}")
            return True, "Theme reset to defaults successfully"
        else:
            return False, message
            
    except Exception as e:
        logger.error(f"Failed to reset theme for org_id={org_id}: {e}")
        return False, f"Failed to reset theme: {str(e)}"


def validate_theme_data(data: Dict[str, Any]) -> Tuple[bool, list]:
    """
    Validate theme update data.
    Returns (is_valid, errors).
    """
    errors = []
    
    # Check hex colors
    color_fields = ['primary_hex', 'secondary_hex', 'accent_hex', 'background_hex', 'text_hex']
    for field in color_fields:
        if field in data and data[field]:
            if not validate_hex_color(data[field]):
                errors.append(f"Invalid hex color format for {field}")
    
    # Check display name length
    if 'display_name' in data and data['display_name']:
        if len(data['display_name']) > 255:
            errors.append("Display name too long (max 255 characters)")
    
    # Check custom CSS length
    if 'custom_css' in data and data['custom_css']:
        if len(data['custom_css']) > 10000:
            errors.append("Custom CSS too long (max 10KB)")
    
    return len(errors) == 0, errors


def export_theme(org_id: int) -> Dict[str, Any]:
    """
    Export theme configuration for backup/transfer.
    """
    theme = get_theme(org_id)
    if not theme:
        return {}
    
    export_data = theme.to_dict()
    
    # Include asset information (but not file contents)
    assets = list_theme_assets(org_id)
    export_data['assets'] = assets
    
    # Remove sensitive/org-specific data
    export_data.pop('id', None)
    export_data.pop('org_id', None)
    export_data.pop('created_at', None)
    export_data.pop('updated_at', None)
    
    return export_data


def import_theme(org_id: int, theme_data: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Import theme configuration (colors/CSS only, not assets).
    """
    try:
        # Validate imported data
        valid, errors = validate_theme_data(theme_data)
        if not valid:
            return False, f"Invalid theme data: {'; '.join(errors)}"
        
        # Remove fields we don't want to import
        clean_data = {}
        allowed_fields = ['primary_hex', 'secondary_hex', 'accent_hex', 
                         'background_hex', 'text_hex', 'display_name', 'custom_css']
        
        for field in allowed_fields:
            if field in theme_data:
                clean_data[field] = theme_data[field]
        
        # Update theme
        success, message, theme = update_theme(org_id, clean_data)
        
        if success:
            logger.info(f"Imported theme for org_id={org_id}")
            return True, "Theme imported successfully"
        else:
            return False, message
            
    except Exception as e:
        logger.error(f"Failed to import theme for org_id={org_id}: {e}")
        return False, f"Failed to import theme: {str(e)}"


def cleanup_unused_assets():
    """
    Clean up theme asset files that are no longer referenced.
    This is a maintenance function that should be run periodically.
    """
    try:
        if not UPLOAD_DIR.exists():
            return
        
        # Get all active asset file paths from database
        active_paths = set()
        with get_session() as session:
            assets = session.query(ThemeAsset).filter(ThemeAsset.active == True).all()
            for asset in assets:
                if asset.file_path:
                    active_paths.add(asset.file_path)
        
        # Check files in upload directory
        removed_count = 0
        for file_path in UPLOAD_DIR.glob("*"):
            if file_path.is_file() and str(file_path) not in active_paths:
                try:
                    file_path.unlink()
                    removed_count += 1
                    logger.info(f"Cleaned up unused asset: {file_path.name}")
                except Exception as e:
                    logger.warning(f"Could not remove unused asset {file_path.name}: {e}")
        
        logger.info(f"Theme asset cleanup completed: removed {removed_count} unused files")
        return removed_count
        
    except Exception as e:
        logger.error(f"Theme asset cleanup failed: {e}")
        return 0