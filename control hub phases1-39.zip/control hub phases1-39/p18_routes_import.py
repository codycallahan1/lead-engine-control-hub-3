"""
CSV Import Routes for Leads and Buyers
Phase 18: Bulk data import via CSV files with validation and dry-run support
Key responsibilities: Accept multipart CSV uploads, validate headers, provide dry-run mode
"""

import logging
from fastapi import APIRouter, File, UploadFile, Depends, HTTPException, Query
from fastapi.responses import JSONResponse
import io

logger = logging.getLogger(__name__)

# Import services (with try/except for flat file structure)
try:
    from p18__server_services_import import parse_csv, upsert_leads, upsert_buyers
except ImportError:
    logger.warning("Import services not found - ensure proper package structure")
    def parse_csv(*args, **kwargs):
        return [], ["Import services not available"]
    def upsert_leads(*args, **kwargs):
        return {"inserted": 0, "updated": 0, "rejected": []}
    def upsert_buyers(*args, **kwargs):
        return {"inserted": 0, "updated": 0, "rejected": []}

router = APIRouter(prefix="/import", tags=["import"])

def require_admin_token(admin_token: str = None):
    """Require admin token for import operations"""
    if not admin_token or admin_token != "change-me":
        raise HTTPException(status_code=403, detail="Admin token required")
    return True

@router.post("/leads")
async def import_leads_csv(
    file: UploadFile = File(...),
    dry_run: bool = Query(False),
    _: bool = Depends(require_admin_token)
):
    """
    Import leads from CSV file
    Required headers: name,email,phone (phone optional)
    """
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be CSV format")
    
    try:
        # Read file contents
        contents = await file.read()
        file_text = contents.decode('utf-8')
        
        logger.info(f"Processing leads import: {file.filename}, dry_run={dry_run}")
        
        # Parse CSV
        rows, errors = parse_csv(file_text, required_headers=['name', 'email'])
        
        if errors:
            return JSONResponse({
                "success": False,
                "errors": errors,
                "dry_run": dry_run
            }, status_code=400)
        
        # Process leads
        result = upsert_leads(rows, dry_run=dry_run)
        result["dry_run"] = dry_run
        
        logger.info(f"Import leads result: {result['inserted']} inserted, {result['updated']} updated, {len(result['rejected'])} rejected")
        
        return JSONResponse(result)
        
    except Exception as e:
        logger.error(f"Error importing leads: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

@router.post("/buyers")
async def import_buyers_csv(
    file: UploadFile = File(...),
    dry_run: bool = Query(False),
    _: bool = Depends(require_admin_token)
):
    """
    Import buyers from CSV file
    Required headers: name,email
    """
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be CSV format")
    
    try:
        # Read file contents
        contents = await file.read()
        file_text = contents.decode('utf-8')
        
        logger.info(f"Processing buyers import: {file.filename}, dry_run={dry_run}")
        
        # Parse CSV
        rows, errors = parse_csv(file_text, required_headers=['name', 'email'])
        
        if errors:
            return JSONResponse({
                "success": False,
                "errors": errors,
                "dry_run": dry_run
            }, status_code=400)
        
        # Process buyers
        result = upsert_buyers(rows, dry_run=dry_run)
        result["dry_run"] = dry_run
        
        logger.info(f"Import buyers result: {result['inserted']} inserted, {result['updated']} updated, {len(result['rejected'])} rejected")
        
        return JSONResponse(result)
        
    except Exception as e:
        logger.error(f"Error importing buyers: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")
