"""
Organization Context Middleware
Phase 24: Automatically set org context for all requests
Key responsibilities: Resolve and set request.state.org_id, log org access
"""

import logging
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p24__server_services_scope import current_org, validate_org_access, get_user_org_context, log_org_access
    from p23__server_security_auth import get_current_user_context
except ImportError:
    logger.warning("Org context modules not found - using mock implementations")
    def current_org(request):
        return 1
    
    def validate_org_access(request, org_id):
        return True
    
    def get_user_org_context(request):
        return {"current_org_id": 1, "available_orgs": []}
    
    def log_org_access(request, resource, action):
        pass
    
    def get_current_user_context(request):
        return {"authenticated": False}

class OrganizationContextMiddleware(BaseHTTPMiddleware):
    """
    Middleware to automatically resolve and set organization context
    Sets request.state.org_id and request.state.org_context for all requests
    """
    
    def __init__(self, app, log_access: bool = True, validate_access: bool = True):
        """
        Initialize org context middleware
        
        Args:
            app: FastAPI application
            log_access: Whether to log org access attempts
            validate_access: Whether to validate org access (strict mode)
        """
        super().__init__(app)
        self.log_access = log_access
        self.validate_access = validate_access
    
    async def dispatch(self, request: Request, call_next):
        """
        Process request and set organization context
        
        Args:
            request: Incoming HTTP request
            call_next: Next middleware/handler in chain
        
        Returns:
            HTTP response
        """
        try:
            # Skip org resolution for certain paths
            if self._should_skip_org_resolution(request):
                request.state.org_id = None
                request.state.org_context = None
                return await call_next(request)
            
            # Resolve organization ID
            org_id = current_org(request)
            
            # Validate access if enabled
            if self.validate_access:
                access_valid = validate_org_access(request, org_id)
                if not access_valid:
                    logger.warning(f"Org access denied: user attempted to access org {org_id}")
                    # In strict mode, you might want to return 403 here
                    # For now, we'll just log and continue
            
            # Set org context in request state
            request.state.org_id = org_id
            request.state.org_context = get_user_org_context(request)
            
            # Log access if enabled
            if self.log_access:
                self._log_request_access(request, org_id)
            
            # Add org info to response headers (optional)
            response = await call_next(request)
            response.headers["X-Current-Org-ID"] = str(org_id)
            
            return response
        
        except Exception as e:
            logger.error(f"Error in org context middleware: {e}")
            # Set default context and continue
            request.state.org_id = 1
            request.state.org_context = {"current_org_id": 1, "available_orgs": []}
            return await call_next(request)
    
    def _should_skip_org_resolution(self, request: Request) -> bool:
        """
        Determine if org resolution should be skipped for this request
        
        Args:
            request: HTTP request
        
        Returns:
            True if org resolution should be skipped
        """
        skip_paths = [
            "/health",
            "/version", 
            "/docs",
            "/openapi.json",
            "/static/",
            "/favicon.ico"
        ]
        
        path = request.url.path
        return any(path.startswith(skip_path) for skip_path in skip_paths)
    
    def _log_request_access(self, request: Request, org_id: int):
        """
        Log organization access for the request
        
        Args:
            request: HTTP request
            org_id: Organization ID being accessed
        """
        try:
            # Extract resource and action from request
            resource = self._extract_resource_from_path(request.url.path)
            action = self._extract_action_from_method(request.method)
            
            # Only log certain types of requests to avoid spam
            if self._should_log_request(request):
                log_org_access(request, resource, action)
        
        except Exception as e:
            logger.debug(f"Error logging request access: {e}")
    
    def _extract_resource_from_path(self, path: str) -> str:
        """Extract resource name from URL path"""
        # Remove leading slash and split
        parts = path.lstrip('/').split('/')
        
        # Map common paths to resources
        resource_mapping = {
            'leads': 'leads',
            'buyers': 'buyers', 
            'sites': 'sites',
            'deployments': 'deployments',
            'export': 'export',
            'import': 'import',
            'webhooks': 'webhooks',
            'matching': 'matching',
            'privacy': 'privacy',
            'orgs': 'organizations'
        }
        
        if parts and parts[0] in resource_mapping:
            return resource_mapping[parts[0]]
        
        return parts[0] if parts else 'unknown'
    
    def _extract_action_from_method(self, method: str) -> str:
        """Extract action from HTTP method"""
        action_mapping = {
            'GET': 'read',
            'POST': 'create',
            'PUT': 'update',
            'PATCH': 'update',
            'DELETE': 'delete'
        }
        
        return action_mapping.get(method.upper(), method.lower())
    
    def _should_log_request(self, request: Request) -> bool:
        """
        Determine if this request should be logged
        
        Args:
            request: HTTP request
        
        Returns:
            True if request should be logged
        """
        # Log API requests but not static files, health checks, etc.
        path = request.url.path
        
        # Skip logging for these paths
        skip_logging = [
            "/health",
            "/version",
            "/static/",
            "/favicon.ico",
            "/docs",
            "/openapi.json"
        ]
        
        if any(path.startswith(skip_path) for skip_path in skip_logging):
            return False
        
        # Log API operations
        api_paths = [
            "/leads",
            "/buyers", 
            "/sites",
            "/deployments",
            "/export",
            "/import",
            "/webhooks",
            "/matching",
            "/privacy",
            "/orgs"
        ]
        
        return any(path.startswith(api_path) for api_path in api_paths)

# Helper functions for accessing org context

def get_request_org_id(request: Request) -> int:
    """
    Get organization ID from request state
    
    Args:
        request: FastAPI request object
    
    Returns:
        Organization ID (defaults to 1 if not set)
    """
    return getattr(request.state, 'org_id', 1)

def get_request_org_context(request: Request) -> dict:
    """
    Get full organization context from request state
    
    Args:
        request: FastAPI request object
    
    Returns:
        Organization context dictionary
    """
    return getattr(request.state, 'org_context', {"current_org_id": 1, "available_orgs": []})

def require_org_context(request: Request) -> dict:
    """
    Require organization context or raise exception
    
    Args:
        request: FastAPI request object
    
    Returns:
        Organization context dictionary
    
    Raises:
        ValueError: If org context not available
    """
    org_context = get_request_org_context(request)
    if not org_context or not org_context.get('current_org_id'):
        raise ValueError("Organization context not available - ensure org middleware is enabled")
    
    return org_context

# Dependency functions for FastAPI routes

def get_current_org_id(request: Request) -> int:
    """
    FastAPI dependency to get current organization ID
    
    Args:
        request: FastAPI request object
    
    Returns:
        Current organization ID
    """
    return get_request_org_id(request)

def get_org_context(request: Request) -> dict:
    """
    FastAPI dependency to get full organization context
    
    Args:
        request: FastAPI request object
    
    Returns:
        Organization context dictionary
    """
    return get_request_org_context(request)

# Middleware setup helper

def add_org_context_middleware(app, log_access: bool = True, validate_access: bool = False):
    """
    Add organization context middleware to FastAPI app
    
    Args:
        app: FastAPI application
        log_access: Whether to log organization access
        validate_access: Whether to validate access (strict mode)
    """
    app.add_middleware(
        OrganizationContextMiddleware,
        log_access=log_access,
        validate_access=validate_access
    )
    logger.info("Organization context middleware added")

# Context validation helpers

def validate_org_context_setup(request: Request) -> dict:
    """
    Validate that org context is properly set up
    Useful for debugging and health checks
    
    Args:
        request: FastAPI request object
    
    Returns:
        Validation results
    """
    try:
        org_id = get_request_org_id(request)
        org_context = get_request_org_context(request)
        user_context = get_current_user_context(request)
        
        return {
            "org_middleware_active": True,
            "org_id_set": org_id is not None,
            "org_context_available": bool(org_context),
            "user_authenticated": user_context.get('authenticated', False),
            "current_org_id": org_id,
            "validation_passed": True
        }
    
    except Exception as e:
        return {
            "org_middleware_active": False,
            "validation_passed": False,
            "error": str(e)
        }

# Statistics and monitoring

def get_org_middleware_stats() -> dict:
    """
    Get statistics about org middleware usage
    Useful for monitoring and debugging
    """
    # In a real implementation, you'd track these metrics
    return {
        "middleware_active": True,
        "requests_processed": "N/A",  # Would track actual count
        "org_switches": "N/A",       # Would track org context changes
        "access_violations": "N/A",   # Would track access denials
        "most_accessed_orgs": ["1"]   # Would track popular orgs
    }
