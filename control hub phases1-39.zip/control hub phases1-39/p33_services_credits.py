"""
Lead Engine Control Hub - Credit Management Service
Phase 33: Buyer credits and spend controls
Purpose: Core business logic for credit operations and spend tracking
"""

import logging
from datetime import datetime
from typing import Optional, Tuple
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

# Import models and database utilities
try:
    from p33__server_models_credits import BuyerCredit, SpendLedger
    from p02__server_db import get_session
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    class BuyerCredit:
        pass
    class SpendLedger:
        pass
    def get_session():
        pass
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")

logger = logging.getLogger(__name__)


class InsufficientCreditError(Exception):
    """Raised when buyer doesn't have enough credit for a transaction."""
    pass


class CreditCapExceededError(Exception):
    """Raised when transaction would exceed buyer's credit cap."""
    pass


def get_or_create_credit(buyer_id: int, org_id: int, session: Session = None) -> BuyerCredit:
    """
    Get existing buyer credit record or create a new one with defaults.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        session: Database session (optional)
    
    Returns:
        BuyerCredit instance
    """
    if session is None:
        with get_session() as session:
            return get_or_create_credit(buyer_id, org_id, session)
    
    # Try to find existing credit record
    credit = session.query(BuyerCredit).filter_by(
        buyer_id=buyer_id,
        org_id=org_id
    ).first()
    
    if credit:
        return credit
    
    # Create new credit record with defaults
    credit = BuyerCredit(
        buyer_id=buyer_id,
        org_id=org_id,
        balance_cents=0,
        cap_cents=100000,  # $1000 default cap
        renewal_period="monthly",
        renewed_at=datetime.utcnow()
    )
    
    session.add(credit)
    session.commit()
    session.refresh(credit)
    
    logger.info(f"Created new credit account for buyer {buyer_id}")
    audit(
        kind="credit_account_created",
        message=f"Credit account created for buyer {buyer_id}",
        meta={"buyer_id": buyer_id, "org_id": org_id, "cap_dollars": credit.cap_dollars}
    )
    
    return credit


def get_credit_info(buyer_id: int, org_id: int) -> dict:
    """
    Get comprehensive credit information for a buyer.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
    
    Returns:
        Dictionary with credit details
    """
    with get_session() as session:
        credit = get_or_create_credit(buyer_id, org_id, session)
        
        # Get recent spend activity
        recent_spend = session.query(SpendLedger).filter_by(
            buyer_id=buyer_id,
            org_id=org_id
        ).order_by(SpendLedger.created_at.desc()).limit(10).all()
        
        # Calculate period spend (simplified - would need more complex logic for actual periods)
        period_spend = sum(
            entry.amount_cents for entry in recent_spend 
            if entry.kind == "charge" and entry.created_at >= credit.renewed_at
        )
        
        return {
            "buyer_id": buyer_id,
            "balance_cents": credit.balance_cents,
            "balance_dollars": credit.balance_dollars,
            "cap_cents": credit.cap_cents,
            "cap_dollars": credit.cap_dollars,
            "renewal_period": credit.renewal_period,
            "renewed_at": credit.renewed_at.isoformat(),
            "period_spend_cents": abs(period_spend),
            "period_spend_dollars": abs(period_spend) / 100,
            "available_cents": credit.balance_cents,
            "available_dollars": credit.balance_dollars,
            "recent_activity_count": len(recent_spend)
        }


def ensure_sufficient_credit(buyer_id: int, org_id: int, amount_cents: int) -> bool:
    """
    Check if buyer has sufficient credit for a transaction.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        amount_cents: Required amount in cents
    
    Returns:
        True if sufficient credit available
    
    Raises:
        InsufficientCreditError: If not enough credit
    """
    with get_session() as session:
        credit = get_or_create_credit(buyer_id, org_id, session)
        
        if not credit.has_sufficient_credit(amount_cents):
            logger.warning(
                f"Insufficient credit for buyer {buyer_id}: needs ${amount_cents/100:.2f}, has ${credit.balance_dollars:.2f}"
            )
            raise InsufficientCreditError(
                f"Insufficient credit: needs ${amount_cents/100:.2f}, available ${credit.balance_dollars:.2f}"
            )
        
        return True


def charge_credit(buyer_id: int, org_id: int, lead_id: int, amount_cents: int, 
                 note: str = None, created_by: str = "system") -> Tuple[SpendLedger, BuyerCredit]:
    """
    Charge buyer's credit for a lead transaction.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        lead_id: Lead identifier
        amount_cents: Amount to charge in cents (positive)
        note: Optional transaction note
        created_by: Who initiated the transaction
    
    Returns:
        Tuple of (SpendLedger entry, updated BuyerCredit)
    
    Raises:
        InsufficientCreditError: If not enough credit
    """
    with get_session() as session:
        credit = get_or_create_credit(buyer_id, org_id, session)
        
        # Verify sufficient credit
        if not credit.has_sufficient_credit(amount_cents):
            raise InsufficientCreditError(
                f"Cannot charge ${amount_cents/100:.2f}: only ${credit.balance_dollars:.2f} available"
            )
        
        # Create ledger entry (negative amount for charge)
        ledger_entry = SpendLedger(
            org_id=org_id,
            buyer_id=buyer_id,
            lead_id=lead_id,
            amount_cents=-amount_cents,  # Negative for charge
            kind="charge",
            note=note or f"Lead {lead_id} charge",
            created_by=created_by
        )
        
        # Update credit balance
        credit.balance_cents -= amount_cents
        credit.updated_at = datetime.utcnow()
        
        session.add(ledger_entry)
        session.commit()
        session.refresh(ledger_entry)
        session.refresh(credit)
        
        logger.info(f"Charged buyer {buyer_id} ${amount_cents/100:.2f} for lead {lead_id}")
        audit(
            kind="credit_charged",
            message=f"Charged buyer {buyer_id} ${amount_cents/100:.2f} for lead {lead_id}",
            meta={
                "buyer_id": buyer_id,
                "lead_id": lead_id,
                "amount_dollars": amount_cents / 100,
                "new_balance_dollars": credit.balance_dollars,
                "ledger_id": ledger_entry.id
            }
        )
        
        return ledger_entry, credit


def top_up_credit(buyer_id: int, org_id: int, amount_cents: int,
                 note: str = None, created_by: str = "admin") -> Tuple[SpendLedger, BuyerCredit]:
    """
    Add credit to buyer's account.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier  
        amount_cents: Amount to add in cents (positive)
        note: Optional transaction note
        created_by: Who initiated the top-up
    
    Returns:
        Tuple of (SpendLedger entry, updated BuyerCredit)
    
    Raises:
        CreditCapExceededError: If top-up would exceed cap
    """
    with get_session() as session:
        credit = get_or_create_credit(buyer_id, org_id, session)
        
        # Check if top-up would exceed cap
        if not credit.is_within_cap(amount_cents):
            raise CreditCapExceededError(
                f"Top-up would exceed cap: ${credit.cap_dollars:.2f} maximum"
            )
        
        # Create ledger entry (positive amount for top-up)
        ledger_entry = SpendLedger(
            org_id=org_id,
            buyer_id=buyer_id,
            lead_id=None,  # No lead for top-ups
            amount_cents=amount_cents,  # Positive for credit
            kind="topup",
            note=note or f"Credit top-up ${amount_cents/100:.2f}",
            created_by=created_by
        )
        
        # Update credit balance
        credit.balance_cents += amount_cents
        credit.updated_at = datetime.utcnow()
        
        session.add(ledger_entry)
        session.commit()
        session.refresh(ledger_entry)
        session.refresh(credit)
        
        logger.info(f"Topped up buyer {buyer_id} with ${amount_cents/100:.2f}")
        audit(
            kind="credit_topped_up",
            message=f"Topped up buyer {buyer_id} with ${amount_cents/100:.2f}",
            meta={
                "buyer_id": buyer_id,
                "amount_dollars": amount_cents / 100,
                "new_balance_dollars": credit.balance_dollars,
                "ledger_id": ledger_entry.id,
                "created_by": created_by
            }
        )
        
        return ledger_entry, credit


def update_credit_cap(buyer_id: int, org_id: int, new_cap_cents: int,
                     created_by: str = "admin") -> BuyerCredit:
    """
    Update buyer's credit cap.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        new_cap_cents: New cap in cents
        created_by: Who updated the cap
    
    Returns:
        Updated BuyerCredit
    """
    with get_session() as session:
        credit = get_or_create_credit(buyer_id, org_id, session)
        
        old_cap = credit.cap_cents
        credit.cap_cents = new_cap_cents
        credit.updated_at = datetime.utcnow()
        
        session.commit()
        session.refresh(credit)
        
        logger.info(f"Updated credit cap for buyer {buyer_id}: ${old_cap/100:.2f} -> ${new_cap_cents/100:.2f}")
        audit(
            kind="credit_cap_updated",
            message=f"Updated credit cap for buyer {buyer_id} from ${old_cap/100:.2f} to ${new_cap_cents/100:.2f}",
            meta={
                "buyer_id": buyer_id,
                "old_cap_dollars": old_cap / 100,
                "new_cap_dollars": new_cap_cents / 100,
                "created_by": created_by
            }
        )
        
        return credit


def get_spend_history(buyer_id: int, org_id: int, limit: int = 50, offset: int = 0) -> dict:
    """
    Get paginated spend history for a buyer.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        limit: Maximum records to return
        offset: Records to skip
    
    Returns:
        Dictionary with transactions and metadata
    """
    with get_session() as session:
        query = session.query(SpendLedger).filter_by(
            buyer_id=buyer_id,
            org_id=org_id
        ).order_by(SpendLedger.created_at.desc())
        
        total = query.count()
        transactions = query.offset(offset).limit(limit).all()
        
        return {
            "transactions": [
                {
                    "id": tx.id,
                    "amount_cents": tx.amount_cents,
                    "amount_dollars": tx.amount_dollars,
                    "kind": tx.kind,
                    "note": tx.note,
                    "lead_id": tx.lead_id,
                    "created_at": tx.created_at.isoformat(),
                    "created_by": tx.created_by
                }
                for tx in transactions
            ],
            "total": total,
            "limit": limit,
            "offset": offset,
            "has_more": total > (offset + limit)
        }
