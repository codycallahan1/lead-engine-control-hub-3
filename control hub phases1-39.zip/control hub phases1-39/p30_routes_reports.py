"""
Reports and analytics API routes.

Phase: 30
Purpose: Provide endpoints for operational reports and data exports.
Key responsibilities:
- Summary KPI endpoints
- Buyer performance rankings
- CSV export endpoints with streaming
"""

from fastapi import APIRouter, Depends, HTTPException, Request, Query
from fastapi.responses import StreamingResponse
from typing import Optional
import logging
import io

try:
    from p30__server_services_reports import (
        generate_summary_report,
        buyer_intake_ranking,
        leads_by_day,
        matches_by_day,
        dispatch_success_rate,
        export_leads_csv,
        export_matches_csv,
        export_dispatches_csv
    )
    from p24__server_services_scope import current_org
    from p08__server_services_audit import audit_data_operation
except ImportError as e:
    logging.warning(f"Reports routes: missing dependency {e}")

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/reports", tags=["reports"])


def require_ops_admin():
    """Placeholder for ops/admin role requirement."""
    return "admin"


@router.get("/summary")
async def get_summary_report(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Get comprehensive summary report with key metrics."""
    
    try:
        summary = generate_summary_report(org_id, start, end)
        
        if "error" in summary:
            raise HTTPException(status_code=500, detail=summary["error"])
        
        # Audit the report generation
        audit_data_operation(
            "report_generated",
            "reports",
            1,  # One report
            actor,
            {
                "report_type": "summary",
                "period_start": start,
                "period_end": end,
                "org_id": org_id
            }
        )
        
        logger.info(f"Generated summary report for org {org_id}")
        return summary
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating summary report: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate summary report")


@router.get("/buyer-ranking")
async def get_buyer_ranking(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    top: int = Query(10, ge=1, le=50, description="Number of top buyers to return"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Get buyer performance ranking by lead intake and success rates."""
    
    try:
        rankings = buyer_intake_ranking(org_id, start, end, top)
        
        # Audit the report generation
        audit_data_operation(
            "report_generated",
            "buyer_rankings",
            len(rankings),
            actor,
            {
                "report_type": "buyer_ranking",
                "period_start": start,
                "period_end": end,
                "top_count": top,
                "org_id": org_id
            }
        )
        
        logger.info(f"Generated buyer ranking for org {org_id}: top {len(rankings)} buyers")
        
        return {
            "rankings": rankings,
            "total_buyers": len(rankings),
            "period": {
                "start": start,
                "end": end
            },
            "generated_at": rankings[0].get("generated_at") if rankings else None
        }
    
    except Exception as e:
        logger.error(f"Error generating buyer ranking: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate buyer ranking")


@router.get("/leads-timeline")
async def get_leads_timeline(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Get daily lead creation timeline."""
    
    try:
        timeline = leads_by_day(org_id, start, end)
        
        total_leads = sum(day["count"] for day in timeline)
        
        return {
            "timeline": timeline,
            "total_leads": total_leads,
            "period": {
                "start": start,
                "end": end,
                "days": len(timeline)
            }
        }
    
    except Exception as e:
        logger.error(f"Error generating leads timeline: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate leads timeline")


@router.get("/matches-timeline")
async def get_matches_timeline(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Get daily matching success timeline."""
    
    try:
        timeline = matches_by_day(org_id, start, end)
        
        total_matches = sum(day["total"] for day in timeline)
        successful_matches = sum(day["matched"] for day in timeline)
        overall_rate = (successful_matches / total_matches * 100) if total_matches > 0 else 0
        
        return {
            "timeline": timeline,
            "summary": {
                "total_matches": total_matches,
                "successful_matches": successful_matches,
                "overall_success_rate": round(overall_rate, 1)
            },
            "period": {
                "start": start,
                "end": end,
                "days": len(timeline)
            }
        }
    
    except Exception as e:
        logger.error(f"Error generating matches timeline: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate matches timeline")


@router.get("/dispatch-metrics")
async def get_dispatch_metrics(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Get dispatch success metrics and performance data."""
    
    try:
        metrics = dispatch_success_rate(org_id, start, end)
        
        return {
            "metrics": metrics,
            "period": {
                "start": start,
                "end": end
            }
        }
    
    except Exception as e:
        logger.error(f"Error generating dispatch metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate dispatch metrics")


# CSV Export endpoints
@router.get("/exports/leads.csv")
async def export_leads_csv_endpoint(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Export leads data as CSV file."""
    
    try:
        # Generate filename with date range
        from datetime import datetime
        date_suffix = f"{start or 'all'}_{end or datetime.utcnow().strftime('%Y-%m-%d')}"
        filename = f"leads_export_{date_suffix}.csv"
        
        # Create streaming response
        csv_generator = export_leads_csv(org_id, start, end)
        
        # Audit the export
        audit_data_operation(
            "export",
            "leads",
            0,  # Count will be determined by the generator
            actor,
            {
                "format": "csv",
                "period_start": start,
                "period_end": end,
                "org_id": org_id,
                "filename": filename
            }
        )
        
        logger.info(f"Starting leads CSV export for org {org_id}")
        
        return StreamingResponse(
            csv_generator,
            media_type="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "X-Download-Filename": filename,
                "Cache-Control": "no-cache"
            }
        )
    
    except Exception as e:
        logger.error(f"Error exporting leads CSV: {e}")
        raise HTTPException(status_code=500, detail="Failed to export leads CSV")


@router.get("/exports/matches.csv")
async def export_matches_csv_endpoint(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Export matches data as CSV file."""
    
    try:
        # Generate filename with date range
        from datetime import datetime
        date_suffix = f"{start or 'all'}_{end or datetime.utcnow().strftime('%Y-%m-%d')}"
        filename = f"matches_export_{date_suffix}.csv"
        
        # Create streaming response
        csv_generator = export_matches_csv(org_id, start, end)
        
        # Audit the export
        audit_data_operation(
            "export",
            "matches",
            0,  # Count will be determined by the generator
            actor,
            {
                "format": "csv",
                "period_start": start,
                "period_end": end,
                "org_id": org_id,
                "filename": filename
            }
        )
        
        logger.info(f"Starting matches CSV export for org {org_id}")
        
        return StreamingResponse(
            csv_generator,
            media_type="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "X-Download-Filename": filename,
                "Cache-Control": "no-cache"
            }
        )
    
    except Exception as e:
        logger.error(f"Error exporting matches CSV: {e}")
        raise HTTPException(status_code=500, detail="Failed to export matches CSV")


@router.get("/exports/dispatches.csv")
async def export_dispatches_csv_endpoint(
    request: Request,
    start: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Export dispatch logs as CSV file."""
    
    try:
        # Generate filename with date range
        from datetime import datetime
        date_suffix = f"{start or 'all'}_{end or datetime.utcnow().strftime('%Y-%m-%d')}"
        filename = f"dispatches_export_{date_suffix}.csv"
        
        # Create streaming response
        csv_generator = export_dispatches_csv(org_id, start, end)
        
        # Audit the export
        audit_data_operation(
            "export",
            "dispatches",
            0,  # Count will be determined by the generator
            actor,
            {
                "format": "csv",
                "period_start": start,
                "period_end": end,
                "org_id": org_id,
                "filename": filename
            }
        )
        
        logger.info(f"Starting dispatches CSV export for org {org_id}")
        
        return StreamingResponse(
            csv_generator,
            media_type="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "X-Download-Filename": filename,
                "Cache-Control": "no-cache"
            }
        )
    
    except Exception as e:
        logger.error(f"Error exporting dispatches CSV: {e}")
        raise HTTPException(status_code=500, detail="Failed to export dispatches CSV")
