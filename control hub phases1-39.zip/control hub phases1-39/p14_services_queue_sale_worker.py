"""
Sale delivery worker extension for the job queue system.

Phase: 14
Purpose: Register and handle sale delivery jobs in the queue
Key responsibilities: deliver_sale job handler registration and delivery simulation
"""

import logging
import time
import random
from typing import Dict, Any

# Import attempt with graceful fallback
try:
    from p02__server_db import get_session
    from p14__server_models_sales import LeadSale
    from p07__server_services_queue import register as register_handler
except ImportError as e:
    logging.warning(f"Import issue in sale worker: {e}")
    # Fallback for development
    def get_session():
        return None
    class LeadSale:
        pass
    def register_handler(kind, handler_fn):
        pass

logger = logging.getLogger(__name__)

def deliver_sale_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process sale delivery job.
    
    Simulates delivering a lead to a buyer and marks the sale as delivered.
    This could involve sending emails, API calls, or other notification methods.
    
    Args:
        payload: Job payload containing sale_id and delivery details
        
    Returns:
        Result dict with delivery status and metrics
    """
    sale_id = payload.get('sale_id')
    logger.info(f"Processing sale delivery for sale {sale_id}")
    
    if not sale_id:
        logger.error("No sale_id provided in payload")
        return {"success": False, "error": "Missing sale_id"}
    
    # Simulate delivery processing time
    start_time = time.time()
    time.sleep(random.uniform(0.5, 2.0))  # 500ms-2s simulated delivery time
    end_time = time.time()
    
    delivery_ms = int((end_time - start_time) * 1000)
    
    # Simulate random delivery success/failure (95% success rate)
    success = random.random() > 0.05
    
    with get_session() as session:
        sale = session.query(LeadSale).filter(LeadSale.id == sale_id).first()
        
        if not sale:
            logger.error(f"Sale {sale_id} not found")
            return {"success": False, "error": f"Sale {sale_id} not found"}
        
        if sale.status != "created":
            logger.warning(f"Sale {sale_id} status is {sale.status}, expected 'created'")
            return {"success": False, "error": f"Sale {sale_id} is not in created status"}
        
        if success:
            sale.mark_delivered()
            session.commit()
            
            logger.info(f"Sale {sale_id} delivered successfully in {delivery_ms}ms")
            
            return {
                "success": True,
                "sale_id": sale_id,
                "delivery_ms": delivery_ms,
                "lead_id": sale.lead_id,
                "buyer_id": sale.buyer_id,
                "price_cents": sale.price_cents
            }
        else:
            # In a real system, failed deliveries might be retried
            # For now, we'll leave the sale in "created" status
            logger.warning(f"Sale {sale_id} delivery failed after {delivery_ms}ms")
            
            return {
                "success": False,
                "sale_id": sale_id,
                "delivery_ms": delivery_ms,
                "error": "Delivery simulation failed"
            }

def create_sale_delivery_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Alternative worker that handles the full create-and-deliver flow.
    
    This worker could be used for immediate delivery scenarios.
    
    Args:
        payload: Job payload containing lead_id and buyer matching info
        
    Returns:
        Result dict with sale creation and delivery status
    """
    lead_id = payload.get('lead_id')
    logger.info(f"Processing create-and-deliver for lead {lead_id}")
    
    # This would integrate with the matching service to create and deliver
    # For now, just log the attempt
    logger.info(f"Would create sale and deliver for lead {lead_id}")
    
    # Simulate processing
    time.sleep(random.uniform(0.2, 1.0))
    
    return {
        "success": True,
        "lead_id": lead_id,
        "action": "create_and_deliver",
        "note": "Simulation completed"
    }

def init_sale_queue():
    """
    Register the sale workers with the queue system.
    
    This should be called during application startup to ensure
    sale jobs can be processed.
    """
    logger.info("Initializing sale queue workers")
    
    try:
        register_handler('deliver_sale', deliver_sale_worker)
        register_handler('create_sale_delivery', create_sale_delivery_worker)
        logger.info("Sale workers registered successfully")
    except Exception as e:
        logger.error(f"Failed to register sale workers: {e}")

# Auto-initialize when module is imported
init_sale_queue()

# Log worker initialization
logger.info("Sale queue worker module loaded and initialized")
