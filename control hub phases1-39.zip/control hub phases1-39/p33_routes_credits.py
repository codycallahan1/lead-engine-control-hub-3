"""
Lead Engine Control Hub - Credit Management Routes
Phase 33: Buyer credits and spend controls
Purpose: REST API endpoints for credit operations
"""

import logging
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field

# Import credit services and auth
try:
    from p33__server_services_credits import (
        get_credit_info, top_up_credit, update_credit_cap, get_spend_history,
        InsufficientCreditError, CreditCapExceededError
    )
    from p20__server_middleware_auth import require_role
    from p24__server_services_scope import current_org
except ImportError:
    # Fallback for development
    def get_credit_info(buyer_id, org_id):
        return {"buyer_id": buyer_id, "balance_dollars": 0}
    def top_up_credit(buyer_id, org_id, amount_cents, note=None, created_by="admin"):
        return None, None
    def update_credit_cap(buyer_id, org_id, new_cap_cents, created_by="admin"):
        return None
    def get_spend_history(buyer_id, org_id, limit=50, offset=0):
        return {"transactions": [], "total": 0}
    def require_role(*roles):
        return lambda: None
    def current_org(request):
        return 1
    
    class InsufficientCreditError(Exception):
        pass
    class CreditCapExceededError(Exception):
        pass

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/buyers", tags=["credits"])


# Request/Response models
class TopUpRequest(BaseModel):
    amount_cents: int = Field(..., gt=0, description="Amount to add in cents")
    note: Optional[str] = Field(None, max_length=500, description="Optional note")


class CreditCapRequest(BaseModel):
    cap_cents: int = Field(..., gt=0, description="New credit cap in cents")


class CreditResponse(BaseModel):
    buyer_id: int
    balance_cents: int
    balance_dollars: float
    cap_cents: int
    cap_dollars: float
    renewal_period: str
    renewed_at: str
    period_spend_cents: int
    period_spend_dollars: float
    available_cents: int
    available_dollars: float
    recent_activity_count: int


class SpendHistoryResponse(BaseModel):
    transactions: list
    total: int
    limit: int
    offset: int
    has_more: bool


# Routes
@router.get("/{buyer_id}/credits", response_model=CreditResponse)
async def get_buyer_credits(
    buyer_id: int,
    request: Request,
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Get credit information for a buyer.
    
    Returns current balance, cap, and recent activity summary.
    Requires ops or admin role.
    """
    try:
        org_id = current_org(request)
        credit_info = get_credit_info(buyer_id, org_id)
        return CreditResponse(**credit_info)
        
    except Exception as e:
        logger.error(f"Error retrieving credits for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve credit information")


@router.post("/{buyer_id}/credits/topup")
async def topup_buyer_credits(
    buyer_id: int,
    request: Request,
    topup_data: TopUpRequest,
    _: None = Depends(require_role("admin"))
):
    """
    Add credits to buyer's account.
    
    Only admins can perform top-ups.
    Validates that top-up doesn't exceed credit cap.
    """
    try:
        org_id = current_org(request)
        
        # Perform top-up
        ledger_entry, credit = top_up_credit(
            buyer_id=buyer_id,
            org_id=org_id,
            amount_cents=topup_data.amount_cents,
            note=topup_data.note,
            created_by="admin"  # Could extract from request.state.user if available
        )
        
        logger.info(f"Admin topped up buyer {buyer_id} with ${topup_data.amount_cents/100:.2f}")
        
        return {
            "success": True,
            "message": f"Added ${topup_data.amount_cents/100:.2f} to buyer {buyer_id}",
            "ledger_id": ledger_entry.id if ledger_entry else None,
            "new_balance_cents": credit.balance_cents if credit else 0,
            "new_balance_dollars": credit.balance_dollars if credit else 0
        }
        
    except CreditCapExceededError as e:
        logger.warning(f"Top-up rejected for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
        
    except Exception as e:
        logger.error(f"Error topping up buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to process top-up")


@router.get("/{buyer_id}/spend", response_model=SpendHistoryResponse)
async def get_buyer_spend_history(
    buyer_id: int,
    request: Request,
    limit: int = 50,
    offset: int = 0,
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Get paginated spend history for a buyer.
    
    Returns chronological list of all credit transactions
    including charges, top-ups, and adjustments.
    """
    try:
        # Validate pagination parameters
        if limit > 100:
            limit = 100
        if limit < 1:
            limit = 50
        if offset < 0:
            offset = 0
            
        org_id = current_org(request)
        history = get_spend_history(buyer_id, org_id, limit, offset)
        
        return SpendHistoryResponse(**history)
        
    except Exception as e:
        logger.error(f"Error retrieving spend history for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve spend history")


@router.patch("/{buyer_id}/credit-cap")
async def update_buyer_credit_cap(
    buyer_id: int,
    request: Request,
    cap_data: CreditCapRequest,
    _: None = Depends(require_role("admin"))
):
    """
    Update buyer's credit cap.
    
    Only admins can modify credit caps.
    Cap must be positive and reasonable (under $100,000).
    """
    try:
        # Validate cap amount
        if cap_data.cap_cents > 10_000_000:  # $100,000 max
            raise HTTPException(
                status_code=400, 
                detail="Credit cap cannot exceed $100,000"
            )
            
        org_id = current_org(request)
        
        credit = update_credit_cap(
            buyer_id=buyer_id,
            org_id=org_id,
            new_cap_cents=cap_data.cap_cents,
            created_by="admin"
        )
        
        logger.info(f"Admin updated credit cap for buyer {buyer_id} to ${cap_data.cap_cents/100:.2f}")
        
        return {
            "success": True,
            "message": f"Updated credit cap for buyer {buyer_id} to ${cap_data.cap_cents/100:.2f}",
            "buyer_id": buyer_id,
            "new_cap_cents": cap_data.cap_cents,
            "new_cap_dollars": cap_data.cap_cents / 100,
            "current_balance_cents": credit.balance_cents if credit else 0,
            "current_balance_dollars": credit.balance_dollars if credit else 0
        }
        
    except Exception as e:
        logger.error(f"Error updating credit cap for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to update credit cap")


@router.get("/{buyer_id}/credits/summary")
async def get_buyer_credit_summary(
    buyer_id: int,
    request: Request,
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Get simplified credit summary for dashboard display.
    
    Returns just the essential information needed for UI cards.
    """
    try:
        org_id = current_org(request)
        credit_info = get_credit_info(buyer_id, org_id)
        
        # Return simplified view
        return {
            "buyer_id": buyer_id,
            "balance_dollars": credit_info["balance_dollars"],
            "cap_dollars": credit_info["cap_dollars"],
            "utilization_percent": round(
                (credit_info["balance_dollars"] / credit_info["cap_dollars"]) * 100, 1
            ) if credit_info["cap_dollars"] > 0 else 0,
            "status": "active" if credit_info["balance_dollars"] > 0 else "low_credit",
            "recent_activity": credit_info["recent_activity_count"] > 0
        }
        
    except Exception as e:
        logger.error(f"Error retrieving credit summary for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve credit summary")


# Include router in main app
def include_credits_routes(app):
    """Include credit routes in the main FastAPI app."""
    app.include_router(router)
    logger.info("Credit management routes registered")
