"""
Metrics UI routes with server-side rendered charts.

Phase: 15
Purpose: Metrics dashboard with inline SVG charts and data visualization
Key responsibilities: metrics page rendering with chart data preparation
"""

import logging
from typing import Dict, Any
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# Import attempt with graceful fallback
try:
    from p15__server_services_metrics import get_chart_data, get_conversion_metrics
except ImportError as e:
    logging.warning(f"Import issue in metrics UI routes: {e}")
    # Fallback for development
    def get_chart_data():
        return {
            'totals': {'leads': 0, 'buyers': 0, 'sites': 0, 'sales': 0, 'deployments': 0},
            'trends': {'leads': [], 'sales': []},
            'max_values': {'leads': 0, 'sales': 0}
        }
    def get_conversion_metrics():
        return {'conversion_rate': 0.0, 'delivery_rate': 0.0, 'refund_rate': 0.0}

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/metrics", tags=["metrics"])

# Template setup - would be wired from main app
templates = Jinja2Templates(directory=".")

def prepare_chart_svg_data(trend_data: list, max_value: int, width: int = 400, height: int = 200) -> Dict[str, Any]:
    """
    Prepare data for rendering inline SVG bar charts.
    
    Args:
        trend_data: List of dict with 'date', 'date_short', 'count'
        max_value: Maximum value for scaling
        width: Chart width in pixels
        height: Chart height in pixels
        
    Returns:
        Dict with SVG-ready chart data
    """
    if not trend_data or max_value == 0:
        return {
            'bars': [],
            'width': width,
            'height': height,
            'max_value': 0,
            'has_data': False
        }
    
    bar_width = (width - 40) / len(trend_data)  # Leave margin for labels
    bars = []
    
    for i, day in enumerate(trend_data):
        # Calculate bar height (leave space for x-axis labels)
        chart_height = height - 30
        bar_height = (day['count'] / max(max_value, 1)) * chart_height
        
        # Calculate positions
        x = 20 + (i * bar_width) + (bar_width * 0.1)  # Small gap between bars
        y = height - 30 - bar_height
        bar_width_actual = bar_width * 0.8
        
        bars.append({
            'x': x,
            'y': y,
            'width': bar_width_actual,
            'height': bar_height,
            'count': day['count'],
            'date': day['date_short'],
            'label_x': x + (bar_width_actual / 2),
            'label_y': height - 10
        })
    
    return {
        'bars': bars,
        'width': width,
        'height': height,
        'max_value': max_value,
        'has_data': True,
        'y_axis_labels': [
            {'value': 0, 'y': height - 30},
            {'value': max_value // 2, 'y': height - 30 - (chart_height // 2)},
            {'value': max_value, 'y': height - 30 - chart_height}
        ]
    }

@router.get("/page", response_class=HTMLResponse)
async def metrics_page(request: Request):
    """
    Server-side rendered metrics dashboard with charts and cards.
    """
    logger.info("GET /metrics/page - HTML metrics dashboard requested")
    
    try:
        # Get comprehensive metrics data
        chart_data = get_chart_data()
        conversion_data = get_conversion_metrics()
        
        # Prepare SVG chart data
        leads_chart = prepare_chart_svg_data(
            chart_data['trends']['leads'],
            chart_data['max_values']['leads'],
            width=600,
            height=250
        )
        
        sales_chart = prepare_chart_svg_data(
            chart_data['trends']['sales'],
            chart_data['max_values']['sales'],
            width=600,
            height=250
        )
        
        # Calculate some additional display metrics
        totals = chart_data['totals']
        revenue_per_sale = (totals.get('total_revenue_dollars', 0) / 
                           max(totals.get('sales', 1), 1))
        
        context = {
            "request": request,
            "totals": totals,
            "conversion_metrics": conversion_data,
            "leads_chart": leads_chart,
            "sales_chart": sales_chart,
            "revenue_per_sale": round(revenue_per_sale, 2),
            "chart_period": "14 days"
        }
        
        try:
            return templates.TemplateResponse("p15__server-templates-metrics.html", context)
        except Exception as e:
            logger.error(f"Template error: {e}")
            # Fallback HTML response
            return HTMLResponse(f"""
            <html>
            <head><title>Metrics Dashboard</title></head>
            <body style="font-family: Arial, sans-serif; padding: 2rem; background: #1a1a1a; color: white;">
                <h1>Metrics Dashboard</h1>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 2rem 0;">
                    <div style="background: #2d2d2d; padding: 1.5rem; border-radius: 8px;">
                        <h3>Total Leads</h3>
                        <div style="font-size: 2rem; color: #3b82f6;">{totals.get('leads', 0)}</div>
                    </div>
                    <div style="background: #2d2d2d; padding: 1.5rem; border-radius: 8px;">
                        <h3>Total Sales</h3>
                        <div style="font-size: 2rem; color: #22c55e;">{totals.get('sales', 0)}</div>
                    </div>
                    <div style="background: #2d2d2d; padding: 1.5rem; border-radius: 8px;">
                        <h3>Revenue</h3>
                        <div style="font-size: 2rem; color: #10b981;">${totals.get('total_revenue_dollars', 0):.2f}</div>
                    </div>
                    <div style="background: #2d2d2d; padding: 1.5rem; border-radius: 8px;">
                        <h3>Conversion Rate</h3>
                        <div style="font-size: 2rem; color: #f59e0b;">{conversion_data.get('conversion_rate', 0)}%</div>
                    </div>
                </div>
                <p>Chart visualization requires full template support.</p>
            </body>
            </html>
            """)
            
    except Exception as e:
        logger.error(f"Failed to load metrics page: {e}")
        raise HTTPException(status_code=500, detail="Failed to load metrics page")

@router.get("/chart-data", response_model=Dict[str, Any])
async def get_chart_data_json():
    """
    Get chart data as JSON for client-side rendering if needed.
    """
    logger.info("GET /metrics/chart-data - JSON chart data requested")
    
    try:
        chart_data = get_chart_data()
        conversion_data = get_conversion_metrics()
        
        result = {
            **chart_data,
            'conversion_metrics': conversion_data,
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info("Chart data JSON returned successfully")
        return result
        
    except Exception as e:
        logger.error(f"Failed to get chart data: {e}")
        raise HTTPException(status_code=500, detail="Failed to get chart data")

# Log router initialization
logger.info("Metrics UI routes initialized: GET /page, GET /chart-data")
