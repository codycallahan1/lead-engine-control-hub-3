"""
Lead Engine Control Hub - Lead Services
Phase: 3
Purpose: Service layer for lead operations (CRUD) using database sessions
Key Responsibilities:
- Lead creation, retrieval, update, and deletion
- Business logic for lead management
- Database session handling
- Error handling and logging
"""

import logging
from typing import List, Optional

from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

# Import database and models
try:
    from p02__server_db import get_session
    from p02__server_models import Lead
    from p02__server_schemas import LeadIn, LeadOut, LeadUpdate
except ImportError as e:
    logging.warning(f"Import error in leads service: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 files are available")

logger = logging.getLogger(__name__)

class LeadService:
    """Service class for Lead operations"""
    
    @staticmethod
    def get_all_leads() -> List[Lead]:
        """
        Retrieve all leads from the database.
        
        Returns:
            List of Lead objects
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                leads = db.query(Lead).order_by(Lead.created_at.desc()).all()
                logger.info(f"Retrieved {len(leads)} leads")
                return leads
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve leads: {e}")
            raise
    
    @staticmethod
    def get_lead_by_id(lead_id: int) -> Optional[Lead]:
        """
        Retrieve a lead by ID.
        
        Args:
            lead_id: ID of the lead to retrieve
            
        Returns:
            Lead object or None if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                lead = db.query(Lead).filter(Lead.id == lead_id).first()
                if lead:
                    logger.info(f"Retrieved lead: {lead}")
                else:
                    logger.info(f"Lead not found with ID: {lead_id}")
                return lead
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve lead {lead_id}: {e}")
            raise
    
    @staticmethod
    def get_lead_by_email(email: str) -> Optional[Lead]:
        """
        Retrieve a lead by email address.
        
        Args:
            email: Email address to search for
            
        Returns:
            Lead object or None if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                lead = db.query(Lead).filter(Lead.email == email).first()
                if lead:
                    logger.info(f"Retrieved lead by email: {lead}")
                else:
                    logger.info(f"Lead not found with email: {email}")
                return lead
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve lead by email {email}: {e}")
            raise
    
    @staticmethod
    def create_lead(lead_data: LeadIn) -> Lead:
        """
        Create a new lead.
        
        Args:
            lead_data: Lead input data
            
        Returns:
            Created Lead object
            
        Raises:
            IntegrityError: If email already exists
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                # Create new lead instance
                lead = Lead(
                    name=lead_data.name,
                    email=lead_data.email,
                    phone=lead_data.phone
                )
                
                db.add(lead)
                db.flush()  # Flush to get the ID before commit
                db.refresh(lead)  # Refresh to get all fields including created_at
                
                logger.info(f"Created lead: {lead}")
                return lead
                
        except IntegrityError as e:
            logger.error(f"Lead creation failed - email already exists: {lead_data.email}")
            raise ValueError(f"Lead with email {lead_data.email} already exists")
        except SQLAlchemyError as e:
            logger.error(f"Failed to create lead: {e}")
            raise
    
    @staticmethod
    def update_lead(lead_id: int, lead_data: LeadUpdate) -> Optional[Lead]:
        """
        Update an existing lead.
        
        Args:
            lead_id: ID of the lead to update
            lead_data: Lead update data
            
        Returns:
            Updated Lead object or None if not found
            
        Raises:
            IntegrityError: If email update conflicts with existing lead
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                lead = db.query(Lead).filter(Lead.id == lead_id).first()
                
                if not lead:
                    logger.info(f"Lead not found for update: {lead_id}")
                    return None
                
                # Update only provided fields
                update_data = lead_data.dict(exclude_unset=True)
                for field, value in update_data.items():
                    setattr(lead, field, value)
                
                db.flush()  # Flush to check for constraint violations
                db.refresh(lead)  # Refresh to get updated fields
                
                logger.info(f"Updated lead: {lead}")
                return lead
                
        except IntegrityError as e:
            logger.error(f"Lead update failed - email conflict: {lead_data.email}")
            raise ValueError(f"Lead with email {lead_data.email} already exists")
        except SQLAlchemyError as e:
            logger.error(f"Failed to update lead {lead_id}: {e}")
            raise
    
    @staticmethod
    def delete_lead(lead_id: int) -> bool:
        """
        Delete a lead by ID.
        
        Args:
            lead_id: ID of the lead to delete
            
        Returns:
            True if deleted, False if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                lead = db.query(Lead).filter(Lead.id == lead_id).first()
                
                if not lead:
                    logger.info(f"Lead not found for deletion: {lead_id}")
                    return False
                
                db.delete(lead)
                logger.info(f"Deleted lead: {lead}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Failed to delete lead {lead_id}: {e}")
            raise
    
    @staticmethod
    def search_leads(query: str) -> List[Lead]:
        """
        Search leads by name or email.
        
        Args:
            query: Search query string
            
        Returns:
            List of matching Lead objects
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                search_pattern = f"%{query}%"
                leads = db.query(Lead).filter(
                    (Lead.name.ilike(search_pattern)) |
                    (Lead.email.ilike(search_pattern))
                ).order_by(Lead.created_at.desc()).all()
                
                logger.info(f"Search for '{query}' returned {len(leads)} leads")
                return leads
                
        except SQLAlchemyError as e:
            logger.error(f"Failed to search leads with query '{query}': {e}")
            raise
    
    @staticmethod
    def get_leads_count() -> int:
        """
        Get total count of leads.
        
        Returns:
            Number of leads in database
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                count = db.query(Lead).count()
                logger.info(f"Lead count: {count}")
                return count
        except SQLAlchemyError as e:
            logger.error(f"Failed to get leads count: {e}")
            raise

# Convenience functions for direct usage
def list_leads() -> List[Lead]:
    """Get all leads"""
    return LeadService.get_all_leads()

def get_lead(lead_id: int) -> Optional[Lead]:
    """Get lead by ID"""
    return LeadService.get_lead_by_id(lead_id)

def create_lead(lead_data: LeadIn) -> Lead:
    """Create new lead"""
    return LeadService.create_lead(lead_data)

def update_lead(lead_id: int, lead_data: LeadUpdate) -> Optional[Lead]:
    """Update existing lead"""
    return LeadService.update_lead(lead_id, lead_data)

def delete_lead(lead_id: int) -> bool:
    """Delete lead"""
    return LeadService.delete_lead(lead_id)

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Lead Services Module Test ===")
    
    try:
        # Test getting all leads (should be empty initially)
        leads = LeadService.get_all_leads()
        logger.info(f"Current leads count: {len(leads)}")
        
        # Test getting count
        count = LeadService.get_leads_count()
        logger.info(f"Leads count from service: {count}")
        
        logger.info("✅ Lead services module test completed")
        
    except Exception as e:
        logger.error(f"Lead services test failed: {e}")
        logger.info("Note: This is expected if database/models are not available")