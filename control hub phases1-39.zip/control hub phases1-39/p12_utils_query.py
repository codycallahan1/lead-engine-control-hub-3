"""
Query utilities for pagination, filtering, and sorting.

Phase: 12
Purpose: Helpers to parse query parameters and apply them to SQLAlchemy queries
Key responsibilities: parse_query_params, apply_query functions
"""

import logging
from typing import Dict, Any, List, Optional
from fastapi import Request
from sqlalchemy.orm import Query
from sqlalchemy import asc, desc, or_

logger = logging.getLogger(__name__)

def parse_query_params(request: Request) -> Dict[str, Any]:
    """
    Parse standard query parameters from request.
    
    Returns dict with: page, per_page, sort, q
    """
    try:
        page = max(1, int(request.query_params.get('page', 1)))
    except (ValueError, TypeError):
        page = 1
        
    try:
        per_page = min(100, max(1, int(request.query_params.get('per_page', 20))))
    except (ValueError, TypeError):
        per_page = 20
        
    sort = request.query_params.get('sort', '').strip()
    q = request.query_params.get('q', '').strip()
    
    params = {
        'page': page,
        'per_page': per_page,
        'sort': sort,
        'q': q
    }
    
    logger.info(f"Parsed query params: {params}")
    return params

def apply_query(
    model_query: Query, 
    params: Dict[str, Any], 
    searchable_cols: List[str], 
    sortable_cols: List[str]
) -> tuple[Query, int]:
    """
    Apply search, sort, and pagination to a SQLAlchemy query.
    
    Args:
        model_query: Base SQLAlchemy query
        params: Dict from parse_query_params
        searchable_cols: List of column names that can be searched with LIKE
        sortable_cols: List of column names that can be sorted
        
    Returns:
        Tuple of (modified_query, total_count)
    """
    base_query = model_query
    
    # Apply search filter
    if params.get('q'):
        search_term = f"%{params['q']}%"
        search_conditions = []
        
        for col_name in searchable_cols:
            if hasattr(model_query.column_descriptions[0]['type'], col_name):
                col = getattr(model_query.column_descriptions[0]['type'], col_name)
                search_conditions.append(col.ilike(search_term))
        
        if search_conditions:
            base_query = base_query.filter(or_(*search_conditions))
            logger.info(f"Applied search filter for term: {params['q']}")
    
    # Get total count before pagination
    total_count = base_query.count()
    
    # Apply sorting
    if params.get('sort'):
        sort_field = params['sort']
        descending = sort_field.startswith('-')
        
        if descending:
            sort_field = sort_field[1:]
            
        if sort_field in sortable_cols:
            if hasattr(model_query.column_descriptions[0]['type'], sort_field):
                col = getattr(model_query.column_descriptions[0]['type'], sort_field)
                if descending:
                    base_query = base_query.order_by(desc(col))
                else:
                    base_query = base_query.order_by(asc(col))
                logger.info(f"Applied sort: {params['sort']}")
    
    # Apply pagination
    offset = (params['page'] - 1) * params['per_page']
    base_query = base_query.offset(offset).limit(params['per_page'])
    
    logger.info(f"Applied pagination: page={params['page']}, per_page={params['per_page']}, total={total_count}")
    
    return base_query, total_count
