"""
Lead Engine Control Hub - SQLAlchemy Models
Phase: 2
Purpose: Define database models for Lead, Buyer, and Site entities
Key Responsibilities:
- Lead model with contact information and timestamps
- Buyer model for lead purchasers
- Site model for tracking different sites/sources
- Proper relationships and constraints
"""

import logging
from datetime import datetime
from typing import Optional

from sqlalchemy import Column, Integer, String, DateTime, Text
from sqlalchemy.sql import func

# Import Base from database module
try:
    from p02__server_db import Base
except ImportError:
    # Fallback for standalone testing
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()
    logging.warning("Using fallback Base class - ensure p02__server-db.py is available")

logger = logging.getLogger(__name__)

class Lead(Base):
    """
    Lead model representing potential customers.
    
    Attributes:
        id: Primary key
        name: Full name of the lead
        email: Email address (required)
        phone: Phone number (optional)
        created_at: Timestamp when lead was created
    """
    __tablename__ = "leads"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    email = Column(String(255), nullable=False, unique=True, index=True)
    phone = Column(String(50), nullable=True)
    created_at = Column(
        DateTime(timezone=True), 
        server_default=func.now(),
        nullable=False
    )
    
    def __repr__(self):
        return f"<Lead(id={self.id}, name='{self.name}', email='{self.email}')>"
    
    def to_dict(self):
        """Convert model instance to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "phone": self.phone,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

class Buyer(Base):
    """
    Buyer model representing entities that purchase leads.
    
    Attributes:
        id: Primary key
        name: Buyer company/individual name
        email: Contact email for the buyer
        created_at: Timestamp when buyer was registered
    """
    __tablename__ = "buyers"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    email = Column(String(255), nullable=False, unique=True, index=True)
    created_at = Column(
        DateTime(timezone=True), 
        server_default=func.now(),
        nullable=False
    )
    
    def __repr__(self):
        return f"<Buyer(id={self.id}, name='{self.name}', email='{self.email}')>"
    
    def to_dict(self):
        """Convert model instance to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

class Site(Base):
    """
    Site model representing different websites or sources that generate leads.
    
    Attributes:
        id: Primary key
        name: Display name for the site
        domain: Domain name of the site
        status: Site status (active, inactive, etc.)
        created_at: Timestamp when site was registered
    """
    __tablename__ = "sites"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    domain = Column(String(255), nullable=False, unique=True, index=True)
    status = Column(String(50), default="active", nullable=False, index=True)
    created_at = Column(
        DateTime(timezone=True), 
        server_default=func.now(),
        nullable=False
    )
    
    def __repr__(self):
        return f"<Site(id={self.id}, name='{self.name}', domain='{self.domain}', status='{self.status}')>"
    
    def to_dict(self):
        """Convert model instance to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "domain": self.domain,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

# Model registry for easy access
MODELS = {
    "Lead": Lead,
    "Buyer": Buyer,
    "Site": Site
}

def get_model_by_name(model_name: str):
    """
    Get model class by name.
    
    Args:
        model_name: Name of the model ("Lead", "Buyer", "Site")
        
    Returns:
        Model class or None if not found
    """
    return MODELS.get(model_name)

def get_all_models():
    """
    Get list of all model classes.
    
    Returns:
        List of model classes
    """
    return list(MODELS.values())

def create_sample_data():
    """
    Create sample data for testing purposes.
    Note: This requires a database session to be provided externally.
    """
    sample_leads = [
        {"name": "John Doe", "email": "john@example.com", "phone": "555-0101"},
        {"name": "Jane Smith", "email": "jane@example.com", "phone": "555-0102"},
        {"name": "Bob Johnson", "email": "bob@example.com", "phone": None},
    ]
    
    sample_buyers = [
        {"name": "ABC Corp", "email": "contact@abccorp.com"},
        {"name": "XYZ Industries", "email": "leads@xyzind.com"},
    ]
    
    sample_sites = [
        {"name": "Main Site", "domain": "example.com", "status": "active"},
        {"name": "Landing Page", "domain": "landing.example.com", "status": "active"},
        {"name": "Old Site", "domain": "old.example.com", "status": "inactive"},
    ]
    
    return {
        "leads": [Lead(**data) for data in sample_leads],
        "buyers": [Buyer(**data) for data in sample_buyers],
        "sites": [Site(**data) for data in sample_sites]
    }

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Models Module Test ===")
    
    # Test model creation
    lead = Lead(name="Test Lead", email="test@example.com", phone="555-0000")
    buyer = Buyer(name="Test Buyer", email="buyer@example.com")
    site = Site(name="Test Site", domain="test.com", status="active")
    
    logger.info(f"Created lead: {lead}")
    logger.info(f"Created buyer: {buyer}")
    logger.info(f"Created site: {site}")
    
    # Test to_dict methods
    logger.info(f"Lead dict: {lead.to_dict()}")
    logger.info(f"Buyer dict: {buyer.to_dict()}")
    logger.info(f"Site dict: {site.to_dict()}")
    
    # Test model registry
    logger.info(f"Available models: {list(MODELS.keys())}")
    logger.info("✅ Models module test completed")
