"""
Lightweight In-Process Scheduler Service
Phase 19: Simple thread-based scheduler for daily tasks
Key responsibilities: Run daily metrics capture, manage background tasks
"""

import threading
import time
import logging
from datetime import datetime, timezone
from typing import Dict, Callable, Optional

logger = logging.getLogger(__name__)

class SimpleScheduler:
    """
    Lightweight scheduler for periodic tasks
    Runs in a separate daemon thread
    """
    
    def __init__(self):
        self.tasks: Dict[str, Dict] = {}
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
    
    def add_daily_task(self, name: str, handler: Callable, hour: int = 0, minute: int = 5):
        """
        Add a daily task to run at specified UTC time
        
        Args:
            name: Task identifier
            handler: Function to call
            hour: Hour (0-23) in UTC
            minute: Minute (0-59)
        """
        self.tasks[name] = {
            "handler": handler,
            "hour": hour,
            "minute": minute,
            "last_run": None,
            "type": "daily"
        }
        logger.info(f"Scheduled daily task '{name}' for {hour:02d}:{minute:02d} UTC")
    
    def start(self):
        """Start the scheduler in a background thread"""
        if self.running:
            logger.warning("Scheduler already running")
            return
        
        self.running = True
        self._stop_event.clear()
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        logger.info("Scheduler started")
    
    def stop(self):
        """Stop the scheduler"""
        if not self.running:
            return
        
        self.running = False
        self._stop_event.set()
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Scheduler stopped")
    
    def _run_loop(self):
        """Main scheduler loop"""
        logger.info("Scheduler loop started")
        
        while self.running and not self._stop_event.is_set():
            try:
                current_time = datetime.now(timezone.utc)
                
                for task_name, task_config in self.tasks.items():
                    if self._should_run_task(task_name, task_config, current_time):
                        self._run_task(task_name, task_config)
                
                # Sleep for 60 seconds, checking stop event every 5 seconds
                for _ in range(12):  # 12 * 5 = 60 seconds
                    if self._stop_event.wait(5):
                        break
                        
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}")
                time.sleep(60)  # Wait before retrying
        
        logger.info("Scheduler loop ended")
    
    def _should_run_task(self, task_name: str, task_config: Dict, current_time: datetime) -> bool:
        """Check if a task should run now"""
        if task_config["type"] != "daily":
            return False
        
        target_hour = task_config["hour"]
        target_minute = task_config["minute"]
        last_run = task_config["last_run"]
        
        # Check if we're at or past the target time today
        today = current_time.date()
        target_time = datetime.combine(today, datetime.min.time().replace(
            hour=target_hour, minute=target_minute
        )).replace(tzinfo=timezone.utc)
        
        # Don't run if current time is before target time
        if current_time < target_time:
            return False
        
        # Don't run if we already ran today
        if last_run and last_run.date() == today:
            return False
        
        return True
    
    def _run_task(self, task_name: str, task_config: Dict):
        """Execute a scheduled task"""
        try:
            logger.info(f"Running scheduled task: {task_name}")
            start_time = time.time()
            
            # Execute the task handler
            handler = task_config["handler"]
            result = handler()
            
            elapsed = time.time() - start_time
            task_config["last_run"] = datetime.now(timezone.utc)
            
            logger.info(f"Task '{task_name}' completed in {elapsed:.2f}s: {result}")
            
        except Exception as e:
            logger.error(f"Error running task '{task_name}': {e}")

# Global scheduler instance
_scheduler = None

def get_scheduler() -> SimpleScheduler:
    """Get the global scheduler instance"""
    global _scheduler
    if _scheduler is None:
        _scheduler = SimpleScheduler()
    return _scheduler

def start_scheduler():
    """Start the global scheduler with default tasks"""
    scheduler = get_scheduler()
    
    # Import and register metrics capture task
    try:
        from p19__server_services_metrics_capture import capture_metrics
        scheduler.add_daily_task("capture_metrics", capture_metrics, hour=0, minute=5)
    except ImportError:
        logger.warning("Could not import metrics capture - task not registered")
        # Register a mock handler for testing
        def mock_capture():
            logger.info("Mock metrics capture executed")
            return "mock_success"
        scheduler.add_daily_task("capture_metrics", mock_capture, hour=0, minute=5)
    
    scheduler.start()
    logger.info("Scheduler started with daily metrics capture task")

def stop_scheduler():
    """Stop the global scheduler"""
    scheduler = get_scheduler()
    scheduler.stop()

def get_scheduler_status() -> Dict:
    """Get current scheduler status"""
    scheduler = get_scheduler()
    
    next_runs = {}
    current_time = datetime.now(timezone.utc)
    
    for task_name, task_config in scheduler.tasks.items():
        if task_config["type"] == "daily":
            today = current_time.date()
            target_time = datetime.combine(today, datetime.min.time().replace(
                hour=task_config["hour"], minute=task_config["minute"]
            )).replace(tzinfo=timezone.utc)
            
            # If target time has passed today, schedule for tomorrow
            if current_time >= target_time:
                from datetime import timedelta
                target_time += timedelta(days=1)
            
            next_runs[task_name] = {
                "next_run": target_time.isoformat(),
                "last_run": task_config["last_run"].isoformat() if task_config["last_run"] else None
            }
    
    return {
        "running": scheduler.running,
        "tasks_count": len(scheduler.tasks),
        "next_runs": next_runs
    }
