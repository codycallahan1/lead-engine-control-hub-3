"""
Lead Engine Control Hub - Compliance Routes
Phase 34: Consent flags and PII redaction utilities
Purpose: REST API endpoints for compliance and consent management
"""

import logging
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field

# Import compliance services and auth
try:
    from p34__server_services_redaction import (
        get_compliance_policy, apply_redaction_policy, create_redaction_preview,
        validate_redaction_settings
    )
    from p34__server_models_compliance import ComplianceSetting, ConsentLog
    from p20__server_middleware_auth import require_role
    from p24__server_services_scope import current_org
    from p02__server_db import get_session
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    def get_compliance_policy(org_id):
        class MockPolicy:
            mask_email = False
            mask_phone = False
            export_mask = False
            log_pii_access = True
            require_consent = False
            retention_days = None
        return MockPolicy()
    
    def apply_redaction_policy(data, org_id, context="display"):
        return data
    
    def create_redaction_preview(data, org_id):
        return {"policy": {}, "examples": {}}
    
    def validate_redaction_settings(settings):
        return {}
    
    def require_role(*roles):
        return lambda: None
    
    def current_org(request):
        return 1
    
    def get_session():
        pass
    
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")
    
    class ComplianceSetting:
        pass
    
    class ConsentLog:
        pass

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/compliance", tags=["compliance"])


# Request/Response models
class ComplianceSettingsRequest(BaseModel):
    mask_email: Optional[bool] = None
    mask_phone: Optional[bool] = None
    export_mask: Optional[bool] = None
    log_pii_access: Optional[bool] = None
    require_consent: Optional[bool] = None
    retention_days: Optional[int] = None


class ComplianceSettingsResponse(BaseModel):
    org_id: int
    mask_email: bool
    mask_phone: bool
    export_mask: bool
    log_pii_access: bool
    require_consent: bool
    retention_days: Optional[int]
    updated_at: Optional[str]
    updated_by: Optional[str]


class ConsentUpdateRequest(BaseModel):
    opt_in: bool = Field(..., description="True for opt-in, False for opt-out")
    source: Optional[str] = Field(None, max_length=50, description="Source of consent change")
    tags: Optional[List[str]] = Field(None, description="Additional tags to add")
    notes: Optional[str] = Field(None, max_length=1000, description="Additional notes")


class RedactionPreviewRequest(BaseModel):
    sample_data: dict = Field(..., description="Sample data to preview redaction")


# Routes
@router.get("/settings", response_model=ComplianceSettingsResponse)
async def get_compliance_settings(
    request: Request,
    _: None = Depends(require_role("admin"))
):
    """
    Get current compliance settings for the organization.
    
    Returns current PII masking and consent requirements.
    """
    try:
        org_id = current_org(request)
        policy = get_compliance_policy(org_id)
        
        return ComplianceSettingsResponse(
            org_id=org_id,
            mask_email=policy.mask_email,
            mask_phone=policy.mask_phone,
            export_mask=policy.export_mask,
            log_pii_access=policy.log_pii_access,
            require_consent=policy.require_consent,
            retention_days=policy.retention_days,
            updated_at=policy.updated_at.isoformat() if hasattr(policy, 'updated_at') and policy.updated_at else None,
            updated_by=policy.updated_by if hasattr(policy, 'updated_by') else None
        )
        
    except Exception as e:
        logger.error(f"Error retrieving compliance settings: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve compliance settings")


@router.put("/settings")
async def update_compliance_settings(
    request: Request,
    settings: ComplianceSettingsRequest,
    _: None = Depends(require_role("admin"))
):
    """
    Update compliance settings for the organization.
    
    Only admins can modify compliance policies.
    Changes are audited and applied immediately.
    """
    try:
        org_id = current_org(request)
        
        # Validate settings
        settings_dict = settings.dict(exclude_unset=True)
        validation_errors = validate_redaction_settings(settings_dict)
        
        if validation_errors:
            raise HTTPException(
                status_code=400,
                detail={"message": "Invalid settings", "errors": validation_errors}
            )
        
        # Get or create compliance settings
        with get_session() as session:
            policy = session.query(ComplianceSetting).filter_by(org_id=org_id).first()
            
            if not policy:
                policy = ComplianceSetting(org_id=org_id)
                session.add(policy)
            
            # Track changes for audit
            changes = {}
            
            # Update fields that were provided
            for field, value in settings_dict.items():
                if hasattr(policy, field):
                    old_value = getattr(policy, field)
                    if old_value != value:
                        changes[field] = {"from": old_value, "to": value}
                        setattr(policy, field, value)
            
            # Update metadata
            policy.updated_at = datetime.utcnow()
            policy.updated_by = "admin"  # Could extract from request.state.user
            
            session.commit()
            session.refresh(policy)
            
            # Audit the changes
            if changes:
                audit(
                    kind="compliance_settings_updated",
                    message=f"Compliance settings updated for org {org_id}",
                    meta={
                        "org_id": org_id,
                        "changes": changes,
                        "updated_by": "admin"
                    }
                )
            
            logger.info(f"Updated compliance settings for org {org_id}: {changes}")
            
            return {
                "success": True,
                "message": "Compliance settings updated successfully",
                "changes": changes,
                "settings": policy.to_dict() if hasattr(policy, 'to_dict') else settings_dict
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating compliance settings: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to update compliance settings")


@router.post("/leads/{lead_id}/consent")
async def update_lead_consent(
    lead_id: int,
    request: Request,
    consent_data: ConsentUpdateRequest,
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Update consent status for a specific lead.
    
    Records consent changes with full audit trail.
    Updates lead record and creates consent log entry.
    """
    try:
        org_id = current_org(request)
        
        with get_session() as session:
            # Verify lead exists and belongs to org
            lead = session.query("Lead").filter_by(id=lead_id, org_id=org_id).first()
            if not lead:
                raise HTTPException(status_code=404, detail="Lead not found")
            
            # Get current consent status
            old_consent = getattr(lead, 'consent_opt_in', None) if hasattr(lead, 'consent_opt_in') else None
            
            # Update lead consent fields (these would be added to Lead model)
            # lead.consent_opt_in = consent_data.opt_in
            # lead.consent_date = datetime.utcnow()
            # lead.consent_source = consent_data.source
            
            # Update tags if provided
            current_tags = getattr(lead, 'tags', []) if hasattr(lead, 'tags') else []
            if consent_data.tags:
                # Add new tags, avoiding duplicates
                updated_tags = list(set(current_tags + consent_data.tags))
                # lead.tags = updated_tags
            
            # Create consent log entry
            consent_log = ConsentLog(
                org_id=org_id,
                lead_id=lead_id,
                old_consent=old_consent,
                new_consent=consent_data.opt_in,
                source=consent_data.source,
                tags_added=consent_data.tags,
                notes=consent_data.notes,
                created_by="admin",  # Could extract from request
                ip_address=request.client.host if hasattr(request, 'client') else None
            )
            
            session.add(consent_log)
            session.commit()
            session.refresh(consent_log)
            
            # Audit the consent change
            audit(
                kind="consent_updated",
                message=f"Consent updated for lead {lead_id}: {old_consent} -> {consent_data.opt_in}",
                meta={
                    "lead_id": lead_id,
                    "org_id": org_id,
                    "old_consent": old_consent,
                    "new_consent": consent_data.opt_in,
                    "source": consent_data.source,
                    "consent_log_id": consent_log.id,
                    "action": consent_log.consent_action if hasattr(consent_log, 'consent_action') else "updated"
                }
            )
            
            logger.info(f"Updated consent for lead {lead_id}: {old_consent} -> {consent_data.opt_in}")
            
            return {
                "success": True,
                "message": f"Consent updated for lead {lead_id}",
                "lead_id": lead_id,
                "old_consent": old_consent,
                "new_consent": consent_data.opt_in,
                "action": consent_log.consent_action if hasattr(consent_log, 'consent_action') else "updated",
                "consent_log_id": consent_log.id,
                "updated_at": consent_log.created_at.isoformat()
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating consent for lead {lead_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to update consent")


@router.post("/preview")
async def preview_redaction(
    request: Request,
    preview_data: RedactionPreviewRequest,
    _: None = Depends(require_role("admin"))
):
    """
    Preview how data would look with current redaction settings.
    
    Useful for testing and demonstrating redaction policies
    before applying them to real data.
    """
    try:
        org_id = current_org(request)
        
        preview = create_redaction_preview(preview_data.sample_data, org_id)
        
        return {
            "org_id": org_id,
            "preview": preview,
            "note": "This preview shows how data would appear with current settings"
        }
        
    except Exception as e:
        logger.error(f"Error creating redaction preview: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to create preview")


@router.get("/leads/{lead_id}/consent-history")
async def get_lead_consent_history(
    lead_id: int,
    request: Request,
    limit: int = 20,
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Get consent change history for a specific lead.
    
    Returns chronological list of all consent changes
    with full audit information.
    """
    try:
        org_id = current_org(request)
        
        with get_session() as session:
            # Verify lead exists
            lead = session.query("Lead").filter_by(id=lead_id, org_id=org_id).first()
            if not lead:
                raise HTTPException(status_code=404, detail="Lead not found")
            
            # Get consent history
            consent_logs = session.query(ConsentLog).filter_by(
                lead_id=lead_id,
                org_id=org_id
            ).order_by(ConsentLog.created_at.desc()).limit(limit).all()
            
            history = []
            for log in consent_logs:
                history.append({
                    "id": log.id,
                    "old_consent": log.old_consent,
                    "new_consent": log.new_consent,
                    "action": log.consent_action if hasattr(log, 'consent_action') else "unknown",
                    "source": log.source,
                    "tags_added": log.tags_added,
                    "notes": log.notes,
                    "created_at": log.created_at.isoformat(),
                    "created_by": log.created_by,
                    "ip_address": log.ip_address
                })
            
            return {
                "lead_id": lead_id,
                "history": history,
                "total_entries": len(history),
                "limit": limit
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving consent history for lead {lead_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve consent history")


@router.get("/data-processing-log")
async def get_data_processing_log(
    request: Request,
    days: int = 30,
    activity: Optional[str] = None,
    limit: int = 100,
    _: None = Depends(require_role("admin"))
):
    """
    Get data processing activity log for compliance reporting.
    
    Returns log of PII access and processing activities
    for the specified time period.
    """
    try:
        org_id = current_org(request)
        
        # This would query DataProcessingLog model
        # For now, return mock data structure
        
        processing_log = {
            "org_id": org_id,
            "period_days": days,
            "activity_filter": activity,
            "entries": [],  # Would contain actual log entries
            "summary": {
                "total_activities": 0,
                "unique_leads_accessed": 0,
                "most_common_activities": [],
                "compliance_notes": "Data processing log available for audit"
            }
        }
        
        return processing_log
        
    except Exception as e:
        logger.error(f"Error retrieving data processing log: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve processing log")


# Include router in main app
def include_compliance_routes(app):
    """Include compliance routes in the main FastAPI app."""
    app.include_router(router)
    logger.info("Compliance management routes registered")
