"""
Lead Engine Control Hub - Dispatch Credit Integration
Phase 33: Buyer credits and spend controls
Purpose: Integration hooks for credit checking and charging in dispatch workflow
"""

import logging
from typing import Optional

# Import credit services and dispatch components
try:
    from p33__server_services_credits import (
        ensure_sufficient_credit, charge_credit, get_credit_info,
        InsufficientCreditError
    )
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    def ensure_sufficient_credit(buyer_id, org_id, amount_cents):
        return True
    def charge_credit(buyer_id, org_id, lead_id, amount_cents, note=None, created_by="system"):
        return None, None
    def get_credit_info(buyer_id, org_id):
        return {"balance_dollars": 100}
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")
    
    class InsufficientCreditError(Exception):
        pass

logger = logging.getLogger(__name__)


def get_buyer_cpl(buyer_id: int, org_id: int) -> int:
    """
    Get cost-per-lead for a buyer in cents.
    
    In a real implementation, this would query the Buyer model
    for the cpl_cents field added in the migration.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
    
    Returns:
        Cost per lead in cents (defaults to $10.00)
    """
    # TODO: Query actual Buyer model when CPL field is added
    # For now, return default $10.00
    return 1000  # $10.00 in cents


def pre_dispatch_credit_check(buyer_id: int, org_id: int, lead_id: int) -> dict:
    """
    Verify buyer has sufficient credit before dispatching a lead.
    
    This should be called before any dispatch operation to ensure
    the buyer can afford the lead.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier  
        lead_id: Lead identifier
    
    Returns:
        Dictionary with check results and details
    """
    try:
        # Get cost per lead for this buyer
        cpl_cents = get_buyer_cpl(buyer_id, org_id)
        
        # Check if buyer has sufficient credit
        ensure_sufficient_credit(buyer_id, org_id, cpl_cents)
        
        # Get current credit info for logging
        credit_info = get_credit_info(buyer_id, org_id)
        
        logger.info(
            f"Credit check passed for buyer {buyer_id}: ${cpl_cents/100:.2f} charge, "
            f"${credit_info['balance_dollars']:.2f} available"
        )
        
        return {
            "approved": True,
            "buyer_id": buyer_id,
            "lead_id": lead_id,
            "charge_cents": cpl_cents,
            "charge_dollars": cpl_cents / 100,
            "remaining_balance_cents": credit_info["balance_cents"],
            "remaining_balance_dollars": credit_info["balance_dollars"],
            "message": "Credit check passed"
        }
        
    except InsufficientCreditError as e:
        logger.warning(f"Credit check failed for buyer {buyer_id}: {str(e)}")
        
        # Log the blocked transaction
        audit(
            kind="credit_blocked",
            message=f"Dispatch blocked for buyer {buyer_id} due to insufficient credit",
            meta={
                "buyer_id": buyer_id,
                "lead_id": lead_id,
                "required_dollars": cpl_cents / 100,
                "error": str(e)
            }
        )
        
        return {
            "approved": False,
            "buyer_id": buyer_id,
            "lead_id": lead_id,
            "charge_cents": cpl_cents,
            "charge_dollars": cpl_cents / 100,
            "error": str(e),
            "message": "Insufficient credit for dispatch"
        }
        
    except Exception as e:
        logger.error(f"Unexpected error in credit check for buyer {buyer_id}: {str(e)}")
        
        return {
            "approved": False,
            "buyer_id": buyer_id,
            "lead_id": lead_id,
            "error": "Credit check system error",
            "message": "Unable to verify credit status"
        }


def post_dispatch_credit_charge(buyer_id: int, org_id: int, lead_id: int, 
                               dispatch_success: bool, dispatch_log_id: Optional[int] = None) -> dict:
    """
    Charge buyer's credit after successful lead dispatch.
    
    Only charges if dispatch was successful. Failed dispatches don't incur charges.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        lead_id: Lead identifier
        dispatch_success: Whether the dispatch was successful
        dispatch_log_id: Optional reference to dispatch log entry
    
    Returns:
        Dictionary with charge results
    """
    if not dispatch_success:
        logger.info(f"Skipping credit charge for buyer {buyer_id} - dispatch failed")
        return {
            "charged": False,
            "reason": "dispatch_failed",
            "message": "No charge applied - dispatch was unsuccessful"
        }
    
    try:
        # Get cost per lead
        cpl_cents = get_buyer_cpl(buyer_id, org_id)
        
        # Charge the buyer's credit
        note = f"Lead {lead_id} dispatch charge"
        if dispatch_log_id:
            note += f" (dispatch log {dispatch_log_id})"
            
        ledger_entry, credit = charge_credit(
            buyer_id=buyer_id,
            org_id=org_id,
            lead_id=lead_id,
            amount_cents=cpl_cents,
            note=note,
            created_by="dispatch_system"
        )
        
        logger.info(
            f"Charged buyer {buyer_id} ${cpl_cents/100:.2f} for lead {lead_id} dispatch"
        )
        
        return {
            "charged": True,
            "buyer_id": buyer_id,
            "lead_id": lead_id,
            "amount_cents": cpl_cents,
            "amount_dollars": cpl_cents / 100,
            "ledger_id": ledger_entry.id if ledger_entry else None,
            "new_balance_cents": credit.balance_cents if credit else 0,
            "new_balance_dollars": credit.balance_dollars if credit else 0,
            "message": f"Successfully charged ${cpl_cents/100:.2f}"
        }
        
    except InsufficientCreditError as e:
        # This shouldn't happen if pre-check was done, but handle gracefully
        logger.error(f"Unexpected insufficient credit during charge for buyer {buyer_id}: {str(e)}")
        
        audit(
            kind="credit_charge_failed",
            message=f"Credit charge failed for buyer {buyer_id} after successful dispatch",
            meta={
                "buyer_id": buyer_id,
                "lead_id": lead_id,
                "dispatch_log_id": dispatch_log_id,
                "error": str(e)
            }
        )
        
        return {
            "charged": False,
            "error": str(e),
            "message": "Credit charge failed after dispatch"
        }
        
    except Exception as e:
        logger.error(f"Unexpected error charging buyer {buyer_id}: {str(e)}")
        
        return {
            "charged": False,
            "error": "Credit charge system error",
            "message": "Unable to process credit charge"
        }


def get_dispatch_eligibility(buyer_id: int, org_id: int) -> dict:
    """
    Get comprehensive dispatch eligibility information for a buyer.
    
    Useful for UI to show whether a buyer can receive dispatches
    and what their current credit status is.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
    
    Returns:
        Dictionary with eligibility details
    """
    try:
        credit_info = get_credit_info(buyer_id, org_id)
        cpl_cents = get_buyer_cpl(buyer_id, org_id)
        
        # Calculate how many leads they can afford
        max_leads = credit_info["balance_cents"] // cpl_cents if cpl_cents > 0 else 0
        
        # Determine eligibility status
        if credit_info["balance_cents"] < cpl_cents:
            status = "insufficient_credit"
            eligible = False
        elif credit_info["balance_cents"] < (cpl_cents * 5):  # Less than 5 leads worth
            status = "low_credit"
            eligible = True
        else:
            status = "active"
            eligible = True
        
        return {
            "eligible": eligible,
            "status": status,
            "buyer_id": buyer_id,
            "balance_dollars": credit_info["balance_dollars"],
            "cost_per_lead_dollars": cpl_cents / 100,
            "max_affordable_leads": max_leads,
            "credit_utilization_percent": round(
                (credit_info["balance_dollars"] / credit_info["cap_dollars"]) * 100, 1
            ) if credit_info["cap_dollars"] > 0 else 0,
            "renewal_period": credit_info["renewal_period"],
            "last_activity": credit_info["recent_activity_count"] > 0
        }
        
    except Exception as e:
        logger.error(f"Error checking dispatch eligibility for buyer {buyer_id}: {str(e)}")
        
        return {
            "eligible": False,
            "status": "error",
            "buyer_id": buyer_id,
            "error": str(e),
            "message": "Unable to determine eligibility"
        }


# Integration function for existing dispatch workflow
def integrate_credit_checks_with_dispatch():
    """
    Integration helper to wire credit checks into existing dispatch workflow.
    
    This would modify the existing dispatch service to:
    1. Call pre_dispatch_credit_check() before dispatch
    2. Update DispatchLog with "blocked_credit" status if check fails
    3. Call post_dispatch_credit_charge() after successful dispatch
    """
    logger.info("Credit integration for dispatch workflow configured")
    
    # In a real implementation, this would:
    # - Modify p29__server_services_dispatch.py to include credit checks
    # - Update DispatchLog model to include credit-related status codes
    # - Ensure dispatch worker calls these hook functions
    
    pass
