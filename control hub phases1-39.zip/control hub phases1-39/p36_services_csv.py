"""
Lead Engine Control Hub - CSV Import Service
Phase 36: CSV importers (leads & buyers)
Purpose: Bulk data import with validation and error reporting
"""

import csv
import io
import logging
import re
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime

# Import validation utilities
try:
    from p02__server_schemas import LeadIn, BuyerIn
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    class LeadIn:
        def __init__(self, **kwargs):
            pass
    class BuyerIn:
        def __init__(self, **kwargs):
            pass
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")

logger = logging.getLogger(__name__)


class CsvImportError(Exception):
    """Base exception for CSV import operations."""
    pass


class FileTooLargeError(CsvImportError):
    """Raised when CSV file exceeds size limits."""
    pass


class InvalidHeaderError(CsvImportError):
    """Raised when CSV headers are invalid or missing."""
    pass


def parse_csv_content(content: bytes, required_columns: List[str], 
                     max_size_mb: int = 10) -> List[Dict[str, Any]]:
    """
    Parse CSV content and validate structure.
    
    Args:
        content: Raw CSV file content
        required_columns: List of required column names
        max_size_mb: Maximum file size in MB
    
    Returns:
        List of dictionaries representing CSV rows
    
    Raises:
        FileTooLargeError: If file exceeds size limit
        InvalidHeaderError: If required columns are missing
    """
    # Check file size
    size_mb = len(content) / (1024 * 1024)
    if size_mb > max_size_mb:
        raise FileTooLargeError(f"File size {size_mb:.1f}MB exceeds limit of {max_size_mb}MB")
    
    try:
        # Decode content
        text_content = content.decode('utf-8-sig')  # Handle BOM
    except UnicodeDecodeError:
        try:
            text_content = content.decode('latin-1')  # Fallback encoding
        except UnicodeDecodeError:
            raise CsvImportError("Unable to decode file. Please ensure it's UTF-8 or Latin-1 encoded.")
    
    # Parse CSV
    try:
        csv_reader = csv.DictReader(io.StringIO(text_content))
        rows = list(csv_reader)
    except csv.Error as e:
        raise CsvImportError(f"Invalid CSV format: {str(e)}")
    
    if not rows:
        raise CsvImportError("CSV file is empty or contains no data rows")
    
    # Normalize and validate headers
    if not csv_reader.fieldnames:
        raise InvalidHeaderError("CSV file must contain headers")
    
    # Clean headers (strip whitespace, normalize case)
    normalized_headers = [header.strip().lower() for header in csv_reader.fieldnames]
    
    # Check for required columns
    missing_columns = []
    for required in required_columns:
        if required.lower() not in normalized_headers:
            missing_columns.append(required)
    
    if missing_columns:
        raise InvalidHeaderError(f"Missing required columns: {', '.join(missing_columns)}")
    
    # Normalize row data
    normalized_rows = []
    for i, row in enumerate(rows):
        normalized_row = {}
        for key, value in row.items():
            if key:  # Skip empty headers
                clean_key = key.strip().lower()
                clean_value = value.strip() if value else ""
                normalized_row[clean_key] = clean_value
        
        # Add row number for error reporting
        normalized_row['_row_number'] = i + 2  # +2 for header and 1-based indexing
        normalized_rows.append(normalized_row)
    
    # Filter out completely empty rows
    filtered_rows = [row for row in normalized_rows if any(
        value for key, value in row.items() if key != '_row_number'
    )]
    
    logger.info(f"Parsed CSV: {len(filtered_rows)} data rows, {len(csv_reader.fieldnames)} columns")
    
    return filtered_rows


def validate_email(email: str) -> bool:
    """Validate email address format."""
    if not email:
        return False
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def validate_phone(phone: str) -> bool:
    """Validate phone number format (flexible)."""
    if not phone:
        return True  # Phone is optional
    
    # Remove all non-digits
    digits_only = re.sub(r'\D', '', phone)
    
    # Must be 7-15 digits (allows for various international formats)
    return 7 <= len(digits_only) <= 15


def validate_lead_row(row: Dict[str, Any]) -> List[str]:
    """
    Validate a single lead row and return list of errors.
    
    Args:
        row: Dictionary representing a CSV row
    
    Returns:
        List of validation error messages
    """
    errors = []
    
    # Required fields
    name = row.get('name', '').strip()
    email = row.get('email', '').strip()
    
    # Validate name
    if not name:
        errors.append("Name is required")
    elif len(name) < 2:
        errors.append("Name must be at least 2 characters")
    elif len(name) > 100:
        errors.append("Name must be less than 100 characters")
    
    # Validate email
    if not email:
        errors.append("Email is required")
    elif not validate_email(email):
        errors.append("Invalid email format")
    elif len(email) > 255:
        errors.append("Email must be less than 255 characters")
    
    # Validate phone (optional)
    phone = row.get('phone', '').strip()
    if phone and not validate_phone(phone):
        errors.append("Invalid phone number format")
    
    # Validate source (optional)
    source = row.get('source', '').strip()
    if source and len(source) > 100:
        errors.append("Source must be less than 100 characters")
    
    return errors


def validate_buyer_row(row: Dict[str, Any]) -> List[str]:
    """
    Validate a single buyer row and return list of errors.
    
    Args:
        row: Dictionary representing a CSV row
    
    Returns:
        List of validation error messages
    """
    errors = []
    
    # Required fields
    name = row.get('name', '').strip()
    email = row.get('email', '').strip()
    
    # Validate name
    if not name:
        errors.append("Name is required")
    elif len(name) < 2:
        errors.append("Name must be at least 2 characters")
    elif len(name) > 100:
        errors.append("Name must be less than 100 characters")
    
    # Validate email
    if not email:
        errors.append("Email is required")
    elif not validate_email(email):
        errors.append("Invalid email format")
    elif len(email) > 255:
        errors.append("Email must be less than 255 characters")
    
    # Validate CPL (optional)
    cpl = row.get('cpl_cents', '').strip()
    if cpl:
        try:
            cpl_value = int(cpl)
            if cpl_value < 0:
                errors.append("CPL cents must be positive")
            elif cpl_value > 1000000:  # $10,000 max
                errors.append("CPL cents must be less than 1,000,000 (max $10,000)")
        except ValueError:
            errors.append("CPL cents must be a valid number")
    
    return errors


def row_to_lead(row: Dict[str, Any], org_id: int) -> Dict[str, Any]:
    """
    Convert a validated CSV row to Lead model data.
    
    Args:
        row: Validated CSV row
        org_id: Organization ID
    
    Returns:
        Dictionary suitable for Lead creation
    """
    return {
        'name': row.get('name', '').strip(),
        'email': row.get('email', '').strip().lower(),
        'phone': row.get('phone', '').strip() or None,
        'source': row.get('source', '').strip() or 'csv_import',
        'org_id': org_id,
        'created_at': datetime.utcnow()
    }


def row_to_buyer(row: Dict[str, Any], org_id: int) -> Dict[str, Any]:
    """
    Convert a validated CSV row to Buyer model data.
    
    Args:
        row: Validated CSV row
        org_id: Organization ID
    
    Returns:
        Dictionary suitable for Buyer creation
    """
    buyer_data = {
        'name': row.get('name', '').strip(),
        'email': row.get('email', '').strip().lower(),
        'org_id': org_id,
        'created_at': datetime.utcnow()
    }
    
    # Add optional CPL if provided
    cpl = row.get('cpl_cents', '').strip()
    if cpl:
        try:
            buyer_data['cpl_cents'] = int(cpl)
        except ValueError:
            pass  # Should have been caught in validation
    
    return buyer_data


def process_lead_import(content: bytes, org_id: int, dry_run: bool = False) -> Dict[str, Any]:
    """
    Process lead CSV import with validation and optional dry run.
    
    Args:
        content: Raw CSV file content
        org_id: Organization ID
        dry_run: If True, validate only without persisting data
    
    Returns:
        Dictionary with import results and statistics
    """
    try:
        # Parse CSV
        rows = parse_csv_content(content, required_columns=['name', 'email'])
        
        # Validate rows
        valid_rows = []
        invalid_rows = []
        
        for row in rows:
            errors = validate_lead_row(row)
            if errors:
                invalid_rows.append({
                    'row': row['_row_number'],
                    'data': {k: v for k, v in row.items() if k != '_row_number'},
                    'errors': errors
                })
            else:
                valid_rows.append(row)
        
        # Check for duplicate emails within the import
        email_counts = {}
        duplicate_emails = set()
        
        for row in valid_rows:
            email = row.get('email', '').lower()
            if email in email_counts:
                duplicate_emails.add(email)
            email_counts[email] = email_counts.get(email, 0) + 1
        
        # Mark duplicate rows as invalid
        duplicate_rows = []
        final_valid_rows = []
        
        for row in valid_rows:
            email = row.get('email', '').lower()
            if email in duplicate_emails:
                duplicate_rows.append({
                    'row': row['_row_number'],
                    'data': {k: v for k, v in row.items() if k != '_row_number'},
                    'errors': ['Duplicate email in import file']
                })
            else:
                final_valid_rows.append(row)
        
        # Combine all invalid rows
        all_invalid_rows = invalid_rows + duplicate_rows
        
        result = {
            'total_rows': len(rows),
            'valid_rows': len(final_valid_rows),
            'invalid_rows': len(all_invalid_rows),
            'duplicate_emails': len(duplicate_rows),
            'dry_run': dry_run,
            'sample_errors': all_invalid_rows[:10],  # First 10 errors for preview
            'would_create': len(final_valid_rows) if dry_run else 0,
            'created': 0 if dry_run else len(final_valid_rows)
        }
        
        if not dry_run and final_valid_rows:
            # TODO: Actually create Lead records here
            # This would involve:
            # 1. Converting rows to Lead model format
            # 2. Checking for existing emails in database
            # 3. Creating new Lead records
            # 4. Handling any database errors
            
            logger.info(f"Would create {len(final_valid_rows)} leads (dry_run={dry_run})")
            audit(
                kind="leads_import",
                message=f"Processed lead import: {len(final_valid_rows)} valid, {len(all_invalid_rows)} invalid",
                meta={
                    'org_id': org_id,
                    'total_rows': len(rows),
                    'valid_rows': len(final_valid_rows),
                    'invalid_rows': len(all_invalid_rows),
                    'dry_run': dry_run
                }
            )
        
        return result
        
    except (FileTooLargeError, InvalidHeaderError, CsvImportError) as e:
        logger.error(f"CSV import error: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error in lead import: {str(e)}")
        raise CsvImportError(f"Import failed: {str(e)}")


def process_buyer_import(content: bytes, org_id: int, dry_run: bool = False) -> Dict[str, Any]:
    """
    Process buyer CSV import with validation and optional dry run.
    
    Args:
        content: Raw CSV file content
        org_id: Organization ID
        dry_run: If True, validate only without persisting data
    
    Returns:
        Dictionary with import results and statistics
    """
    try:
        # Parse CSV
        rows = parse_csv_content(content, required_columns=['name', 'email'])
        
        # Validate rows
        valid_rows = []
        invalid_rows = []
        
        for row in rows:
            errors = validate_buyer_row(row)
            if errors:
                invalid_rows.append({
                    'row': row['_row_number'],
                    'data': {k: v for k, v in row.items() if k != '_row_number'},
                    'errors': errors
                })
            else:
                valid_rows.append(row)
        
        # Check for duplicate emails within the import
        email_counts = {}
        duplicate_emails = set()
        
        for row in valid_rows:
            email = row.get('email', '').lower()
            if email in email_counts:
                duplicate_emails.add(email)
            email_counts[email] = email_counts.get(email, 0) + 1
        
        # Mark duplicate rows as invalid
        duplicate_rows = []
        final_valid_rows = []
        
        for row in valid_rows:
            email = row.get('email', '').lower()
            if email in duplicate_emails:
                duplicate_rows.append({
                    'row': row['_row_number'],
                    'data': {k: v for k, v in row.items() if k != '_row_number'},
                    'errors': ['Duplicate email in import file']
                })
            else:
                final_valid_rows.append(row)
        
        # Combine all invalid rows
        all_invalid_rows = invalid_rows + duplicate_rows
        
        result = {
            'total_rows': len(rows),
            'valid_rows': len(final_valid_rows),
            'invalid_rows': len(all_invalid_rows),
            'duplicate_emails': len(duplicate_rows),
            'dry_run': dry_run,
            'sample_errors': all_invalid_rows[:10],  # First 10 errors for preview
            'would_create': len(final_valid_rows) if dry_run else 0,
            'created': 0 if dry_run else len(final_valid_rows)
        }
        
        if not dry_run and final_valid_rows:
            # TODO: Actually create Buyer records here
            logger.info(f"Would create {len(final_valid_rows)} buyers (dry_run={dry_run})")
            audit(
                kind="buyers_import",
                message=f"Processed buyer import: {len(final_valid_rows)} valid, {len(all_invalid_rows)} invalid",
                meta={
                    'org_id': org_id,
                    'total_rows': len(rows),
                    'valid_rows': len(final_valid_rows),
                    'invalid_rows': len(all_invalid_rows),
                    'dry_run': dry_run
                }
            )
        
        return result
        
    except (FileTooLargeError, InvalidHeaderError, CsvImportError) as e:
        logger.error(f"CSV import error: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error in buyer import: {str(e)}")
        raise CsvImportError(f"Import failed: {str(e)}")


def get_sample_csv_headers() -> Dict[str, List[str]]:
    """
    Get sample CSV headers for documentation.
    
    Returns:
        Dictionary with sample headers for each import type
    """
    return {
        'leads': ['name', 'email', 'phone', 'source'],
        'buyers': ['name', 'email', 'cpl_cents']
    }


def validate_csv_headers(content: bytes, import_type: str) -> Dict[str, Any]:
    """
    Validate CSV headers without processing full content.
    
    Args:
        content: Raw CSV file content
        import_type: 'leads' or 'buyers'
    
    Returns:
        Dictionary with header validation results
    """
    try:
        # Decode just the first line for header check
        text_content = content.decode('utf-8-sig')
        first_line = text_content.split('\n')[0]
        
        # Parse headers
        csv_reader = csv.reader(io.StringIO(first_line))
        headers = next(csv_reader, [])
        
        if not headers:
            return {'valid': False, 'error': 'No headers found'}
        
        # Clean headers
        clean_headers = [h.strip().lower() for h in headers]
        
        # Get required columns for import type
        required_columns = {
            'leads': ['name', 'email'],
            'buyers': ['name', 'email']
        }.get(import_type, [])
        
        # Check for required columns
        missing = [col for col in required_columns if col not in clean_headers]
        
        return {
            'valid': len(missing) == 0,
            'headers': headers,
            'clean_headers': clean_headers,
            'required_columns': required_columns,
            'missing_columns': missing,
            'extra_columns': [h for h in clean_headers if h not in required_columns]
        }
        
    except Exception as e:
        return {'valid': False, 'error': str(e)}
