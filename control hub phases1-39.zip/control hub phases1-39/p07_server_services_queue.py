"""
Lead Engine Control Hub - In-Memory Job Queue Service
Phase: 7
Purpose: Simple thread-based job queue for processing deployment tasks
Key Responsibilities:
- Job registration and handler management
- In-memory job storage with status tracking
- Background worker thread management
- Job enqueue/dequeue operations with logging
"""

import logging
import threading
import time
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class JobStatus(Enum):
    """Job status enumeration"""
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"

@dataclass
class Job:
    """Job data structure"""
    id: str
    kind: str
    payload: Dict[str, Any]
    status: JobStatus = JobStatus.QUEUED
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert job to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "kind": self.kind,
            "payload": self.payload,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result,
            "error": self.error,
            "duration_seconds": self.get_duration_seconds()
        }
    
    def get_duration_seconds(self) -> Optional[float]:
        """Get job duration in seconds"""
        if not self.started_at:
            return None
        end_time = self.completed_at or datetime.utcnow()
        return (end_time - self.started_at).total_seconds()

class JobQueue:
    """
    In-memory job queue with background worker thread.
    
    Features:
    - Handler registration by job kind
    - Automatic worker thread management
    - Job status tracking and results storage
    - Thread-safe operations
    """
    
    def __init__(self):
        self._jobs: Dict[str, Job] = {}
        self._queue: List[str] = []  # Job IDs in queue order
        self._handlers: Dict[str, Callable] = {}
        self._worker_thread: Optional[threading.Thread] = None
        self._worker_running = False
        self._lock = threading.RLock()
        self._queue_condition = threading.Condition(self._lock)
        
        logger.info("JobQueue initialized")
    
    def register(self, kind: str, handler_fn: Callable) -> None:
        """
        Register a job handler for a specific job kind.
        
        Args:
            kind: Job type identifier
            handler_fn: Function to handle jobs of this kind
        """
        with self._lock:
            self._handlers[kind] = handler_fn
            logger.info(f"Registered handler for job kind: {kind}")
    
    def enqueue(self, kind: str, payload: Dict[str, Any]) -> str:
        """
        Enqueue a new job.
        
        Args:
            kind: Job type identifier
            payload: Job data payload
            
        Returns:
            Job ID
            
        Raises:
            ValueError: If no handler registered for job kind
        """
        if kind not in self._handlers:
            raise ValueError(f"No handler registered for job kind: {kind}")
        
        job_id = str(uuid.uuid4())
        job = Job(
            id=job_id,
            kind=kind,
            payload=payload
        )
        
        with self._queue_condition:
            self._jobs[job_id] = job
            self._queue.append(job_id)
            logger.info(f"Enqueued job {job_id} of kind '{kind}'")
            
            # Ensure worker is running
            self.ensure_worker_running()
            
            # Notify worker thread
            self._queue_condition.notify()
        
        return job_id
    
    def list_jobs(self, status: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """
        List jobs with optional status filtering.
        
        Args:
            status: Optional status filter
            limit: Maximum number of jobs to return
            
        Returns:
            List of job dictionaries
        """
        with self._lock:
            jobs = list(self._jobs.values())
            
            # Filter by status if provided
            if status:
                try:
                    status_enum = JobStatus(status.lower())
                    jobs = [job for job in jobs if job.status == status_enum]
                except ValueError:
                    logger.warning(f"Invalid status filter: {status}")
                    return []
            
            # Sort by creation time (newest first)
            jobs.sort(key=lambda j: j.created_at, reverse=True)
            
            # Apply limit
            jobs = jobs[:limit]
            
            return [job.to_dict() for job in jobs]
    
    def get_job_status(self, job_id: str) -> Optional[Dict[str, Any]]:
        """
        Get status and details of a specific job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Job dictionary or None if not found
        """
        with self._lock:
            job = self._jobs.get(job_id)
            return job.to_dict() if job else None
    
    def ensure_worker_running(self) -> None:
        """
        Ensure the worker thread is running.
        Auto-starts worker if not already running.
        """
        with self._lock:
            if not self._worker_running or (self._worker_thread and not self._worker_thread.is_alive()):
                self._start_worker()
    
    def _start_worker(self) -> None:
        """Start the background worker thread"""
        if self._worker_running and self._worker_thread and self._worker_thread.is_alive():
            return
        
        self._worker_running = True
        self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker_thread.start()
        logger.info("Job queue worker thread started")
    
    def stop_worker(self) -> None:
        """Stop the background worker thread"""
        with self._queue_condition:
            self._worker_running = False
            self._queue_condition.notify()
        
        if self._worker_thread:
            self._worker_thread.join(timeout=5.0)
            logger.info("Job queue worker thread stopped")
    
    def _worker_loop(self) -> None:
        """Main worker loop that processes jobs"""
        logger.info("Job queue worker loop started")
        
        while self._worker_running:
            job_id = None
            
            # Get next job from queue
            with self._queue_condition:
                while self._worker_running and not self._queue:
                    self._queue_condition.wait(timeout=1.0)
                
                if not self._worker_running:
                    break
                
                if self._queue:
                    job_id = self._queue.pop(0)
            
            if job_id:
                self._process_job(job_id)
        
        logger.info("Job queue worker loop terminated")
    
    def _process_job(self, job_id: str) -> None:
        """
        Process a single job.
        
        Args:
            job_id: Job identifier to process
        """
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                logger.error(f"Job not found: {job_id}")
                return
            
            handler = self._handlers.get(job.kind)
            if not handler:
                job.status = JobStatus.FAILED
                job.error = f"No handler for job kind: {job.kind}"
                job.completed_at = datetime.utcnow()
                logger.error(f"No handler for job {job_id} of kind '{job.kind}'")
                return
            
            # Mark job as running
            job.status = JobStatus.RUNNING
            job.started_at = datetime.utcnow()
            logger.info(f"Processing job {job_id} of kind '{job.kind}'")
        
        # Execute handler outside of lock to avoid blocking
        try:
            result = handler(job.payload)
            
            with self._lock:
                job.status = JobStatus.SUCCESS
                job.result = result if isinstance(result, dict) else {"result": result}
                job.completed_at = datetime.utcnow()
                
            logger.info(f"Job {job_id} completed successfully in {job.get_duration_seconds():.2f}s")
            
        except Exception as e:
            logger.error(f"Job {job_id} failed: {e}")
            
            with self._lock:
                job.status = JobStatus.FAILED
                job.error = str(e)
                job.completed_at = datetime.utcnow()
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get queue statistics.
        
        Returns:
            Dictionary with queue statistics
        """
        with self._lock:
            stats = {
                "total_jobs": len(self._jobs),
                "queued_jobs": len(self._queue),
                "running_jobs": len([j for j in self._jobs.values() if j.status == JobStatus.RUNNING]),
                "completed_jobs": len([j for j in self._jobs.values() if j.status == JobStatus.SUCCESS]),
                "failed_jobs": len([j for j in self._jobs.values() if j.status == JobStatus.FAILED]),
                "registered_handlers": list(self._handlers.keys()),
                "worker_running": self._worker_running,
                "worker_thread_alive": self._worker_thread.is_alive() if self._worker_thread else False
            }
        
        return stats

# Global queue instance
_global_queue: Optional[JobQueue] = None

def get_queue() -> JobQueue:
    """Get the global job queue instance"""
    global _global_queue
    if _global_queue is None:
        _global_queue = JobQueue()
    return _global_queue

def register_handler(kind: str, handler_fn: Callable) -> None:
    """Register a job handler (convenience function)"""
    get_queue().register(kind, handler_fn)

def enqueue_job(kind: str, payload: Dict[str, Any]) -> str:
    """Enqueue a job (convenience function)"""
    return get_queue().enqueue(kind, payload)

def list_all_jobs(status: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    """List jobs (convenience function)"""
    return get_queue().list_jobs(status, limit)

def get_job_status(job_id: str) -> Optional[Dict[str, Any]]:
    """Get job status (convenience function)"""
    return get_queue().get_job_status(job_id)

def ensure_worker_running() -> None:
    """Ensure worker is running (convenience function)"""
    get_queue().ensure_worker_running()

def stop_worker() -> None:
    """Stop worker (convenience function)"""
    get_queue().stop_worker()

def get_queue_stats() -> Dict[str, Any]:
    """Get queue stats (convenience function)"""
    return get_queue().get_stats()

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Job Queue Module Test ===")
    
    # Test handler registration
    def test_handler(payload):
        logger.info(f"Test handler called with: {payload}")
        time.sleep(1)  # Simulate work
        return {"processed": True, "data": payload}
    
    queue = get_queue()
    register_handler("test", test_handler)
    
    # Test job enqueueing
    job_id = enqueue_job("test", {"message": "Hello, World!"})
    logger.info(f"Enqueued test job: {job_id}")
    
    # Wait for processing
    time.sleep(2)
    
    # Check job status
    status = get_job_status(job_id)
    logger.info(f"Job status: {status}")
    
    # Get queue stats
    stats = get_queue_stats()
    logger.info(f"Queue stats: {stats}")
    
    # Stop worker
    stop_worker()
    
    logger.info("✅ Job queue module test completed")