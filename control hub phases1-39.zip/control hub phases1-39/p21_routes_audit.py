"""
Audit Log API Routes
Phase 21: Endpoints for viewing audit logs, export, and retention management
Key responsibilities: List audit events, export CSV, manage retention policy
"""

import logging
from fastapi import APIRouter, Query, HTTPException, Request, Depends
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
import csv
import io
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p21__server_models_audit import Audit, AuditKind, AppSetting, get_audit_retention_days, set_audit_retention_days
    from p12__server_utils_query import parse_query_params, apply_query
    from p20__server_middleware_auth import require_admin, require_viewer
except ImportError:
    logger.warning("Audit modules not found - using mock implementations")
    def get_session():
        return None
    
    class Audit:
        def __init__(self, **kwargs):
            self.id = 1
            self.ts = datetime.utcnow()
            self.kind = kwargs.get('kind', 'mock_event')
            self.message = kwargs.get('message', 'Mock audit message')
            self.meta_json = '{}'
        
        def to_dict(self):
            return {
                "id": self.id,
                "timestamp": self.ts.isoformat(),
                "kind": self.kind,
                "message": self.message,
                "metadata": {}
            }
    
    class AuditKind:
        @classmethod
        def all_kinds(cls):
            return ['system_startup', 'lead_created', 'export_data']
    
    def get_audit_retention_days(session):
        return 30
    
    def set_audit_retention_days(session, days):
        pass
    
    def parse_query_params(request):
        return {"page": 1, "per_page": 20, "sort": None, "q": None}
    
    def apply_query(query, params, searchable, sortable):
        return query
    
    def require_admin(request):
        return {"role": "admin"}
    
    def require_viewer(request):
        return {"role": "viewer"}

router = APIRouter(prefix="/audit", tags=["audit"])

# Pydantic models
class RetentionUpdateRequest(BaseModel):
    days: int
    
    class Config:
        schema_extra = {
            "example": {
                "days": 14
            }
        }

class AuditResponse(BaseModel):
    id: int
    timestamp: str
    kind: str
    message: str
    metadata: Optional[Dict[str, Any]] = None

class AuditListResponse(BaseModel):
    items: List[AuditResponse]
    page: int
    per_page: int
    total: int
    total_pages: int

@router.get("/", response_model=AuditListResponse)
async def list_audit_logs(
    request: Request,
    kind: Optional[str] = Query(None, description="Filter by event kind"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(20, ge=1, le=100, description="Items per page"),
    _: dict = Depends(require_viewer)
) -> Dict[str, Any]:
    """
    List audit log entries with filtering and pagination
    Requires viewer role or higher
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_audits = [
                {
                    "id": 1,
                    "timestamp": datetime.utcnow().isoformat(),
                    "kind": "system_startup",
                    "message": "System started successfully",
                    "metadata": {"version": "1.0.0"}
                },
                {
                    "id": 2,
                    "timestamp": (datetime.utcnow() - timedelta(hours=1)).isoformat(),
                    "kind": "lead_created",
                    "message": "New lead created via API",
                    "metadata": {"lead_id": 123, "source": "api"}
                }
            ]
            
            return {
                "items": mock_audits,
                "page": page,
                "per_page": per_page,
                "total": 2,
                "total_pages": 1
            }
        
        with session:
            # Build base query
            query = session.query(Audit)
            
            # Apply kind filter
            if kind:
                query = query.filter(Audit.kind == kind)
            
            # Get total count before pagination
            total = query.count()
            
            # Apply sorting (default: newest first)
            query = query.order_by(Audit.ts.desc())
            
            # Apply pagination
            offset = (page - 1) * per_page
            audits = query.offset(offset).limit(per_page).all()
            
            # Convert to response format
            items = [audit.to_dict() for audit in audits]
            total_pages = (total + per_page - 1) // per_page
            
            logger.info(f"Listed {len(items)} audit entries (page {page}/{total_pages})")
            
            return {
                "items": items,
                "page": page,
                "per_page": per_page,
                "total": total,
                "total_pages": total_pages
            }
    
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve audit logs")

@router.get("/kinds")
async def list_audit_kinds(
    _: dict = Depends(require_viewer)
) -> Dict[str, Any]:
    """
    List all available audit event kinds
    Useful for filtering
    """
    try:
        all_kinds = AuditKind.all_kinds()
        
        # Get count of each kind from database
        session = get_session()
        kind_counts = {}
        
        if session:
            with session:
                for kind in all_kinds:
                    count = session.query(Audit).filter(Audit.kind == kind).count()
                    kind_counts[kind] = count
        else:
            # Mock counts
            kind_counts = {kind: 1 for kind in all_kinds[:5]}
        
        return {
            "kinds": all_kinds,
            "counts": kind_counts,
            "total_kinds": len(all_kinds)
        }
    
    except Exception as e:
        logger.error(f"Error listing audit kinds: {e}")
        raise HTTPException(status_code=500, detail="Failed to list audit kinds")

@router.get("/export.csv")
async def export_audit_csv(
    kind: Optional[str] = Query(None, description="Filter by event kind"),
    days: int = Query(30, ge=1, le=365, description="Number of days to export"),
    _: dict = Depends(require_admin)
):
    """
    Export audit logs as CSV
    Admin access required
    """
    try:
        session = get_session()
        audits_data = []
        
        if session:
            with session:
                # Build query
                query = session.query(Audit)
                
                # Apply filters
                if kind:
                    query = query.filter(Audit.kind == kind)
                
                # Date filter
                cutoff_date = datetime.utcnow() - timedelta(days=days)
                query = query.filter(Audit.ts >= cutoff_date)
                
                # Order by timestamp
                query = query.order_by(Audit.ts.desc())
                
                audits = query.all()
                audits_data = [audit.to_dict() for audit in audits]
        else:
            # Mock data for testing
            audits_data = [
                {
                    "id": 1,
                    "timestamp": datetime.utcnow().isoformat(),
                    "kind": "system_startup",
                    "message": "System started",
                    "metadata": {}
                }
            ]
        
        # Generate CSV
        output = io.StringIO()
        if audits_data:
            fieldnames = ["id", "timestamp", "kind", "message", "metadata"]
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            
            for audit in audits_data:
                # Flatten metadata for CSV
                row = {
                    "id": audit["id"],
                    "timestamp": audit["timestamp"],
                    "kind": audit["kind"],
                    "message": audit["message"],
                    "metadata": str(audit.get("metadata", {}))
                }
                writer.writerow(row)
        
        csv_content = output.getvalue()
        
        # Log the export
        logger.info(f"Exported {len(audits_data)} audit entries as CSV (kind={kind}, days={days})")
        
        # Create streaming response with security headers
        filename = f"audit-logs-{datetime.now().strftime('%Y%m%d')}.csv"
        response = StreamingResponse(
            io.StringIO(csv_content),
            media_type="text/csv",
            headers={
                "X-Download-Filename": filename,
                "Content-Disposition": f'attachment; filename="{filename}"',
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error exporting audit CSV: {e}")
        raise HTTPException(status_code=500, detail="Failed to export audit logs")

@router.get("/retention")
async def get_retention_policy(
    _: dict = Depends(require_viewer)
) -> Dict[str, Any]:
    """
    Get current audit log retention policy
    """
    try:
        session = get_session()
        if not session:
            return {
                "retention_days": 30,
                "description": "Audit logs are kept for 30 days (mock)"
            }
        
        with session:
            retention_days = get_audit_retention_days(session)
            
            return {
                "retention_days": retention_days,
                "description": f"Audit logs are kept for {retention_days} days"
            }
    
    except Exception as e:
        logger.error(f"Error getting retention policy: {e}")
        raise HTTPException(status_code=500, detail="Failed to get retention policy")

@router.post("/retention")
async def update_retention_policy(
    request: RetentionUpdateRequest,
    _: dict = Depends(require_admin)
) -> Dict[str, Any]:
    """
    Update audit log retention policy
    Admin access required
    """
    try:
        if request.days < 1 or request.days > 365:
            raise HTTPException(status_code=400, detail="Retention days must be between 1 and 365")
        
        session = get_session()
        if not session:
            logger.info(f"Mock: Updated retention policy to {request.days} days")
            return {
                "retention_days": request.days,
                "message": f"Retention policy updated to {request.days} days (mock)"
            }
        
        with session:
            old_days = get_audit_retention_days(session)
            set_audit_retention_days(session, request.days)
            
            logger.info(f"Updated audit retention policy: {old_days} -> {request.days} days")
            
            return {
                "retention_days": request.days,
                "message": f"Retention policy updated from {old_days} to {request.days} days"
            }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating retention policy: {e}")
        raise HTTPException(status_code=500, detail="Failed to update retention policy")

@router.get("/stats")
async def get_audit_stats(
    _: dict = Depends(require_viewer)
) -> Dict[str, Any]:
    """
    Get audit log statistics
    Useful for monitoring and capacity planning
    """
    try:
        session = get_session()
        
        if not session:
            # Mock stats
            return {
                "total_entries": 100,
                "oldest_entry": (datetime.utcnow() - timedelta(days=25)).isoformat(),
                "newest_entry": datetime.utcnow().isoformat(),
                "entries_by_kind": {
                    "system_startup": 5,
                    "lead_created": 30,
                    "export_data": 10
                },
                "retention_days": 30,
                "estimated_purge_date": (datetime.utcnow() + timedelta(days=5)).isoformat()
            }
        
        with session:
            total_entries = session.query(Audit).count()
            
            # Get date range
            oldest = session.query(Audit.ts).order_by(Audit.ts.asc()).first()
            newest = session.query(Audit.ts).order_by(Audit.ts.desc()).first()
            
            # Get counts by kind
            kind_counts = {}
            for kind in AuditKind.all_kinds()[:10]:  # Limit to top kinds
                count = session.query(Audit).filter(Audit.kind == kind).count()
                if count > 0:
                    kind_counts[kind] = count
            
            # Get retention info
            retention_days = get_audit_retention_days(session)
            purge_cutoff = datetime.utcnow() - timedelta(days=retention_days)
            
            return {
                "total_entries": total_entries,
                "oldest_entry": oldest[0].isoformat() if oldest else None,
                "newest_entry": newest[0].isoformat() if newest else None,
                "entries_by_kind": kind_counts,
                "retention_days": retention_days,
                "estimated_purge_date": purge_cutoff.isoformat()
            }
    
    except Exception as e:
        logger.error(f"Error getting audit stats: {e}")
        raise HTTPException(status_code=500, detail="Failed to get audit statistics")
