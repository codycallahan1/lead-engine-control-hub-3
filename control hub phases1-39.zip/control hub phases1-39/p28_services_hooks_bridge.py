"""
Integration hooks for automatic lead matching on creation.

Phase: 28
Purpose: Bridge service to automatically trigger matching when leads are created.
Key responsibilities:
- Hook into lead creation events
- Trigger automatic matching based on org settings
- Provide toggle for auto-matching feature
"""

import logging
from typing import Optional, Dict, Any

try:
    from p28__server_services_matching import match_and_record
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Hooks bridge: missing dependency {e}")

logger = logging.getLogger(__name__)

# In-memory settings for auto-matching (would be database-backed in production)
_auto_match_settings = {}


def set_auto_match_enabled(org_id: int, enabled: bool, actor: str = "system"):
    """
    Enable or disable auto-matching for an organization.
    
    Args:
        org_id: Organization ID
        enabled: Whether to enable auto-matching
        actor: Who made the change (for audit)
    """
    global _auto_match_settings
    
    old_setting = _auto_match_settings.get(org_id, False)
    _auto_match_settings[org_id] = enabled
    
    logger.info(f"Auto-matching for org {org_id}: {'enabled' if enabled else 'disabled'} by {actor}")
    
    # Audit the setting change
    audit(
        kind="auto_match_setting_changed",
        message=f"Auto-matching {'enabled' if enabled else 'disabled'} for org {org_id}",
        meta={
            "org_id": org_id,
            "enabled": enabled,
            "previous_setting": old_setting,
            "actor": actor
        }
    )


def is_auto_match_enabled(org_id: int) -> bool:
    """
    Check if auto-matching is enabled for an organization.
    
    Args:
        org_id: Organization ID
    
    Returns:
        True if auto-matching is enabled
    """
    return _auto_match_settings.get(org_id, False)


def on_lead_created(lead_id: int, org_id: int, source: str = "unknown") -> Optional[Dict[str, Any]]:
    """
    Hook called when a new lead is created.
    
    Args:
        lead_id: ID of newly created lead
        org_id: Organization ID
        source: Source of lead creation (e.g., "api", "ingest_form", "import")
    
    Returns:
        Match result dict if auto-matching was performed, None otherwise
    """
    try:
        # Check if auto-matching is enabled for this org
        if not is_auto_match_enabled(org_id):
            logger.debug(f"Auto-matching disabled for org {org_id}, skipping lead {lead_id}")
            return None
        
        logger.info(f"Auto-matching triggered for lead {lead_id} from {source}")
        
        # Perform the match
        match_log = match_and_record(lead_id, org_id)
        
        if match_log:
            result = {
                "auto_matched": True,
                "match_log_id": match_log.id,
                "status": match_log.status,
                "buyer_id": match_log.buyer_id,
                "rule_id": match_log.rule_id,
                "score": match_log.score,
                "source": source
            }
            
            # Audit the auto-match
            audit(
                kind="lead_auto_matched",
                message=f"Lead {lead_id} auto-matched via {source}: {match_log.get_status_display()}",
                meta={
                    "lead_id": lead_id,
                    "org_id": org_id,
                    "source": source,
                    "match_result": result
                }
            )
            
            logger.info(f"Auto-match completed for lead {lead_id}: {match_log.get_status_display()}")
            return result
        else:
            logger.warning(f"Auto-match failed for lead {lead_id}: no match log created")
            return None
    
    except Exception as e:
        logger.error(f"Error in auto-match for lead {lead_id}: {e}")
        
        # Audit the failure
        audit(
            kind="lead_auto_match_failed",
            message=f"Auto-match failed for lead {lead_id}: {str(e)}",
            meta={
                "lead_id": lead_id,
                "org_id": org_id,
                "source": source,
                "error": str(e)
            }
        )
        
        return None


def on_lead_ingested(lead_id: int, org_id: int) -> Optional[Dict[str, Any]]:
    """
    Specific hook for leads created via public ingest form.
    
    Args:
        lead_id: ID of ingested lead
        org_id: Organization ID
    
    Returns:
        Match result if auto-matching performed
    """
    return on_lead_created(lead_id, org_id, "ingest_form")


def on_lead_imported(lead_id: int, org_id: int) -> Optional[Dict[str, Any]]:
    """
    Specific hook for leads created via CSV import.
    
    Args:
        lead_id: ID of imported lead
        org_id: Organization ID
    
    Returns:
        Match result if auto-matching performed
    """
    return on_lead_created(lead_id, org_id, "csv_import")


def on_lead_api_created(lead_id: int, org_id: int) -> Optional[Dict[str, Any]]:
    """
    Specific hook for leads created via API.
    
    Args:
        lead_id: ID of API-created lead
        org_id: Organization ID
    
    Returns:
        Match result if auto-matching performed
    """
    return on_lead_created(lead_id, org_id, "api")


def get_auto_match_stats(org_id: int) -> Dict[str, Any]:
    """
    Get statistics about auto-matching for an organization.
    
    Args:
        org_id: Organization ID
    
    Returns:
        Dict with auto-matching statistics
    """
    try:
        from p02__server_db import get_session
        from p28__server_models_matching import MatchLog
        from sqlalchemy import func
        from datetime import datetime, timedelta
        
        with get_session() as db:
            # Get auto-match stats for last 30 days
            cutoff = datetime.utcnow() - timedelta(days=30)
            
            # Count total matches
            total_matches = db.query(MatchLog).filter(
                MatchLog.org_id == org_id,
                MatchLog.created_at >= cutoff
            ).count()
            
            # Count successful matches
            successful_matches = db.query(MatchLog).filter(
                MatchLog.org_id == org_id,
                MatchLog.status == "matched",
                MatchLog.created_at >= cutoff
            ).count()
            
            # Count by status
            status_counts = db.query(
                MatchLog.status,
                func.count(MatchLog.id).label('count')
            ).filter(
                MatchLog.org_id == org_id,
                MatchLog.created_at >= cutoff
            ).group_by(MatchLog.status).all()
            
            status_breakdown = {status: count for status, count in status_counts}
            
            # Calculate success rate
            success_rate = (successful_matches / total_matches * 100) if total_matches > 0 else 0
            
            return {
                "enabled": is_auto_match_enabled(org_id),
                "total_matches_30d": total_matches,
                "successful_matches_30d": successful_matches,
                "success_rate_30d": round(success_rate, 1),
                "status_breakdown_30d": status_breakdown,
                "period": "last_30_days"
            }
    
    except Exception as e:
        logger.error(f"Error getting auto-match stats for org {org_id}: {e}")
        return {
            "enabled": is_auto_match_enabled(org_id),
            "error": str(e)
        }


def get_all_org_settings() -> Dict[int, bool]:
    """
    Get auto-match settings for all organizations.
    
    Returns:
        Dict mapping org_id to enabled status
    """
    return _auto_match_settings.copy()


# Example integration points where these hooks would be called:

def example_ingest_integration():
    """
    Example of how to integrate with the ingest form endpoint.
    
    In the actual ingest route (p04__server_routes_ingest.py), after creating
    a lead, you would call:
    
    ```python
    # After lead creation
    new_lead = Lead(...)
    db.add(new_lead)
    db.commit()
    
    # Trigger auto-matching
    from p28__server_services_hooks_bridge import on_lead_ingested
    match_result = on_lead_ingested(new_lead.id, org_id)
    
    # Include match result in response if desired
    response_data = {
        "status": "success",
        "lead_id": new_lead.id,
        "auto_match": match_result
    }
    ```
    """
    pass


def example_api_integration():
    """
    Example of how to integrate with the leads API endpoint.
    
    In the leads creation route (p03__server_routes_leads.py), after creating
    a lead, you would call:
    
    ```python
    # After lead creation
    new_lead = Lead(...)
    db.add(new_lead)
    db.commit()
    
    # Trigger auto-matching
    from p28__server_services_hooks_bridge import on_lead_api_created
    match_result = on_lead_api_created(new_lead.id, org_id)
    
    # Optionally include in response
    if match_result:
        logger.info(f"Lead {new_lead.id} auto-matched to buyer {match_result['buyer_id']}")
    ```
    """
    pass


def example_import_integration():
    """
    Example of how to integrate with the CSV import worker.
    
    In the import worker (p25__server_services_queue_import_worker.py), after
    creating each lead, you would call:
    
    ```python
    # After successful lead import
    new_lead = Lead(...)
    db.add(new_lead)
    db.flush()  # Get ID without committing
    
    # Trigger auto-matching
    from p28__server_services_hooks_bridge import on_lead_imported
    match_result = on_lead_imported(new_lead.id, org_id)
    
    # Track auto-match results in import stats
    if match_result and match_result['status'] == 'matched':
        auto_matched_count += 1
    ```
    """
    pass
