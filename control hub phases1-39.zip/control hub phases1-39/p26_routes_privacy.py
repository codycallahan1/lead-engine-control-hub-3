"""
Privacy routes for GDPR-lite data export and erasure.

Phase: 26
Purpose: Provide endpoints for lead data export and erasure operations.
Key responsibilities:
- Export individual lead data as downloadable JSON
- Safely erase lead PII with business rule enforcement
- Audit all privacy operations
"""

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import json
import io
import logging
from typing import Optional

try:
    from p26__server_services_privacy import (
        export_lead_data, 
        erase_lead, 
        check_erasure_eligibility,
        audit_privacy
    )
    from p24__server_services_scope import current_org
except ImportError as e:
    logging.warning(f"Privacy routes: missing dependency {e}")

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/privacy", tags=["privacy"])


class EraseRequest(BaseModel):
    confirm: bool = False
    reason: str = "User request"


class EraseResponse(BaseModel):
    success: bool
    message: str
    erased_at: Optional[str] = None
    redacted_fields: Optional[list] = None


def require_ops_admin():
    """Placeholder for ops/admin role requirement."""
    # In actual implementation, would check roles from Phase 23
    return "admin"  # Return actor identifier


@router.get("/leads/{lead_id}/export")
async def export_lead_privacy_data(
    lead_id: int,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Export complete data for a lead as JSON download."""
    
    try:
        # Export the data
        export_data = export_lead_data(lead_id, org_id)
        
        # Create JSON response
        json_content = json.dumps(export_data, indent=2, ensure_ascii=False)
        json_bytes = json_content.encode('utf-8')
        
        # Create streaming response
        def generate():
            yield json_bytes
        
        # Audit the export
        audit_privacy(
            "lead_exported",
            lead_id,
            actor,
            True,
            f"Lead data exported by {actor}"
        )
        
        logger.info(f"Lead {lead_id} data exported by {actor}")
        
        return StreamingResponse(
            io.BytesIO(json_bytes),
            media_type="application/json",
            headers={
                "Content-Disposition": f"attachment; filename=lead_{lead_id}_export.json",
                "X-Download-Filename": f"lead_{lead_id}_export.json",
                "Content-Length": str(len(json_bytes))
            }
        )
    
    except ValueError as e:
        logger.warning(f"Lead erasure failed - validation error: {e}")
        
        audit_privacy(
            "lead_erase_failed",
            lead_id,
            actor,
            False,
            f"Validation error: {str(e)}"
        )
        
        if "active sales" in str(e):
            raise HTTPException(status_code=409, detail=str(e))
        else:
            raise HTTPException(status_code=404, detail=str(e))
    
    except Exception as e:
        logger.error(f"Lead erasure failed for {lead_id}: {e}")
        
        audit_privacy(
            "lead_erase_failed",
            lead_id,
            actor,
            False,
            f"System error: {str(e)}"
        )
        
        raise HTTPException(status_code=500, detail="Erasure failed")


@router.get("/leads/{lead_id}/eligibility")
async def check_lead_erasure_eligibility(
    lead_id: int,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Check if a lead can be erased without violating business rules."""
    
    try:
        eligibility = check_erasure_eligibility(lead_id, org_id)
        
        # Audit the check
        audit_privacy(
            "erasure_eligibility_checked",
            lead_id,
            actor,
            True,
            f"Eligibility check: {'eligible' if eligibility['eligible'] else 'blocked'}"
        )
        
        return eligibility
    
    except Exception as e:
        logger.error(f"Eligibility check failed for lead {lead_id}: {e}")
        
        audit_privacy(
            "erasure_eligibility_check_failed",
            lead_id,
            actor,
            False,
            f"Check error: {str(e)}"
        )
        
        raise HTTPException(status_code=500, detail="Eligibility check failed") e:
        logger.warning(f"Lead export failed - not found: {e}")
        
        audit_privacy(
            "lead_export_failed",
            lead_id,
            actor,
            False,
            f"Lead not found: {str(e)}"
        )
        
        raise HTTPException(status_code=404, detail=str(e))
    
    except Exception as e:
        logger.error(f"Lead export failed for {lead_id}: {e}")
        
        audit_privacy(
            "lead_export_failed",
            lead_id,
            actor,
            False,
            f"Export error: {str(e)}"
        )
        
        raise HTTPException(status_code=500, detail="Export failed")


@router.post("/leads/{lead_id}/erase", response_model=EraseResponse)
async def erase_lead_data(
    lead_id: int,
    erase_request: EraseRequest,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Erase/anonymize a lead's personal data."""
    
    if not erase_request.confirm:
        raise HTTPException(
            status_code=400, 
            detail="Erasure must be confirmed by setting 'confirm: true'"
        )
    
    try:
        # Check eligibility first
        eligibility = check_erasure_eligibility(lead_id, org_id)
        
        if not eligibility["eligible"]:
            error_msg = f"Cannot erase lead: {', '.join(eligibility['blockers'])}"
            
            audit_privacy(
                "lead_erase_blocked",
                lead_id,
                actor,
                False,
                error_msg
            )
            
            raise HTTPException(status_code=409, detail=error_msg)
        
        # Perform erasure
        result = erase_lead(lead_id, actor, org_id)
        
        logger.info(f"Lead {lead_id} erased by {actor}")
        
        return EraseResponse(
            success=result["success"],
            message=result["message"],
            erased_at=result.get("erased_at"),
            redacted_fields=result.get("redacted_fields")
        )
    
    except HTTPException:
        raise
    except ValueError as