"""
Notification configuration and settings management.

Phase: 16
Purpose: Configuration for notification recipients and email settings
Key responsibilities: get_notification_recipients, get_notification_settings functions
"""

import logging
import os
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger(__name__)

# Default notification settings
DEFAULT_SETTINGS = {
    'enabled': True,
    'default_from': 'noreply@leadengine.example',
    'reply_to': 'support@leadengine.example',
    'min_alert_severity': 'warning',
    'batch_size': 50,
    'retry_attempts': 3,
    'retry_delays': [30, 300, 1800],  # 30s, 5min, 30min
    'current_time': datetime.now().isoformat()
}

# Default recipient configuration
DEFAULT_RECIPIENTS = {
    'admin': [
        'admin@leadengine.example'
    ],
    'sales': [
        'sales@leadengine.example'
    ],
    'support': [
        'support@leadengine.example'
    ]
}

def get_notification_recipients() -> Dict[str, List[str]]:
    """
    Get configured notification recipients by type.
    
    Loads recipient configuration from environment variables or defaults.
    
    Returns:
        Dict mapping recipient types to email lists
    """
    logger.debug("Loading notification recipients")
    
    recipients = {}
    
    # Load from environment variables with fallbacks
    recipients['admin'] = _parse_email_list(
        os.getenv('NOTIFY_ADMIN_EMAILS', ''),
        DEFAULT_RECIPIENTS['admin']
    )
    
    recipients['sales'] = _parse_email_list(
        os.getenv('NOTIFY_SALES_EMAILS', ''),
        DEFAULT_RECIPIENTS['sales']
    )
    
    recipients['support'] = _parse_email_list(
        os.getenv('NOTIFY_SUPPORT_EMAILS', ''),
        DEFAULT_RECIPIENTS['support']
    )
    
    # Filter out invalid emails
    for recipient_type in recipients:
        recipients[recipient_type] = [
            email for email in recipients[recipient_type]
            if _is_valid_email(email)
        ]
    
    logger.info(f"Loaded notification recipients: admin={len(recipients['admin'])}, sales={len(recipients['sales'])}, support={len(recipients['support'])}")
    
    return recipients

def get_notification_settings() -> Dict[str, Any]:
    """
    Get notification system settings.
    
    Loads settings from environment variables with sensible defaults.
    
    Returns:
        Dict with notification configuration
    """
    logger.debug("Loading notification settings")
    
    settings = DEFAULT_SETTINGS.copy()
    
    # Override with environment variables if present
    if os.getenv('NOTIFY_ENABLED'):
        settings['enabled'] = os.getenv('NOTIFY_ENABLED').lower() in ('true', '1', 'yes')
    
    if os.getenv('NOTIFY_FROM_EMAIL'):
        settings['default_from'] = os.getenv('NOTIFY_FROM_EMAIL')
    
    if os.getenv('NOTIFY_REPLY_TO'):
        settings['reply_to'] = os.getenv('NOTIFY_REPLY_TO')
    
    if os.getenv('NOTIFY_MIN_SEVERITY'):
        severity = os.getenv('NOTIFY_MIN_SEVERITY').lower()
        if severity in ['info', 'warning', 'error', 'critical']:
            settings['min_alert_severity'] = severity
    
    if os.getenv('NOTIFY_BATCH_SIZE'):
        try:
            batch_size = int(os.getenv('NOTIFY_BATCH_SIZE'))
            if 1 <= batch_size <= 1000:
                settings['batch_size'] = batch_size
        except ValueError:
            logger.warning("Invalid NOTIFY_BATCH_SIZE value, using default")
    
    if os.getenv('NOTIFY_RETRY_ATTEMPTS'):
        try:
            retry_attempts = int(os.getenv('NOTIFY_RETRY_ATTEMPTS'))
            if 0 <= retry_attempts <= 10:
                settings['retry_attempts'] = retry_attempts
        except ValueError:
            logger.warning("Invalid NOTIFY_RETRY_ATTEMPTS value, using default")
    
    # Update current time
    settings['current_time'] = datetime.now().isoformat()
    
    logger.info(f"Loaded notification settings: enabled={settings['enabled']}, from={settings['default_from']}")
    
    return settings

def update_notification_recipients(recipient_type: str, emails: List[str]) -> bool:
    """
    Update notification recipients for a specific type.
    
    In a real implementation, this would persist to database.
    For now, this is a placeholder that validates the inputs.
    
    Args:
        recipient_type: Type of recipients (admin, sales, support)
        emails: List of email addresses
        
    Returns:
        True if update was successful
    """
    logger.info(f"Updating {recipient_type} notification recipients")
    
    if recipient_type not in ['admin', 'sales', 'support']:
        logger.error(f"Invalid recipient type: {recipient_type}")
        return False
    
    # Validate all emails
    valid_emails = [email for email in emails if _is_valid_email(email)]
    
    if len(valid_emails) != len(emails):
        invalid_count = len(emails) - len(valid_emails)
        logger.warning(f"Filtered out {invalid_count} invalid email addresses")
    
    if not valid_emails:
        logger.error("No valid email addresses provided")
        return False
    
    # In a real implementation, persist to database here
    logger.info(f"Would update {recipient_type} recipients to: {valid_emails}")
    
    return True

def update_notification_settings(new_settings: Dict[str, Any]) -> bool:
    """
    Update notification system settings.
    
    In a real implementation, this would persist to database.
    For now, this validates the inputs.
    
    Args:
        new_settings: Dict with setting updates
        
    Returns:
        True if update was successful
    """
    logger.info("Updating notification settings")
    
    # Validate settings
    valid_settings = {}
    
    if 'enabled' in new_settings:
        if isinstance(new_settings['enabled'], bool):
            valid_settings['enabled'] = new_settings['enabled']
        else:
            logger.warning("Invalid 'enabled' setting, must be boolean")
    
    if 'default_from' in new_settings:
        if _is_valid_email(new_settings['default_from']):
            valid_settings['default_from'] = new_settings['default_from']
        else:
            logger.warning("Invalid 'default_from' email address")
    
    if 'min_alert_severity' in new_settings:
        severity = str(new_settings['min_alert_severity']).lower()
        if severity in ['info', 'warning', 'error', 'critical']:
            valid_settings['min_alert_severity'] = severity
        else:
            logger.warning("Invalid 'min_alert_severity', must be info/warning/error/critical")
    
    if not valid_settings:
        logger.error("No valid settings provided for update")
        return False
    
    # In a real implementation, persist to database here
    logger.info(f"Would update notification settings: {valid_settings}")
    
    return True

def _parse_email_list(email_string: str, default: List[str]) -> List[str]:
    """
    Parse comma-separated email list from string.
    
    Args:
        email_string: Comma-separated email addresses
        default: Default email list if parsing fails
        
    Returns:
        List of email addresses
    """
    if not email_string.strip():
        return default.copy()
    
    emails = [email.strip() for email in email_string.split(',')]
    return [email for email in emails if email]

def _is_valid_email(email: str) -> bool:
    """
    Basic email validation.
    
    Args:
        email: Email address to validate
        
    Returns:
        True if email appears valid
    """
    if not email or not isinstance(email, str):
        return False
    
    email = email.strip()
    
    # Basic validation
    if '@' not in email:
        return False
    
    local, domain = email.split('@', 1)
    
    if not local or not domain:
        return False
    
    if '.' not in domain:
        return False
    
    # Additional checks could be added here
    return True

def get_email_templates() -> Dict[str, Dict[str, str]]:
    """
    Get available email templates.
    
    Returns:
        Dict mapping template names to template info
    """
    templates = {
        'new_lead_notification': {
            'name': 'New Lead Notification',
            'description': 'Sent when a new lead is ingested',
            'variables': ['lead_name', 'lead_email', 'lead_id', 'admin_url']
        },
        'sale_delivered_notification': {
            'name': 'Sale Delivered Notification',
            'description': 'Sent when a sale is successfully delivered',
            'variables': ['sale_id', 'buyer_name', 'lead_name', 'price', 'admin_url']
        },
        'system_alert': {
            'name': 'System Alert',
            'description': 'Sent for system alerts and errors',
            'variables': ['alert_type', 'severity', 'message', 'timestamp']
        },
        'weekly_summary': {
            'name': 'Weekly Summary',
            'description': 'Weekly performance summary report',
            'variables': ['period_start', 'period_end', 'stats', 'charts']
        }
    }
    
    return templates

# Log configuration initialization
logger.info("Notification configuration initialized with environment variable support")
