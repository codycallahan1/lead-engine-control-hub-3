"""
CSV Import Service Layer
Phase 18: Parse CSV files and upsert leads/buyers with validation
Key responsibilities: CSV parsing, data validation, upsert operations with de-duplication
"""

import csv
import io
import logging
from typing import List, Dict, Tuple, Any
from datetime import datetime
import re

logger = logging.getLogger(__name__)

# Mock database operations for flat file structure
try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer
except ImportError:
    logger.warning("Database modules not found - using mock implementations")
    def get_session():
        return None
    
    class Lead:
        def __init__(self, **kwargs):
            pass
    
    class Buyer:
        def __init__(self, **kwargs):
            pass

def parse_csv(file_content: str, required_headers: List[str]) -> Tuple[List[Dict], List[str]]:
    """
    Parse CSV content and validate headers
    Returns: (rows, errors)
    """
    errors = []
    rows = []
    
    try:
        # Create CSV reader
        csv_file = io.StringIO(file_content)
        reader = csv.DictReader(csv_file)
        
        # Validate headers
        if not reader.fieldnames:
            return [], ["CSV file appears to be empty or invalid"]
        
        # Clean headers (strip whitespace)
        cleaned_headers = {name.strip(): name for name in reader.fieldnames if name.strip()}
        missing_headers = set(required_headers) - set(cleaned_headers.keys())
        
        if missing_headers:
            return [], [f"Missing required headers: {', '.join(missing_headers)}"]
        
        # Process rows
        for row_num, row in enumerate(reader, start=2):  # Start at 2 for header
            # Clean row data
            cleaned_row = {}
            for key, value in row.items():
                if key and key.strip():
                    cleaned_key = key.strip()
                    cleaned_value = value.strip() if value else ""
                    cleaned_row[cleaned_key] = cleaned_value
            
            # Skip empty rows
            if not any(cleaned_row.values()):
                continue
            
            # Validate required fields
            row_errors = []
            for header in required_headers:
                if not cleaned_row.get(header):
                    row_errors.append(f"Missing {header}")
            
            # Validate email format
            if 'email' in cleaned_row:
                email = cleaned_row['email'].lower()
                if not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
                    row_errors.append("Invalid email format")
                else:
                    cleaned_row['email'] = email  # Store normalized
            
            # Validate name length
            if 'name' in cleaned_row and len(cleaned_row['name']) < 2:
                row_errors.append("Name must be at least 2 characters")
            
            if row_errors:
                errors.append(f"Row {row_num}: {'; '.join(row_errors)}")
            else:
                cleaned_row['_row_num'] = row_num
                rows.append(cleaned_row)
    
    except Exception as e:
        errors.append(f"CSV parsing error: {str(e)}")
    
    logger.info(f"Parsed CSV: {len(rows)} valid rows, {len(errors)} errors")
    return rows, errors

def upsert_leads(rows: List[Dict], dry_run: bool = False) -> Dict[str, Any]:
    """
    Insert or update leads from CSV data
    Returns: {inserted, updated, rejected: [{row, reason}]}
    """
    result = {
        "inserted": 0,
        "updated": 0,
        "rejected": []
    }
    
    if dry_run:
        logger.info("DRY RUN: Would process %d lead rows", len(rows))
        # In dry run, simulate processing
        result["inserted"] = len(rows)
        return result
    
    try:
        # Mock database session context
        session = get_session()
        if not session:
            logger.warning("No database session available - using mock")
            result["inserted"] = len(rows)
            return result
        
        # Process each row
        seen_emails = set()
        
        with session:
            for row in rows:
                try:
                    email = row['email']
                    
                    # Check for duplicates in this batch
                    if email in seen_emails:
                        result["rejected"].append({
                            "row": row['_row_num'],
                            "reason": "Duplicate email in import batch"
                        })
                        continue
                    
                    seen_emails.add(email)
                    
                    # Check if lead exists
                    existing = session.query(Lead).filter(Lead.email == email).first()
                    
                    if existing:
                        # Update existing
                        existing.name = row['name']
                        existing.phone = row.get('phone', '')
                        result["updated"] += 1
                        logger.debug(f"Updated lead: {email}")
                    else:
                        # Create new
                        new_lead = Lead(
                            name=row['name'],
                            email=email,
                            phone=row.get('phone', ''),
                            created_at=datetime.utcnow()
                        )
                        session.add(new_lead)
                        result["inserted"] += 1
                        logger.debug(f"Created lead: {email}")
                
                except Exception as e:
                    result["rejected"].append({
                        "row": row.get('_row_num', '?'),
                        "reason": f"Database error: {str(e)}"
                    })
            
            session.commit()
    
    except Exception as e:
        logger.error(f"Error in upsert_leads: {str(e)}")
        result["rejected"].append({
            "row": "all",
            "reason": f"Transaction failed: {str(e)}"
        })
    
    logger.info(f"Upserted leads: {result['inserted']} inserted, {result['updated']} updated")
    return result

def upsert_buyers(rows: List[Dict], dry_run: bool = False) -> Dict[str, Any]:
    """
    Insert or update buyers from CSV data
    Returns: {inserted, updated, rejected: [{row, reason}]}
    """
    result = {
        "inserted": 0,
        "updated": 0,
        "rejected": []
    }
    
    if dry_run:
        logger.info("DRY RUN: Would process %d buyer rows", len(rows))
        result["inserted"] = len(rows)
        return result
    
    try:
        session = get_session()
        if not session:
            logger.warning("No database session available - using mock")
            result["inserted"] = len(rows)
            return result
        
        seen_emails = set()
        
        with session:
            for row in rows:
                try:
                    email = row['email']
                    
                    # Check for duplicates in this batch
                    if email in seen_emails:
                        result["rejected"].append({
                            "row": row['_row_num'],
                            "reason": "Duplicate email in import batch"
                        })
                        continue
                    
                    seen_emails.add(email)
                    
                    # Check if buyer exists
                    existing = session.query(Buyer).filter(Buyer.email == email).first()
                    
                    if existing:
                        # Update existing
                        existing.name = row['name']
                        result["updated"] += 1
                        logger.debug(f"Updated buyer: {email}")
                    else:
                        # Create new
                        new_buyer = Buyer(
                            name=row['name'],
                            email=email,
                            created_at=datetime.utcnow()
                        )
                        session.add(new_buyer)
                        result["inserted"] += 1
                        logger.debug(f"Created buyer: {email}")
                
                except Exception as e:
                    result["rejected"].append({
                        "row": row.get('_row_num', '?'),
                        "reason": f"Database error: {str(e)}"
                    })
            
            session.commit()
    
    except Exception as e:
        logger.error(f"Error in upsert_buyers: {str(e)}")
        result["rejected"].append({
            "row": "all",
            "reason": f"Transaction failed: {str(e)}"
        })
    
    logger.info(f"Upserted buyers: {result['inserted']} inserted, {result['updated']} updated")
    return result
