"""
Reports and analytics service for operational insights.

Phase: 30
Purpose: Generate KPIs and analytics reports with date bucketing.
Key responsibilities:
- Time-series data aggregation by day
- Success rate calculations
- Buyer performance rankings
- CSV export utilities
"""

import logging
from datetime import datetime, timedelta, date
from typing import Dict, Any, List, Optional, Tuple
from collections import defaultdict

try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer
    from p28__server_models_matching import MatchLog
    from p29__server_models_webhooks import DispatchLog
    from sqlalchemy import func, and_, or_
except ImportError as e:
    logging.warning(f"Reports service: missing dependency {e}")

logger = logging.getLogger(__name__)


def parse_date_range(start_str: Optional[str], end_str: Optional[str]) -> Tuple[datetime, datetime]:
    """
    Parse date range strings with sensible defaults.
    
    Args:
        start_str: Start date in YYYY-MM-DD format (optional)
        end_str: End date in YYYY-MM-DD format (optional)
    
    Returns:
        Tuple of (start_datetime, end_datetime)
    """
    # Default to last 30 days if not specified
    if not end_str:
        end_date = datetime.utcnow().date()
    else:
        end_date = datetime.strptime(end_str, "%Y-%m-%d").date()
    
    if not start_str:
        start_date = end_date - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_str, "%Y-%m-%d").date()
    
    # Convert to datetime with time boundaries
    start_datetime = datetime.combine(start_date, datetime.min.time())
    end_datetime = datetime.combine(end_date, datetime.max.time())
    
    return start_datetime, end_datetime


def generate_date_buckets(start_datetime: datetime, end_datetime: datetime) -> List[date]:
    """
    Generate list of dates between start and end (inclusive).
    
    Args:
        start_datetime: Start datetime
        end_datetime: End datetime
    
    Returns:
        List of date objects
    """
    dates = []
    current_date = start_datetime.date()
    end_date = end_datetime.date()
    
    while current_date <= end_date:
        dates.append(current_date)
        current_date += timedelta(days=1)
    
    return dates


def leads_by_day(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Get daily lead creation counts.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
    
    Returns:
        List of {"date": "YYYY-MM-DD", "count": int} dicts
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        with get_session() as db:
            # Get daily counts from database
            daily_counts = db.query(
                func.date(Lead.created_at).label('date'),
                func.count(Lead.id).label('count')
            ).filter(
                Lead.org_id == org_id,
                Lead.created_at >= start_datetime,
                Lead.created_at <= end_datetime
            ).group_by(
                func.date(Lead.created_at)
            ).all()
            
            # Convert to dict for easy lookup
            counts_dict = {row.date: row.count for row in daily_counts}
            
            # Generate complete date range with zero-filled gaps
            date_buckets = generate_date_buckets(start_datetime, end_datetime)
            
            result = []
            for bucket_date in date_buckets:
                result.append({
                    "date": bucket_date.isoformat(),
                    "count": counts_dict.get(bucket_date, 0)
                })
            
            logger.info(f"Generated leads by day report: {len(result)} days, {sum(r['count'] for r in result)} total leads")
            return result
    
    except Exception as e:
        logger.error(f"Error generating leads by day report: {e}")
        return []


def matches_by_day(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Get daily match counts with success breakdown.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
    
    Returns:
        List of {"date": "YYYY-MM-DD", "total": int, "matched": int, "success_rate": float} dicts
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        with get_session() as db:
            # Get daily match counts by status
            daily_matches = db.query(
                func.date(MatchLog.created_at).label('date'),
                MatchLog.status,
                func.count(MatchLog.id).label('count')
            ).filter(
                MatchLog.org_id == org_id,
                MatchLog.created_at >= start_datetime,
                MatchLog.created_at <= end_datetime
            ).group_by(
                func.date(MatchLog.created_at),
                MatchLog.status
            ).all()
            
            # Organize by date and status
            daily_data = defaultdict(lambda: {"total": 0, "matched": 0})
            
            for row in daily_matches:
                day_key = row.date
                daily_data[day_key]["total"] += row.count
                
                if row.status == "matched":
                    daily_data[day_key]["matched"] += row.count
            
            # Generate complete date range
            date_buckets = generate_date_buckets(start_datetime, end_datetime)
            
            result = []
            for bucket_date in date_buckets:
                data = daily_data.get(bucket_date, {"total": 0, "matched": 0})
                success_rate = (data["matched"] / data["total"] * 100) if data["total"] > 0 else 0
                
                result.append({
                    "date": bucket_date.isoformat(),
                    "total": data["total"],
                    "matched": data["matched"],
                    "success_rate": round(success_rate, 1)
                })
            
            logger.info(f"Generated matches by day report: {len(result)} days")
            return result
    
    except Exception as e:
        logger.error(f"Error generating matches by day report: {e}")
        return []


def dispatch_success_rate(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None) -> Dict[str, Any]:
    """
    Calculate dispatch success rates and metrics.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
    
    Returns:
        Dict with success rate metrics
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        with get_session() as db:
            # Get dispatch counts by status
            dispatch_counts = db.query(
                DispatchLog.status,
                func.count(DispatchLog.id).label('count'),
                func.avg(DispatchLog.response_time_ms).label('avg_response_time'),
                func.avg(DispatchLog.attempts).label('avg_attempts')
            ).filter(
                DispatchLog.org_id == org_id,
                DispatchLog.created_at >= start_datetime,
                DispatchLog.created_at <= end_datetime
            ).group_by(DispatchLog.status).all()
            
            # Calculate metrics
            total_dispatches = 0
            successful_dispatches = 0
            status_breakdown = {}
            avg_response_time = 0
            avg_attempts = 0
            
            for row in dispatch_counts:
                status_breakdown[row.status] = row.count
                total_dispatches += row.count
                
                if row.status == "success":
                    successful_dispatches += row.count
                    avg_response_time = row.avg_response_time or 0
                    avg_attempts = row.avg_attempts or 0
            
            success_rate = (successful_dispatches / total_dispatches * 100) if total_dispatches > 0 else 0
            
            result = {
                "total_dispatches": total_dispatches,
                "successful_dispatches": successful_dispatches,
                "success_rate": round(success_rate, 1),
                "avg_response_time_ms": round(avg_response_time, 1) if avg_response_time else 0,
                "avg_attempts": round(avg_attempts, 1) if avg_attempts else 0,
                "status_breakdown": status_breakdown,
                "period": {
                    "start": start_datetime.date().isoformat(),
                    "end": end_datetime.date().isoformat()
                }
            }
            
            logger.info(f"Generated dispatch success rate report: {success_rate}% success rate")
            return result
    
    except Exception as e:
        logger.error(f"Error calculating dispatch success rate: {e}")
        return {
            "total_dispatches": 0,
            "successful_dispatches": 0,
            "success_rate": 0,
            "avg_response_time_ms": 0,
            "avg_attempts": 0,
            "status_breakdown": {},
            "error": str(e)
        }


def buyer_intake_ranking(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None, top: int = 10) -> List[Dict[str, Any]]:
    """
    Rank buyers by lead intake volume and success metrics.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
        top: Number of top buyers to return
    
    Returns:
        List of buyer ranking dicts
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        with get_session() as db:
            # Get buyer stats from matches and dispatches
            buyer_stats = db.query(
                Buyer.id,
                Buyer.name,
                func.count(MatchLog.id).label('total_matches'),
                func.sum(func.case([(MatchLog.status == 'matched', 1)], else_=0)).label('successful_matches'),
                func.count(DispatchLog.id).label('total_dispatches'),
                func.sum(func.case([(DispatchLog.status == 'success', 1)], else_=0)).label('successful_dispatches')
            ).outerjoin(
                MatchLog, and_(
                    MatchLog.buyer_id == Buyer.id,
                    MatchLog.created_at >= start_datetime,
                    MatchLog.created_at <= end_datetime
                )
            ).outerjoin(
                DispatchLog, and_(
                    DispatchLog.buyer_id == Buyer.id,
                    DispatchLog.created_at >= start_datetime,
                    DispatchLog.created_at <= end_datetime
                )
            ).filter(
                Buyer.org_id == org_id
            ).group_by(
                Buyer.id, Buyer.name
            ).order_by(
                func.count(MatchLog.id).desc()
            ).limit(top).all()
            
            result = []
            for i, stats in enumerate(buyer_stats, 1):
                total_matches = stats.total_matches or 0
                successful_matches = stats.successful_matches or 0
                total_dispatches = stats.total_dispatches or 0
                successful_dispatches = stats.successful_dispatches or 0
                
                match_rate = (successful_matches / total_matches * 100) if total_matches > 0 else 0
                dispatch_rate = (successful_dispatches / total_dispatches * 100) if total_dispatches > 0 else 0
                
                result.append({
                    "rank": i,
                    "buyer_id": stats.id,
                    "buyer_name": stats.name,
                    "total_matches": total_matches,
                    "successful_matches": successful_matches,
                    "match_success_rate": round(match_rate, 1),
                    "total_dispatches": total_dispatches,
                    "successful_dispatches": successful_dispatches,
                    "dispatch_success_rate": round(dispatch_rate, 1),
                    "overall_score": round((match_rate + dispatch_rate) / 2, 1)
                })
            
            logger.info(f"Generated buyer ranking: top {len(result)} buyers")
            return result
    
    except Exception as e:
        logger.error(f"Error generating buyer ranking: {e}")
        return []


def generate_summary_report(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None) -> Dict[str, Any]:
    """
    Generate comprehensive summary report with all key metrics.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
    
    Returns:
        Dict with complete summary metrics
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        # Generate individual reports
        leads_data = leads_by_day(org_id, start_str, end_str)
        matches_data = matches_by_day(org_id, start_str, end_str)
        dispatch_data = dispatch_success_rate(org_id, start_str, end_str)
        buyer_rankings = buyer_intake_ranking(org_id, start_str, end_str, top=5)
        
        # Calculate summary totals
        total_leads = sum(day["count"] for day in leads_data)
        total_matches = sum(day["total"] for day in matches_data)
        successful_matches = sum(day["matched"] for day in matches_data)
        
        overall_match_rate = (successful_matches / total_matches * 100) if total_matches > 0 else 0
        
        # Calculate daily averages
        num_days = len(leads_data)
        avg_leads_per_day = total_leads / num_days if num_days > 0 else 0
        avg_matches_per_day = total_matches / num_days if num_days > 0 else 0
        
        summary = {
            "period": {
                "start": start_datetime.date().isoformat(),
                "end": end_datetime.date().isoformat(),
                "days": num_days
            },
            "totals": {
                "leads": total_leads,
                "matches": total_matches,
                "successful_matches": successful_matches,
                "dispatches": dispatch_data["total_dispatches"]
            },
            "rates": {
                "match_success_rate": round(overall_match_rate, 1),
                "dispatch_success_rate": dispatch_data["success_rate"]
            },
            "averages": {
                "leads_per_day": round(avg_leads_per_day, 1),
                "matches_per_day": round(avg_matches_per_day, 1)
            },
            "top_buyers": buyer_rankings[:3],  # Top 3 for summary
            "dispatch_metrics": {
                "avg_response_time_ms": dispatch_data["avg_response_time_ms"],
                "avg_attempts": dispatch_data["avg_attempts"]
            },
            "generated_at": datetime.utcnow().isoformat()
        }
        
        logger.info(f"Generated summary report for org {org_id}: {total_leads} leads, {overall_match_rate}% match rate")
        return summary
    
    except Exception as e:
        logger.error(f"Error generating summary report: {e}")
        return {
            "error": str(e),
            "period": {
                "start": start_str or "unknown",
                "end": end_str or "unknown",
                "days": 0
            }
        }


def export_leads_csv(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None):
    """
    Generator function for streaming leads CSV export.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
    
    Yields:
        CSV rows as strings
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        # CSV header
        yield "id,name,email,phone,created_at,matched,buyer_id,dispatched\n"
        
        with get_session() as db:
            # Stream leads with join to match/dispatch data
            leads_query = db.query(
                Lead.id,
                Lead.name,
                Lead.email,
                Lead.phone,
                Lead.created_at,
                MatchLog.buyer_id,
                MatchLog.status.label('match_status'),
                DispatchLog.status.label('dispatch_status')
            ).outerjoin(
                MatchLog, and_(
                    MatchLog.lead_id == Lead.id,
                    MatchLog.status == 'matched'
                )
            ).outerjoin(
                DispatchLog, and_(
                    DispatchLog.lead_id == Lead.id,
                    DispatchLog.status == 'success'
                )
            ).filter(
                Lead.org_id == org_id,
                Lead.created_at >= start_datetime,
                Lead.created_at <= end_datetime
            ).order_by(Lead.created_at)
            
            # Stream results in batches
            batch_size = 1000
            offset = 0
            
            while True:
                batch = leads_query.offset(offset).limit(batch_size).all()
                if not batch:
                    break
                
                for lead in batch:
                    # Format CSV row
                    csv_row = f"{lead.id}," \
                             f'"{lead.name or ""}",' \
                             f'"{lead.email or ""}",' \
                             f'"{lead.phone or ""}",' \
                             f'"{lead.created_at.isoformat() if lead.created_at else ""}",' \
                             f'"{lead.match_status or "no"}",' \
                             f'"{lead.buyer_id or ""}",' \
                             f'"{lead.dispatch_status or "no"}"\n'
                    
                    yield csv_row
                
                offset += batch_size
        
        logger.info(f"Completed leads CSV export for org {org_id}")
    
    except Exception as e:
        logger.error(f"Error in leads CSV export: {e}")
        yield f"# Error: {str(e)}\n"


def export_matches_csv(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None):
    """
    Generator function for streaming matches CSV export.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
    
    Yields:
        CSV rows as strings
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        # CSV header
        yield "match_id,lead_id,buyer_id,rule_id,score,status,created_at,lead_name,lead_email,buyer_name\n"
        
        with get_session() as db:
            # Stream matches with lead/buyer details
            matches_query = db.query(
                MatchLog.id,
                MatchLog.lead_id,
                MatchLog.buyer_id,
                MatchLog.rule_id,
                MatchLog.score,
                MatchLog.status,
                MatchLog.created_at,
                Lead.name.label('lead_name'),
                Lead.email.label('lead_email'),
                Buyer.name.label('buyer_name')
            ).join(
                Lead, Lead.id == MatchLog.lead_id
            ).outerjoin(
                Buyer, Buyer.id == MatchLog.buyer_id
            ).filter(
                MatchLog.org_id == org_id,
                MatchLog.created_at >= start_datetime,
                MatchLog.created_at <= end_datetime
            ).order_by(MatchLog.created_at)
            
            # Stream results in batches
            batch_size = 1000
            offset = 0
            
            while True:
                batch = matches_query.offset(offset).limit(batch_size).all()
                if not batch:
                    break
                
                for match in batch:
                    # Format CSV row
                    csv_row = f"{match.id}," \
                             f"{match.lead_id}," \
                             f'"{match.buyer_id or ""}",' \
                             f'"{match.rule_id or ""}",' \
                             f"{match.score}," \
                             f'"{match.status}",' \
                             f'"{match.created_at.isoformat() if match.created_at else ""}",' \
                             f'"{match.lead_name or ""}",' \
                             f'"{match.lead_email or ""}",' \
                             f'"{match.buyer_name or ""}"\n'
                    
                    yield csv_row
                
                offset += batch_size
        
        logger.info(f"Completed matches CSV export for org {org_id}")
    
    except Exception as e:
        logger.error(f"Error in matches CSV export: {e}")
        yield f"# Error: {str(e)}\n"


def export_dispatches_csv(org_id: int, start_str: Optional[str] = None, end_str: Optional[str] = None):
    """
    Generator function for streaming dispatches CSV export.
    
    Args:
        org_id: Organization ID for scoping
        start_str: Start date string (YYYY-MM-DD)
        end_str: End date string (YYYY-MM-DD)
    
    Yields:
        CSV rows as strings
    """
    try:
        start_datetime, end_datetime = parse_date_range(start_str, end_str)
        
        # CSV header
        yield "dispatch_id,lead_id,buyer_id,endpoint_id,status,attempts,response_code,response_time_ms,created_at,completed_at,lead_email,buyer_name\n"
        
        with get_session() as db:
            # Stream dispatches with lead/buyer details
            dispatches_query = db.query(
                DispatchLog.id,
                DispatchLog.lead_id,
                DispatchLog.buyer_id,
                DispatchLog.endpoint_id,
                DispatchLog.status,
                DispatchLog.attempts,
                DispatchLog.response_code,
                DispatchLog.response_time_ms,
                DispatchLog.created_at,
                DispatchLog.completed_at,
                Lead.email.label('lead_email'),
                Buyer.name.label('buyer_name')
            ).join(
                Lead, Lead.id == DispatchLog.lead_id
            ).join(
                Buyer, Buyer.id == DispatchLog.buyer_id
            ).filter(
                DispatchLog.org_id == org_id,
                DispatchLog.created_at >= start_datetime,
                DispatchLog.created_at <= end_datetime
            ).order_by(DispatchLog.created_at)
            
            # Stream results in batches
            batch_size = 1000
            offset = 0
            
            while True:
                batch = dispatches_query.offset(offset).limit(batch_size).all()
                if not batch:
                    break
                
                for dispatch in batch:
                    # Format CSV row
                    csv_row = f"{dispatch.id}," \
                             f"{dispatch.lead_id}," \
                             f"{dispatch.buyer_id}," \
                             f"{dispatch.endpoint_id}," \
                             f'"{dispatch.status}",' \
                             f"{dispatch.attempts}," \
                             f'"{dispatch.response_code or ""}",' \
                             f'"{dispatch.response_time_ms or ""}",' \
                             f'"{dispatch.created_at.isoformat() if dispatch.created_at else ""}",' \
                             f'"{dispatch.completed_at.isoformat() if dispatch.completed_at else ""}",' \
                             f'"{dispatch.lead_email or ""}",' \
                             f'"{dispatch.buyer_name or ""}"\n'
                    
                    yield csv_row
                
                offset += batch_size
        
        logger.info(f"Completed dispatches CSV export for org {org_id}")
    
    except Exception as e:
        logger.error(f"Error in dispatches CSV export: {e}")
        yield f"# Error: {str(e)}\n"
