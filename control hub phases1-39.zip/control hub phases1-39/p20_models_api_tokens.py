"""
API Tokens Database Model
Phase 20: Role-based access control with API tokens
Key responsibilities: Store tokens with roles, support admin/viewer permissions
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import secrets

# Import base from existing models or create if needed
try:
    from p02__server_db import Base
except ImportError:
    Base = declarative_base()

class ApiToken(Base):
    """
    API token for role-based access control
    Supports admin and viewer roles with different permissions
    """
    __tablename__ = "api_tokens"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)  # Human-readable name
    token = Column(String(64), unique=True, index=True, nullable=False)  # Actual token
    role = Column(String(50), nullable=False)  # 'admin' or 'viewer'
    active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f"<ApiToken(name='{self.name}', role='{self.role}', active={self.active})>"
    
    def to_dict(self, include_token=False):
        """
        Convert to dictionary for JSON serialization
        
        Args:
            include_token: Whether to include the actual token (only on creation)
        """
        result = {
            "id": self.id,
            "name": self.name,
            "role": self.role,
            "active": self.active,
            "created_at": self.created_at.isoformat(),
            "token_preview": f"{self.token[:8]}..." if self.token else None
        }
        
        if include_token:
            result["token"] = self.token
        
        return result
    
    @classmethod
    def generate_token(cls):
        """Generate a secure random token"""
        return secrets.token_urlsafe(32)  # 32 bytes = 43 characters base64
    
    @classmethod
    def create_token(cls, name: str, role: str, active: bool = True):
        """
        Create a new API token instance
        
        Args:
            name: Human-readable name for the token
            role: Role ('admin' or 'viewer')
            active: Whether token is active
        
        Returns:
            ApiToken instance with generated token
        """
        if role not in ['admin', 'viewer']:
            raise ValueError("Role must be 'admin' or 'viewer'")
        
        return cls(
            name=name,
            token=cls.generate_token(),
            role=role,
            active=active,
            created_at=datetime.utcnow()
        )
    
    def has_permission(self, required_role: str) -> bool:
        """
        Check if token has required permission level
        
        Args:
            required_role: Required role ('admin' or 'viewer')
        
        Returns:
            True if token has sufficient permissions
        """
        if not self.active:
            return False
        
        if required_role == 'viewer':
            return self.role in ['admin', 'viewer']
        elif required_role == 'admin':
            return self.role == 'admin'
        
        return False
    
    def is_admin(self) -> bool:
        """Check if token has admin privileges"""
        return self.active and self.role == 'admin'
    
    def is_viewer(self) -> bool:
        """Check if token has at least viewer privileges"""
        return self.active and self.role in ['admin', 'viewer']

# Role constants for consistency
class TokenRole:
    ADMIN = 'admin'
    VIEWER = 'viewer'
    
    @classmethod
    def all_roles(cls):
        return [cls.ADMIN, cls.VIEWER]
    
    @classmethod
    def is_valid(cls, role: str) -> bool:
        return role in cls.all_roles()

# Ensure table creation helper
def create_api_tokens_table(engine):
    """Create API tokens table if it doesn't exist"""
    try:
        ApiToken.__table__.create(engine, checkfirst=True)
        return True
    except Exception as e:
        print(f"Error creating API tokens table: {e}")
        return False

# Token validation helpers
def validate_token_data(name: str, role: str) -> tuple:
    """
    Validate token creation data
    
    Returns:
        (is_valid, error_message)
    """
    if not name or len(name.strip()) < 3:
        return False, "Token name must be at least 3 characters"
    
    if not TokenRole.is_valid(role):
        return False, f"Invalid role. Must be one of: {', '.join(TokenRole.all_roles())}"
    
    return True, None
