"""
Audit Log Retention Service
Phase 21: Automated cleanup of old audit records based on retention policy
Key responsibilities: Daily purge job, configurable retention, logging of cleanup operations
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p21__server_models_audit import Audit, AuditKind, get_audit_retention_days, log_audit_event
except ImportError:
    logger.warning("Audit retention modules not found - using mock implementations")
    def get_session():
        return None
    
    class Audit:
        pass
    
    class AuditKind:
        DATA_PURGED = "data_purged"
    
    def get_audit_retention_days(session):
        return 30
    
    def log_audit_event(session, kind, message, meta=None):
        logger.info(f"AUDIT: {kind} - {message}")

def purge_old_records() -> str:
    """
    Purge audit records older than retention policy
    Called daily by scheduler
    
    Returns:
        Status message indicating results
    """
    try:
        session = get_session()
        if not session:
            logger.warning("No database session - audit purge skipped")
            return "skipped_no_db"
        
        with session:
            # Get retention policy
            retention_days = get_audit_retention_days(session)
            cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
            
            logger.info(f"Starting audit purge: retention={retention_days} days, cutoff={cutoff_date}")
            
            # Count records to be purged
            old_records_query = session.query(Audit).filter(Audit.ts < cutoff_date)
            records_to_purge = old_records_query.count()
            
            if records_to_purge == 0:
                logger.info("No audit records to purge")
                return "no_records_to_purge"
            
            # Get some stats before deletion
            oldest_record = session.query(Audit.ts).order_by(Audit.ts.asc()).first()
            oldest_date = oldest_record[0] if oldest_record else None
            
            # Perform deletion
            deleted_count = old_records_query.delete()
            session.commit()
            
            # Log the purge operation
            purge_message = f"Purged {deleted_count} audit records older than {retention_days} days"
            purge_meta = {
                "retention_days": retention_days,
                "cutoff_date": cutoff_date.isoformat(),
                "deleted_count": deleted_count,
                "oldest_purged_date": oldest_date.isoformat() if oldest_date else None
            }
            
            log_audit_event(session, AuditKind.DATA_PURGED, purge_message, purge_meta)
            
            logger.info(f"Audit purge completed: deleted {deleted_count} records")
            return f"purged_{deleted_count}_records"
    
    except Exception as e:
        error_msg = f"Error during audit purge: {str(e)}"
        logger.error(error_msg)
        
        # Try to log the error (if possible)
        try:
            session = get_session()
            if session:
                with session:
                    log_audit_event(
                        session,
                        AuditKind.DATA_PURGED,
                        f"Audit purge failed: {str(e)}",
                        {"error": str(e), "status": "failed"}
                    )
        except:
            pass  # Don't let logging errors prevent error reporting
        
        return f"error: {str(e)}"

def get_purge_preview(retention_days: int = None) -> Dict[str, Any]:
    """
    Preview what would be purged without actually deleting
    Useful for administrators to understand impact
    
    Args:
        retention_days: Override retention policy for preview
    
    Returns:
        Dictionary with purge preview information
    """
    try:
        session = get_session()
        if not session:
            return {
                "preview_mode": True,
                "error": "No database session available",
                "records_to_purge": 0
            }
        
        with session:
            # Use provided retention or get from settings
            if retention_days is None:
                retention_days = get_audit_retention_days(session)
            
            cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
            
            # Count records that would be purged
            records_to_purge = session.query(Audit).filter(Audit.ts < cutoff_date).count()
            
            # Get oldest and newest records in purge range
            purge_query = session.query(Audit).filter(Audit.ts < cutoff_date)
            oldest_in_range = purge_query.order_by(Audit.ts.asc()).first()
            newest_in_range = purge_query.order_by(Audit.ts.desc()).first()
            
            # Get total record count for context
            total_records = session.query(Audit).count()
            
            # Get counts by kind for records to be purged
            kind_counts = {}
            for kind in ['system_startup', 'lead_created', 'export_data', 'webhook_triggered']:
                count = session.query(Audit).filter(
                    Audit.ts < cutoff_date,
                    Audit.kind == kind
                ).count()
                if count > 0:
                    kind_counts[kind] = count
            
            return {
                "preview_mode": True,
                "retention_days": retention_days,
                "cutoff_date": cutoff_date.isoformat(),
                "records_to_purge": records_to_purge,
                "total_records": total_records,
                "percentage_to_purge": (records_to_purge / total_records * 100) if total_records > 0 else 0,
                "oldest_record_to_purge": oldest_in_range.ts.isoformat() if oldest_in_range else None,
                "newest_record_to_purge": newest_in_range.ts.isoformat() if newest_in_range else None,
                "records_by_kind": kind_counts
            }
    
    except Exception as e:
        logger.error(f"Error generating purge preview: {e}")
        return {
            "preview_mode": True,
            "error": str(e),
            "records_to_purge": 0
        }

def force_purge_by_kind(kind: str, older_than_days: int = 7) -> Dict[str, Any]:
    """
    Force purge specific kind of audit records
    Useful for cleaning up verbose logs or specific event types
    
    Args:
        kind: Audit event kind to purge
        older_than_days: Only purge records older than this many days
    
    Returns:
        Results of the forced purge operation
    """
    try:
        session = get_session()
        if not session:
            return {"error": "No database session available", "deleted": 0}
        
        cutoff_date = datetime.utcnow() - timedelta(days=older_than_days)
        
        with session:
            # Count and delete records of specific kind
            target_query = session.query(Audit).filter(
                Audit.kind == kind,
                Audit.ts < cutoff_date
            )
            
            records_to_delete = target_query.count()
            
            if records_to_delete == 0:
                return {
                    "kind": kind,
                    "cutoff_date": cutoff_date.isoformat(),
                    "deleted": 0,
                    "message": f"No {kind} records found older than {older_than_days} days"
                }
            
            # Perform deletion
            deleted_count = target_query.delete()
            session.commit()
            
            # Log the forced purge
            purge_message = f"Force purged {deleted_count} '{kind}' audit records older than {older_than_days} days"
            purge_meta = {
                "kind": kind,
                "older_than_days": older_than_days,
                "cutoff_date": cutoff_date.isoformat(),
                "deleted_count": deleted_count,
                "operation": "force_purge_by_kind"
            }
            
            log_audit_event(session, AuditKind.DATA_PURGED, purge_message, purge_meta)
            
            logger.info(f"Force purged {deleted_count} '{kind}' audit records")
            
            return {
                "kind": kind,
                "cutoff_date": cutoff_date.isoformat(),
                "deleted": deleted_count,
                "message": f"Successfully purged {deleted_count} '{kind}' records"
            }
    
    except Exception as e:
        error_msg = f"Error during force purge of '{kind}': {str(e)}"
        logger.error(error_msg)
        return {"error": error_msg, "deleted": 0}

def get_retention_stats() -> Dict[str, Any]:
    """
    Get statistics about audit retention and storage usage
    Useful for monitoring and capacity planning
    """
    try:
        session = get_session()
        if not session:
            return {
                "error": "No database session available",
                "total_records": 0
            }
        
        with session:
            retention_days = get_audit_retention_days(session)
            cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
            
            # Count records in various categories
            total_records = session.query(Audit).count()
            records_within_retention = session.query(Audit).filter(Audit.ts >= cutoff_date).count()
            records_beyond_retention = session.query(Audit).filter(Audit.ts < cutoff_date).count()
            
            # Get date range of all records
            oldest_record = session.query(Audit.ts).order_by(Audit.ts.asc()).first()
            newest_record = session.query(Audit.ts).order_by(Audit.ts.desc()).first()
            
            # Calculate storage efficiency
            retention_compliance = (records_within_retention / total_records * 100) if total_records > 0 else 100
            
            return {
                "retention_policy": {
                    "days": retention_days,
                    "cutoff_date": cutoff_date.isoformat()
                },
                "record_counts": {
                    "total": total_records,
                    "within_retention": records_within_retention,
                    "beyond_retention": records_beyond_retention
                },
                "date_range": {
                    "oldest": oldest_record[0].isoformat() if oldest_record else None,
                    "newest": newest_record[0].isoformat() if newest_record else None
                },
                "compliance": {
                    "percentage_within_retention": round(retention_compliance, 2),
                    "needs_purge": records_beyond_retention > 0
                },
                "recommendations": {
                    "should_run_purge": records_beyond_retention > 0,
                    "estimated_space_savings": f"{records_beyond_retention} records"
                }
            }
    
    except Exception as e:
        logger.error(f"Error getting retention stats: {e}")
        return {"error": str(e), "total_records": 0}

# Scheduler integration function
def register_retention_task(scheduler):
    """
    Register daily retention cleanup task with scheduler
    Should be called during application startup
    """
    try:
        scheduler.add_daily_task("audit_retention", purge_old_records, hour=2, minute=0)
        logger.info("Audit retention task registered with scheduler")
    except Exception as e:
        logger.error(f"Failed to register audit retention task: {e}")
