"""
Lead Engine Control Hub - Pydantic Schemas
Phase: 2
Purpose: Define Pydantic schemas for API request/response validation and serialization
Key Responsibilities:
- Input schemas for creating/updating entities
- Output schemas for API responses
- Update schemas for partial updates
- Email validation and type safety
"""

import logging
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, validator

logger = logging.getLogger(__name__)

# =============================================================================
# LEAD SCHEMAS
# =============================================================================

class LeadBase(BaseModel):
    """Base schema for Lead with common fields"""
    name: str = Field(..., min_length=2, max_length=255, description="Full name of the lead")
    email: EmailStr = Field(..., description="Valid email address")
    phone: Optional[str] = Field(None, max_length=50, description="Phone number (optional)")

    @validator('name')
    def validate_name(cls, v):
        """Validate name field"""
        if not v.strip():
            raise ValueError('Name cannot be empty or just whitespace')
        return v.strip()

    @validator('phone')
    def validate_phone(cls, v):
        """Validate phone field"""
        if v is not None:
            v = v.strip()
            if not v:  # Empty string after strip
                return None
        return v

class LeadIn(LeadBase):
    """Schema for creating a new lead"""
    pass

class LeadOut(LeadBase):
    """Schema for lead responses"""
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

class LeadUpdate(BaseModel):
    """Schema for updating an existing lead"""
    name: Optional[str] = Field(None, min_length=2, max_length=255)
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, max_length=50)

    @validator('name')
    def validate_name(cls, v):
        """Validate name field"""
        if v is not None:
            if not v.strip():
                raise ValueError('Name cannot be empty or just whitespace')
            return v.strip()
        return v

    @validator('phone')
    def validate_phone(cls, v):
        """Validate phone field"""
        if v is not None:
            v = v.strip()
            if not v:  # Empty string after strip
                return None
        return v

# =============================================================================
# BUYER SCHEMAS
# =============================================================================

class BuyerBase(BaseModel):
    """Base schema for Buyer with common fields"""
    name: str = Field(..., min_length=2, max_length=255, description="Buyer company or individual name")
    email: EmailStr = Field(..., description="Contact email for the buyer")

    @validator('name')
    def validate_name(cls, v):
        """Validate name field"""
        if not v.strip():
            raise ValueError('Name cannot be empty or just whitespace')
        return v.strip()

class BuyerIn(BuyerBase):
    """Schema for creating a new buyer"""
    pass

class BuyerOut(BuyerBase):
    """Schema for buyer responses"""
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

class BuyerUpdate(BaseModel):
    """Schema for updating an existing buyer"""
    name: Optional[str] = Field(None, min_length=2, max_length=255)
    email: Optional[EmailStr] = None

    @validator('name')
    def validate_name(cls, v):
        """Validate name field"""
        if v is not None:
            if not v.strip():
                raise ValueError('Name cannot be empty or just whitespace')
            return v.strip()
        return v

# =============================================================================
# SITE SCHEMAS
# =============================================================================

class SiteBase(BaseModel):
    """Base schema for Site with common fields"""
    name: str = Field(..., min_length=2, max_length=255, description="Display name for the site")
    domain: str = Field(..., min_length=3, max_length=255, description="Domain name of the site")
    status: str = Field("active", description="Site status")

    @validator('name')
    def validate_name(cls, v):
        """Validate name field"""
        if not v.strip():
            raise ValueError('Name cannot be empty or just whitespace')
        return v.strip()

    @validator('domain')
    def validate_domain(cls, v):
        """Validate domain field"""
        if not v.strip():
            raise ValueError('Domain cannot be empty or just whitespace')
        domain = v.strip().lower()
        # Basic domain validation
        if not '.' in domain or domain.startswith('.') or domain.endswith('.'):
            raise ValueError('Invalid domain format')
        return domain

    @validator('status')
    def validate_status(cls, v):
        """Validate status field"""
        allowed_statuses = {'active', 'inactive', 'pending', 'suspended'}
        if v.lower() not in allowed_statuses:
            raise ValueError(f'Status must be one of: {", ".join(allowed_statuses)}')
        return v.lower()

class SiteIn(SiteBase):
    """Schema for creating a new site"""
    pass

class SiteOut(SiteBase):
    """Schema for site responses"""
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

class SiteUpdate(BaseModel):
    """Schema for updating an existing site"""
    name: Optional[str] = Field(None, min_length=2, max_length=255)
    domain: Optional[str] = Field(None, min_length=3, max_length=255)
    status: Optional[str] = None

    @validator('name')
    def validate_name(cls, v):
        """Validate name field"""
        if v is not None:
            if not v.strip():
                raise ValueError('Name cannot be empty or just whitespace')
            return v.strip()
        return v

    @validator('domain')
    def validate_domain(cls, v):
        """Validate domain field"""
        if v is not None:
            if not v.strip():
                raise ValueError('Domain cannot be empty or just whitespace')
            domain = v.strip().lower()
            # Basic domain validation
            if not '.' in domain or domain.startswith('.') or domain.endswith('.'):
                raise ValueError('Invalid domain format')
            return domain
        return v

    @validator('status')
    def validate_status(cls, v):
        """Validate status field"""
        if v is not None:
            allowed_statuses = {'active', 'inactive', 'pending', 'suspended'}
            if v.lower() not in allowed_statuses:
                raise ValueError(f'Status must be one of: {", ".join(allowed_statuses)}')
            return v.lower()
        return v

# =============================================================================
# UTILITY SCHEMAS
# =============================================================================

class ResponseMessage(BaseModel):
    """Generic response message schema"""
    message: str
    status: str = "success"

class ErrorResponse(BaseModel):
    """Error response schema"""
    detail: str
    status: str = "error"

class HealthResponse(BaseModel):
    """Health check response schema"""
    status: str = "ok"
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class VersionResponse(BaseModel):
    """Version information response schema"""
    app: str
    version: str
    phase: int
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# =============================================================================
# SCHEMA REGISTRY
# =============================================================================

SCHEMAS = {
    "Lead": {
        "in": LeadIn,
        "out": LeadOut,
        "update": LeadUpdate
    },
    "Buyer": {
        "in": BuyerIn,
        "out": BuyerOut,
        "update": BuyerUpdate
    },
    "Site": {
        "in": SiteIn,
        "out": SiteOut,
        "update": SiteUpdate
    }
}

def get_schema(entity: str, schema_type: str):
    """
    Get schema class by entity and type.
    
    Args:
        entity: Entity name ("Lead", "Buyer", "Site")
        schema_type: Schema type ("in", "out", "update")
        
    Returns:
        Schema class or None if not found
    """
    return SCHEMAS.get(entity, {}).get(schema_type)

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Schemas Module Test ===")
    
    # Test Lead schemas
    try:
        lead_in = LeadIn(name="Test Lead", email="test@example.com", phone="555-0000")
        logger.info(f"Created LeadIn: {lead_in}")
        
        lead_update = LeadUpdate(name="Updated Name")
        logger.info(f"Created LeadUpdate: {lead_update}")
        
    except Exception as e:
        logger.error(f"Lead schema test failed: {e}")
    
    # Test Buyer schemas
    try:
        buyer_in = BuyerIn(name="Test Buyer", email="buyer@example.com")
        logger.info(f"Created BuyerIn: {buyer_in}")
        
    except Exception as e:
        logger.error(f"Buyer schema test failed: {e}")
    
    # Test Site schemas
    try:
        site_in = SiteIn(name="Test Site", domain="test.com", status="active")
        logger.info(f"Created SiteIn: {site_in}")
        
    except Exception as e:
        logger.error(f"Site schema test failed: {e}")
    
    # Test validation errors
    try:
        invalid_lead = LeadIn(name="", email="invalid-email", phone="555-0000")
    except Exception as e:
        logger.info(f"Expected validation error: {e}")
    
    logger.info(f"Available schemas: {list(SCHEMAS.keys())}")
    logger.info("✅ Schemas module test completed")