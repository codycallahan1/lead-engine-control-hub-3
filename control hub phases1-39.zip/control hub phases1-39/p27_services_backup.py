"""
Database backup service for SQLite maintenance operations.

Phase: 27
Purpose: Handle database backups, rotation, and verification.
Key responsibilities:
- Create timestamped SQLite backups
- Rotate old backups to maintain disk space
- Verify backup integrity
"""

import os
import shutil
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# Default backup configuration
DEFAULT_DB_PATH = "./controlhub.db"
DEFAULT_BACKUP_DIR = "./backups"
DEFAULT_KEEP_DAYS = 7
DEFAULT_MAX_BACKUPS = 10


def ensure_backup_directory(backup_dir: str = DEFAULT_BACKUP_DIR) -> Path:
    """Ensure backup directory exists and return Path object."""
    backup_path = Path(backup_dir)
    backup_path.mkdir(exist_ok=True)
    return backup_path


def backup_sqlite(
    db_path: str = DEFAULT_DB_PATH,
    backup_dir: str = DEFAULT_BACKUP_DIR,
    prefix: str = "controlhub"
) -> str:
    """
    Create a timestamped backup of SQLite database.
    
    Args:
        db_path: Path to source database file
        backup_dir: Directory to store backups
        prefix: Filename prefix for backup
    
    Returns:
        Path to created backup file
    
    Raises:
        FileNotFoundError: If source database doesn't exist
        Exception: If backup operation fails
    """
    db_file = Path(db_path)
    if not db_file.exists():
        raise FileNotFoundError(f"Database file not found: {db_path}")
    
    # Create backup directory
    backup_path = ensure_backup_directory(backup_dir)
    
    # Generate timestamped filename
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"{prefix}_backup_{timestamp}.db"
    backup_file = backup_path / backup_filename
    
    logger.info(f"Creating backup: {db_path} -> {backup_file}")
    
    try:
        # Use shutil.copy2 to preserve metadata
        shutil.copy2(db_path, backup_file)
        
        # Verify backup was created and has reasonable size
        if not backup_file.exists():
            raise Exception("Backup file was not created")
        
        original_size = db_file.stat().st_size
        backup_size = backup_file.stat().st_size
        
        if backup_size == 0:
            backup_file.unlink()  # Remove empty backup
            raise Exception("Backup file is empty")
        
        if backup_size < original_size * 0.9:  # Allow 10% difference for SQLite overhead
            logger.warning(f"Backup size ({backup_size}) significantly smaller than original ({original_size})")
        
        logger.info(f"Backup created successfully: {backup_file} ({backup_size} bytes)")
        return str(backup_file)
    
    except Exception as e:
        logger.error(f"Backup failed: {e}")
        # Clean up partial backup if it exists
        if backup_file.exists():
            try:
                backup_file.unlink()
            except:
                pass
        raise


def list_backups(backup_dir: str = DEFAULT_BACKUP_DIR) -> List[Dict[str, Any]]:
    """
    List all backup files with metadata.
    
    Args:
        backup_dir: Directory containing backups
    
    Returns:
        List of backup info dictionaries
    """
    backup_path = Path(backup_dir)
    if not backup_path.exists():
        return []
    
    backups = []
    
    try:
        for backup_file in backup_path.glob("*_backup_*.db"):
            try:
                stat = backup_file.stat()
                created_at = datetime.fromtimestamp(stat.st_ctime)
                
                backups.append({
                    "filename": backup_file.name,
                    "path": str(backup_file),
                    "size_bytes": stat.st_size,
                    "size_mb": round(stat.st_size / (1024 * 1024), 2),
                    "created_at": created_at,
                    "age_days": (datetime.now() - created_at).days,
                    "valid": verify_backup_copy(str(backup_file))
                })
            except Exception as e:
                logger.warning(f"Error reading backup file {backup_file}: {e}")
    
    except Exception as e:
        logger.error(f"Error listing backups: {e}")
    
    # Sort by creation time (newest first)
    backups.sort(key=lambda x: x["created_at"], reverse=True)
    return backups


def verify_backup_copy(backup_path: str) -> bool:
    """
    Verify backup file integrity.
    
    Args:
        backup_path: Path to backup file
    
    Returns:
        True if backup appears valid
    """
    try:
        backup_file = Path(backup_path)
        
        if not backup_file.exists():
            return False
        
        # Check file size
        if backup_file.stat().st_size == 0:
            return False
        
        # Basic SQLite header check
        with open(backup_file, 'rb') as f:
            header = f.read(16)
            if not header.startswith(b'SQLite format 3\x00'):
                return False
        
        # Try to open with SQLite (basic connectivity test)
        try:
            import sqlite3
            with sqlite3.connect(backup_path) as conn:
                # Test basic query
                cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                cursor.fetchone()
            return True
        except sqlite3.Error:
            return False
    
    except Exception as e:
        logger.warning(f"Backup verification failed for {backup_path}: {e}")
        return False


def rotate_keep(
    keep_count: int = DEFAULT_MAX_BACKUPS,
    keep_days: int = DEFAULT_KEEP_DAYS,
    backup_dir: str = DEFAULT_BACKUP_DIR
) -> Dict[str, Any]:
    """
    Rotate backups keeping only recent ones.
    
    Args:
        keep_count: Maximum number of backups to keep
        keep_days: Maximum age in days to keep
        backup_dir: Directory containing backups
    
    Returns:
        Summary of rotation operation
    """
    logger.info(f"Starting backup rotation: keep {keep_count} backups, {keep_days} days max")
    
    backups = list_backups(backup_dir)
    if not backups:
        return {"removed": 0, "kept": 0, "total": 0}
    
    cutoff_date = datetime.now() - timedelta(days=keep_days)
    removed_count = 0
    kept_count = 0
    
    # Sort backups by age (newest first)
    backups.sort(key=lambda x: x["created_at"], reverse=True)
    
    for i, backup in enumerate(backups):
        should_remove = False
        reason = ""
        
        # Remove if beyond count limit
        if i >= keep_count:
            should_remove = True
            reason = f"beyond count limit ({keep_count})"
        
        # Remove if beyond age limit
        elif backup["created_at"] < cutoff_date:
            should_remove = True
            reason = f"older than {keep_days} days"
        
        # Remove if backup is invalid
        elif not backup["valid"]:
            should_remove = True
            reason = "backup file is invalid"
        
        if should_remove:
            try:
                Path(backup["path"]).unlink()
                logger.info(f"Removed backup {backup['filename']}: {reason}")
                removed_count += 1
            except Exception as e:
                logger.error(f"Failed to remove backup {backup['filename']}: {e}")
        else:
            kept_count += 1
    
    result = {
        "removed": removed_count,
        "kept": kept_count,
        "total": len(backups)
    }
    
    logger.info(f"Backup rotation complete: {result}")
    return result


def restore_check(backup_path: str) -> Dict[str, Any]:
    """
    Perform dry-run check of backup restore without actually restoring.
    
    Args:
        backup_path: Path to backup file to check
    
    Returns:
        Restore readiness information
    """
    result = {
        "backup_valid": False,
        "backup_size": 0,
        "table_count": 0,
        "estimated_restore_time": 0,
        "warnings": [],
        "errors": []
    }
    
    try:
        backup_file = Path(backup_path)
        
        if not backup_file.exists():
            result["errors"].append("Backup file does not exist")
            return result
        
        result["backup_size"] = backup_file.stat().st_size
        
        # Verify backup integrity
        if not verify_backup_copy(backup_path):
            result["errors"].append("Backup file appears corrupted")
            return result
        
        result["backup_valid"] = True
        
        # Analyze backup content
        import sqlite3
        with sqlite3.connect(backup_path) as conn:
            # Count tables
            cursor = conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
            result["table_count"] = cursor.fetchone()[0]
            
            # Estimate restore time based on file size (rough estimate)
            size_mb = result["backup_size"] / (1024 * 1024)
            result["estimated_restore_time"] = max(1, int(size_mb * 0.5))  # ~0.5 seconds per MB
            
            # Check for common tables
            cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            expected_tables = ["leads", "buyers", "sites"]
            missing_tables = [t for t in expected_tables if t not in tables]
            if missing_tables:
                result["warnings"].append(f"Expected tables not found: {missing_tables}")
    
    except Exception as e:
        result["errors"].append(f"Error analyzing backup: {str(e)}")
    
    return result


def get_backup_stats(backup_dir: str = DEFAULT_BACKUP_DIR) -> Dict[str, Any]:
    """Get summary statistics about backups."""
    backups = list_backups(backup_dir)
    
    if not backups:
        return {
            "count": 0,
            "total_size_mb": 0,
            "oldest_backup": None,
            "newest_backup": None,
            "valid_backups": 0
        }
    
    total_size = sum(b["size_bytes"] for b in backups)
    valid_count = sum(1 for b in backups if b["valid"])
    
    return {
        "count": len(backups),
        "total_size_mb": round(total_size / (1024 * 1024), 2),
        "oldest_backup": backups[-1]["created_at"].isoformat() if backups else None,
        "newest_backup": backups[0]["created_at"].isoformat() if backups else None,
        "valid_backups": valid_count,
        "disk_usage_warning": total_size > 100 * 1024 * 1024  # Warn if > 100MB
    }
