"""
Buyer matching rules for automated lead assignment.

Phase: 14
Purpose: SQLAlchemy models for buyer lead matching rules
Key responsibilities: BuyerRule table definition with matching criteria
"""

import logging
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship

# Import attempt with graceful fallback
try:
    from p02__server_db import Base
except ImportError as e:
    logging.warning(f"Import issue in buyer rules models: {e}")
    # Fallback for development
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()

logger = logging.getLogger(__name__)

class BuyerRule(Base):
    """
    Matching rules for automatically assigning leads to buyers.
    
    Defines criteria for matching leads to buyers based on email domains,
    price constraints, and other extendable parameters.
    """
    __tablename__ = "buyer_rules"
    
    id = Column(Integer, primary_key=True, index=True)
    buyer_id = Column(Integer, ForeignKey("buyers.id"), nullable=False, index=True)
    
    # Rule criteria - all nullable to allow flexible rule combinations
    contains_email_domain = Column(String(100), nullable=True, index=True)  # e.g., "gmail.com", "yahoo.com"
    max_price_cents = Column(Integer, nullable=True)  # Maximum price this buyer will pay in cents
    
    # Rule metadata
    active = Column(Boolean, default=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Relationship (would be defined when integrated with existing models)
    # buyer = relationship("Buyer", back_populates="rules")
    
    def __repr__(self):
        return f"<BuyerRule(id={self.id}, buyer_id={self.buyer_id}, email_domain='{self.contains_email_domain}', max_price={self.max_price_cents}, active={self.active})>"
    
    def matches_lead(self, lead_email: str) -> bool:
        """
        Check if this rule matches a given lead.
        
        Args:
            lead_email: Email address of the lead to check
            
        Returns:
            True if this rule matches the lead
        """
        if not self.active:
            return False
            
        # Check email domain filter
        if self.contains_email_domain:
            if '@' not in lead_email:
                return False
            lead_domain = lead_email.split('@')[1].lower()
            rule_domain = self.contains_email_domain.lower()
            if rule_domain not in lead_domain:
                return False
        
        # Additional rule criteria can be added here
        # For now, we only have email domain matching
        
        logger.debug(f"Rule {self.id} matches lead with email {lead_email}")
        return True
    
    @property
    def max_price_dollars(self) -> float:
        """Convert max price from cents to dollars for display."""
        if self.max_price_cents is None:
            return 0.0
        return self.max_price_cents / 100.0
    
    def get_effective_price(self, default_price_cents: int = 1000) -> int:
        """
        Get the effective price for this rule.
        
        Args:
            default_price_cents: Default price if no max is set
            
        Returns:
            Price in cents to charge for leads matching this rule
        """
        if self.max_price_cents is not None:
            return self.max_price_cents
        return default_price_cents
    
    def summary(self) -> str:
        """Get a human-readable summary of this rule."""
        parts = []
        
        if self.contains_email_domain:
            parts.append(f"email contains '{self.contains_email_domain}'")
            
        if self.max_price_cents:
            parts.append(f"max price ${self.max_price_dollars:.2f}")
            
        if not parts:
            parts.append("matches all leads")
            
        status = "active" if self.active else "inactive"
        return f"{', '.join(parts)} ({status})"

# Log model creation
logger.info("Buyer rules models defined: BuyerRule")
