"""
Backup & Restore routes for SQLite database and templates.
Phase 38: Backup & Restore (SQLite & Templates)
Purpose: downloadable DB snapshot and template pack; admin-only restore
"""

import os
import tempfile
from pathlib import Path
from typing import Dict, Any

from fastapi import APIRouter, HTTPException, UploadFile, File, Depends
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel
import logging

# Import our backup service
try:
    from p38__server_services_backup import (
        snapshot_sqlite, snapshot_templates, restore_sqlite, 
        verify_integrity, get_backup_list, cleanup_old_backups,
        is_retention_sweep_running
    )
except ImportError:
    # Fallback for when files are reorganized
    logging.warning("Could not import backup service - imports may need adjustment during packaging")
    def snapshot_sqlite(): raise NotImplementedError("Backup service not available")
    def snapshot_templates(): raise NotImplementedError("Backup service not available")
    def restore_sqlite(path): return False, "Service not available"
    def verify_integrity(path): return False
    def get_backup_list(): return []
    def cleanup_old_backups(count): pass
    def is_retention_sweep_running(): return False

logger = logging.getLogger(__name__)

router = APIRouter()

# Placeholder for admin auth dependency
def require_admin():
    """Placeholder for admin authentication dependency."""
    # In final package, this would be imported from middleware/auth
    pass

class RestoreResponse(BaseModel):
    success: bool
    message: str
    restart_required: bool = False


@router.get("/backup/sqlite")
async def download_sqlite_backup(admin: Any = Depends(require_admin)):
    """
    Download a SQLite database backup.
    Admin authentication required.
    """
    try:
        if is_retention_sweep_running():
            raise HTTPException(
                status_code=503, 
                detail="Backup unavailable while retention sweep is running"
            )
        
        logger.info("Admin requested SQLite backup download")
        
        # Create backup
        backup_path = snapshot_sqlite()
        
        if not os.path.exists(backup_path):
            raise HTTPException(status_code=500, detail="Backup file not found")
        
        # Get just the filename for security
        filename = Path(backup_path).name
        
        def cleanup_after_send():
            """Generator that yields file contents and cleans up."""
            try:
                with open(backup_path, "rb") as f:
                    while True:
                        chunk = f.read(8192)
                        if not chunk:
                            break
                        yield chunk
            finally:
                # Optional: clean up the temporary backup file
                # For now, we keep it for disaster recovery
                pass
        
        # Return as streaming download
        return StreamingResponse(
            cleanup_after_send(),
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "X-Download-Filename": filename
            }
        )
        
    except Exception as e:
        logger.error(f"SQLite backup download failed: {e}")
        raise HTTPException(status_code=500, detail=f"Backup failed: {str(e)}")


@router.get("/backup/templates.zip")
async def download_templates_backup(admin: Any = Depends(require_admin)):
    """
    Download a ZIP backup of all template files.
    Admin authentication required.
    """
    try:
        if is_retention_sweep_running():
            raise HTTPException(
                status_code=503, 
                detail="Backup unavailable while retention sweep is running"
            )
        
        logger.info("Admin requested templates backup download")
        
        # Create templates backup
        zip_path = snapshot_templates()
        
        if not os.path.exists(zip_path):
            raise HTTPException(status_code=500, detail="Templates backup file not found")
        
        # Get just the filename for security
        filename = Path(zip_path).name
        
        def cleanup_after_send():
            """Generator that yields file contents."""
            try:
                with open(zip_path, "rb") as f:
                    while True:
                        chunk = f.read(8192)
                        if not chunk:
                            break
                        yield chunk
            finally:
                # Keep the backup file
                pass
        
        return StreamingResponse(
            cleanup_after_send(),
            media_type="application/zip",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "X-Download-Filename": filename
            }
        )
        
    except Exception as e:
        logger.error(f"Templates backup download failed: {e}")
        raise HTTPException(status_code=500, detail=f"Templates backup failed: {str(e)}")


@router.post("/restore/sqlite", response_model=RestoreResponse)
async def restore_sqlite_database(
    file: UploadFile = File(...),
    admin: Any = Depends(require_admin)
):
    """
    Restore SQLite database from uploaded file.
    Admin authentication required.
    """
    try:
        if is_retention_sweep_running():
            raise HTTPException(
                status_code=503, 
                detail="Restore unavailable while retention sweep is running"
            )
        
        logger.info(f"Admin requested SQLite restore from file: {file.filename}")
        
        # Validate file
        if not file.filename or not file.filename.endswith('.db'):
            raise HTTPException(
                status_code=400, 
                detail="Invalid file format. Expected .db file."
            )
        
        # Check file size (max 100MB)
        max_size = 100 * 1024 * 1024
        content = await file.read()
        
        if len(content) > max_size:
            raise HTTPException(
                status_code=413, 
                detail="File too large. Maximum size is 100MB."
            )
        
        if len(content) < 1024:
            raise HTTPException(
                status_code=400, 
                detail="File too small to be a valid database."
            )
        
        # Save uploaded file to temporary location
        with tempfile.NamedTemporaryFile(delete=False, suffix='.db') as temp_file:
            temp_file.write(content)
            temp_path = temp_file.name
        
        try:
            # Restore database
            success, message = restore_sqlite(temp_path)
            
            if success:
                logger.info("SQLite database restored successfully")
                
                # Clean up old backups
                cleanup_old_backups(keep_count=10)
                
                return RestoreResponse(
                    success=True,
                    message=message,
                    restart_required=True
                )
            else:
                logger.error(f"SQLite restore failed: {message}")
                return RestoreResponse(
                    success=False,
                    message=message,
                    restart_required=False
                )
                
        finally:
            # Clean up temporary file
            try:
                os.unlink(temp_path)
            except Exception as e:
                logger.warning(f"Could not clean up temp file: {e}")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"SQLite restore failed: {e}")
        raise HTTPException(status_code=500, detail=f"Restore failed: {str(e)}")


@router.get("/backup/list")
async def list_backups(admin: Any = Depends(require_admin)):
    """
    List available backup files with metadata.
    Admin authentication required.
    """
    try:
        logger.info("Admin requested backup list")
        
        backups = get_backup_list()
        
        return {
            "backups": backups,
            "total_count": len(backups),
            "retention_sweep_running": is_retention_sweep_running()
        }
        
    except Exception as e:
        logger.error(f"Failed to list backups: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list backups: {str(e)}")


@router.post("/backup/cleanup")
async def cleanup_backups(
    keep_count: int = 10,
    admin: Any = Depends(require_admin)
):
    """
    Clean up old backup files, keeping only the most recent ones.
    Admin authentication required.
    """
    try:
        if is_retention_sweep_running():
            raise HTTPException(
                status_code=503, 
                detail="Cleanup unavailable while retention sweep is running"
            )
        
        logger.info(f"Admin requested backup cleanup, keeping {keep_count} files")
        
        cleanup_old_backups(keep_count=keep_count)
        
        # Get updated list
        remaining_backups = get_backup_list()
        
        return {
            "success": True,
            "message": f"Cleanup completed, kept {len(remaining_backups)} most recent backups",
            "remaining_count": len(remaining_backups)
        }
        
    except Exception as e:
        logger.error(f"Backup cleanup failed: {e}")
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# Health check for backup service
@router.get("/backup/health")
async def backup_health():
    """
    Check backup service health.
    """
    try:
        backup_dir = Path("./server/backups")
        
        return {
            "status": "ok",
            "backup_directory_exists": backup_dir.exists(),
            "backup_directory_writable": backup_dir.exists() and os.access(backup_dir, os.W_OK),
            "retention_sweep_running": is_retention_sweep_running(),
            "available_backups": len(get_backup_list())
        }
        
    except Exception as e:
        return {
            "status": "error",
            "error": str(e)
        }
