"""
Lead Engine Control Hub - Site Routes
Phase: 6
Purpose: FastAPI router for site endpoints (JSON API + HTML pages)
Key Responsibilities:
- REST API endpoints for site CRUD operations
- HTML page rendering for site management
- Domain uniqueness validation with 400 status codes
- Request/response handling and error management
"""

import logging
from typing import List
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# Import services and schemas
try:
    from p06__server_services_sites import SiteService
    from p02__server_schemas import SiteIn, SiteOut, SiteUpdate
except ImportError as e:
    logging.warning(f"Import error in sites routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 and 6 files are available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/sites", tags=["sites"])

# Initialize templates
try:
    templates_path = Path(__file__).parent / "templates"
    templates_path.mkdir(exist_ok=True)
    templates = Jinja2Templates(directory=str(templates_path))
    logger.info("Templates initialized for sites routes")
except Exception as e:
    logger.warning(f"Could not initialize templates: {e}")
    templates = None

# =============================================================================
# JSON API ENDPOINTS
# =============================================================================

@router.get("/", response_model=List[SiteOut])
async def get_all_sites(
    search: str = Query(None, description="Search sites by name or domain"),
    status: str = Query(None, description="Filter by status")
):
    """
    Get all sites or search/filter sites.
    
    Args:
        search: Optional search query for filtering sites
        status: Optional status filter
        
    Returns:
        List of sites matching the criteria
    """
    try:
        logger.info(f"GET /sites - search: {search}, status: {status}")
        
        if search:
            sites = SiteService.search_sites(search)
            logger.info(f"Search returned {len(sites)} sites")
        elif status:
            sites = SiteService.get_sites_by_status(status)
            logger.info(f"Status filter returned {len(sites)} sites")
        else:
            sites = SiteService.get_all_sites()
            logger.info(f"Retrieved {len(sites)} sites")
        
        return sites
        
    except Exception as e:
        logger.error(f"Failed to retrieve sites: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/", response_model=SiteOut, status_code=201)
async def create_site(site_data: SiteIn):
    """
    Create a new site with domain uniqueness validation.
    
    Args:
        site_data: Site creation data
        
    Returns:
        Created site object
        
    Raises:
        400: If site with domain already exists
        422: If validation fails
    """
    try:
        logger.info(f"POST /sites - creating site: {site_data.domain}")
        
        site = SiteService.create_site(site_data)
        logger.info(f"Created site with ID: {site.id}")
        
        return site
        
    except ValueError as e:
        logger.warning(f"Site creation failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to create site: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/{site_id}", response_model=SiteOut)
async def get_site(site_id: int):
    """
    Get a site by ID.
    
    Args:
        site_id: ID of the site to retrieve
        
    Returns:
        Site object
        
    Raises:
        404: If site not found
    """
    try:
        logger.info(f"GET /sites/{site_id}")
        
        site = SiteService.get_site_by_id(site_id)
        if not site:
            logger.warning(f"Site not found: {site_id}")
            raise HTTPException(status_code=404, detail="Site not found")
        
        return site
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retrieve site {site_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.patch("/{site_id}", response_model=SiteOut)
async def update_site(site_id: int, site_data: SiteUpdate):
    """
    Update a site by ID.
    
    Args:
        site_id: ID of the site to update
        site_data: Site update data
        
    Returns:
        Updated site object
        
    Raises:
        404: If site not found
        400: If domain conflict occurs
    """
    try:
        logger.info(f"PATCH /sites/{site_id}")
        
        site = SiteService.update_site(site_id, site_data)
        if not site:
            logger.warning(f"Site not found for update: {site_id}")
            raise HTTPException(status_code=404, detail="Site not found")
        
        logger.info(f"Updated site: {site.id}")
        return site
        
    except ValueError as e:
        logger.warning(f"Site update failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update site {site_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.delete("/{site_id}", status_code=204)
async def delete_site(site_id: int):
    """
    Delete a site by ID.
    
    Args:
        site_id: ID of the site to delete
        
    Raises:
        404: If site not found
    """
    try:
        logger.info(f"DELETE /sites/{site_id}")
        
        deleted = SiteService.delete_site(site_id)
        if not deleted:
            logger.warning(f"Site not found for deletion: {site_id}")
            raise HTTPException(status_code=404, detail="Site not found")
        
        logger.info(f"Deleted site: {site_id}")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete site {site_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# =============================================================================
# HTML PAGE ENDPOINTS
# =============================================================================

@router.get("-page", response_class=HTMLResponse)
async def sites_page(request: Request):
    """
    Render HTML page showing all sites in a table with Deploy buttons.
    
    Args:
        request: FastAPI request object
        
    Returns:
        HTML response with sites table
    """
    try:
        logger.info("GET /sites-page - rendering sites table")
        
        if not templates:
            return HTMLResponse(
                "<h1>Sites Page</h1><p>Templates not available</p>",
                status_code=200
            )
        
        # Get all sites
        sites = SiteService.get_all_sites()
        logger.info(f"Rendering {len(sites)} sites in HTML table")
        
        context = {
            "request": request,
            "title": "Sites Management",
            "sites": sites,
            "sites_count": len(sites)
        }
        
        # Try to render with a specific template, fall back to simple HTML
        try:
            return templates.TemplateResponse("sites.html", context)
        except Exception as template_error:
            logger.warning(f"Template error, using fallback: {template_error}")
            
            # Fallback HTML generation
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Sites Management</title>
                <link rel="stylesheet" href="/static/main.css">
                <style>
                    .action-buttons {{ display: flex; gap: 0.5rem; }}
                    .btn-small {{ padding: 0.5rem 1rem; font-size: 0.9rem; }}
                    .btn-deploy {{ background-color: #4caf50; }}
                    .btn-deploy:hover {{ background-color: #45a049; }}
                    .status-active {{ color: #4caf50; }}
                    .status-inactive {{ color: #f44336; }}
                    .status-pending {{ color: #ff9800; }}
                </style>
            </head>
            <body>
                <nav class="main-nav">
                    <div class="nav-container">
                        <div class="nav-brand"><h1>Lead Engine Control Hub</h1></div>
                        <div class="nav-links">
                            <a href="/">Dashboard</a>
                            <a href="/leads-page">Leads</a>
                            <a href="/buyers-page">Buyers</a>
                            <a href="/sites-page">Sites</a>
                        </div>
                    </div>
                </nav>
                
                <main class="main-content">
                    <h2>Sites Management</h2>
                    <p>Total sites: {len(sites)}</p>
                    
                    <div style="margin-bottom: 1rem;">
                        <a href="#" class="btn" onclick="alert('Add New Site functionality coming soon')">Add New Site</a>
                    </div>
                    
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Domain</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            
            if sites:
                for site in sites:
                    created_str = site.created_at.strftime("%Y-%m-%d %H:%M") if site.created_at else "N/A"
                    status_class = f"status-{site.status}"
                    html_content += f"""
                            <tr>
                                <td>{site.id}</td>
                                <td>{site.name}</td>
                                <td>{site.domain}</td>
                                <td><span class="{status_class}">{site.status}</span></td>
                                <td>{created_str}</td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-small btn-deploy" 
                                                onclick="deploySite({site.id})"
                                                title="Deploy this site">
                                            Deploy
                                        </button>
                                        <button class="btn btn-small btn-secondary" 
                                                onclick="editSite({site.id})"
                                                title="Edit this site">
                                            Edit
                                        </button>
                                        <button class="btn btn-small btn-secondary" 
                                                onclick="deleteSite({site.id})"
                                                title="Delete this site">
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                    """
            else:
                html_content += """
                            <tr>
                                <td colspan="6" style="text-align: center; color: #888;">No sites found</td>
                            </tr>
                """
            
            html_content += """
                        </tbody>
                    </table>
                </main>
                
                <script>
                    function deploySite(siteId) {
                        // Deploy functionality will be implemented in Phase 7
                        alert('Deploy functionality coming in Phase 7. Site ID: ' + siteId);
                    }
                    
                    function editSite(siteId) {
                        alert('Edit functionality coming soon. Site ID: ' + siteId);
                    }
                    
                    function deleteSite(siteId) {
                        if (confirm('Are you sure you want to delete this site?')) {
                            fetch('/sites/' + siteId, {
                                method: 'DELETE'
                            })
                            .then(response => {
                                if (response.ok) {
                                    location.reload();
                                } else {
                                    alert('Failed to delete site');
                                }
                            })
                            .catch(error => {
                                alert('Error deleting site: ' + error);
                            });
                        }
                    }
                </script>
            </body>
            </html>
            """
            
            return HTMLResponse(html_content, status_code=200)
        
    except Exception as e:
        logger.error(f"Failed to render sites page: {e}")
        return HTMLResponse(
            f"<h1>Error</h1><p>Failed to load sites page: {e}</p>",
            status_code=500
        )

# =============================================================================
# UTILITY ENDPOINTS
# =============================================================================

@router.get("/count/total")
async def get_sites_count():
    """
    Get total count of sites.
    
    Returns:
        JSON object with sites count
    """
    try:
        logger.info("GET /sites/count/total")
        
        count = SiteService.get_sites_count()
        logger.info(f"Sites count: {count}")
        
        return {"count": count, "entity": "sites"}
        
    except Exception as e:
        logger.error(f"Failed to get sites count: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/status/{status}")
async def get_sites_by_status(status: str):
    """
    Get sites filtered by status.
    
    Args:
        status: Status to filter by
        
    Returns:
        JSON array of sites with matching status
    """
    try:
        logger.info(f"GET /sites/status/{status}")
        
        sites = SiteService.get_sites_by_status(status)
        logger.info(f"Found {len(sites)} sites with status '{status}'")
        
        return sites
        
    except Exception as e:
        logger.error(f"Failed to get sites by status '{status}': {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Site Routes Module Test ===")
    logger.info("✅ Site routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET    /sites")
    logger.info("  POST   /sites")
    logger.info("  GET    /sites/{id}")
    logger.info("  PATCH  /sites/{id}")
    logger.info("  DELETE /sites/{id}")
    logger.info("  GET    /sites-page")
    logger.info("  GET    /sites/count/total")
    logger.info("  GET    /sites/status/{status}")
    logger.info("")
    logger.info("Integration notes:")
    logger.info("- Add 'from p06__server_routes_sites import router as sites_router' to main app")
    logger.info("- Add 'app.include_router(sites_router)' to wire in the endpoints")
    logger.info("- Deploy button functionality will be implemented in Phase 7")