"""
Enhanced Deployment Routes v2
Phase 22: Advanced deployment endpoints with pipeline orchestration
Key responsibilities: v2 deployment API, step detail views, pipeline status tracking
"""

import logging
from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p02__server_models import Site
    from p06__server_models_deployments import Deployment
    from p22__server_models_deploy_steps import DeploymentStep, get_deployment_steps, get_step_summary
    from p07__server_services_queue import enqueue
    from p20__server_middleware_auth import require_admin
    from p21__server_models_audit import log_audit_event, AuditKind
except ImportError:
    logger.warning("Deployment v2 modules not found - using mock implementations")
    def get_session():
        return None
    
    class Site:
        def __init__(self, **kwargs):
            self.id = 1
            self.name = "Mock Site"
            self.domain = "mock.example.com"
    
    class Deployment:
        def __init__(self, **kwargs):
            self.id = 1
            self.site_id = 1
            self.status = "pending"
    
    class DeploymentStep:
        def __init__(self, **kwargs):
            self.id = 1
            self.step = "mock_step"
            self.status = "completed"
        
        def to_dict(self):
            return {"id": 1, "step": "mock_step", "status": "completed"}
    
    def get_deployment_steps(session, deployment_id):
        return [DeploymentStep()]
    
    def get_step_summary(session, deployment_id):
        return {"total_steps": 1, "completed_steps": 1, "status": "completed"}
    
    def enqueue(job_type, payload):
        return "mock_job_123"
    
    def require_admin(request):
        return {"role": "admin"}
    
    def log_audit_event(session, kind, message, meta=None):
        logger.info(f"AUDIT: {kind} - {message}")

router = APIRouter(prefix="/sites", tags=["deployments_v2"])

# Pydantic models
class DeploymentV2Response(BaseModel):
    success: bool
    deployment_id: int
    job_id: str
    message: str

class DeploymentDetailResponse(BaseModel):
    deployment_id: int
    site_id: int
    site_name: str
    site_domain: str
    status: str
    steps: List[Dict[str, Any]]
    summary: Dict[str, Any]
    created_at: str

class StepDetailResponse(BaseModel):
    id: int
    deployment_id: int
    step: str
    status: str
    started_at: str
    finished_at: Optional[str]
    duration_seconds: Optional[float]
    details: Dict[str, Any]

@router.post("/{site_id}/deploy/v2", response_model=DeploymentV2Response)
async def deploy_site_v2(
    site_id: int,
    request: Request,
    _: dict = Depends(require_admin)
) -> JSONResponse:
    """
    Deploy a site using the v2 pipeline
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response for testing
            mock_response = {
                "success": True,
                "deployment_id": 1,
                "job_id": "mock_job_123",
                "message": f"Mock deployment initiated for site {site_id}"
            }
            logger.info(f"Mock v2 deployment for site {site_id}")
            return JSONResponse(mock_response)
        
        with session:
            # Verify site exists
            site = session.query(Site).filter(Site.id == site_id).first()
            if not site:
                raise HTTPException(status_code=404, detail=f"Site {site_id} not found")
            
            # Check if there's already a pending/running deployment
            existing_deployment = session.query(Deployment).filter(
                Deployment.site_id == site_id,
                Deployment.status.in_(["pending", "running"])
            ).first()
            
            if existing_deployment:
                raise HTTPException(
                    status_code=409, 
                    detail=f"Site {site_id} already has a deployment in progress (ID: {existing_deployment.id})"
                )
            
            # Create new deployment record
            deployment = Deployment(
                site_id=site_id,
                status="pending",
                created_at=datetime.utcnow()
            )
            session.add(deployment)
            session.commit()
            session.refresh(deployment)
            
            # Enqueue v2 deployment job
            job_payload = {
                "site_id": site_id,
                "deployment_id": deployment.id,
                "pipeline_version": "v2"
            }
            
            job_id = enqueue("deploy_v2", job_payload)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.SITE_DEPLOYED,
                f"V2 deployment initiated for site {site.name} ({site.domain})",
                {
                    "site_id": site_id,
                    "deployment_id": deployment.id,
                    "job_id": job_id,
                    "pipeline_version": "v2"
                }
            )
            
            logger.info(f"V2 deployment initiated: site={site_id}, deployment={deployment.id}, job={job_id}")
            
            response_data = {
                "success": True,
                "deployment_id": deployment.id,
                "job_id": job_id,
                "message": f"V2 deployment initiated for {site.name} ({site.domain})"
            }
            
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error initiating v2 deployment for site {site_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to initiate deployment: {str(e)}")

@router.get("/deployments/{deployment_id}/detail", response_model=DeploymentDetailResponse)
async def get_deployment_detail(
    deployment_id: int,
    _: dict = Depends(require_admin)
) -> Dict[str, Any]:
    """
    Get detailed deployment information including all steps
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response for testing
            mock_response = {
                "deployment_id": deployment_id,
                "site_id": 1,
                "site_name": "Mock Site",
                "site_domain": "mock.example.com",
                "status": "completed",
                "steps": [
                    {
                        "id": 1,
                        "step": "purchase_domain",
                        "status": "completed",
                        "started_at": "2024-01-01T00:00:00",
                        "finished_at": "2024-01-01T00:01:00",
                        "duration_seconds": 60.0,
                        "details": {"domain": "mock.example.com", "success": True}
                    }
                ],
                "summary": {
                    "total_steps": 1,
                    "completed_steps": 1,
                    "status": "completed",
                    "progress_percentage": 100
                },
                "created_at": "2024-01-01T00:00:00"
            }
            logger.info(f"Mock deployment detail for {deployment_id}")
            return mock_response
        
        with session:
            # Get deployment record
            deployment = session.query(Deployment).filter(Deployment.id == deployment_id).first()
            if not deployment:
                raise HTTPException(status_code=404, detail=f"Deployment {deployment_id} not found")
            
            # Get associated site
            site = session.query(Site).filter(Site.id == deployment.site_id).first()
            if not site:
                raise HTTPException(status_code=404, detail=f"Site {deployment.site_id} not found")
            
            # Get all deployment steps
            steps = get_deployment_steps(session, deployment_id)
            steps_data = [step.to_dict() for step in steps]
            
            # Get step summary
            summary = get_step_summary(session, deployment_id)
            
            response_data = {
                "deployment_id": deployment.id,
                "site_id": site.id,
                "site_name": site.name,
                "site_domain": site.domain,
                "status": deployment.status,
                "steps": steps_data,
                "summary": summary,
                "created_at": deployment.created_at.isoformat() if hasattr(deployment, 'created_at') else None
            }
            
            logger.info(f"Retrieved deployment detail for {deployment_id}: {len(steps_data)} steps")
            
            return response_data
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting deployment detail for {deployment_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve deployment detail: {str(e)}")

@router.get("/deployments/{deployment_id}/steps", response_model=List[StepDetailResponse])
async def get_deployment_steps_api(
    deployment_id: int,
    _: dict = Depends(require_admin)
) -> List[Dict[str, Any]]:
    """
    Get list of steps for a deployment
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_steps = [
                {
                    "id": 1,
                    "deployment_id": deployment_id,
                    "step": "purchase_domain",
                    "status": "completed",
                    "started_at": "2024-01-01T00:00:00",
                    "finished_at": "2024-01-01T00:01:00",
                    "duration_seconds": 60.0,
                    "details": {"domain": "mock.example.com", "success": True}
                },
                {
                    "id": 2,
                    "deployment_id": deployment_id,
                    "step": "create_dns",
                    "status": "completed",
                    "started_at": "2024-01-01T00:01:00",
                    "finished_at": "2024-01-01T00:02:00",
                    "duration_seconds": 60.0,
                    "details": {"domain": "mock.example.com", "record_type": "A", "success": True}
                }
            ]
            logger.info(f"Mock steps for deployment {deployment_id}")
            return mock_steps
        
        with session:
            # Verify deployment exists
            deployment = session.query(Deployment).filter(Deployment.id == deployment_id).first()
            if not deployment:
                raise HTTPException(status_code=404, detail=f"Deployment {deployment_id} not found")
            
            # Get steps
            steps = get_deployment_steps(session, deployment_id)
            steps_data = [step.to_dict() for step in steps]
            
            logger.info(f"Retrieved {len(steps_data)} steps for deployment {deployment_id}")
            
            return steps_data
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting steps for deployment {deployment_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve deployment steps: {str(e)}")

@router.get("/deployments/{deployment_id}/summary")
async def get_deployment_summary(
    deployment_id: int,
    _: dict = Depends(require_admin)
) -> Dict[str, Any]:
    """
    Get deployment summary statistics
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_summary = {
                "deployment_id": deployment_id,
                "total_steps": 3,
                "completed_steps": 3,
                "failed_steps": 0,
                "pending_steps": 0,
                "status": "completed",
                "progress_percentage": 100.0,
                "total_duration": 180.0
            }
            return mock_summary
        
        with session:
            # Verify deployment exists
            deployment = session.query(Deployment).filter(Deployment.id == deployment_id).first()
            if not deployment:
                raise HTTPException(status_code=404, detail=f"Deployment {deployment_id} not found")
            
            # Get summary
            summary = get_step_summary(session, deployment_id)
            summary["deployment_id"] = deployment_id
            
            logger.info(f"Retrieved summary for deployment {deployment_id}: {summary['status']}")
            
            return summary
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting summary for deployment {deployment_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve deployment summary: {str(e)}")

@router.post("/deployments/{deployment_id}/retry")
async def retry_failed_deployment(
    deployment_id: int,
    _: dict = Depends(require_admin)
) -> JSONResponse:
    """
    Retry a failed deployment
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            mock_response = {
                "success": True,
                "deployment_id": deployment_id,
                "job_id": "retry_job_456",
                "message": f"Mock retry initiated for deployment {deployment_id}"
            }
            return JSONResponse(mock_response)
        
        with session:
            # Get deployment
            deployment = session.query(Deployment).filter(Deployment.id == deployment_id).first()
            if not deployment:
                raise HTTPException(status_code=404, detail=f"Deployment {deployment_id} not found")
            
            if deployment.status not in ["failed"]:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Can only retry failed deployments. Current status: {deployment.status}"
                )
            
            # Reset deployment status
            deployment.status = "pending"
            session.commit()
            
            # Enqueue retry job
            job_payload = {
                "site_id": deployment.site_id,
                "deployment_id": deployment.id,
                "pipeline_version": "v2",
                "retry": True
            }
            
            job_id = enqueue("deploy_v2", job_payload)
            
            # Log audit event
            log_audit_event(
                session,
                AuditKind.SITE_DEPLOYED,
                f"V2 deployment retry initiated for deployment {deployment_id}",
                {
                    "deployment_id": deployment_id,
                    "site_id": deployment.site_id,
                    "job_id": job_id,
                    "action": "retry"
                }
            )
            
            logger.info(f"Deployment retry initiated: deployment={deployment_id}, job={job_id}")
            
            response_data = {
                "success": True,
                "deployment_id": deployment_id,
                "job_id": job_id,
                "message": f"Retry initiated for deployment {deployment_id}"
            }
            
            return JSONResponse(response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrying deployment {deployment_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retry deployment: {str(e)}")

@router.get("/deployments/active")
async def get_active_deployments(
    _: dict = Depends(require_admin)
) -> List[Dict[str, Any]]:
    """
    Get all active (pending/running) deployments
    Admin access required
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            return [
                {
                    "deployment_id": 1,
                    "site_id": 1,
                    "site_name": "Mock Site",
                    "site_domain": "mock.example.com",
                    "status": "running",
                    "started_at": "2024-01-01T00:00:00",
                    "progress_percentage": 66.7
                }
            ]
        
        with session:
            # Query active deployments
            active_deployments = session.query(Deployment).filter(
                Deployment.status.in_(["pending", "running"])
            ).all()
            
            result = []
            for deployment in active_deployments:
                # Get associated site
                site = session.query(Site).filter(Site.id == deployment.site_id).first()
                
                # Get progress summary
                summary = get_step_summary(session, deployment.id)
                
                deployment_info = {
                    "deployment_id": deployment.id,
                    "site_id": deployment.site_id,
                    "site_name": site.name if site else "Unknown",
                    "site_domain": site.domain if site else "Unknown",
                    "status": deployment.status,
                    "started_at": deployment.created_at.isoformat() if hasattr(deployment, 'created_at') else None,
                    "progress_percentage": summary.get("progress_percentage", 0)
                }
                
                result.append(deployment_info)
            
            logger.info(f"Retrieved {len(result)} active deployments")
            return result
    
    except Exception as e:
        logger.error(f"Error getting active deployments: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve active deployments: {str(e)}")

# Legacy endpoint compatibility (from phase 7)
@router.get("/deployments", response_model=List[Dict[str, Any]])
async def list_all_deployments(
    limit: int = 50,
    _: dict = Depends(require_admin)
) -> List[Dict[str, Any]]:
    """
    List all deployments with basic information
    Maintains compatibility with phase 7 endpoint
    """
    try:
        session = get_session()
        if not session:
            # Mock response
            return [
                {
                    "id": 1,
                    "site_id": 1,
                    "site_name": "Mock Site",
                    "site_domain": "mock.example.com",
                    "status": "completed",
                    "created_at": "2024-01-01T00:00:00"
                }
            ]
        
        with session:
            deployments = session.query(Deployment)\
                               .order_by(Deployment.created_at.desc())\
                               .limit(limit)\
                               .all()
            
            result = []
            for deployment in deployments:
                # Get associated site
                site = session.query(Site).filter(Site.id == deployment.site_id).first()
                
                deployment_info = {
                    "id": deployment.id,
                    "site_id": deployment.site_id,
                    "site_name": site.name if site else "Unknown",
                    "site_domain": site.domain if site else "Unknown",
                    "status": deployment.status,
                    "created_at": deployment.created_at.isoformat() if hasattr(deployment, 'created_at') else None
                }
                
                result.append(deployment_info)
            
            logger.info(f"Listed {len(result)} deployments")
            return result
    
    except Exception as e:
        logger.error(f"Error listing deployments: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list deployments: {str(e)}")