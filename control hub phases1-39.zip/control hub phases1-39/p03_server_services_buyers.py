"""
Lead Engine Control Hub - Buyer Services
Phase: 3
Purpose: Service layer for buyer operations (CRUD) using database sessions
Key Responsibilities:
- Buyer creation, retrieval, update, and deletion
- Business logic for buyer management
- Database session handling
- Error handling and logging
"""

import logging
from typing import List, Optional

from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

# Import database and models
try:
    from p02__server_db import get_session
    from p02__server_models import Buyer
    from p02__server_schemas import BuyerIn, BuyerOut, BuyerUpdate
except ImportError as e:
    logging.warning(f"Import error in buyers service: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 files are available")

logger = logging.getLogger(__name__)

class BuyerService:
    """Service class for Buyer operations"""
    
    @staticmethod
    def get_all_buyers() -> List[Buyer]:
        """
        Retrieve all buyers from the database.
        
        Returns:
            List of Buyer objects
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                buyers = db.query(Buyer).order_by(Buyer.created_at.desc()).all()
                logger.info(f"Retrieved {len(buyers)} buyers")
                return buyers
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve buyers: {e}")
            raise
    
    @staticmethod
    def get_buyer_by_id(buyer_id: int) -> Optional[Buyer]:
        """
        Retrieve a buyer by ID.
        
        Args:
            buyer_id: ID of the buyer to retrieve
            
        Returns:
            Buyer object or None if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                buyer = db.query(Buyer).filter(Buyer.id == buyer_id).first()
                if buyer:
                    logger.info(f"Retrieved buyer: {buyer}")
                else:
                    logger.info(f"Buyer not found with ID: {buyer_id}")
                return buyer
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve buyer {buyer_id}: {e}")
            raise
    
    @staticmethod
    def get_buyer_by_email(email: str) -> Optional[Buyer]:
        """
        Retrieve a buyer by email address.
        
        Args:
            email: Email address to search for
            
        Returns:
            Buyer object or None if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                buyer = db.query(Buyer).filter(Buyer.email == email).first()
                if buyer:
                    logger.info(f"Retrieved buyer by email: {buyer}")
                else:
                    logger.info(f"Buyer not found with email: {email}")
                return buyer
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve buyer by email {email}: {e}")
            raise
    
    @staticmethod
    def create_buyer(buyer_data: BuyerIn) -> Buyer:
        """
        Create a new buyer.
        
        Args:
            buyer_data: Buyer input data
            
        Returns:
            Created Buyer object
            
        Raises:
            IntegrityError: If email already exists
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                # Create new buyer instance
                buyer = Buyer(
                    name=buyer_data.name,
                    email=buyer_data.email
                )
                
                db.add(buyer)
                db.flush()  # Flush to get the ID before commit
                db.refresh(buyer)  # Refresh to get all fields including created_at
                
                logger.info(f"Created buyer: {buyer}")
                return buyer
                
        except IntegrityError as e:
            logger.error(f"Buyer creation failed - email already exists: {buyer_data.email}")
            raise ValueError(f"Buyer with email {buyer_data.email} already exists")
        except SQLAlchemyError as e:
            logger.error(f"Failed to create buyer: {e}")
            raise
    
    @staticmethod
    def update_buyer(buyer_id: int, buyer_data: BuyerUpdate) -> Optional[Buyer]:
        """
        Update an existing buyer.
        
        Args:
            buyer_id: ID of the buyer to update
            buyer_data: Buyer update data
            
        Returns:
            Updated Buyer object or None if not found
            
        Raises:
            IntegrityError: If email update conflicts with existing buyer
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                buyer = db.query(Buyer).filter(Buyer.id == buyer_id).first()
                
                if not buyer:
                    logger.info(f"Buyer not found for update: {buyer_id}")
                    return None
                
                # Update only provided fields
                update_data = buyer_data.dict(exclude_unset=True)
                for field, value in update_data.items():
                    setattr(buyer, field, value)
                
                db.flush()  # Flush to check for constraint violations
                db.refresh(buyer)  # Refresh to get updated fields
                
                logger.info(f"Updated buyer: {buyer}")
                return buyer
                
        except IntegrityError as e:
            logger.error(f"Buyer update failed - email conflict: {buyer_data.email}")
            raise ValueError(f"Buyer with email {buyer_data.email} already exists")
        except SQLAlchemyError as e:
            logger.error(f"Failed to update buyer {buyer_id}: {e}")
            raise
    
    @staticmethod
    def delete_buyer(buyer_id: int) -> bool:
        """
        Delete a buyer by ID.
        
        Args:
            buyer_id: ID of the buyer to delete
            
        Returns:
            True if deleted, False if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                buyer = db.query(Buyer).filter(Buyer.id == buyer_id).first()
                
                if not buyer:
                    logger.info(f"Buyer not found for deletion: {buyer_id}")
                    return False
                
                db.delete(buyer)
                logger.info(f"Deleted buyer: {buyer}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Failed to delete buyer {buyer_id}: {e}")
            raise
    
    @staticmethod
    def search_buyers(query: str) -> List[Buyer]:
        """
        Search buyers by name or email.
        
        Args:
            query: Search query string
            
        Returns:
            List of matching Buyer objects
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                search_pattern = f"%{query}%"
                buyers = db.query(Buyer).filter(
                    (Buyer.name.ilike(search_pattern)) |
                    (Buyer.email.ilike(search_pattern))
                ).order_by(Buyer.created_at.desc()).all()
                
                logger.info(f"Search for '{query}' returned {len(buyers)} buyers")
                return buyers
                
        except SQLAlchemyError as e:
            logger.error(f"Failed to search buyers with query '{query}': {e}")
            raise
    
    @staticmethod
    def get_buyers_count() -> int:
        """
        Get total count of buyers.
        
        Returns:
            Number of buyers in database
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                count = db.query(Buyer).count()
                logger.info(f"Buyer count: {count}")
                return count
        except SQLAlchemyError as e:
            logger.error(f"Failed to get buyers count: {e}")
            raise

# Convenience functions for direct usage
def list_buyers() -> List[Buyer]:
    """Get all buyers"""
    return BuyerService.get_all_buyers()

def get_buyer(buyer_id: int) -> Optional[Buyer]:
    """Get buyer by ID"""
    return BuyerService.get_buyer_by_id(buyer_id)

def create_buyer(buyer_data: BuyerIn) -> Buyer:
    """Create new buyer"""
    return BuyerService.create_buyer(buyer_data)

def update_buyer(buyer_id: int, buyer_data: BuyerUpdate) -> Optional[Buyer]:
    """Update existing buyer"""
    return BuyerService.update_buyer(buyer_id, buyer_data)

def delete_buyer(buyer_id: int) -> bool:
    """Delete buyer"""
    return BuyerService.delete_buyer(buyer_id)

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Buyer Services Module Test ===")
    
    try:
        # Test getting all buyers (should be empty initially)
        buyers = BuyerService.get_all_buyers()
        logger.info(f"Current buyers count: {len(buyers)}")
        
        # Test getting count
        count = BuyerService.get_buyers_count()
        logger.info(f"Buyers count from service: {count}")
        
        logger.info("✅ Buyer services module test completed")
        
    except Exception as e:
        logger.error(f"Buyer services test failed: {e}")
        logger.info("Note: This is expected if database/models are not available")