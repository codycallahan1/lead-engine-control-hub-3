"""
Lead import staging models for bulk CSV processing.

Phase: 25
Purpose: Define staging table for CSV imports with validation and batch tracking.
Key responsibilities:
- LeadStaging model for temporary storage during import
- Batch tracking and validation state management
- Error storage for invalid rows
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, DateTime, ForeignKey
from sqlalchemy.sql import func
import json
import logging

# Note: In final package structure, this would merge with main models.py
# For now, standalone with self-contained Base reference

try:
    from p02__server_db import Base
except ImportError:
    logging.info("Import staging models: p02__server_db not found, using standalone Base")
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()

logger = logging.getLogger(__name__)


class LeadStaging(Base):
    """Staging table for lead imports before validation and commit."""
    
    __tablename__ = "lead_staging"
    
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, nullable=False, default=1)  # Organization scoping
    name = Column(String(255), nullable=False)
    email = Column(String(320), nullable=False)  # RFC 5321 email length
    phone = Column(String(50), nullable=True)
    valid = Column(Boolean, default=False)  # Validation status
    errors_json = Column(Text, nullable=True)  # JSON array of error messages
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    batch_id = Column(String(50), nullable=False, index=True)  # UUID or similar
    
    def __repr__(self):
        status = "✓" if self.valid else "✗"
        return f"<LeadStaging {self.id}: {self.name} <{self.email}> [{status}]>"
    
    @property
    def errors(self):
        """Parse errors_json into list."""
        if not self.errors_json:
            return []
        try:
            return json.loads(self.errors_json)
        except (json.JSONDecodeError, TypeError):
            return ["Invalid error data"]
    
    @errors.setter
    def errors(self, error_list):
        """Set errors from list."""
        if error_list:
            self.errors_json = json.dumps(error_list)
            self.valid = False
        else:
            self.errors_json = None
            self.valid = True
    
    def add_error(self, message):
        """Add a single error message."""
        current_errors = self.errors
        current_errors.append(message)
        self.errors = current_errors
    
    def validate_row(self):
        """Validate staging row and set errors."""
        errors = []
        
        # Name validation
        if not self.name or len(self.name.strip()) < 2:
            errors.append("Name must be at least 2 characters")
        
        # Email validation (basic)
        if not self.email or "@" not in self.email:
            errors.append("Valid email required")
        elif len(self.email) > 320:
            errors.append("Email too long")
        
        # Phone validation (optional but if present, basic check)
        if self.phone and len(self.phone.strip()) > 50:
            errors.append("Phone number too long")
        
        self.errors = errors
        return self.valid


def create_staging_tables():
    """Create staging tables if they don't exist."""
    try:
        from p02__server_db import engine
        Base.metadata.create_all(bind=engine, tables=[LeadStaging.__table__])
        logger.info("Lead staging tables created/verified")
    except ImportError:
        logger.warning("Cannot create staging tables: database engine not available")
