"""
Lead Engine Control Hub - Diagnostics Service
Phase: 10
Purpose: Comprehensive system health checks and diagnostics
Key Responsibilities:
- Database connectivity testing
- Job queue health verification
- Template availability checking
- Provider mock validation
- System information gathering
- Performance metrics collection
"""

import logging
import platform
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class DiagnosticsService:
    """
    Comprehensive diagnostics service for system health monitoring.
    """
    
    def __init__(self):
        self.start_time = None
        self.results = {}
    
    def run_full(self) -> Dict[str, Any]:
        """
        Run complete diagnostic suite and return comprehensive report.
        
        Returns:
            Dictionary with diagnostic results and system status
        """
        self.start_time = time.time()
        logger.info("Starting full diagnostic suite")
        
        try:
            # Initialize results structure
            self.results = {
                "status": "ok",
                "runtime_ms": 0.0,
                "app_info": self._get_app_info(),
                "components": {
                    "database": self.check_db_connection(),
                    "queue": self.check_queue_service(),
                    "providers": self.check_provider_mocks(),
                    "templates": self.check_templates()
                },
                "system_info": self._get_system_info(),
                "timestamp": datetime.utcnow().isoformat()
            }
            
            # Determine overall status
            self._determine_overall_status()
            
            # Calculate runtime
            self.results["runtime_ms"] = round((time.time() - self.start_time) * 1000, 2)
            
            logger.info(f"Diagnostics completed in {self.results['runtime_ms']}ms with status: {self.results['status']}")
            return self.results
            
        except Exception as e:
            logger.error(f"Diagnostics suite failed: {e}")
            return {
                "status": "error",
                "runtime_ms": round((time.time() - self.start_time) * 1000, 2) if self.start_time else 0,
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    def check_db_connection(self) -> Dict[str, Any]:
        """
        Test database connectivity and basic operations.
        
        Returns:
            Dictionary with database diagnostic results
        """
        logger.info("Checking database connection")
        
        try:
            # Import database components
            from p02__server_db import get_session
            
            # Test basic connection
            with get_session() as db:
                result = db.execute("SELECT 1 as test").fetchone()
                if result and result[0] == 1:
                    connection_status = "ok"
                    connection_message = "Database connection successful"
                else:
                    connection_status = "error"
                    connection_message = "Database query returned unexpected result"
            
            # Get database file information
            db_path = Path("./controlhub.db")
            file_info = {}
            if db_path.exists():
                stat_info = db_path.stat()
                file_info = {
                    "exists": True,
                    "size_bytes": stat_info.st_size,
                    "size_mb": round(stat_info.st_size / (1024 * 1024), 2),
                    "last_modified": datetime.fromtimestamp(stat_info.st_mtime).isoformat()
                }
            else:
                file_info = {"exists": False}
            
            # Test table access
            tables_status = self._check_database_tables()
            
            return {
                "status": connection_status,
                "message": connection_message,
                "file_info": file_info,
                "tables": tables_status,
                "driver": "SQLite",
                "connection_pool": "SQLAlchemy default"
            }
            
        except ImportError as e:
            logger.error(f"Database module import failed: {e}")
            return {
                "status": "error",
                "message": f"Database module not available: {e}",
                "import_error": True
            }
        except Exception as e:
            logger.error(f"Database connection check failed: {e}")
            return {
                "status": "error",
                "message": f"Database connection failed: {e}"
            }
    
    def check_queue_service(self) -> Dict[str, Any]:
        """
        Verify job queue service health and functionality.
        
        Returns:
            Dictionary with queue diagnostic results
        """
        logger.info("Checking job queue service")
        
        try:
            # Import queue components
            from p07__server_services_queue import get_queue_stats, get_queue
            
            # Get queue statistics
            stats = get_queue_stats()
            
            # Test queue functionality
            queue = get_queue()
            
            # Check worker status
            worker_status = "running" if stats.get("worker_running", False) else "stopped"
            worker_healthy = stats.get("worker_thread_alive", False)
            
            # Validate registered handlers
            handlers = stats.get("registered_handlers", [])
            expected_handlers = ["deployment"]  # Expected from Phase 7
            missing_handlers = [h for h in expected_handlers if h not in handlers]
            
            status = "ok"
            issues = []
            
            if not worker_healthy:
                status = "warning"
                issues.append("Worker thread not healthy")
            
            if missing_handlers:
                status = "warning"
                issues.append(f"Missing handlers: {missing_handlers}")
            
            return {
                "status": status,
                "message": f"Queue service {worker_status}, {len(handlers)} handlers registered",
                "worker_status": worker_status,
                "worker_healthy": worker_healthy,
                "total_jobs": stats.get("total_jobs", 0),
                "registered_handlers": handlers,
                "missing_handlers": missing_handlers,
                "issues": issues
            }
            
        except ImportError as e:
            logger.error(f"Queue service import failed: {e}")
            return {
                "status": "error",
                "message": f"Queue service not available: {e}",
                "import_error": True
            }
        except Exception as e:
            logger.error(f"Queue service check failed: {e}")
            return {
                "status": "error",
                "message": f"Queue service check failed: {e}"
            }
    
    def check_provider_mocks(self) -> Dict[str, Any]:
        """
        Test provider mock availability and functionality.
        
        Returns:
            Dictionary with provider mock diagnostic results
        """
        logger.info("Checking provider mocks")
        
        providers = {
            "domains": {"status": "error", "available": False},
            "dns": {"status": "error", "available": False},
            "hosting": {"status": "error", "available": False}
        }
        
        # Test domains provider
        try:
            from p10__server_providers_domains_mock import purchase
            test_result = purchase("test-domain.com")
            providers["domains"] = {
                "status": "ok",
                "available": True,
                "test_result": test_result,
                "functions": ["purchase"]
            }
        except ImportError:
            providers["domains"] = {
                "status": "warning",
                "available": False,
                "message": "Domains provider mock not available"
            }
        except Exception as e:
            providers["domains"] = {
                "status": "error",
                "available": False,
                "message": f"Domains provider test failed: {e}"
            }
        
        # Test DNS provider
        try:
            from p10__server_providers_dns_mock import create_record
            test_result = create_record("test.com", "A", "192.168.1.1")
            providers["dns"] = {
                "status": "ok",
                "available": True,
                "test_result": test_result,
                "functions": ["create_record"]
            }
        except ImportError:
            providers["dns"] = {
                "status": "warning",
                "available": False,
                "message": "DNS provider mock not available"
            }
        except Exception as e:
            providers["dns"] = {
                "status": "error",
                "available": False,
                "message": f"DNS provider test failed: {e}"
            }
        
        # Test hosting provider
        try:
            from p10__server_providers_hosting_mock import deploy
            test_result = deploy("test.com", "/tmp/test", "us-east-1")
            providers["hosting"] = {
                "status": "ok",
                "available": True,
                "test_result": test_result,
                "functions": ["deploy"]
            }
        except ImportError:
            providers["hosting"] = {
                "status": "warning",
                "available": False,
                "message": "Hosting provider mock not available"
            }
        except Exception as e:
            providers["hosting"] = {
                "status": "error",
                "available": False,
                "message": f"Hosting provider test failed: {e}"
            }
        
        # Determine overall provider status
        available_count = sum(1 for p in providers.values() if p.get("available", False))
        total_count = len(providers)
        
        if available_count == total_count:
            overall_status = "ok"
            overall_message = f"All {total_count} provider mocks available"
        elif available_count > 0:
            overall_status = "warning"
            overall_message = f"{available_count}/{total_count} provider mocks available"
        else:
            overall_status = "error"
            overall_message = "No provider mocks available"
        
        return {
            "status": overall_status,
            "message": overall_message,
            "providers": providers,
            "summary": {
                "total": total_count,
                "available": available_count,
                "unavailable": total_count - available_count
            }
        }
    
    def check_templates(self) -> Dict[str, Any]:
        """
        Verify template availability and structure.
        
        Returns:
            Dictionary with template diagnostic results
        """
        logger.info("Checking templates")
        
        # Expected templates by phase
        expected_templates = [
            "base.html",           # Phase 1
            "dashboard.html",      # Phase 5
            "leads.html",          # Phase 3/8 (updated)
            "buyers.html",         # Phase 3
            "sites.html",          # Phase 6
            "deployments.html",    # Phase 7
            "ingest_form.html",    # Phase 4
            "settings.html"        # Phase 9
        ]
        
        # Check current directory and templates subdirectory
        search_paths = [
            Path("."),
            Path("./templates"),
            Path(__file__).parent / "templates"
        ]
        
        found_templates = []
        missing_templates = []
        template_locations = {}
        
        for template in expected_templates:
            found = False
            for search_path in search_paths:
                template_path = search_path / template
                if template_path.exists():
                    found_templates.append(template)
                    template_locations[template] = str(template_path)
                    found = True
                    break
                
                # Also check with phase prefixes
                for phase in range(1, 12):
                    prefixed_template = search_path / f"p{phase:02d}__server-templates-{template}"
                    if prefixed_template.exists():
                        found_templates.append(template)
                        template_locations[template] = str(prefixed_template)
                        found = True
                        break
                
                if found:
                    break
            
            if not found:
                missing_templates.append(template)
        
        # Determine status
        found_count = len(found_templates)
        total_count = len(expected_templates)
        
        if found_count == total_count:
            status = "ok"
            message = f"All {total_count} expected templates found"
        elif found_count > 0:
            status = "warning"
            message = f"{found_count}/{total_count} templates found, {len(missing_templates)} missing"
        else:
            status = "error"
            message = "No expected templates found"
        
        return {
            "status": status,
            "message": message,
            "found": found_templates,
            "missing": missing_templates,
            "locations": template_locations,
            "summary": {
                "total_expected": total_count,
                "found": found_count,
                "missing": len(missing_templates)
            }
        }
    
    def _check_database_tables(self) -> Dict[str, Any]:
        """Check database table availability and structure."""
        try:
            from p02__server_db import get_session, engine
            from sqlalchemy import inspect
            
            inspector = inspect(engine)
            tables = inspector.get_table_names()
            
            expected_tables = ["leads", "buyers", "sites", "deployments"]
            missing_tables = [t for t in expected_tables if t not in tables]
            extra_tables = [t for t in tables if t not in expected_tables]
            
            return {
                "available": tables,
                "missing": missing_tables,
                "extra": extra_tables,
                "total_count": len(tables)
            }
            
        except Exception as e:
            return {
                "error": f"Table check failed: {e}",
                "available": [],
                "missing": [],
                "extra": []
            }
    
    def _get_app_info(self) -> Dict[str, Any]:
        """Get application information."""
        return {
            "name": "Lead Engine Control Hub",
            "version": "1.0.0",
            "phase": 10,
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "platform": platform.system(),
            "architecture": platform.machine()
        }
    
    def _get_system_info(self) -> Dict[str, Any]:
        """Get system information."""
        return {
            "python_version": sys.version,
            "platform": platform.platform(),
            "processor": platform.processor(),
            "memory": "unknown",  # Could add psutil for memory info
            "disk_space": "unknown",  # Could add disk space check
            "uptime": "unknown"  # Could add uptime calculation
        }
    
    def _determine_overall_status(self) -> None:
        """Determine overall diagnostic status based on component results."""
        components = self.results.get("components", {})
        
        error_count = 0
        warning_count = 0
        
        for component_name, component_result in components.items():
            status = component_result.get("status", "unknown")
            if status == "error":
                error_count += 1
            elif status == "warning":
                warning_count += 1
        
        if error_count > 0:
            self.results["status"] = "error"
        elif warning_count > 0:
            self.results["status"] = "warning"
        else:
            self.results["status"] = "ok"

# Global diagnostics instance
_diagnostics_service = DiagnosticsService()

def run_full_diagnostics() -> Dict[str, Any]:
    """Run complete diagnostic suite (convenience function)."""
    return _diagnostics_service.run_full()

def run_quick_health_check() -> Dict[str, Any]:
    """Run abbreviated health check."""
    start_time = time.time()
    
    try:
        # Quick database check
        from p02__server_db import get_session
        with get_session() as db:
            db.execute("SELECT 1").fetchone()
        db_status = "ok"
    except Exception:
        db_status = "error"
    
    # Quick queue check
    try:
        from p07__server_services_queue import get_queue_stats
        stats = get_queue_stats()
        queue_status = "ok" if stats.get("worker_running") else "warning"
    except Exception:
        queue_status = "error"
    
    runtime_ms = round((time.time() - start_time) * 1000, 2)
    
    return {
        "status": "ok" if db_status == "ok" and queue_status != "error" else "warning",
        "runtime_ms": runtime_ms,
        "components": {
            "database": db_status,
            "queue": queue_status
        },
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Diagnostics Service Module Test ===")
    
    # Run full diagnostics
    result = run_full_diagnostics()
    logger.info(f"Full diagnostics result: {result['status']} in {result['runtime_ms']}ms")
    
    # Run quick health check
    quick_result = run_quick_health_check()
    logger.info(f"Quick health check: {quick_result['status']} in {quick_result['runtime_ms']}ms")
    
    logger.info("✅ Diagnostics service module test completed")