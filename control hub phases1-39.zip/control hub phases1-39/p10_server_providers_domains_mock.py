"""
Lead Engine Control Hub - Domains Provider Mock
Phase: 10
Purpose: Mock domain purchase functionality for testing and diagnostics
Key Responsibilities:
- Simulate domain purchase operations
- Provide realistic response delays
- Return success/failure responses for testing
- Support diagnostics verification
"""

import logging
import time
import random
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class DomainsProviderMock:
    """
    Mock domains provider for testing domain purchase operations.
    Simulates realistic domain registration service behavior.
    """
    
    def __init__(self):
        # Simulate some domains as already taken
        self.taken_domains = {
            "google.com",
            "facebook.com", 
            "amazon.com",
            "microsoft.com",
            "test.com",
            "example.com"
        }
        
        # Track purchase history
        self.purchase_history = []
    
    def purchase(self, domain: str, registrant_info: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        Mock domain purchase operation.
        
        Args:
            domain: Domain name to purchase
            registrant_info: Optional registrant information
            
        Returns:
            Dictionary with purchase result
        """
        logger.info(f"Mock domain purchase attempt: {domain}")
        
        # Simulate processing delay
        delay = random.uniform(0.5, 2.0)
        time.sleep(delay)
        
        # Clean domain name
        domain = domain.lower().strip()
        
        # Validate domain format
        if not self._is_valid_domain(domain):
            result = {
                "success": False,
                "domain": domain,
                "error": "Invalid domain format",
                "error_code": "INVALID_FORMAT",
                "processing_time_seconds": delay
            }
            logger.warning(f"Domain purchase failed - invalid format: {domain}")
            return result
        
        # Check if domain is already taken
        if domain in self.taken_domains:
            result = {
                "success": False,
                "domain": domain,
                "error": "Domain already registered",
                "error_code": "DOMAIN_TAKEN",
                "processing_time_seconds": delay,
                "suggestions": self._generate_suggestions(domain)
            }
            logger.info(f"Domain purchase failed - already taken: {domain}")
            return result
        
        # Simulate random failures for testing
        if random.random() < 0.1:  # 10% failure rate
            result = {
                "success": False,
                "domain": domain,
                "error": "Payment processing failed",
                "error_code": "PAYMENT_FAILED",
                "processing_time_seconds": delay,
                "retry_suggested": True
            }
            logger.info(f"Domain purchase failed - payment error: {domain}")
            return result
        
        # Successful purchase
        purchase_id = f"DOM_{int(time.time())}_{random.randint(1000, 9999)}"
        
        result = {
            "success": True,
            "domain": domain,
            "purchase_id": purchase_id,
            "registration_period_years": 1,
            "cost_usd": round(random.uniform(10.99, 29.99), 2),
            "processing_time_seconds": delay,
            "registrant": registrant_info or {
                "name": "Test User",
                "email": "test@example.com"
            },
            "nameservers": [
                "ns1.example-registrar.com",
                "ns2.example-registrar.com"
            ],
            "expires_at": "2025-01-01T00:00:00Z"
        }
        
        # Add to taken domains and history
        self.taken_domains.add(domain)
        self.purchase_history.append(result.copy())
        
        logger.info(f"Domain purchase successful: {domain} (ID: {purchase_id})")
        return result
    
    def check_availability(self, domain: str) -> Dict[str, Any]:
        """
        Check domain availability without purchasing.
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dictionary with availability information
        """
        logger.info(f"Checking domain availability: {domain}")
        
        # Simulate processing delay
        delay = random.uniform(0.1, 0.5)
        time.sleep(delay)
        
        domain = domain.lower().strip()
        
        if not self._is_valid_domain(domain):
            return {
                "domain": domain,
                "available": False,
                "error": "Invalid domain format",
                "processing_time_seconds": delay
            }
        
        available = domain not in self.taken_domains
        
        result = {
            "domain": domain,
            "available": available,
            "price_usd": round(random.uniform(10.99, 29.99), 2) if available else None,
            "processing_time_seconds": delay
        }
        
        if not available:
            result["suggestions"] = self._generate_suggestions(domain)
        
        return result
    
    def get_purchase_history(self) -> list:
        """
        Get history of mock purchases.
        
        Returns:
            List of purchase records
        """
        return self.purchase_history.copy()
    
    def reset_state(self) -> None:
        """Reset mock state for testing."""
        self.purchase_history.clear()
        # Keep some domains as permanently taken
        self.taken_domains = {
            "google.com",
            "facebook.com", 
            "amazon.com",
            "microsoft.com"
        }
        logger.info("Domain provider mock state reset")
    
    def _is_valid_domain(self, domain: str) -> bool:
        """Basic domain validation."""
        if not domain or len(domain) < 3:
            return False
        
        if not '.' in domain:
            return False
        
        if domain.startswith('.') or domain.endswith('.'):
            return False
        
        if '..' in domain:
            return False
        
        # Check for invalid characters (simplified)
        allowed_chars = set('abcdefghijklmnopqrstuvwxyz0123456789.-')
        return all(c in allowed_chars for c in domain)
    
    def _generate_suggestions(self, domain: str) -> list:
        """Generate alternative domain suggestions."""
        base = domain.split('.')[0] if '.' in domain else domain
        tld = domain.split('.')[-1] if '.' in domain else 'com'
        
        suggestions = []
        
        # Add prefixes
        prefixes = ['get', 'my', 'the', 'new', 'best']
        for prefix in prefixes[:2]:
            suggestions.append(f"{prefix}{base}.{tld}")
        
        # Add suffixes
        suffixes = ['app', 'site', 'web', 'pro', 'now']
        for suffix in suffixes[:2]:
            suggestions.append(f"{base}{suffix}.{tld}")
        
        # Try different TLDs
        alt_tlds = ['net', 'org', 'io', 'co']
        for alt_tld in alt_tlds[:2]:
            suggestions.append(f"{base}.{alt_tld}")
        
        return suggestions[:5]  # Limit to 5 suggestions

# Global mock instance
_domains_mock = DomainsProviderMock()

def purchase(domain: str, registrant_info: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Purchase a domain (mock implementation).
    
    Args:
        domain: Domain name to purchase
        registrant_info: Optional registrant information
        
    Returns:
        Dictionary with purchase result
    """
    return _domains_mock.purchase(domain, registrant_info)

def check_availability(domain: str) -> Dict[str, Any]:
    """
    Check domain availability (mock implementation).
    
    Args:
        domain: Domain name to check
        
    Returns:
        Dictionary with availability information
    """
    return _domains_mock.check_availability(domain)

def get_purchase_history() -> list:
    """Get purchase history (mock implementation)."""
    return _domains_mock.get_purchase_history()

def reset_mock_state() -> None:
    """Reset mock state for testing."""
    _domains_mock.reset_state()

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Domains Provider Mock Test ===")
    
    # Test domain availability check
    result = check_availability("test-domain-123.com")
    logger.info(f"Availability check: {result}")
    
    # Test domain purchase
    if result.get("available"):
        purchase_result = purchase("test-domain-123.com", {
            "name": "Test User",
            "email": "test@example.com"
        })
        logger.info(f"Purchase result: {purchase_result}")
    
    # Test invalid domain
    invalid_result = purchase("invalid..domain")
    logger.info(f"Invalid domain result: {invalid_result}")
    
    # Test taken domain
    taken_result = purchase("google.com")
    logger.info(f"Taken domain result: {taken_result}")
    
    # Show purchase history
    history = get_purchase_history()
    logger.info(f"Purchase history: {len(history)} items")
    
    logger.info("✅ Domains provider mock test completed")