"""
App initialization snippet showing maintenance middleware integration.

Phase: 27 (Updated app init)
Purpose: Show how to wire read-only middleware and maintenance routes.
Key responsibilities:
- Demonstrate middleware ordering for read-only mode
- Show router inclusion for maintenance endpoints
- Ensure proper placement after CORS/static mounts
"""

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import logging

# Import middleware and routes
try:
    from p27__server_middleware_readonly import create_readonly_middleware, simple_readonly_check
    from p27__server_routes_maintenance import router as maintenance_router
    from p08__server_services_audit import audit_system_event
except ImportError as e:
    logging.warning(f"App wiring: missing maintenance dependencies {e}")

logger = logging.getLogger(__name__)


def create_app_with_maintenance():
    """
    Example of how to create FastAPI app with maintenance features.
    
    This function shows the proper order of middleware and router inclusion
    for the read-only mode and backup functionality.
    """
    
    # Create FastAPI app
    app = FastAPI(
        title="Lead Engine Control Hub",
        description="Lead management system with deployment automation",
        version="1.0.0"
    )
    
    # 1. FIRST: Mount static files (before middleware)
    try:
        app.mount("/static", StaticFiles(directory="static"), name="static")
    except RuntimeError:
        logger.warning("Static directory not found - continuing without static files")
    
    # 2. SECOND: Add CORS middleware if needed
    # from fastapi.middleware.cors import CORSMiddleware
    # app.add_middleware(CORSMiddleware, ...)
    
    # 3. THIRD: Add read-only middleware (after CORS, before routes)
    app.add_middleware(
        create_readonly_middleware,
        readonly_check_func=simple_readonly_check
    )
    
    # 4. Add other middleware (error handling, rate limiting, etc.)
    try:
        from p17__server_middleware_errors import add_exception_handlers
        add_exception_handlers(app)
    except ImportError:
        pass
    
    try:
        from p17__server_middleware_ratelimit import RateLimitMiddleware
        app.add_middleware(RateLimitMiddleware)
    except ImportError:
        pass
    
    # 5. Include routers
    
    # Core routers (from earlier phases)
    try:
        from p03__server_routes_leads import router as leads_router
        from p03__server_routes_buyers import router as buyers_router
        from p06__server_routes_sites import router as sites_router
        
        app.include_router(leads_router)
        app.include_router(buyers_router)
        app.include_router(sites_router)
    except ImportError:
        logger.warning("Core routers not available")
    
    # Maintenance router (IMPORTANT: include after read-only middleware)
    app.include_router(maintenance_router)
    
    # Other routers
    try:
        from p04__server_routes_ingest import router as ingest_router
        from p05__server_routes_metrics import router as metrics_router
        from p08__server_routes_export import router as export_router
        from p13__server_routes_webhooks import router as webhooks_router
        from p26__server_routes_privacy import router as privacy_router
        
        app.include_router(ingest_router)
        app.include_router(metrics_router)
        app.include_router(export_router)
        app.include_router(webhooks_router)
        app.include_router(privacy_router)
    except ImportError:
        logger.warning("Some optional routers not available")
    
    # 6. Add startup/shutdown events
    
    @app.on_event("startup")
    async def startup_event():
        """Initialize services on startup."""
        logger.info("Lead Engine Control Hub starting up...")
        
        # Initialize database
        try:
            from p02__server_db import create_all_tables
            create_all_tables()
            logger.info("Database tables initialized")
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
        
        # Initialize queue workers
        try:
            from p07__server_services_queue import ensure_worker_running
            from p25__server_services_queue_import_worker import init_import_queue
            
            ensure_worker_running()
            init_import_queue()
            logger.info("Queue workers initialized")
        except Exception as e:
            logger.warning(f"Queue initialization failed: {e}")
        
        # Start scheduler
        try:
            from p19__server_services_scheduler import start_scheduler
            start_scheduler()
            logger.info("Scheduler started")
        except Exception as e:
            logger.warning(f"Scheduler initialization failed: {e}")
        
        # Audit startup
        audit_system_event("startup", "application", "success", {
            "version": "1.0.0",
            "maintenance_features": True
        })
        
        logger.info("Startup complete")
    
    @app.on_event("shutdown")
    async def shutdown_event():
        """Cleanup on shutdown."""
        logger.info("Lead Engine Control Hub shutting down...")
        
        # Stop scheduler
        try:
            from p19__server_services_scheduler import stop_scheduler
            stop_scheduler()
        except Exception as e:
            logger.warning(f"Scheduler shutdown failed: {e}")
        
        # Stop queue workers
        try:
            from p07__server_services_queue import stop_worker
            stop_worker()
        except Exception as e:
            logger.warning(f"Queue shutdown failed: {e}")
        
        # Audit shutdown
        audit_system_event("shutdown", "application", "success")
        
        logger.info("Shutdown complete")
    
    # 7. Add basic health endpoint that bypasses read-only mode
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint - always available."""
        return {"status": "ok", "read_only_aware": True}
    
    @app.get("/version")
    async def version_info():
        """Version endpoint - always available."""
        return {
            "app": "Lead Engine Control Hub",
            "version": "1.0.0",
            "phase": 27,
            "features": ["maintenance", "read_only_mode", "backups"]
        }
    
    return app


# Example usage and configuration notes
def configure_maintenance_settings():
    """
    Example of maintenance configuration that would be called at startup.
    """
    
    # Set backup retention policy
    from p27__server_services_backup import DEFAULT_KEEP_DAYS, DEFAULT_MAX_BACKUPS
    
    backup_config = {
        "keep_days": 30,
        "max_backups": 10,
        "backup_dir": "./backups",
        "auto_cleanup": True
    }
    
    # Set read-only mode defaults
    readonly_config = {
        "enabled": False,
        "allowed_paths": ["/health", "/version", "/maintenance"],
        "maintenance_html": True
    }
    
    logger.info(f"Maintenance configured: backups={backup_config}, readonly={readonly_config}")
    
    return backup_config, readonly_config


# Middleware ordering guide (CRITICAL)
"""
MIDDLEWARE ORDER (applied in reverse):

1. StaticFiles mount (not middleware, but affects routing)
2. CORSMiddleware (if used)
3. ReadOnlyMiddleware ← MUST be here to catch mutations
4. ErrorHandlingMiddleware
5. RateLimitMiddleware
6. AuthMiddleware (if used)
7. OrganizationContextMiddleware (if used)

The read-only middleware MUST be placed early enough to catch
all mutating requests but AFTER CORS to allow preflight requests.

Key points:
- Static files are mounted, not middleware, so they're unaffected
- Health/version endpoints work regardless of read-only mode
- Maintenance endpoints can toggle read-only mode
- Error handling comes after read-only to catch 503 responses
"""

# Database migration note
"""
For read-only mode persistence across restarts, you may want to add
an app_settings table:

CREATE TABLE app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO app_settings (key, value) VALUES ('read_only_mode', 'false');

This allows read-only state to survive server restarts.
"""
