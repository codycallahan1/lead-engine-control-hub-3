"""
Webhook worker extension for the job queue system.

Phase: 13
Purpose: Register and handle webhook delivery jobs in the queue
Key responsibilities: webhook job handler registration and mock HTTP delivery
"""

import logging
import json
import time
import random
from typing import Dict, Any

# Import attempt with graceful fallback
try:
    from p02__server_db import get_session
    from p13__server_models_webhooks import Webhook, WebhookDelivery
    from p07__server_services_queue import register as register_handler
except ImportError as e:
    logging.warning(f"Import issue in webhook worker: {e}")
    # Fallback for development
    def get_session():
        return None
    class Webhook:
        pass
    class WebhookDelivery:
        pass
    def register_handler(kind, handler_fn):
        pass

logger = logging.getLogger(__name__)

def webhook_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process webhook delivery job.
    
    Simulates HTTP POST to webhook URL and records the result.
    No actual external HTTP calls are made - this is a mock implementation.
    
    Args:
        payload: Job payload containing webhook_id, delivery_id, url, event, payload
        
    Returns:
        Result dict with success status and metrics
    """
    webhook_id = payload.get('webhook_id')
    delivery_id = payload.get('delivery_id')
    url = payload.get('url', 'unknown')
    event = payload.get('event', 'unknown')
    
    logger.info(f"Processing webhook delivery {delivery_id} to {url} for event {event}")
    
    # Simulate HTTP request latency
    start_time = time.time()
    time.sleep(random.uniform(0.1, 0.5))  # 100-500ms simulated latency
    end_time = time.time()
    
    response_ms = int((end_time - start_time) * 1000)
    
    # Simulate random success/failure (90% success rate)
    success = random.random() > 0.1
    
    if success:
        status = 'success'
        response_code = 200
        logger.info(f"Webhook delivery {delivery_id} succeeded in {response_ms}ms")
    else:
        status = 'failed'
        response_code = random.choice([404, 500, 502, 503, 504])
        logger.warning(f"Webhook delivery {delivery_id} failed with {response_code} in {response_ms}ms")
    
    # Update delivery record
    with get_session() as session:
        delivery = session.query(WebhookDelivery).filter(
            WebhookDelivery.id == delivery_id
        ).first()
        
        if delivery:
            delivery.status = status
            delivery.response_code = response_code
            delivery.response_ms = response_ms
            session.commit()
            
            # Update webhook last status
            webhook = session.query(Webhook).filter(Webhook.id == webhook_id).first()
            if webhook:
                webhook.last_status = status
                webhook.last_response_ms = response_ms
                session.commit()
        else:
            logger.error(f"Delivery record {delivery_id} not found")
    
    return {
        'success': success,
        'webhook_id': webhook_id,
        'delivery_id': delivery_id,
        'response_code': response_code,
        'response_ms': response_ms,
        'url': url
    }

def init_webhook_queue():
    """
    Register the webhook worker with the queue system.
    
    This should be called during application startup to ensure
    webhook jobs can be processed.
    """
    logger.info("Initializing webhook queue worker")
    
    try:
        register_handler('webhook', webhook_worker)
        logger.info("Webhook worker registered successfully")
    except Exception as e:
        logger.error(f"Failed to register webhook worker: {e}")

# Auto-initialize when module is imported
init_webhook_queue()

# Log worker initialization
logger.info("Webhook queue worker module loaded and initialized")