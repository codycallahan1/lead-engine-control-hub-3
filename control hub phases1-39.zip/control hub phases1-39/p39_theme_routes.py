"""
Theme routes for organization branding management.
Phase 39: Theming & Branding per Org
Purpose: per-Org logo/colors; inject into base template + public ingest form
"""

from typing import Dict, Any
from fastapi import APIRouter, HTTPException, UploadFile, File, Depends, Request
from pydantic import BaseModel, Field
import logging

# Import theme service
try:
    from p39__server_services_theme import (
        get_theme, update_theme, upload_logo, get_logo_url, 
        get_theme_preview, delete_logo, reset_theme, 
        export_theme, import_theme, validate_theme_data
    )
except ImportError:
    # Fallback for when files are reorganized
    logging.warning("Could not import theme service - imports may need adjustment during packaging")
    def get_theme(org_id): return None
    def update_theme(org_id, data): return False, "Service not available", None
    def upload_logo(org_id, content, filename, user): return False, "Service not available", None
    def get_logo_url(org_id, base=""): return None
    def get_theme_preview(org_id): return {}
    def delete_logo(org_id): return False, "Service not available"
    def reset_theme(org_id): return False, "Service not available"
    def export_theme(org_id): return {}
    def import_theme(org_id, data): return False, "Service not available"
    def validate_theme_data(data): return True, []

logger = logging.getLogger(__name__)

router = APIRouter()

# Placeholder for auth dependencies
def require_admin():
    """Placeholder for admin authentication dependency."""
    pass

def get_current_org_id(request: Request) -> int:
    """Get current organization ID from request context."""
    # In final package, this would read from request.state.org_id
    return getattr(request.state, 'org_id', 1)


class ThemeUpdateRequest(BaseModel):
    primary_hex: str = Field(None, description="Primary color hex code")
    secondary_hex: str = Field(None, description="Secondary color hex code") 
    accent_hex: str = Field(None, description="Accent color hex code")
    background_hex: str = Field(None, description="Background color hex code")
    text_hex: str = Field(None, description="Text color hex code")
    display_name: str = Field(None, description="Organization display name override")
    custom_css: str = Field(None, description="Custom CSS rules")


class ThemeResponse(BaseModel):
    success: bool
    message: str
    theme: Dict[str, Any] = None


@router.get("/theme")
async def get_organization_theme(
    request: Request,
    admin: Any = Depends(require_admin)
):
    """
    Get current theme configuration for organization.
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin requested theme for org_id={org_id}")
        
        theme = get_theme(org_id)
        if not theme:
            raise HTTPException(status_code=404, detail="Theme not found")
        
        theme_data = theme.to_dict()
        theme_data['logo_url'] = get_logo_url(org_id)
        
        return {
            "success": True,
            "theme": theme_data
        }
        
    except Exception as e:
        logger.error(f"Failed to get theme: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get theme: {str(e)}")


@router.put("/theme", response_model=ThemeResponse)
async def update_organization_theme(
    theme_data: ThemeUpdateRequest,
    request: Request,
    admin: Any = Depends(require_admin)
):
    """
    Update theme configuration for organization.
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin updating theme for org_id={org_id}")
        
        # Convert to dict, excluding None values
        update_data = {}
        for field, value in theme_data.dict().items():
            if value is not None:
                update_data[field] = value
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No theme data provided")
        
        # Validate data
        valid, errors = validate_theme_data(update_data)
        if not valid:
            raise HTTPException(status_code=400, detail=f"Invalid theme data: {'; '.join(errors)}")
        
        # Update theme
        success, message, theme = update_theme(org_id, update_data)
        
        if success:
            theme_dict = theme.to_dict() if theme else {}
            theme_dict['logo_url'] = get_logo_url(org_id)
            
            return ThemeResponse(
                success=True,
                message=message,
                theme=theme_dict
            )
        else:
            raise HTTPException(status_code=400, detail=message)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update theme: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update theme: {str(e)}")


@router.post("/theme/logo")
async def upload_organization_logo(
    file: UploadFile = File(...),
    request: Request = None,
    admin: Any = Depends(require_admin)
):
    """
    Upload logo file for organization.
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin uploading logo for org_id={org_id}: {file.filename}")
        
        # Validate file
        if not file.filename:
            raise HTTPException(status_code=400, detail="No file provided")
        
        # Read file content
        content = await file.read()
        
        # Upload logo
        success, message, file_path = upload_logo(
            org_id=org_id,
            file_content=content,
            filename=file.filename,
            uploaded_by="admin"  # In real app, get from auth context
        )
        
        if success:
            logo_url = get_logo_url(org_id)
            return {
                "success": True,
                "message": message,
                "logo_url": logo_url
            }
        else:
            raise HTTPException(status_code=400, detail=message)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to upload logo: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to upload logo: {str(e)}")


@router.delete("/theme/logo")
async def delete_organization_logo(
    request: Request,
    admin: Any = Depends(require_admin)
):
    """
    Remove logo for organization.
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin deleting logo for org_id={org_id}")
        
        success, message = delete_logo(org_id)
        
        if success:
            return {
                "success": True,
                "message": message
            }
        else:
            raise HTTPException(status_code=400, detail=message)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete logo: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete logo: {str(e)}")


@router.get("/theme/preview")
async def get_theme_preview_data(
    request: Request,
    admin: Any = Depends(require_admin)
):
    """
    Get theme data with computed CSS variables for preview.
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin requested theme preview for org_id={org_id}")
        
        preview_data = get_theme_preview(org_id)
        
        return {
            "success": True,
            "preview": preview_data
        }
        
    except Exception as e:
        logger.error(f"Failed to get theme preview: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get theme preview: {str(e)}")


@router.post("/theme/reset")
async def reset_organization_theme(
    request: Request,
    admin: Any = Depends(require_admin)
):
    """
    Reset theme to default values for organization.
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin resetting theme for org_id={org_id}")
        
        success, message = reset_theme(org_id)
        
        if success:
            # Get updated theme
            theme = get_theme(org_id)
            theme_dict = theme.to_dict() if theme else {}
            theme_dict['logo_url'] = get_logo_url(org_id)
            
            return {
                "success": True,
                "message": message,
                "theme": theme_dict
            }
        else:
            raise HTTPException(status_code=400, detail=message)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to reset theme: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to reset theme: {str(e)}")


@router.get("/theme/export")
async def export_organization_theme(
    request: Request,
    admin: Any = Depends(require_admin)
):
    """
    Export theme configuration for backup/transfer.
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin exporting theme for org_id={org_id}")
        
        export_data = export_theme(org_id)
        
        return {
            "success": True,
            "export": export_data,
            "exported_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to export theme: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to export theme: {str(e)}")


@router.post("/theme/import")
async def import_organization_theme(
    import_data: Dict[str, Any],
    request: Request,
    admin: Any = Depends(require_admin)
):
    """
    Import theme configuration (colors/CSS only).
    Admin authentication required.
    """
    try:
        org_id = get_current_org_id(request)
        logger.info(f"Admin importing theme for org_id={org_id}")
        
        success, message = import_theme(org_id, import_data)
        
        if success:
            # Get updated theme
            theme = get_theme(org_id)
            theme_dict = theme.to_dict() if theme else {}
            theme_dict['logo_url'] = get_logo_url(org_id)
            
            return {
                "success": True,
                "message": message,
                "theme": theme_dict
            }
        else:
            raise HTTPException(status_code=400, detail=message)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to import theme: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to import theme: {str(e)}")


# Public endpoint for getting theme CSS (no auth required)
@router.get("/theme/css")
async def get_theme_css(request: Request):
    """
    Get CSS variables for current organization theme.
    Public endpoint for use in templates.
    """
    try:
        org_id = get_current_org_id(request)
        
        theme = get_theme(org_id)
        if not theme:
            # Return default CSS if no theme
            return {
                "css_vars": {
                    "--color-primary": "#0ea5e9",
                    "--color-secondary": "#22c55e",
                    "--color-accent": "#f59e0b",
                    "--color-background": "#0f172a",
                    "--color-surface": "#1e293b",
                    "--color-text": "#e2e8f0",
                    "--color-text-muted": "#94a3b8",
                    "--color-border": "#334155"
                },
                "custom_css": None
            }
        
        css_vars = theme.get_css_vars()
        
        return {
            "css_vars": css_vars,
            "custom_css": theme.custom_css,
            "logo_url": get_logo_url(org_id)
        }
        
    except Exception as e:
        logger.error(f"Failed to get theme CSS: {e}")
        # Return defaults on error to prevent breaking the UI
        return {
            "css_vars": {
                "--color-primary": "#0ea5e9",
                "--color-secondary": "#22c55e", 
                "--color-background": "#0f172a",
                "--color-text": "#e2e8f0"
            },
            "custom_css": None
        }
