"""
Import worker for queue system - processes staging leads into final leads table.

Phase: 25
Purpose: Background job to validate, dedupe, and migrate staging leads to final table.
Key responsibilities:
- Process staging batches asynchronously
- Deduplicate emails within batch and against existing leads
- Handle validation errors and update staging records
"""

import logging
from typing import Dict, Any
from datetime import datetime

try:
    from p02__server_db import get_session
    from p02__server_models import Lead
    from p25__server_models_import import LeadStaging
    from p07__server_services_queue import register
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Import worker: missing dependency {e}")

logger = logging.getLogger(__name__)


def import_leads_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process a staging batch and import valid leads.
    
    Args:
        payload: {"batch_id": str, "org_id": int}
    
    Returns:
        {"success": bool, "imported": int, "skipped": int, "errors": int}
    """
    batch_id = payload.get('batch_id')
    org_id = payload.get('org_id', 1)
    
    if not batch_id:
        raise ValueError("batch_id required in payload")
    
    logger.info(f"Processing import batch {batch_id} for org {org_id}")
    
    try:
        with get_session() as db:
            # Get all staging rows for this batch
            staging_rows = db.query(LeadStaging).filter(
                LeadStaging.batch_id == batch_id,
                LeadStaging.org_id == org_id
            ).order_by(LeadStaging.id).all()
            
            if not staging_rows:
                logger.warning(f"No staging rows found for batch {batch_id}")
                return {"success": False, "error": "Batch not found"}
            
            # Track results
            imported_count = 0
            skipped_count = 0
            error_count = 0
            
            # Get existing emails in this org for deduplication
            existing_emails = set()
            existing_leads = db.query(Lead.email).filter(
                Lead.org_id == org_id
            ).all()
            for lead in existing_leads:
                if lead.email:
                    existing_emails.add(lead.email.lower())
            
            # Track emails within this batch
            batch_emails = set()
            
            for staging_row in staging_rows:
                try:
                    # Re-validate (in case business rules changed)
                    staging_row.validate_row()
                    
                    if not staging_row.valid:
                        error_count += 1
                        continue
                    
                    email_lower = staging_row.email.lower()
                    
                    # Check for duplicates
                    if email_lower in existing_emails:
                        staging_row.add_error("Email already exists in system")
                        skipped_count += 1
                        continue
                    
                    if email_lower in batch_emails:
                        staging_row.add_error("Duplicate email within batch (keeping first occurrence)")
                        skipped_count += 1
                        continue
                    
                    # Create new lead
                    new_lead = Lead(
                        org_id=org_id,
                        name=staging_row.name.strip(),
                        email=staging_row.email.strip(),
                        phone=staging_row.phone.strip() if staging_row.phone else None
                    )
                    
                    db.add(new_lead)
                    db.flush()  # Get the ID without committing
                    
                    # Mark staging row as processed
                    staging_row.valid = True
                    staging_row.errors = []  # Clear any old errors
                    
                    # Track this email
                    batch_emails.add(email_lower)
                    existing_emails.add(email_lower)
                    imported_count += 1
                    
                    logger.debug(f"Imported lead {new_lead.id}: {new_lead.email}")
                
                except Exception as e:
                    logger.error(f"Error processing staging row {staging_row.id}: {e}")
                    staging_row.add_error(f"Import error: {str(e)}")
                    error_count += 1
            
            # Commit all changes
            db.commit()
            
            result = {
                "success": True,
                "imported": imported_count,
                "skipped": skipped_count,
                "errors": error_count,
                "total_processed": len(staging_rows)
            }
            
            logger.info(f"Import batch {batch_id} completed: {result}")
            
            # Audit the completion
            audit(
                kind="import_batch_processed",
                message=f"Import batch completed: {imported_count} imported, {skipped_count} skipped",
                meta={
                    "batch_id": batch_id,
                    "org_id": org_id,
                    **result
                }
            )
            
            return result
    
    except Exception as e:
        logger.error(f"Import worker failed for batch {batch_id}: {e}")
        
        # Audit the failure
        audit(
            kind="import_batch_failed",
            message=f"Import batch failed: {str(e)}",
            meta={
                "batch_id": batch_id,
                "org_id": org_id,
                "error": str(e)
            }
        )
        
        return {
            "success": False,
            "error": str(e),
            "imported": 0,
            "skipped": 0,
            "errors": 0
        }


def init_import_queue():
    """Register the import worker with the queue system."""
    try:
        register("import_leads", import_leads_worker)
        logger.info("Import worker registered with queue system")
    except Exception as e:
        logger.error(f"Failed to register import worker: {e}")


# Auto-register when imported
if __name__ != "__main__":
    init_import_queue()
