"""
Matching routes for lead-to-buyer rule management and execution.

Phase: 28
Purpose: API endpoints for managing matching rules and executing matches.
Key responsibilities:
- CRUD operations for matching rules
- Preview matching results
- Execute manual matches
"""

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import logging

try:
    from p02__server_db import get_session
    from p28__server_models_matching import MatchingRule, MatchLog, create_matching_tables
    from p28__server_services_matching import (
        match_and_record, 
        preview_match, 
        get_match_history,
        validate_rule_conditions
    )
    from p24__server_services_scope import current_org
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Matching routes: missing dependency {e}")

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/matching", tags=["matching"])


class RuleCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    priority: int = Field(default=10, ge=1, le=100)
    weight: float = Field(default=1.0, gt=0.0, le=10.0)
    conditions_json: Dict[str, Any] = Field(..., alias="conditions")
    buyer_id: int = Field(..., gt=0)
    active: bool = True


class RuleUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    priority: Optional[int] = Field(None, ge=1, le=100)
    weight: Optional[float] = Field(None, gt=0.0, le=10.0)
    conditions_json: Optional[Dict[str, Any]] = Field(None, alias="conditions")
    buyer_id: Optional[int] = Field(None, gt=0)
    active: Optional[bool] = None


class RuleResponse(BaseModel):
    id: int
    org_id: int
    name: str
    priority: int
    weight: float
    conditions: Dict[str, Any]
    conditions_summary: str
    buyer_id: int
    active: bool
    created_at: str


class LeadStub(BaseModel):
    name: str = Field(..., min_length=1)
    email: str = Field(..., min_length=3)
    phone: Optional[str] = None


class MatchPreview(BaseModel):
    lead_data: LeadStub
    total_rules_evaluated: int
    matching_rules: List[Dict[str, Any]]
    recommendation: Optional[Dict[str, Any]]


class MatchResponse(BaseModel):
    success: bool
    match_log_id: int
    status: str
    buyer_id: Optional[int]
    rule_id: Optional[int]
    score: float
    message: str


def require_ops_admin():
    """Placeholder for ops/admin role requirement."""
    return "admin"


@router.get("/rules", response_model=List[RuleResponse])
async def list_matching_rules(
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """List all matching rules for the organization."""
    
    try:
        with get_session() as db:
            create_matching_tables()  # Ensure tables exist
            
            rules = db.query(MatchingRule).filter(
                MatchingRule.org_id == org_id
            ).order_by(MatchingRule.priority, MatchingRule.created_at).all()
            
            response = []
            for rule in rules:
                response.append(RuleResponse(
                    id=rule.id,
                    org_id=rule.org_id,
                    name=rule.name,
                    priority=rule.priority,
                    weight=rule.weight,
                    conditions=rule.conditions,
                    conditions_summary=rule.get_summary(),
                    buyer_id=rule.buyer_id,
                    active=rule.active,
                    created_at=rule.created_at.isoformat() if rule.created_at else ""
                ))
            
            logger.info(f"Listed {len(response)} matching rules for org {org_id}")
            return response
    
    except Exception as e:
        logger.error(f"Error listing matching rules: {e}")
        raise HTTPException(status_code=500, detail="Failed to list matching rules")


@router.post("/rules", response_model=RuleResponse)
async def create_matching_rule(
    rule_data: RuleCreate,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Create a new matching rule."""
    
    # Validate conditions
    validation_errors = validate_rule_conditions(rule_data.conditions_json)
    if validation_errors:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid conditions: {'; '.join(validation_errors)}"
        )
    
    try:
        with get_session() as db:
            create_matching_tables()
            
            # Check if buyer exists in this org
            from p02__server_models import Buyer
            buyer = db.query(Buyer).filter(
                Buyer.id == rule_data.buyer_id,
                Buyer.org_id == org_id
            ).first()
            
            if not buyer:
                raise HTTPException(
                    status_code=404, 
                    detail=f"Buyer {rule_data.buyer_id} not found in this organization"
                )
            
            # Create rule
            rule = MatchingRule(
                org_id=org_id,
                name=rule_data.name,
                priority=rule_data.priority,
                weight=rule_data.weight,
                conditions=rule_data.conditions_json,
                buyer_id=rule_data.buyer_id,
                active=rule_data.active
            )
            
            db.add(rule)
            db.commit()
            db.refresh(rule)
            
            # Audit the creation
            audit(
                kind="matching_rule_created",
                message=f"Matching rule '{rule.name}' created",
                meta={
                    "rule_id": rule.id,
                    "buyer_id": rule.buyer_id,
                    "org_id": org_id,
                    "actor": actor,
                    "conditions_summary": rule.get_summary()
                }
            )
            
            logger.info(f"Created matching rule {rule.id}: {rule.name}")
            
            return RuleResponse(
                id=rule.id,
                org_id=rule.org_id,
                name=rule.name,
                priority=rule.priority,
                weight=rule.weight,
                conditions=rule.conditions,
                conditions_summary=rule.get_summary(),
                buyer_id=rule.buyer_id,
                active=rule.active,
                created_at=rule.created_at.isoformat()
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating matching rule: {e}")
        raise HTTPException(status_code=500, detail="Failed to create matching rule")


@router.patch("/rules/{rule_id}", response_model=RuleResponse)
async def update_matching_rule(
    rule_id: int,
    rule_updates: RuleUpdate,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Update an existing matching rule."""
    
    # Validate conditions if provided
    if rule_updates.conditions_json is not None:
        validation_errors = validate_rule_conditions(rule_updates.conditions_json)
        if validation_errors:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid conditions: {'; '.join(validation_errors)}"
            )
    
    try:
        with get_session() as db:
            rule = db.query(MatchingRule).filter(
                MatchingRule.id == rule_id,
                MatchingRule.org_id == org_id
            ).first()
            
            if not rule:
                raise HTTPException(status_code=404, detail="Matching rule not found")
            
            # Track what changed
            changes = {}
            
            # Update fields
            if rule_updates.name is not None:
                changes["name"] = {"old": rule.name, "new": rule_updates.name}
                rule.name = rule_updates.name
            
            if rule_updates.priority is not None:
                changes["priority"] = {"old": rule.priority, "new": rule_updates.priority}
                rule.priority = rule_updates.priority
            
            if rule_updates.weight is not None:
                changes["weight"] = {"old": rule.weight, "new": rule_updates.weight}
                rule.weight = rule_updates.weight
            
            if rule_updates.conditions_json is not None:
                changes["conditions"] = {"old": rule.conditions, "new": rule_updates.conditions_json}
                rule.conditions = rule_updates.conditions_json
            
            if rule_updates.buyer_id is not None:
                # Verify buyer exists
                from p02__server_models import Buyer
                buyer = db.query(Buyer).filter(
                    Buyer.id == rule_updates.buyer_id,
                    Buyer.org_id == org_id
                ).first()
                
                if not buyer:
                    raise HTTPException(
                        status_code=404, 
                        detail=f"Buyer {rule_updates.buyer_id} not found in this organization"
                    )
                
                changes["buyer_id"] = {"old": rule.buyer_id, "new": rule_updates.buyer_id}
                rule.buyer_id = rule_updates.buyer_id
            
            if rule_updates.active is not None:
                changes["active"] = {"old": rule.active, "new": rule_updates.active}
                rule.active = rule_updates.active
            
            db.commit()
            db.refresh(rule)
            
            # Audit the update
            audit(
                kind="matching_rule_updated",
                message=f"Matching rule '{rule.name}' updated",
                meta={
                    "rule_id": rule.id,
                    "org_id": org_id,
                    "actor": actor,
                    "changes": changes
                }
            )
            
            logger.info(f"Updated matching rule {rule.id}: {rule.name}")
            
            return RuleResponse(
                id=rule.id,
                org_id=rule.org_id,
                name=rule.name,
                priority=rule.priority,
                weight=rule.weight,
                conditions=rule.conditions,
                conditions_summary=rule.get_summary(),
                buyer_id=rule.buyer_id,
                active=rule.active,
                created_at=rule.created_at.isoformat()
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating matching rule {rule_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to update matching rule")


@router.delete("/rules/{rule_id}")
async def delete_matching_rule(
    rule_id: int,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Delete a matching rule."""
    
    try:
        with get_session() as db:
            rule = db.query(MatchingRule).filter(
                MatchingRule.id == rule_id,
                MatchingRule.org_id == org_id
            ).first()
            
            if not rule:
                raise HTTPException(status_code=404, detail="Matching rule not found")
            
            rule_name = rule.name
            db.delete(rule)
            db.commit()
            
            # Audit the deletion
            audit(
                kind="matching_rule_deleted",
                message=f"Matching rule '{rule_name}' deleted",
                meta={
                    "rule_id": rule_id,
                    "org_id": org_id,
                    "actor": actor
                }
            )
            
            logger.info(f"Deleted matching rule {rule_id}: {rule_name}")
            
            return {"success": True, "message": f"Matching rule '{rule_name}' deleted"}
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting matching rule {rule_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete matching rule")


@router.post("/test", response_model=MatchPreview)
async def test_matching(
    lead_stub: LeadStub,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Preview matching results for a sample lead without saving."""
    
    try:
        preview_result = preview_match(lead_stub.dict(), org_id)
        
        return MatchPreview(
            lead_data=lead_stub,
            total_rules_evaluated=preview_result["total_rules_evaluated"],
            matching_rules=preview_result["matching_rules"],
            recommendation=preview_result["recommendation"]
        )
    
    except Exception as e:
        logger.error(f"Error testing match: {e}")
        raise HTTPException(status_code=500, detail="Failed to test matching")


@router.post("/assign/{lead_id}", response_model=MatchResponse)
async def assign_lead_to_buyer(
    lead_id: int,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Execute matching for a specific lead and record the result."""
    
    try:
        match_log = match_and_record(lead_id, org_id)
        
        if not match_log:
            raise HTTPException(status_code=404, detail="Lead not found")
        
        return MatchResponse(
            success=match_log.status in ["matched", "no_match"],
            match_log_id=match_log.id,
            status=match_log.status,
            buyer_id=match_log.buyer_id,
            rule_id=match_log.rule_id,
            score=match_log.score,
            message=match_log.get_status_display()
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error assigning lead {lead_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to assign lead")


@router.get("/logs")
async def get_matching_logs(
    request: Request,
    lead_id: Optional[int] = None,
    buyer_id: Optional[int] = None,
    limit: int = 50,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Get matching logs with optional filtering."""
    
    try:
        logs = get_match_history(lead_id, buyer_id, org_id, min(limit, 100))
        
        response = []
        for log in logs:
            response.append({
                "id": log.id,
                "lead_id": log.lead_id,
                "buyer_id": log.buyer_id,
                "rule_id": log.rule_id,
                "score": log.score,
                "status": log.status,
                "status_display": log.get_status_display(),
                "created_at": log.created_at.isoformat() if log.created_at else None,
                "metadata": log.metadata
            })
        
        return {
            "logs": response,
            "total": len(response),
            "filters": {
                "lead_id": lead_id,
                "buyer_id": buyer_id,
                "org_id": org_id
            }
        }
    
    except Exception as e:
        logger.error(f"Error getting matching logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to get matching logs")
