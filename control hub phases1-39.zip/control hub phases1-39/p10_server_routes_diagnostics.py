"""
Lead Engine Control Hub - Diagnostics Routes
Phase: 10
Purpose: System diagnostics and health check endpoints
Key Responsibilities:
- Comprehensive system diagnostics API
- Quick health check endpoints
- Component-specific diagnostic endpoints
- Performance monitoring and metrics
"""

import logging

from fastapi import APIRouter, HTTPException

# Import diagnostics service
try:
    from p10__server_services_diagnostics import run_full_diagnostics, run_quick_health_check, DiagnosticsService
except ImportError as e:
    logging.warning(f"Import error in diagnostics routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure Phase 10 diagnostics service is available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/diagnostics", tags=["diagnostics"])

# =============================================================================
# COMPREHENSIVE DIAGNOSTICS ENDPOINTS
# =============================================================================

@router.get("/")
async def get_full_diagnostics():
    """
    Run complete diagnostic suite and return comprehensive report.
    
    Returns:
        JSON object with full diagnostic results
        
    Response format:
        {
            "status": "ok|warning|error",
            "runtime_ms": <float>,
            "app_info": {...},
            "components": {
                "database": {"status", "message", ...},
                "queue": {"status", "message", ...},
                "providers": {"status", "message", "providers": {...}},
                "templates": {"status", "message", "missing": [...]}
            },
            "system_info": {...},
            "timestamp": "..."
        }
    """
    try:
        logger.info("GET /diagnostics - running full diagnostic suite")
        
        # Run comprehensive diagnostics
        result = run_full_diagnostics()
        
        logger.info(f"Diagnostics completed with status: {result.get('status', 'unknown')}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to run diagnostics: {e}")
        raise HTTPException(status_code=500, detail=f"Diagnostics failed: {str(e)}")

@router.get("/quick")
async def get_quick_health_check():
    """
    Run abbreviated health check for essential components.
    
    Returns:
        JSON object with quick health status
    """
    try:
        logger.info("GET /diagnostics/quick - running quick health check")
        
        # Run quick health check
        result = run_quick_health_check()
        
        logger.info(f"Quick health check completed: {result.get('status', 'unknown')}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to run quick health check: {e}")
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")

# =============================================================================
# COMPONENT-SPECIFIC DIAGNOSTIC ENDPOINTS
# =============================================================================

@router.get("/database")
async def get_database_diagnostics():
    """
    Run database-specific diagnostics.
    
    Returns:
        JSON object with database diagnostic results
    """
    try:
        logger.info("GET /diagnostics/database - checking database health")
        
        diagnostics = DiagnosticsService()
        result = diagnostics.check_db_connection()
        
        logger.info(f"Database diagnostics: {result.get('status', 'unknown')}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to run database diagnostics: {e}")
        raise HTTPException(status_code=500, detail=f"Database diagnostics failed: {str(e)}")

@router.get("/queue")
async def get_queue_diagnostics():
    """
    Run job queue diagnostics.
    
    Returns:
        JSON object with queue diagnostic results
    """
    try:
        logger.info("GET /diagnostics/queue - checking queue service health")
        
        diagnostics = DiagnosticsService()
        result = diagnostics.check_queue_service()
        
        logger.info(f"Queue diagnostics: {result.get('status', 'unknown')}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to run queue diagnostics: {e}")
        raise HTTPException(status_code=500, detail=f"Queue diagnostics failed: {str(e)}")

@router.get("/providers")
async def get_providers_diagnostics():
    """
    Run provider mock diagnostics.
    
    Returns:
        JSON object with provider diagnostic results
    """
    try:
        logger.info("GET /diagnostics/providers - checking provider mocks")
        
        diagnostics = DiagnosticsService()
        result = diagnostics.check_provider_mocks()
        
        logger.info(f"Provider diagnostics: {result.get('status', 'unknown')}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to run provider diagnostics: {e}")
        raise HTTPException(status_code=500, detail=f"Provider diagnostics failed: {str(e)}")

@router.get("/templates")
async def get_templates_diagnostics():
    """
    Run template availability diagnostics.
    
    Returns:
        JSON object with template diagnostic results
    """
    try:
        logger.info("GET /diagnostics/templates - checking template availability")
        
        diagnostics = DiagnosticsService()
        result = diagnostics.check_templates()
        
        logger.info(f"Template diagnostics: {result.get('status', 'unknown')}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to run template diagnostics: {e}")
        raise HTTPException(status_code=500, detail=f"Template diagnostics failed: {str(e)}")

# =============================================================================
# SYSTEM INFORMATION ENDPOINTS
# =============================================================================

@router.get("/system")
async def get_system_info():
    """
    Get system information and environment details.
    
    Returns:
        JSON object with system information
    """
    try:
        logger.info("GET /diagnostics/system - retrieving system information")
        
        diagnostics = DiagnosticsService()
        app_info = diagnostics._get_app_info()
        system_info = diagnostics._get_system_info()
        
        result = {
            "app_info": app_info,
            "system_info": system_info,
            "status": "ok"
        }
        
        return result
        
    except Exception as e:
        logger.error(f"Failed to get system info: {e}")
        raise HTTPException(status_code=500, detail=f"System info failed: {str(e)}")

@router.get("/performance")
async def get_performance_metrics():
    """
    Get performance metrics and timing information.
    
    Returns:
        JSON object with performance metrics
    """
    try:
        logger.info("GET /diagnostics/performance - collecting performance metrics")
        
        import time
        start_time = time.time()
        
        # Run quick diagnostics to measure performance
        quick_result = run_quick_health_check()
        
        # Measure individual component response times
        diagnostics = DiagnosticsService()
        
        db_start = time.time()
        db_result = diagnostics.check_db_connection()
        db_time = (time.time() - db_start) * 1000
        
        queue_start = time.time()
        queue_result = diagnostics.check_queue_service()
        queue_time = (time.time() - queue_start) * 1000
        
        total_time = (time.time() - start_time) * 1000
        
        performance_metrics = {
            "total_runtime_ms": round(total_time, 2),
            "component_timings": {
                "database_ms": round(db_time, 2),
                "queue_ms": round(queue_time, 2)
            },
            "component_status": {
                "database": db_result.get("status", "unknown"),
                "queue": queue_result.get("status", "unknown")
            },
            "performance_rating": "excellent" if total_time < 100 else "good" if total_time < 500 else "slow",
            "baseline_metrics": {
                "quick_health_check_ms": quick_result.get("runtime_ms", 0),
                "target_response_time_ms": 100,
                "acceptable_response_time_ms": 500
            },
            "timestamp": quick_result.get("timestamp")
        }
        
        logger.info(f"Performance metrics collected in {total_time:.2f}ms")
        return performance_metrics
        
    except Exception as e:
        logger.error(f"Failed to get performance metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Performance metrics failed: {str(e)}")

# =============================================================================
# DIAGNOSTIC UTILITIES ENDPOINTS
# =============================================================================

@router.get("/status")
async def get_diagnostic_status():
    """
    Get overall diagnostic system status.
    
    Returns:
        JSON object with diagnostic system status
    """
    try:
        logger.info("GET /diagnostics/status - checking diagnostic system status")
        
        # Test that diagnostics system itself is working
        test_result = run_quick_health_check()
        
        status = {
            "diagnostics_available": True,
            "last_check_status": test_result.get("status", "unknown"),
            "last_check_runtime_ms": test_result.get("runtime_ms", 0),
            "available_endpoints": [
                "/diagnostics",
                "/diagnostics/quick",
                "/diagnostics/database",
                "/diagnostics/queue",
                "/diagnostics/providers",
                "/diagnostics/templates",
                "/diagnostics/system",
                "/diagnostics/performance"
            ],
            "system_health": test_result.get("status", "unknown"),
            "timestamp": test_result.get("timestamp")
        }
        
        return status
        
    except Exception as e:
        logger.error(f"Failed to get diagnostic status: {e}")
        return {
            "diagnostics_available": False,
            "error": str(e),
            "system_health": "error"
        }

@router.get("/summary")
async def get_diagnostics_summary():
    """
    Get summarized diagnostic information for dashboard display.
    
    Returns:
        JSON object with diagnostic summary
    """
    try:
        logger.info("GET /diagnostics/summary - generating diagnostic summary")
        
        # Run quick diagnostics for summary
        quick_result = run_quick_health_check()
        
        # Get component counts
        diagnostics = DiagnosticsService()
        
        # Quick component checks
        db_status = quick_result.get("components", {}).get("database", "unknown")
        queue_status = quick_result.get("components", {}).get("queue", "unknown")
        
        # Count healthy components
        component_statuses = [db_status, queue_status]
        healthy_count = sum(1 for status in component_statuses if status == "ok")
        total_count = len(component_statuses)
        
        summary = {
            "overall_status": quick_result.get("status", "unknown"),
            "healthy_components": healthy_count,
            "total_components": total_count,
            "health_percentage": round((healthy_count / total_count) * 100, 1) if total_count > 0 else 0,
            "last_check_ms": quick_result.get("runtime_ms", 0),
            "components": {
                "database": db_status,
                "queue": queue_status
            },
            "issues_detected": healthy_count < total_count,
            "timestamp": quick_result.get("timestamp")
        }
        
        return summary
        
    except Exception as e:
        logger.error(f"Failed to generate diagnostics summary: {e}")
        return {
            "overall_status": "error",
            "error": str(e),
            "healthy_components": 0,
            "total_components": 0,
            "health_percentage": 0.0
        }

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Diagnostics Routes Module Test ===")
    logger.info("✅ Diagnostics routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET  /diagnostics              - Complete diagnostic suite")
    logger.info("  GET  /diagnostics/quick         - Quick health check")
    logger.info("  GET  /diagnostics/database      - Database diagnostics")
    logger.info("  GET  /diagnostics/queue         - Queue service diagnostics")
    logger.info("  GET  /diagnostics/providers     - Provider mock diagnostics")
    logger.info("  GET  /diagnostics/templates     - Template availability check")
    logger.info("  GET  /diagnostics/system        - System information")
    logger.info("  GET  /diagnostics/performance   - Performance metrics")
    logger.info("  GET  /diagnostics/status        - Diagnostic system status")
    logger.info("  GET  /diagnostics/summary       - Diagnostic summary")
    logger.info("")
    logger.info("Integration notes:")
    logger.info("- Add 'from p10__server_routes_diagnostics import router as diagnostics_router' to main app")
    logger.info("- Add 'app.include_router(diagnostics_router)' to wire in the endpoints")
    logger.info("- Diagnostics check DB, queue, providers, templates, and system health")
    logger.info("- Performance metrics include component timing and health ratings")