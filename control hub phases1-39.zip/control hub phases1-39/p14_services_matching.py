"""
Lead-buyer matching service for automated sales assignment.

Phase: 14
Purpose: Service layer for matching leads to buyers based on rules
Key responsibilities: match_lead function and create_sale transaction handling
"""

import logging
from typing import Optional, Dict, Any, Tuple
from datetime import datetime

# Import attempt with graceful fallback
try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer  # Assuming these exist from Phase 2
    from p14__server_models_sales import LeadSale
    from p14__server_models_buyer_rules import BuyerRule
except ImportError as e:
    logging.warning(f"Import issue in matching service: {e}")
    # Fallback for development
    def get_session():
        return None
    class Lead:
        def __init__(self):
            self.id = 1
            self.email = "test@example.com"
    class Buyer:
        def __init__(self):
            self.id = 1
            self.name = "Test Buyer"
    class LeadSale:
        pass
    class BuyerRule:
        pass

logger = logging.getLogger(__name__)

def match_lead(lead: Lead) -> Optional[Tuple[Buyer, int]]:
    """
    Find the best buyer match for a lead based on active rules.
    
    Args:
        lead: Lead object to match
        
    Returns:
        Tuple of (buyer, price_cents) if match found, None otherwise
    """
    logger.info(f"Matching lead {lead.id} (email: {lead.email})")
    
    with get_session() as session:
        # Get all active buyer rules, ordered by buyer_id for deterministic results
        rules = session.query(BuyerRule).filter(
            BuyerRule.active == True
        ).order_by(BuyerRule.buyer_id).all()
        
        logger.debug(f"Checking {len(rules)} active buyer rules")
        
        # Check each rule to see if it matches the lead
        for rule in rules:
            if rule.matches_lead(lead.email):
                # Get the buyer for this rule
                buyer = session.query(Buyer).filter(Buyer.id == rule.buyer_id).first()
                if not buyer:
                    logger.warning(f"Buyer {rule.buyer_id} not found for rule {rule.id}")
                    continue
                
                # Check if this lead was already sold to this buyer (prevent duplicates)
                existing_sale = session.query(LeadSale).filter(
                    LeadSale.lead_id == lead.id,
                    LeadSale.buyer_id == buyer.id,
                    LeadSale.status.in_(["created", "delivered"])  # Don't count refunded sales
                ).first()
                
                if existing_sale:
                    logger.info(f"Lead {lead.id} already sold to buyer {buyer.id}, skipping")
                    continue
                
                # Calculate price based on rule
                price_cents = rule.get_effective_price(default_price_cents=1000)
                
                logger.info(f"Matched lead {lead.id} to buyer {buyer.id} (price: ${price_cents/100:.2f})")
                return buyer, price_cents
        
        logger.info(f"No matching buyer found for lead {lead.id}")
        return None

def create_sale(lead: Lead, buyer: Buyer, price_cents: int) -> LeadSale:
    """
    Create a new sale record for a lead-buyer assignment.
    
    Args:
        lead: Lead being sold
        buyer: Buyer purchasing the lead
        price_cents: Price in cents
        
    Returns:
        Created LeadSale object
    """
    logger.info(f"Creating sale: lead {lead.id} to buyer {buyer.id} for ${price_cents/100:.2f}")
    
    with get_session() as session:
        # Double-check for existing sale to prevent duplicates
        existing_sale = session.query(LeadSale).filter(
            LeadSale.lead_id == lead.id,
            LeadSale.buyer_id == buyer.id,
            LeadSale.status.in_(["created", "delivered"])
        ).first()
        
        if existing_sale:
            logger.warning(f"Sale already exists: {existing_sale.id}")
            return existing_sale
        
        # Create new sale
        sale = LeadSale(
            lead_id=lead.id,
            buyer_id=buyer.id,
            price_cents=price_cents,
            status="created"
        )
        
        session.add(sale)
        session.commit()
        
        sale_id = sale.id
        logger.info(f"Sale created with ID: {sale_id}")
        
        return sale

def get_sale_preview(lead_id: int) -> Optional[Dict[str, Any]]:
    """
    Preview what buyer and price a lead would match to without creating a sale.
    
    Args:
        lead_id: ID of lead to preview
        
    Returns:
        Dict with buyer info and price, or None if no match
    """
    logger.info(f"Getting sale preview for lead {lead_id}")
    
    with get_session() as session:
        lead = session.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            logger.warning(f"Lead {lead_id} not found")
            return None
        
        match_result = match_lead(lead)
        if not match_result:
            return None
            
        buyer, price_cents = match_result
        
        return {
            "lead_id": lead.id,
            "lead_email": lead.email,
            "buyer_id": buyer.id,
            "buyer_name": buyer.name,
            "price_cents": price_cents,
            "price_dollars": price_cents / 100.0
        }

def get_sales_summary() -> Dict[str, Any]:
    """
    Get summary statistics for sales.
    
    Returns:
        Dict with sales counts and totals
    """
    logger.info("Getting sales summary")
    
    with get_session() as session:
        total_sales = session.query(LeadSale).count()
        created_sales = session.query(LeadSale).filter(LeadSale.status == "created").count()
        delivered_sales = session.query(LeadSale).filter(LeadSale.status == "delivered").count()
        refunded_sales = session.query(LeadSale).filter(LeadSale.status == "refunded").count()
        
        # Calculate total revenue (excluding refunded)
        revenue_result = session.query(
            session.query(LeadSale.price_cents).filter(
                LeadSale.status.in_(["created", "delivered"])
            ).subquery()
        ).scalar()
        
        total_revenue_cents = revenue_result or 0
        
        summary = {
            "total_sales": total_sales,
            "created_sales": created_sales,
            "delivered_sales": delivered_sales,
            "refunded_sales": refunded_sales,
            "total_revenue_cents": total_revenue_cents,
            "total_revenue_dollars": total_revenue_cents / 100.0
        }
        
        logger.info(f"Sales summary: {summary}")
        return summary

# Log service initialization
logger.info("Matching service initialized with functions: match_lead, create_sale, get_sale_preview, get_sales_summary")
