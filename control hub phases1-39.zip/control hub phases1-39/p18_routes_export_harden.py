"""
Hardened Export Routes with Enhanced Security
Phase 18: Add security headers and admin token requirements to exports
Key responsibilities: Secure file downloads, proper headers, rate limiting integration
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, Response
from fastapi.responses import StreamingResponse
import csv
import json
import io
from datetime import datetime

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer
    from p08__server_services_audit import audit
except ImportError:
    logger.warning("Required modules not found - using mock implementations")
    def get_session():
        return None
    
    class Lead:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    
    class Buyer:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    
    def audit(kind, message, meta=None):
        logger.info(f"AUDIT: {kind} - {message}")

router = APIRouter(prefix="/export", tags=["export"])

def require_admin_token(admin_token: str = None):
    """Require admin token for all export operations"""
    if not admin_token or admin_token != "change-me":
        raise HTTPException(status_code=403, detail="Admin token required for exports")
    return True

def add_security_headers(response: Response, filename: str):
    """Add security headers to export responses"""
    response.headers["X-Download-Filename"] = filename
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"

@router.get("/leads.csv")
async def export_leads_csv(_: bool = Depends(require_admin_token)):
    """
    Export leads as CSV with security headers
    Requires admin token for access
    """
    try:
        session = get_session()
        leads_data = []
        
        if session:
            with session:
                leads = session.query(Lead).all()
                leads_data = [
                    {
                        "id": lead.id,
                        "name": lead.name,
                        "email": lead.email,
                        "phone": getattr(lead, 'phone', ''),
                        "created_at": lead.created_at.isoformat() if hasattr(lead, 'created_at') else datetime.utcnow().isoformat()
                    }
                    for lead in leads
                ]
        else:
            # Mock data for testing
            logger.warning("Using mock leads data")
            leads_data = [
                {
                    "id": 1,
                    "name": "Sample Lead",
                    "email": "sample@example.com",
                    "phone": "555-0123",
                    "created_at": datetime.utcnow().isoformat()
                }
            ]
        
        # Generate CSV
        output = io.StringIO()
        if leads_data:
            fieldnames = ["id", "name", "email", "phone", "created_at"]
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(leads_data)
        
        csv_content = output.getvalue()
        
        # Audit the export
        audit(
            kind="leads_exported",
            message=f"Leads exported as CSV",
            meta={"format": "csv", "count": len(leads_data)}
        )
        
        logger.info(f"Exported {len(leads_data)} leads as CSV")
        
        # Create streaming response with security headers
        response = StreamingResponse(
            io.StringIO(csv_content),
            media_type="text/csv",
            headers={
                "X-Download-Filename": f"leads-{datetime.now().strftime('%Y%m%d')}.csv",
                "Content-Disposition": f'attachment; filename="leads-{datetime.now().strftime('%Y%m%d')}.csv"',
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error exporting leads CSV: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

@router.get("/leads.json")
async def export_leads_json(_: bool = Depends(require_admin_token)):
    """
    Export leads as JSON with security headers
    Requires admin token for access
    """
    try:
        session = get_session()
        leads_data = []
        
        if session:
            with session:
                leads = session.query(Lead).all()
                leads_data = [
                    {
                        "id": lead.id,
                        "name": lead.name,
                        "email": lead.email,
                        "phone": getattr(lead, 'phone', ''),
                        "created_at": lead.created_at.isoformat() if hasattr(lead, 'created_at') else datetime.utcnow().isoformat()
                    }
                    for lead in leads
                ]
        else:
            logger.warning("Using mock leads data")
            leads_data = [
                {
                    "id": 1,
                    "name": "Sample Lead",
                    "email": "sample@example.com",
                    "phone": "555-0123",
                    "created_at": datetime.utcnow().isoformat()
                }
            ]
        
        # Generate JSON
        json_content = json.dumps(leads_data, indent=2)
        
        # Audit the export
        audit(
            kind="leads_exported",
            message=f"Leads exported as JSON",
            meta={"format": "json", "count": len(leads_data)}
        )
        
        logger.info(f"Exported {len(leads_data)} leads as JSON")
        
        # Create streaming response with security headers
        response = StreamingResponse(
            io.StringIO(json_content),
            media_type="application/json",
            headers={
                "X-Download-Filename": f"leads-{datetime.now().strftime('%Y%m%d')}.json",
                "Content-Disposition": f'attachment; filename="leads-{datetime.now().strftime('%Y%m%d')}.json"',
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error exporting leads JSON: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

@router.get("/buyers.csv")
async def export_buyers_csv(_: bool = Depends(require_admin_token)):
    """
    Export buyers as CSV with security headers
    Requires admin token for access
    """
    try:
        session = get_session()
        buyers_data = []
        
        if session:
            with session:
                buyers = session.query(Buyer).all()
                buyers_data = [
                    {
                        "id": buyer.id,
                        "name": buyer.name,
                        "email": buyer.email,
                        "created_at": buyer.created_at.isoformat() if hasattr(buyer, 'created_at') else datetime.utcnow().isoformat()
                    }
                    for buyer in buyers
                ]
        else:
            logger.warning("Using mock buyers data")
            buyers_data = [
                {
                    "id": 1,
                    "name": "Sample Buyer",
                    "email": "buyer@example.com",
                    "created_at": datetime.utcnow().isoformat()
                }
            ]
        
        # Generate CSV
        output = io.StringIO()
        if buyers_data:
            fieldnames = ["id", "name", "email", "created_at"]
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(buyers_data)
        
        csv_content = output.getvalue()
        
        # Audit the export
        audit(
            kind="buyers_exported",
            message=f"Buyers exported as CSV",
            meta={"format": "csv", "count": len(buyers_data)}
        )
        
        logger.info(f"Exported {len(buyers_data)} buyers as CSV")
        
        # Create streaming response with security headers
        response = StreamingResponse(
            io.StringIO(csv_content),
            media_type="text/csv",
            headers={
                "X-Download-Filename": f"buyers-{datetime.now().strftime('%Y%m%d')}.csv",
                "Content-Disposition": f'attachment; filename="buyers-{datetime.now().strftime('%Y%m%d')}.csv"',
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error exporting buyers CSV: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")
