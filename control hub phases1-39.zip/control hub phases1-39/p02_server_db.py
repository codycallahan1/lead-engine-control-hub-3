"""
Lead Engine Control Hub - Database Configuration
Phase: 2
Purpose: SQLite database setup with SQLAlchemy engine, Base, sessionmaker, and context manager
Key Responsibilities:
- Create SQLite database connection
- Provide Base class for models
- Session management with context manager
- Database initialization utilities
"""

import logging
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

# Configure logging
logger = logging.getLogger(__name__)

# Database configuration
DATABASE_PATH = "./controlhub.db"  # SQLite file in current working directory
DATABASE_URL = f"sqlite:///{DATABASE_PATH}"

# Create SQLAlchemy engine
# Note: check_same_thread=False allows SQLAlchemy to work with SQLite in multi-threaded FastAPI
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False  # Set to True for SQL debugging
)

# Create SessionLocal class
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Create Base class for models
Base = declarative_base()

@contextmanager
def get_session() -> Generator[Session, None, None]:
    """
    Context manager for database sessions.
    Ensures proper session cleanup and rollback on errors.
    
    Usage:
        with get_session() as db:
            # database operations
            pass
    """
    db = SessionLocal()
    try:
        logger.debug("Database session created")
        yield db
        db.commit()
        logger.debug("Database session committed")
    except Exception as e:
        logger.error(f"Database session error: {e}")
        db.rollback()
        raise
    finally:
        db.close()
        logger.debug("Database session closed")

def create_all_tables():
    """
    Bootstrap utility to create all database tables.
    Should be called during application startup.
    
    This function creates all tables defined by SQLAlchemy models
    that inherit from Base.
    """
    try:
        logger.info("Creating database tables...")
        Base.metadata.create_all(bind=engine)
        
        # Log database file info
        db_file = Path(DATABASE_PATH)
        if db_file.exists():
            size = db_file.stat().st_size
            logger.info(f"Database file created/updated: {DATABASE_PATH} ({size} bytes)")
        else:
            logger.warning(f"Database file not found after creation: {DATABASE_PATH}")
            
        logger.info("Database tables created successfully")
        
    except Exception as e:
        logger.error(f"Failed to create database tables: {e}")
        raise

def get_db_info():
    """
    Get database connection information for diagnostics.
    Returns dict with database details.
    """
    db_file = Path(DATABASE_PATH)
    
    info = {
        "database_url": DATABASE_URL,
        "database_path": str(db_file.absolute()),
        "file_exists": db_file.exists(),
        "file_size": db_file.stat().st_size if db_file.exists() else 0,
        "engine_info": str(engine.url)
    }
    
    return info

def test_connection():
    """
    Test database connection by executing a simple query.
    Returns True if connection successful, False otherwise.
    """
    try:
        with get_session() as db:
            # Test connection with a simple query
            result = db.execute("SELECT 1").fetchone()
            logger.info("Database connection test successful")
            return True
    except Exception as e:
        logger.error(f"Database connection test failed: {e}")
        return False

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Database Module Test ===")
    logger.info(f"Database URL: {DATABASE_URL}")
    
    # Test connection
    if test_connection():
        logger.info("✅ Database connection working")
    else:
        logger.error("❌ Database connection failed")
    
    # Create tables (will be empty until models are imported)
    create_all_tables()
    
    # Show database info
    info = get_db_info()
    logger.info(f"Database info: {info}")
