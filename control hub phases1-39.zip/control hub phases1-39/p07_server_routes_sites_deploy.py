"""
Lead Engine Control Hub - Site Deployment Routes
Phase: 7
Purpose: Handle site deployment triggering via API endpoints
Key Responsibilities:
- POST endpoint to trigger site deployments
- Verify site exists before deployment
- Create deployment record and enqueue job
- Return deployment and job tracking information
"""

import logging

from fastapi import APIRouter, HTTPException

# Import services
try:
    from p06__server_services_sites import SiteService
    from p07__server_services_builder import trigger_deployment
    from p07__server_services_queue import get_queue_stats
except ImportError as e:
    logging.warning(f"Import error in site deploy routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 6 and 7 files are available")

logger = logging.getLogger(__name__)

# Initialize router - note this extends the sites router
router = APIRouter(prefix="/sites", tags=["sites", "deployments"])

# =============================================================================
# DEPLOYMENT TRIGGER ENDPOINTS
# =============================================================================

@router.post("/{site_id}/deploy")
async def deploy_site(site_id: int):
    """
    Trigger deployment for a specific site.
    
    Steps:
    1. Verify site exists
    2. Create deployment record (pending status)
    3. Enqueue deployment job
    4. Return deployment and job information
    
    Args:
        site_id: ID of the site to deploy
        
    Returns:
        JSON response with deployment and job tracking info
        
    Raises:
        404: If site not found
        500: If deployment trigger fails
    """
    try:
        logger.info(f"POST /sites/{site_id}/deploy - triggering deployment")
        
        # Step 1: Verify site exists
        site = SiteService.get_site_by_id(site_id)
        if not site:
            logger.warning(f"Site not found for deployment: {site_id}")
            raise HTTPException(status_code=404, detail="Site not found")
        
        logger.info(f"Triggering deployment for site: {site.name} ({site.domain})")
        
        # Steps 2-3: Create deployment and enqueue job
        deployment_info = trigger_deployment(site_id)
        
        # Step 4: Return success response
        response = {
            "success": True,
            "site_id": site_id,
            "site_name": site.name,
            "site_domain": site.domain,
            "deployment_id": deployment_info["deployment_id"],
            "job_id": deployment_info["job_id"],
            "status": deployment_info["status"],
            "message": f"Deployment triggered for {site.name}"
        }
        
        logger.info(f"Deployment triggered successfully: deployment {deployment_info['deployment_id']}, job {deployment_info['job_id']}")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to trigger deployment for site {site_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to trigger deployment: {str(e)}")

@router.get("/{site_id}/deployments")
async def get_site_deployments(site_id: int, limit: int = 20):
    """
    Get deployment history for a specific site.
    
    Args:
        site_id: ID of the site
        limit: Maximum number of deployments to return
        
    Returns:
        List of deployments for the site
        
    Raises:
        404: If site not found
    """
    try:
        logger.info(f"GET /sites/{site_id}/deployments - fetching deployment history")
        
        # Verify site exists
        site = SiteService.get_site_by_id(site_id)
        if not site:
            logger.warning(f"Site not found: {site_id}")
            raise HTTPException(status_code=404, detail="Site not found")
        
        # Get deployments for this site
        from p02__server_db import get_session
        from p06__server_models_deployments import Deployment
        
        with get_session() as db:
            deployments = db.query(Deployment).filter(
                Deployment.site_id == site_id
            ).order_by(Deployment.created_at.desc()).limit(limit).all()
            
            deployment_list = []
            for deployment in deployments:
                deployment_dict = deployment.to_dict()
                deployment_dict.update({
                    "site_name": site.name,
                    "site_domain": site.domain,
                    "site_status": site.status
                })
                deployment_list.append(deployment_dict)
        
        logger.info(f"Retrieved {len(deployment_list)} deployments for site {site_id}")
        return deployment_list
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get deployments for site {site_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/{site_id}/deploy/status")
async def get_site_deployment_status(site_id: int):
    """
    Get current deployment status for a site.
    
    Args:
        site_id: ID of the site
        
    Returns:
        JSON with current deployment status information
        
    Raises:
        404: If site not found
    """
    try:
        logger.info(f"GET /sites/{site_id}/deploy/status - checking deployment status")
        
        # Verify site exists
        site = SiteService.get_site_by_id(site_id)
        if not site:
            raise HTTPException(status_code=404, detail="Site not found")
        
        # Get latest deployment for this site
        from p02__server_db import get_session
        from p06__server_models_deployments import Deployment
        
        with get_session() as db:
            latest_deployment = db.query(Deployment).filter(
                Deployment.site_id == site_id
            ).order_by(Deployment.created_at.desc()).first()
        
        if not latest_deployment:
            return {
                "site_id": site_id,
                "site_name": site.name,
                "site_domain": site.domain,
                "has_deployments": False,
                "latest_deployment": None,
                "can_deploy": True
            }
        
        # Check if deployment is currently running
        can_deploy = latest_deployment.status not in ["running", "pending"]
        
        status_info = {
            "site_id": site_id,
            "site_name": site.name,
            "site_domain": site.domain,
            "has_deployments": True,
            "latest_deployment": latest_deployment.to_dict(),
            "can_deploy": can_deploy,
            "deployment_in_progress": latest_deployment.status in ["running", "pending"]
        }
        
        logger.info(f"Deployment status for site {site_id}: can_deploy={can_deploy}")
        return status_info
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get deployment status for site {site_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# =============================================================================
# QUEUE STATUS ENDPOINTS
# =============================================================================

@router.get("/queue/status")
async def get_deployment_queue_status():
    """
    Get deployment queue status and statistics.
    
    Returns:
        JSON with queue statistics and worker status
    """
    try:
        logger.info("GET /sites/queue/status - fetching queue status")
        
        queue_stats = get_queue_stats()
        
        # Add deployment-specific information
        deployment_stats = {
            "queue_stats": queue_stats,
            "deployment_handler_registered": "deployment" in queue_stats.get("registered_handlers", []),
            "worker_healthy": queue_stats.get("worker_running", False) and queue_stats.get("worker_thread_alive", False)
        }
        
        logger.info(f"Queue status: {deployment_stats}")
        return deployment_stats
        
    except Exception as e:
        logger.error(f"Failed to get queue status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Site Deploy Routes Module Test ===")
    logger.info("✅ Site deploy routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  POST /sites/{id}/deploy           - Trigger site deployment")
    logger.info("  GET  /sites/{id}/deployments      - Get site deployment history")
    logger.info("  GET  /sites/{id}/deploy/status    - Get site deployment status")
    logger.info("  GET  /sites/queue/status          - Get deployment queue status")
    logger.info("")
    logger.info("Integration notes:")
    logger.info("- Add 'from p07__server_routes_sites_deploy import router as sites_deploy_router' to main app")
    logger.info("- Add 'app.include_router(sites_deploy_router)' to wire in the endpoints")
    logger.info("- Ensure deployment queue is initialized with init_queue() on startup")