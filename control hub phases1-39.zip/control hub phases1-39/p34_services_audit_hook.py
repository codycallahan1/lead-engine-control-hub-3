"""
Lead Engine Control Hub - Audit Hook for Compliance
Phase 34: Consent flags and PII redaction utilities
Purpose: Integration wrapper for audit service with automatic PII redaction
"""

import logging
from typing import Dict, Any, Optional

# Import redaction service and original audit
try:
    from p34__server_services_redaction import apply_redaction_policy, get_compliance_policy
    from p08__server_services_audit import audit as original_audit
except ImportError:
    # Fallback for development
    def apply_redaction_policy(data, org_id, context="log"):
        return data
    
    def get_compliance_policy(org_id):
        class MockPolicy:
            log_pii_access = True
        return MockPolicy()
    
    def original_audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")

logger = logging.getLogger(__name__)


def audit_with_redaction(kind: str, message: str, meta: Optional[Dict[str, Any]] = None, 
                        org_id: Optional[int] = None, redact: bool = True) -> None:
    """
    Enhanced audit function that applies PII redaction based on org policy.
    
    This wrapper function applies the organization's compliance policy
    to audit log entries, redacting sensitive information when required.
    
    Args:
        kind: Type of audit event
        message: Human-readable audit message
        meta: Additional metadata (may contain PII)
        org_id: Organization ID for policy lookup
        redact: Whether to apply redaction (can be disabled for system events)
    """
    try:
        # Start with original metadata
        audit_meta = meta.copy() if meta else {}
        
        # Apply redaction if org_id provided and redaction enabled
        if redact and org_id and audit_meta:
            policy = get_compliance_policy(org_id)
            
            # Only redact if logging PII access is enabled (indicates they want audit protection)
            if policy.log_pii_access:
                audit_meta = apply_redaction_policy(audit_meta, org_id, context="log")
                
                # Add a flag to indicate redaction was applied
                audit_meta["_redacted"] = True
                audit_meta["_redaction_policy"] = {
                    "mask_email": policy.mask_email,
                    "mask_phone": policy.mask_phone
                }
        
        # Add org_id to metadata if not already present
        if org_id and "org_id" not in audit_meta:
            audit_meta["org_id"] = org_id
        
        # Call original audit function with potentially redacted data
        original_audit(kind, message, audit_meta)
        
    except Exception as e:
        # If redaction fails, log the error but still audit the event
        logger.error(f"Failed to apply audit redaction: {str(e)}")
        
        # Fall back to original audit with a warning in metadata
        fallback_meta = (meta or {}).copy()
        fallback_meta["_audit_redaction_error"] = str(e)
        if org_id:
            fallback_meta["org_id"] = org_id
            
        original_audit(kind, message, fallback_meta)


def audit_pii_access(activity: str, lead_id: Optional[int] = None, user_id: Optional[str] = None,
                    org_id: Optional[int] = None, endpoint: Optional[str] = None,
                    data_categories: Optional[list] = None) -> None:
    """
    Specialized audit function for PII access events.
    
    Records when personally identifiable information is accessed,
    including context about the access for compliance reporting.
    
    Args:
        activity: Type of PII access (view, export, delete, etc.)
        lead_id: Lead record accessed
        user_id: User performing the access
        org_id: Organization context
        endpoint: API endpoint used
        data_categories: Types of data accessed
    """
    try:
        meta = {
            "activity": activity,
            "lead_id": lead_id,
            "user_id": user_id,
            "endpoint": endpoint,
            "data_categories": data_categories or [],
            "timestamp": "auto",  # Will be set by audit system
            "compliance_event": True
        }
        
        message = f"PII access: {activity}"
        if lead_id:
            message += f" for lead {lead_id}"
        if user_id:
            message += f" by user {user_id}"
        
        # Use redacted audit for PII access events
        audit_with_redaction(
            kind="pii_access",
            message=message,
            meta=meta,
            org_id=org_id,
            redact=True
        )
        
    except Exception as e:
        logger.error(f"Failed to audit PII access: {str(e)}")


def audit_consent_change(lead_id: int, old_consent: Optional[bool], new_consent: bool,
                        source: Optional[str] = None, user_id: Optional[str] = None,
                        org_id: Optional[int] = None) -> None:
    """
    Specialized audit function for consent changes.
    
    Records all consent status changes with full context
    for compliance and legal requirements.
    
    Args:
        lead_id: Lead whose consent changed
        old_consent: Previous consent status
        new_consent: New consent status
        source: Source of consent change
        user_id: User who made the change
        org_id: Organization context
    """
    try:
        # Determine consent action
        if old_consent is None and new_consent is True:
            action = "opted_in"
        elif old_consent is None and new_consent is False:
            action = "opted_out"
        elif old_consent is True and new_consent is False:
            action = "withdrew_consent"
        elif old_consent is False and new_consent is True:
            action = "granted_consent"
        else:
            action = "consent_updated"
        
        meta = {
            "lead_id": lead_id,
            "old_consent": old_consent,
            "new_consent": new_consent,
            "action": action,
            "source": source,
            "user_id": user_id,
            "compliance_event": True,
            "legal_significance": True  # Flag for legal/compliance teams
        }
        
        message = f"Consent {action} for lead {lead_id}"
        if source:
            message += f" via {source}"
        
        # Use redacted audit (though consent changes are typically not redacted)
        audit_with_redaction(
            kind="consent_change",
            message=message,
            meta=meta,
            org_id=org_id,
            redact=False  # Consent changes usually need full detail
        )
        
    except Exception as e:
        logger.error(f"Failed to audit consent change: {str(e)}")


def audit_data_export(export_type: str, record_count: int, user_id: Optional[str] = None,
                     org_id: Optional[int] = None, redacted: bool = False,
                     export_purpose: Optional[str] = None) -> None:
    """
    Specialized audit function for data exports.
    
    Records when data is exported from the system,
    including whether redaction was applied.
    
    Args:
        export_type: Type of export (leads, buyers, etc.)
        record_count: Number of records exported
        user_id: User performing export
        org_id: Organization context
        redacted: Whether data was redacted in export
        export_purpose: Business purpose of export
    """
    try:
        meta = {
            "export_type": export_type,
            "record_count": record_count,
            "user_id": user_id,
            "redacted": redacted,
            "export_purpose": export_purpose,
            "compliance_event": True,
            "data_processing": True
        }
        
        message = f"Data export: {record_count} {export_type} records"
        if redacted:
            message += " (redacted)"
        if user_id:
            message += f" by user {user_id}"
        
        # Use redacted audit for export events
        audit_with_redaction(
            kind="data_export",
            message=message,
            meta=meta,
            org_id=org_id,
            redact=True
        )
        
    except Exception as e:
        logger.error(f"Failed to audit data export: {str(e)}")


def audit_compliance_settings_change(changes: Dict[str, Any], user_id: Optional[str] = None,
                                   org_id: Optional[int] = None) -> None:
    """
    Specialized audit function for compliance settings changes.
    
    Records when compliance/privacy settings are modified,
    which is critical for compliance documentation.
    
    Args:
        changes: Dictionary of settings that changed
        user_id: User who made the changes
        org_id: Organization context
    """
    try:
        meta = {
            "changes": changes,
            "user_id": user_id,
            "compliance_event": True,
            "settings_change": True,
            "impact": "organization_wide"
        }
        
        change_count = len(changes)
        message = f"Compliance settings updated: {change_count} setting(s) changed"
        if user_id:
            message += f" by user {user_id}"
        
        # Don't redact compliance settings changes - need full audit trail
        audit_with_redaction(
            kind="compliance_settings_updated",
            message=message,
            meta=meta,
            org_id=org_id,
            redact=False
        )
        
    except Exception as e:
        logger.error(f"Failed to audit compliance settings change: {str(e)}")


# Enhanced audit function that can be used as drop-in replacement
def audit(kind: str, message: str, meta: Optional[Dict[str, Any]] = None, 
         org_id: Optional[int] = None) -> None:
    """
    Enhanced audit function with automatic compliance handling.
    
    This can be used as a drop-in replacement for the original audit function,
    with added compliance and redaction capabilities.
    
    Args:
        kind: Type of audit event
        message: Human-readable message
        meta: Additional metadata
        org_id: Organization ID (for redaction policy)
    """
    # Determine if this is a compliance-sensitive event
    compliance_event_types = [
        "pii_access", "consent_change", "data_export", "lead_created",
        "lead_updated", "lead_deleted", "privacy_request"
    ]
    
    should_redact = kind in compliance_event_types
    
    audit_with_redaction(kind, message, meta, org_id, redact=should_redact)


# Migration helper to update existing audit calls
def migrate_audit_calls():
    """
    Helper function to identify where audit calls need org_id parameter added.
    
    In the final implementation, existing audit() calls throughout the codebase
    would need to be updated to pass org_id when available.
    """
    logger.info("To complete compliance integration, update audit() calls to include org_id parameter")
    
    # Example of calls that would need updating:
    examples = [
        "audit('lead_created', 'Lead created', {'lead_id': lead.id}, org_id=lead.org_id)",
        "audit('data_export', 'Leads exported', {'count': len(leads)}, org_id=current_org)",
        "audit('user_login', 'User logged in', {'user_id': user.id}, org_id=user.org_id)"
    ]
    
    for example in examples:
        logger.info(f"Example update: {example}")
