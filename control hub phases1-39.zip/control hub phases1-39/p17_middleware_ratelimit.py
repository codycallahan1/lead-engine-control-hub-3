"""
In-memory rate limiting middleware with token bucket algorithm.

Phase: 17
Purpose: Simple rate limiting to protect against abuse without external dependencies
Key responsibilities: RateLimitMiddleware class, token bucket implementation, 429 responses
"""

import logging
import time
from typing import Dict, Tuple, Optional
from collections import defaultdict
from fastapi import Request
from fastapi.responses import JSONResponse, HTMLResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

class TokenBucket:
    """
    Token bucket implementation for rate limiting.
    
    Allows burst traffic up to bucket capacity, then enforces
    steady rate of token replenishment.
    """
    
    def __init__(self, capacity: int, refill_rate: float):
        """
        Initialize token bucket.
        
        Args:
            capacity: Maximum number of tokens (burst limit)
            refill_rate: Tokens added per second
        """
        self.capacity = capacity
        self.refill_rate = refill_rate
        self.tokens = capacity
        self.last_refill = time.time()
    
    def consume(self, tokens: int = 1) -> bool:
        """
        Attempt to consume tokens from the bucket.
        
        Args:
            tokens: Number of tokens to consume
            
        Returns:
            True if tokens were available and consumed
        """
        now = time.time()
        
        # Add tokens based on time elapsed
        time_elapsed = now - self.last_refill
        tokens_to_add = time_elapsed * self.refill_rate
        
        self.tokens = min(self.capacity, self.tokens + tokens_to_add)
        self.last_refill = now
        
        # Check if we have enough tokens
        if self.tokens >= tokens:
            self.tokens -= tokens
            return True
        else:
            return False
    
    def get_wait_time(self, tokens: int = 1) -> float:
        """
        Calculate how long to wait before tokens are available.
        
        Args:
            tokens: Number of tokens needed
            
        Returns:
            Wait time in seconds
        """
        if self.tokens >= tokens:
            return 0.0
        
        tokens_needed = tokens - self.tokens
        return tokens_needed / self.refill_rate

class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Rate limiting middleware using token bucket algorithm.
    
    Limits requests per IP address and path combination.
    Configurable limits for different endpoint types.
    """
    
    def __init__(self, app, default_rate: int = 60, default_burst: int = 10):
        """
        Initialize rate limit middleware.
        
        Args:
            app: FastAPI application
            default_rate: Default requests per minute
            default_burst: Default burst capacity
        """
        super().__init__(app)
        
        self.default_rate = default_rate
        self.default_burst = default_burst
        
        # Storage for token buckets per IP+path
        self.buckets: Dict[str, TokenBucket] = {}
        
        # Custom rate limits for specific paths
        self.path_limits = {
            '/health': (240, 20),        # 240/min, burst 20
            '/metrics/summary': (120, 15), # 120/min, burst 15
            '/diagnostics': (30, 5),      # 30/min, burst 5
            '/ingest/lead': (30, 10),     # 30/min, burst 10 (public endpoint)
            '/leads': (120, 20),          # 120/min, burst 20
            '/buyers': (120, 20),         # 120/min, burst 20
            '/sites': (120, 20),          # 120/min, burst 20
            '/webhooks': (60, 10),        # 60/min, burst 10 (admin only)
            '/matching': (30, 5),         # 30/min, burst 5 (admin only)
        }
        
        # Cleanup old buckets periodically
        self.last_cleanup = time.time()
        self.cleanup_interval = 300  # 5 minutes
        
        logger.info(f"Rate limit middleware initialized: {default_rate}/min default, {default_burst} burst")
    
    async def dispatch(self, request: Request, call_next):
        """
        Process request with rate limiting.
        
        Args:
            request: Incoming request
            call_next: Next middleware/handler
            
        Returns:
            Response with rate limit headers
        """
        # Get client IP
        client_ip = self._get_client_ip(request)
        
        # Get path for rate limit key
        path = request.url.path
        
        # Create rate limit key
        rate_key = f"{client_ip}:{path}"
        
        # Get or create token bucket
        bucket = self._get_or_create_bucket(rate_key, path)
        
        # Check rate limit
        if not bucket.consume(1):
            # Rate limit exceeded
            wait_time = bucket.get_wait_time(1)
            
            logger.warning(f"Rate limit exceeded for {client_ip} on {path}, wait {wait_time:.1f}s")
            
            return self._create_rate_limit_response(request, wait_time, bucket)
        
        # Process request
        response = await call_next(request)
        
        # Add rate limit headers
        self._add_rate_limit_headers(response, bucket, path)
        
        # Periodic cleanup
        self._cleanup_old_buckets()
        
        return response
    
    def _get_client_ip(self, request: Request) -> str:
        """
        Extract client IP address from request.
        
        Checks X-Forwarded-For and X-Real-IP headers for proxy scenarios.
        
        Args:
            request: FastAPI request
            
        Returns:
            Client IP address
        """
        # Check forwarded headers (for proxies/load balancers)
        forwarded_for = request.headers.get('X-Forwarded-For')
        if forwarded_for:
            # Take the first IP (original client)
            return forwarded_for.split(',')[0].strip()
        
        real_ip = request.headers.get('X-Real-IP')
        if real_ip:
            return real_ip.strip()
        
        # Fallback to direct client IP
        if hasattr(request, 'client') and request.client:
            return request.client.host
        
        return 'unknown'
    
    def _get_or_create_bucket(self, rate_key: str, path: str) -> TokenBucket:
        """
        Get existing bucket or create new one for rate limit key.
        
        Args:
            rate_key: Unique key for this client+path
            path: Request path for custom limits
            
        Returns:
            TokenBucket instance
        """
        if rate_key not in self.buckets:
            # Determine rate limits for this path
            rate_per_min, burst = self._get_path_limits(path)
            
            # Convert rate per minute to rate per second
            rate_per_sec = rate_per_min / 60.0
            
            # Create new bucket
            self.buckets[rate_key] = TokenBucket(capacity=burst, refill_rate=rate_per_sec)
            
            logger.debug(f"Created rate limit bucket for {rate_key}: {rate_per_min}/min, burst {burst}")
        
        return self.buckets[rate_key]
    
    def _get_path_limits(self, path: str) -> Tuple[int, int]:
        """
        Get rate limits for a specific path.
        
        Args:
            path: Request path
            
        Returns:
            Tuple of (rate_per_minute, burst_capacity)
        """
        # Check for exact path match
        if path in self.path_limits:
            return self.path_limits[path]
        
        # Check for path prefixes
        for prefix, limits in self.path_limits.items():
            if path.startswith(prefix):
                return limits
        
        # Use default limits
        return (self.default_rate, self.default_burst)
    
    def _create_rate_limit_response(self, request: Request, wait_time: float, bucket: TokenBucket) -> Response:
        """
        Create 429 Too Many Requests response.
        
        Args:
            request: Original request
            wait_time: Seconds to wait before retry
            bucket: Token bucket for remaining count
            
        Returns:
            429 response (HTML or JSON based on Accept header)
        """
        # Calculate remaining tokens and reset time
        remaining = max(0, int(bucket.tokens))
        reset_time = int(time.time() + wait_time)
        
        # Check if client accepts HTML
        accept_header = request.headers.get('accept', '')
        
        if 'text/html' in accept_header:
            # Return HTML error page
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Rate Limit Exceeded</title>
                <style>
                    body {{ font-family: Arial, sans-serif; background: #1a1a1a; color: white; 
                           padding: 2rem; text-align: center; }}
                    .error-container {{ max-width: 600px; margin: 0 auto; }}
                    .error-code {{ font-size: 4rem; color: #f59e0b; margin-bottom: 1rem; }}
                    .error-message {{ font-size: 1.5rem; margin-bottom: 2rem; }}
                    .error-details {{ color: #666; margin-bottom: 2rem; }}
                    .retry-info {{ background: #2d2d2d; padding: 1rem; border-radius: 8px; margin: 1rem 0; }}
                    .btn {{ background: #3b82f6; color: white; padding: 0.5rem 1rem; 
                           text-decoration: none; border-radius: 4px; display: inline-block; margin-top: 1rem; }}
                    .countdown {{ font-size: 2rem; color: #f59e0b; margin: 1rem 0; }}
                </style>
            </head>
            <body>
                <div class="error-container">
                    <div class="error-code">429</div>
                    <div class="error-message">Rate Limit Exceeded</div>
                    <div class="error-details">
                        You've made too many requests. Please wait before trying again.
                    </div>
                    <div class="retry-info">
                        <strong>Retry after:</strong> <span class="countdown" id="countdown">{wait_time:.0f}</span> seconds<br>
                        <strong>Remaining requests:</strong> {remaining}<br>
                        <strong>Reset time:</strong> {time.strftime('%H:%M:%S', time.localtime(reset_time))}
                    </div>
                    <a href="/" class="btn">Return to Dashboard</a>
                </div>
                
                <script>
                let countdown = {wait_time:.0f};
                const countdownEl = document.getElementById('countdown');
                
                const timer = setInterval(() => {{
                    countdown--;
                    countdownEl.textContent = countdown;
                    
                    if (countdown <= 0) {{
                        clearInterval(timer);
                        countdownEl.textContent = '0';
                        countdownEl.parentNode.innerHTML = '<strong>You can now retry your request</strong>';
                    }}
                }}, 1000);
                </script>
            </body>
            </html>
            """
            
            response = HTMLResponse(content=html_content, status_code=429)
        else:
            # Return JSON error response
            response = JSONResponse(
                status_code=429,
                content={
                    "error": "Rate limit exceeded",
                    "message": "Too many requests. Please wait before retrying.",
                    "retry_after": int(wait_time),
                    "remaining": remaining,
                    "reset_time": reset_time
                }
            )
        
        # Add rate limit headers
        response.headers["Retry-After"] = str(int(wait_time))
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(reset_time)
        
        return response
    
    def _add_rate_limit_headers(self, response, bucket: TokenBucket, path: str):
        """
        Add rate limit headers to successful responses.
        
        Args:
            response: Response to add headers to
            bucket: Token bucket for current rate limit
            path: Request path for limit info
        """
        rate_per_min, burst = self._get_path_limits(path)
        remaining = max(0, int(bucket.tokens))
        reset_time = int(time.time() + (burst - bucket.tokens) / (rate_per_min / 60.0))
        
        response.headers["X-RateLimit-Limit"] = str(rate_per_min)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(reset_time)
    
    def _cleanup_old_buckets(self):
        """
        Remove old unused token buckets to prevent memory leaks.
        """
        now = time.time()
        
        if now - self.last_cleanup < self.cleanup_interval:
            return
        
        # Remove buckets that haven't been used in 1 hour
        cutoff_time = now - 3600
        keys_to_remove = []
        
        for key, bucket in self.buckets.items():
            if bucket.last_refill < cutoff_time:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self.buckets[key]
        
        if keys_to_remove:
            logger.info(f"Cleaned up {len(keys_to_remove)} old rate limit buckets")
        
        self.last_cleanup = now

def create_rate_limit_middleware(
    default_rate: int = 60,
    default_burst: int = 10,
    custom_limits: Optional[Dict[str, Tuple[int, int]]] = None
) -> RateLimitMiddleware:
    """
    Factory function to create rate limit middleware with custom configuration.
    
    Args:
        default_rate: Default requests per minute
        default_burst: Default burst capacity
        custom_limits: Dict of path -> (rate, burst) overrides
        
    Returns:
        Configured RateLimitMiddleware instance
    """
    class ConfiguredRateLimitMiddleware(RateLimitMiddleware):
        def __init__(self, app):
            super().__init__(app, default_rate, default_burst)
            if custom_limits:
                self.path_limits.update(custom_limits)
    
    return ConfiguredRateLimitMiddleware

# Log middleware initialization
logger.info("Rate limiting middleware initialized with token bucket algorithm")
