"""
Lead Engine Control Hub - Version Routes
Phase: 9
Purpose: Version information and build details endpoints
Key Responsibilities:
- Provide application version information
- Build timestamp and environment details
- Component version tracking
- API compatibility information
"""

import logging
import platform
import sys
from datetime import datetime

from fastapi import APIRouter

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/version", tags=["version"])

# Version information
VERSION_INFO = {
    "app_name": "Lead Engine Control Hub",
    "version": "1.0.0",
    "phase": 9,
    "build_date": datetime.utcnow().isoformat(),
    "api_version": "v1",
    "schema_version": "1.0"
}

# =============================================================================
# VERSION ENDPOINTS
# =============================================================================

@router.get("/")
async def get_version():
    """
    Get comprehensive version information.
    
    Returns:
        JSON object with version details
    """
    try:
        logger.info("GET /version - retrieving version information")
        
        # Get component versions
        component_versions = {}
        
        # Check FastAPI version
        try:
            import fastapi
            component_versions["fastapi"] = fastapi.__version__
        except (ImportError, AttributeError):
            component_versions["fastapi"] = "unknown"
        
        # Check SQLAlchemy version
        try:
            import sqlalchemy
            component_versions["sqlalchemy"] = sqlalchemy.__version__
        except (ImportError, AttributeError):
            component_versions["sqlalchemy"] = "unknown"
        
        # Check Pydantic version
        try:
            import pydantic
            component_versions["pydantic"] = pydantic.VERSION
        except (ImportError, AttributeError):
            try:
                import pydantic
                component_versions["pydantic"] = pydantic.__version__
            except (ImportError, AttributeError):
                component_versions["pydantic"] = "unknown"
        
        # Check Jinja2 version
        try:
            import jinja2
            component_versions["jinja2"] = jinja2.__version__
        except (ImportError, AttributeError):
            component_versions["jinja2"] = "unknown"
        
        # Check Uvicorn version
        try:
            import uvicorn
            component_versions["uvicorn"] = uvicorn.__version__
        except (ImportError, AttributeError):
            component_versions["uvicorn"] = "unknown"
        
        version_response = {
            "application": VERSION_INFO.copy(),
            "runtime": {
                "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                "python_implementation": platform.python_implementation(),
                "platform": platform.system(),
                "architecture": platform.machine(),
                "processor": platform.processor() or "unknown"
            },
            "components": component_versions,
            "features": {
                "phases_implemented": list(range(1, 10)),  # Phases 1-9
                "total_phases": 11,
                "completion_percentage": round((9 / 11) * 100, 1)
            },
            "api": {
                "version": VERSION_INFO["api_version"],
                "schema_version": VERSION_INFO["schema_version"],
                "endpoints_available": True,
                "documentation_url": "/docs"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        logger.info("Version information retrieved successfully")
        return version_response
        
    except Exception as e:
        logger.error(f"Failed to get version information: {e}")
        # Return minimal version info on error
        return {
            "app_name": VERSION_INFO["app_name"],
            "version": VERSION_INFO["version"],
            "phase": VERSION_INFO["phase"],
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@router.get("/short")
async def get_version_short():
    """
    Get abbreviated version information.
    
    Returns:
        JSON object with essential version details
    """
    try:
        logger.info("GET /version/short - retrieving short version info")
        
        return {
            "app_name": VERSION_INFO["app_name"],
            "version": VERSION_INFO["version"],
            "phase": VERSION_INFO["phase"],
            "api_version": VERSION_INFO["api_version"],
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get short version info: {e}")
        return {
            "app_name": "Lead Engine Control Hub",
            "version": "1.0.0",
            "error": str(e)
        }

@router.get("/build")
async def get_build_info():
    """
    Get build and deployment information.
    
    Returns:
        JSON object with build details
    """
    try:
        logger.info("GET /version/build - retrieving build information")
        
        build_info = {
            "build_date": VERSION_INFO["build_date"],
            "build_environment": "development",  # Could be read from environment
            "git_commit": "unknown",  # Could be injected during build
            "git_branch": "main",     # Could be injected during build
            "builder": "manual",      # Could be automated build system
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "platform": platform.system(),
            "architecture": platform.machine(),
            "schema_migrations": {
                "current_version": VERSION_INFO["schema_version"],
                "migration_required": False
            },
            "deployment": {
                "method": "local",
                "timestamp": VERSION_INFO["build_date"]
            }
        }
        
        return build_info
        
    except Exception as e:
        logger.error(f"Failed to get build info: {e}")
        return {
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@router.get("/api")
async def get_api_version():
    """
    Get API version and compatibility information.
    
    Returns:
        JSON object with API version details
    """
    try:
        logger.info("GET /version/api - retrieving API version info")
        
        api_info = {
            "api_version": VERSION_INFO["api_version"],
            "schema_version": VERSION_INFO["schema_version"],
            "openapi_version": "3.0.0",  # FastAPI uses OpenAPI 3.0
            "supported_formats": ["json"],
            "authentication": {
                "required": False,
                "methods": []  # No auth implemented yet
            },
            "rate_limiting": {
                "enabled": False,
                "max_requests_per_hour": None
            },
            "endpoints": {
                "total_count": "auto-discovered",
                "documentation": "/docs",
                "redoc_documentation": "/redoc",
                "openapi_schema": "/openapi.json"
            },
            "compatibility": {
                "breaking_changes": [],
                "deprecated_endpoints": [],
                "minimum_client_version": "1.0.0"
            }
        }
        
        return api_info
        
    except Exception as e:
        logger.error(f"Failed to get API version info: {e}")
        return {
            "api_version": "v1",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@router.get("/changelog")
async def get_changelog():
    """
    Get version changelog and release notes.
    
    Returns:
        JSON object with changelog information
    """
    try:
        logger.info("GET /version/changelog - retrieving changelog")
        
        # This could be loaded from a file or database in a real application
        changelog = {
            "current_version": VERSION_INFO["version"],
            "releases": [
                {
                    "version": "1.0.0",
                    "phase": 9,
                    "date": VERSION_INFO["build_date"],
                    "type": "major",
                    "features": [
                        "Application settings and configuration endpoints",
                        "Version information API",
                        "Settings management UI",
                        "Feature flags and capabilities tracking"
                    ],
                    "improvements": [
                        "Enhanced system health monitoring",
                        "Comprehensive configuration display",
                        "Administrative tools quick access"
                    ],
                    "fixes": []
                },
                {
                    "version": "0.9.0",
                    "phase": 8,
                    "date": "2024-01-15T00:00:00Z",
                    "type": "minor",
                    "features": [
                        "Data export functionality (CSV/JSON)",
                        "Audit logging system",
                        "Enhanced leads management UI"
                    ]
                },
                {
                    "version": "0.8.0",
                    "phase": 7,
                    "date": "2024-01-14T00:00:00Z",
                    "type": "minor",
                    "features": [
                        "In-process job queue",
                        "Deployment automation",
                        "Real-time deployment monitoring"
                    ]
                },
                {
                    "version": "0.7.0",
                    "phase": 6,
                    "date": "2024-01-13T00:00:00Z",
                    "type": "minor",
                    "features": [
                        "Sites management",
                        "Deployment models",
                        "Site CRUD operations"
                    ]
                }
            ],
            "upcoming": {
                "version": "1.1.0",
                "phase": 11,
                "planned_features": [
                    "AI assistant integration (Jarvis 2.0)",
                    "Advanced diagnostics",
                    "Provider mocks and testing tools",
                    "Chat history and command processing"
                ],
                "estimated_release": "Coming soon"
            }
        }
        
        return changelog
        
    except Exception as e:
        logger.error(f"Failed to get changelog: {e}")
        return {
            "current_version": VERSION_INFO["version"],
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@router.get("/health")
async def get_version_health():
    """
    Get version-related health information.
    
    Returns:
        JSON object with version health status
    """
    try:
        logger.info("GET /version/health - checking version health")
        
        health_status = {
            "version_current": True,
            "schema_compatible": True,
            "api_stable": True,
            "components_healthy": True,
            "migration_needed": False,
            "issues": [],
            "recommendations": []
        }
        
        # Check if we're on a stable version
        version_parts = VERSION_INFO["version"].split(".")
        if len(version_parts) >= 2:
            major, minor = int(version_parts[0]), int(version_parts[1])
            if major == 0:
                health_status["version_current"] = False
                health_status["issues"].append("Pre-release version detected")
                health_status["recommendations"].append("Consider upgrading to stable release")
        
        # Check component compatibility (simplified)
        try:
            import fastapi
            fastapi_version = fastapi.__version__
            if fastapi_version.startswith("0."):
                health_status["components_healthy"] = False
                health_status["issues"].append("FastAPI pre-release version")
        except ImportError:
            health_status["components_healthy"] = False
            health_status["issues"].append("FastAPI not available")
        
        # Overall health assessment
        health_status["overall_status"] = "healthy" if not health_status["issues"] else "warning"
        
        return health_status
        
    except Exception as e:
        logger.error(f"Failed to get version health: {e}")
        return {
            "overall_status": "error",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Version Routes Module Test ===")
    logger.info("✅ Version routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET  /version            - Complete version information")
    logger.info("  GET  /version/short      - Abbreviated version info")
    logger.info("  GET  /version/build      - Build and deployment details")
    logger.info("  GET  /version/api        - API version and compatibility")
    logger.info("  GET  /version/changelog  - Version history and release notes")
    logger.info("  GET  /version/health     - Version-related health status")
    logger.info("")
    logger.info("Integration notes:")
    logger.info("- Add 'from p09__server_routes_version import router as version_router' to main app")
    logger.info("- Add 'app.include_router(version_router)' to wire in the endpoints")
    logger.info("- Version endpoints provide comprehensive application metadata")
    logger.info("- Compatible with existing /version endpoint (can replace or complement)")