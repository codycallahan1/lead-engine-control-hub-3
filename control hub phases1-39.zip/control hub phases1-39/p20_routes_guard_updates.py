"""
Route Guard Updates for Middleware-Based Authentication
Phase 20: Updated dependencies for existing routes to use new auth middleware
Key responsibilities: Replace direct admin token checks with middleware-based role guards
"""

import logging
from fastapi import Depends, Request
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Import new middleware-based auth functions
try:
    from p20__server_middleware_auth import require_admin, require_viewer, get_current_user_info
except ImportError:
    logger.warning("Auth middleware not found - using fallback implementations")
    
    def require_admin(request: Request) -> Dict[str, Any]:
        """Fallback admin check"""
        admin_token = request.headers.get('Admin-Token')
        if admin_token != 'change-me':
            from fastapi import HTTPException
            raise HTTPException(status_code=403, detail="Admin token required")
        return {"role": "admin", "valid": True}
    
    def require_viewer(request: Request) -> Dict[str, Any]:
        """Fallback viewer check"""
        admin_token = request.headers.get('Admin-Token')
        viewer_token = request.headers.get('Viewer-Token')
        if admin_token == 'change-me':
            return {"role": "admin", "valid": True}
        if viewer_token:  # Basic viewer token check
            return {"role": "viewer", "valid": True}
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Authentication required")
    
    def get_current_user_info(request: Request) -> Dict[str, Any]:
        """Fallback user info"""
        return {"role": None, "valid": False}

"""
ROUTE GUARD MIGRATION GUIDE
===========================

This file documents how to update existing route dependencies to use the new 
middleware-based authentication system from Phase 20.

BEFORE (Direct token dependency):
---------------------------------
from fastapi import Depends

def require_admin_token(admin_token: str = None):
    if not admin_token or admin_token != "change-me":
        raise HTTPException(status_code=403, detail="Admin token required")
    return True

@router.post("/some-endpoint")
async def protected_endpoint(_: bool = Depends(require_admin_token)):
    # endpoint logic
    pass

AFTER (Middleware-based):
-------------------------
from fastapi import Depends, Request
from p20__server_middleware_auth import require_admin

@router.post("/some-endpoint")
async def protected_endpoint(
    request: Request,
    user_info: dict = Depends(require_admin)
):
    # endpoint logic
    # user_info contains: {"role": "admin", "valid": True, "token_name": "...", ...}
    pass

ROUTE-BY-ROUTE UPDATES NEEDED:
===============================

1. Import Routes (p18__server-routes-import.py):
   - Replace require_admin_token with require_admin
   - Add Request parameter to endpoints

2. Export Routes (p18__server-routes-export-harden.py):
   - Replace require_admin_token with require_admin
   - Add Request parameter to endpoints

3. Webhooks Routes (p13__server-routes-webhooks.py):
   - Update POST/PATCH operations to use require_admin
   - GET operations can use require_viewer

4. Matching Routes (p14__server-routes-matching.py):
   - Update admin-only endpoints to use require_admin

5. Settings Routes (p16__server-routes-settings-notify.py):
   - Update to use require_admin for mutations

6. Audit Routes (p21__server-routes-audit.py):
   - Export endpoint: require_admin
   - List endpoint: require_viewer (or public)

7. Diagnostics Routes (p10__server-routes-diagnostics.py):
   - Can remain public or use require_viewer

ROLE-BASED ACCESS PATTERNS:
============================

# Admin-only operations (create, update, delete, sensitive data)
@router.post("/admin-only")
async def admin_endpoint(
    request: Request,
    user_info: dict = Depends(require_admin)
):
    pass

# Viewer or higher (read operations)
@router.get("/read-only")
async def viewer_endpoint(
    request: Request,
    user_info: dict = Depends(require_viewer)
):
    pass

# Public endpoints (no authentication required)
@router.get("/public")
async def public_endpoint():
    pass

# Conditional access based on role
@router.get("/conditional")
async def conditional_endpoint(request: Request):
    user_info = get_current_user_info(request)
    
    if user_info.get('role') == 'admin':
        # Return sensitive data
        return {"sensitive": "data"}
    elif user_info.get('role') == 'viewer':
        # Return limited data
        return {"limited": "data"}
    else:
        # Return public data only
        return {"public": "data"}

HEADER COMPATIBILITY:
=====================

The new system maintains backward compatibility:

1. Legacy Admin-Token: 'change-me' continues to work
2. New Admin-Token: Database tokens with admin role
3. New Viewer-Token: Database tokens with viewer role

Multiple tokens in request:
- Admin-Token takes precedence if present
- Falls back to Viewer-Token if no Admin-Token

TESTING MIGRATION:
==================

# Test with legacy token (should still work)
curl -H "Admin-Token: change-me" http://localhost:8000/protected

# Test with new admin token
curl -H "Admin-Token: <database_token>" http://localhost:8000/protected

# Test with viewer token (on viewer-allowed endpoints)
curl -H "Viewer-Token: <viewer_token>" http://localhost:8000/read-only

# Test unauthorized access
curl http://localhost:8000/protected  # Should return 401/403

IMPLEMENTATION CHECKLIST:
=========================

□ Add AuthenticationMiddleware to FastAPI app
□ Update all protected routes to use new dependencies
□ Test backward compatibility with legacy tokens
□ Test new token creation and usage
□ Update route documentation
□ Monitor logs for authentication events

"""

# Example updated route patterns for reference
class UpdatedRouteExamples:
    """
    Examples showing how routes should be updated to use new auth system
    """
    
    @staticmethod
    def old_style_route():
        """
        OLD STYLE - Direct token dependency
        """
        return '''
        def require_admin_token(admin_token: str = None):
            if not admin_token or admin_token != "change-me":
                raise HTTPException(status_code=403, detail="Admin token required")
            return True

        @router.post("/example")
        async def example_endpoint(_: bool = Depends(require_admin_token)):
            return {"message": "success"}
        '''
    
    @staticmethod
    def new_style_route():
        """
        NEW STYLE - Middleware-based auth
        """
        return '''
        from p20__server_middleware_auth import require_admin

        @router.post("/example")
        async def example_endpoint(
            request: Request,
            user_info: dict = Depends(require_admin)
        ):
            # user_info contains role, token_name, etc.
            return {"message": "success", "user": user_info.get('token_name')}
        '''
    
    @staticmethod
    def conditional_access_route():
        """
        CONDITIONAL ACCESS - Different responses based on role
        """
        return '''
        @router.get("/data")
        async def get_data(request: Request):
            user_info = get_current_user_info(request)
            
            base_data = {"public": "information"}
            
            if user_info.get('role') == 'admin':
                base_data.update({"admin": "sensitive_data"})
            elif user_info.get('role') == 'viewer':
                base_data.update({"viewer": "additional_data"})
            
            return base_data
        '''

# Guard migration utility functions
def create_admin_guard():
    """Create admin-only dependency"""
    return Depends(require_admin)

def create_viewer_guard():
    """Create viewer-or-higher dependency"""
    return Depends(require_viewer)

def create_auth_info_getter():
    """Create dependency that gets auth info without requiring specific role"""
    return Depends(get_current_user_info)

# Backward compatibility checker
def check_legacy_token_support(request: Request) -> bool:
    """
    Check if request uses legacy admin token
    Useful for migration monitoring
    """
    admin_token = request.headers.get('Admin-Token')
    user_info = get_current_user_info(request)
    
    is_legacy = (admin_token == 'change-me' and 
                 user_info.get('source') == 'legacy')
    
    if is_legacy:
        logger.info("Legacy admin token used - consider migrating to database tokens")
    
    return is_legacy

# Migration helper for route developers
def get_migration_status() -> Dict[str, Any]:
    """
    Get status of auth system migration
    Useful for monitoring and debugging
    """
    try:
        # Test if new auth system is available
        from p20__server_middleware_auth import AuthenticationMiddleware
        new_system_available = True
    except ImportError:
        new_system_available = False
    
    return {
        "new_auth_system_available": new_system_available,
        "legacy_tokens_supported": True,  # Always true for backward compatibility
        "recommended_migration_steps": [
            "1. Add AuthenticationMiddleware to app",
            "2. Update route dependencies",
            "3. Create database tokens",
            "4. Test with both token types",
            "5. Monitor usage patterns"
        ]
    }

if __name__ == "__main__":
    # Print migration status for developers
    status = get_migration_status()
    print("Auth System Migration Status:")
    for key, value in status.items():
        print(f"  {key}: {value}")
