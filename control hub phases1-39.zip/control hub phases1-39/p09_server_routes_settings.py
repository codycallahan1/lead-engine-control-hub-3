"""
Lead Engine Control Hub - Settings Routes
Phase: 9
Purpose: Application settings and configuration endpoints (public-safe only)
Key Responsibilities:
- Expose public application settings (no secrets)
- Provide server information and configuration
- HTML settings page for administrators
- Version and build information access
"""

import logging
import platform
import sys
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/settings", tags=["settings"])

# Initialize templates
try:
    templates_path = Path(__file__).parent / "templates"
    templates_path.mkdir(exist_ok=True)
    templates = Jinja2Templates(directory=str(templates_path))
    logger.info("Templates initialized for settings routes")
except Exception as e:
    logger.warning(f"Could not initialize templates: {e}")
    templates = None

# Application configuration (public-safe only)
APP_CONFIG = {
    "app_name": "Lead Engine Control Hub",
    "app_version": "1.0.0",
    "app_phase": 9,
    "app_description": "Multi-phase lead management system with deployment automation",
    "build_timestamp": datetime.utcnow().isoformat(),
    "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
    "platform": platform.system(),
    "architecture": platform.machine()
}

# =============================================================================
# SETTINGS API ENDPOINTS
# =============================================================================

@router.get("/")
async def get_public_settings():
    """
    Get public application settings (no secrets exposed).
    
    Returns:
        JSON object with public configuration settings
    """
    try:
        logger.info("GET /settings - retrieving public settings")
        
        # Get database file info if available
        db_info = {}
        try:
            db_path = Path("./controlhub.db")
            if db_path.exists():
                db_stat = db_path.stat()
                db_info = {
                    "database_file_exists": True,
                    "database_size_bytes": db_stat.st_size,
                    "database_size_mb": round(db_stat.st_size / (1024 * 1024), 2)
                }
            else:
                db_info = {"database_file_exists": False}
        except Exception as e:
            logger.warning(f"Could not get database info: {e}")
            db_info = {"database_file_exists": False, "error": str(e)}
        
        # Get queue status if available
        queue_info = {}
        try:
            from p07__server_services_queue import get_queue_stats
            queue_stats = get_queue_stats()
            queue_info = {
                "queue_enabled": True,
                "worker_running": queue_stats.get("worker_running", False),
                "total_jobs": queue_stats.get("total_jobs", 0),
                "registered_handlers": queue_stats.get("registered_handlers", [])
            }
        except Exception as e:
            logger.warning(f"Could not get queue info: {e}")
            queue_info = {"queue_enabled": False, "error": str(e)}
        
        # Compile public settings
        public_settings = {
            "application": APP_CONFIG.copy(),
            "server": {
                "host": "0.0.0.0",  # Default FastAPI host
                "port": 8000,       # Default FastAPI port
                "debug_mode": False,  # Never expose debug status
                "environment": "production"  # Safe default
            },
            "features": {
                "lead_management": True,
                "buyer_management": True,
                "site_management": True,
                "deployment_automation": True,
                "data_export": True,
                "audit_logging": True,
                "public_lead_ingestion": True,
                "metrics_dashboard": True
            },
            "database": db_info,
            "job_queue": queue_info,
            "endpoints": {
                "api_docs": "/docs",
                "health_check": "/health",
                "version_info": "/version",
                "metrics_summary": "/metrics/summary",
                "diagnostics": "/diagnostics"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        logger.info("Public settings retrieved successfully")
        return public_settings
        
    except Exception as e:
        logger.error(f"Failed to retrieve public settings: {e}")
        # Return minimal safe settings on error
        return {
            "application": {
                "app_name": APP_CONFIG["app_name"],
                "app_version": APP_CONFIG["app_version"],
                "app_phase": APP_CONFIG["app_phase"]
            },
            "error": "Failed to retrieve full settings",
            "timestamp": datetime.utcnow().isoformat()
        }

@router.get("/info")
async def get_app_info():
    """
    Get basic application information.
    
    Returns:
        JSON object with application metadata
    """
    try:
        logger.info("GET /settings/info - retrieving app info")
        
        return {
            "name": APP_CONFIG["app_name"],
            "version": APP_CONFIG["app_version"],
            "phase": APP_CONFIG["app_phase"],
            "description": APP_CONFIG["app_description"],
            "build_timestamp": APP_CONFIG["build_timestamp"],
            "runtime": {
                "python_version": APP_CONFIG["python_version"],
                "platform": APP_CONFIG["platform"],
                "architecture": APP_CONFIG["architecture"]
            },
            "uptime_since": APP_CONFIG["build_timestamp"],  # Approximation
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get app info: {e}")
        return {
            "name": "Lead Engine Control Hub",
            "version": "1.0.0",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@router.get("/features")
async def get_feature_flags():
    """
    Get feature flags and capabilities.
    
    Returns:
        JSON object with feature availability
    """
    try:
        logger.info("GET /settings/features - retrieving feature flags")
        
        # Check feature availability dynamically
        features = {
            "core_features": {
                "lead_management": True,
                "buyer_management": True,
                "site_management": True,
                "metrics_dashboard": True,
                "public_lead_ingestion": True
            },
            "advanced_features": {
                "deployment_automation": True,
                "job_queue": True,
                "data_export": True,
                "audit_logging": True
            },
            "integrations": {
                "email_notifications": False,  # Not implemented
                "webhook_support": False,      # Not implemented
                "external_apis": False,       # Not implemented
                "sso_authentication": False   # Not implemented
            },
            "experimental_features": {
                "ai_assistant": True,  # Phase 11 Jarvis
                "diagnostics": True,   # Phase 10
                "provider_mocks": True # Phase 10
            }
        }
        
        return {
            "features": features,
            "total_features": sum(len(category) for category in features.values()),
            "enabled_features": sum(
                sum(1 for enabled in category.values() if enabled)
                for category in features.values()
            ),
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get feature flags: {e}")
        return {
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

# =============================================================================
# SETTINGS HTML PAGE
# =============================================================================

@router.get("-page", response_class=HTMLResponse)
async def settings_page(request: Request):
    """
    Render HTML settings page for administrators.
    
    Args:
        request: FastAPI request object
        
    Returns:
        HTML response with settings page
    """
    try:
        logger.info("GET /settings-page - rendering settings page")
        
        # Get settings data for template
        settings_data = await get_public_settings()
        app_info = await get_app_info()
        features = await get_feature_flags()
        
        context = {
            "request": request,
            "title": "Application Settings",
            "settings": settings_data,
            "app_info": app_info,
            "features": features
        }
        
        if templates:
            try:
                return templates.TemplateResponse("settings.html", context)
            except Exception as template_error:
                logger.warning(f"Template error, using fallback: {template_error}")
        
        # Fallback HTML if template not available
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Application Settings</title>
            <link rel="stylesheet" href="/static/main.css">
            <style>
                .settings-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }}
                .settings-card {{ background-color: #2a2a2a; border: 1px solid #4a4a4a; border-radius: 8px; padding: 1.5rem; }}
                .settings-card h3 {{ color: #4a9eff; margin-bottom: 1rem; }}
                .setting-item {{ margin-bottom: 0.5rem; display: flex; justify-content: space-between; }}
                .setting-label {{ color: #b0b0b0; }}
                .setting-value {{ color: #e0e0e0; font-weight: 500; }}
                .feature-list {{ list-style: none; padding: 0; }}
                .feature-list li {{ padding: 0.25rem 0; }}
                .feature-enabled {{ color: #4caf50; }}
                .feature-disabled {{ color: #f44336; }}
                .quick-links {{ display: flex; gap: 1rem; flex-wrap: wrap; margin-top: 1rem; }}
                .quick-links a {{ padding: 0.5rem 1rem; background-color: #4a9eff; color: white; text-decoration: none; border-radius: 4px; font-size: 0.9rem; }}
                .quick-links a:hover {{ background-color: #3080cc; }}
            </style>
        </head>
        <body>
            <nav class="main-nav">
                <div class="nav-container">
                    <div class="nav-brand"><h1>Lead Engine Control Hub</h1></div>
                    <div class="nav-links">
                        <a href="/">Dashboard</a>
                        <a href="/settings-page">Settings</a>
                    </div>
                </div>
            </nav>
            
            <main class="main-content">
                <h2>Application Settings</h2>
                <p>System configuration and feature information</p>
                
                <div class="settings-grid">
                    <div class="settings-card">
                        <h3>Application Info</h3>
                        <div class="setting-item">
                            <span class="setting-label">Name:</span>
                            <span class="setting-value">{app_info.get('name', 'Unknown')}</span>
                        </div>
                        <div class="setting-item">
                            <span class="setting-label">Version:</span>
                            <span class="setting-value">{app_info.get('version', 'Unknown')}</span>
                        </div>
                        <div class="setting-item">
                            <span class="setting-label">Phase:</span>
                            <span class="setting-value">{app_info.get('phase', 'Unknown')}</span>
                        </div>
                        <div class="setting-item">
                            <span class="setting-label">Python:</span>
                            <span class="setting-value">{app_info.get('runtime', {}).get('python_version', 'Unknown')}</span>
                        </div>
                        <div class="setting-item">
                            <span class="setting-label">Platform:</span>
                            <span class="setting-value">{app_info.get('runtime', {}).get('platform', 'Unknown')}</span>
                        </div>
                    </div>
                    
                    <div class="settings-card">
                        <h3>Database</h3>
                        <div class="setting-item">
                            <span class="setting-label">File Exists:</span>
                            <span class="setting-value">{'Yes' if settings_data.get('database', {}).get('database_file_exists') else 'No'}</span>
                        </div>
                        <div class="setting-item">
                            <span class="setting-label">Size:</span>
                            <span class="setting-value">{settings_data.get('database', {}).get('database_size_mb', 0)} MB</span>
                        </div>
                    </div>
                    
                    <div class="settings-card">
                        <h3>Job Queue</h3>
                        <div class="setting-item">
                            <span class="setting-label">Enabled:</span>
                            <span class="setting-value">{'Yes' if settings_data.get('job_queue', {}).get('queue_enabled') else 'No'}</span>
                        </div>
                        <div class="setting-item">
                            <span class="setting-label">Worker Running:</span>
                            <span class="setting-value">{'Yes' if settings_data.get('job_queue', {}).get('worker_running') else 'No'}</span>
                        </div>
                        <div class="setting-item">
                            <span class="setting-label">Total Jobs:</span>
                            <span class="setting-value">{settings_data.get('job_queue', {}).get('total_jobs', 0)}</span>
                        </div>
                    </div>
                    
                    <div class="settings-card">
                        <h3>Quick Links</h3>
                        <div class="quick-links">
                            <a href="/docs" target="_blank">API Docs</a>
                            <a href="/health">Health Check</a>
                            <a href="/metrics/summary">Metrics</a>
                            <a href="/diagnostics">Diagnostics</a>
                            <a href="/version">Version Info</a>
                        </div>
                    </div>
                </div>
            </main>
        </body>
        </html>
        """
        
        return HTMLResponse(html_content, status_code=200)
        
    except Exception as e:
        logger.error(f"Failed to render settings page: {e}")
        return HTMLResponse(
            f"<h1>Settings Error</h1><p>Failed to load settings: {e}</p>",
            status_code=500
        )

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Settings Routes Module Test ===")
    logger.info("✅ Settings routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET  /settings           - Public application settings")
    logger.info("  GET  /settings/info      - Basic application info")
    logger.info("  GET  /settings/features  - Feature flags and capabilities")
    logger.info("  GET  /settings-page      - HTML settings page")
    logger.info("")
    logger.info("Integration notes:")
    logger.info("- Add 'from p09__server_routes_settings import router as settings_router' to main app")
    logger.info("- Add 'app.include_router(settings_router)' to wire in the endpoints")
    logger.info("- All settings are public-safe (no secrets exposed)")
    logger.info("- Settings page includes quick links to key endpoints")