"""
Organization Scoping Service
Phase 24: Multi-tenant data isolation and org context management
Key responsibilities: Resolve org context, apply data filters, scope enforcement
"""

import logging
from fastapi import Request, HTTPException
from typing import Optional, Union
from sqlalchemy.orm import Query

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p24__server_models_orgs import Organization, Membership, can_user_access_org, get_user_organizations
    from p23__server_security_auth import optional_user_from_key, get_current_user_context
except ImportError:
    logger.warning("Org scoping modules not found - using mock implementations")
    def get_session():
        return None
    
    class Organization:
        def __init__(self, **kwargs):
            self.id = kwargs.get('id', 1)
            self.name = kwargs.get('name', 'Default Org')
    
    def can_user_access_org(session, user_id, org_id):
        return True
    
    def get_user_organizations(session, user_id):
        return [Organization(id=1, name="Default")]
    
    def optional_user_from_key(request):
        return None if not request.headers.get("X-API-Key") else type('MockUser', (), {'id': 1})()
    
    def get_current_user_context(request):
        return {"authenticated": False, "roles": []}

def current_org(request: Request) -> int:
    """
    Resolve current organization ID from request context
    
    Priority order:
    1. X-Org-ID header (admin users only)
    2. ?org_id query parameter (admin users only) 
    3. User's primary organization membership
    4. Default organization (ID: 1)
    
    Args:
        request: FastAPI request object
    
    Returns:
        Organization ID for current request
    """
    try:
        session = get_session()
        if not session:
            logger.warning("No database session - using default org")
            return 1
        
        with session:
            # Get current user context
            user = optional_user_from_key(request)
            user_context = get_current_user_context(request)
            
            # Check for admin override via header or query param
            if user and 'admin' in user_context.get('roles', []):
                # Admin can specify org via header
                org_header = request.headers.get('X-Org-ID')
                if org_header:
                    try:
                        org_id = int(org_header)
                        # Verify org exists
                        org = session.query(Organization).filter(Organization.id == org_id).first()
                        if org:
                            logger.debug(f"Admin using org override via header: {org_id}")
                            return org_id
                    except ValueError:
                        logger.warning(f"Invalid org ID in header: {org_header}")
                
                # Admin can specify org via query param
                org_param = request.query_params.get('org_id')
                if org_param:
                    try:
                        org_id = int(org_param)
                        org = session.query(Organization).filter(Organization.id == org_id).first()
                        if org:
                            logger.debug(f"Admin using org override via query: {org_id}")
                            return org_id
                    except ValueError:
                        logger.warning(f"Invalid org ID in query param: {org_param}")
            
            # Get user's organizations
            if user:
                user_orgs = get_user_organizations(session, user.id)
                if user_orgs:
                    # Use first org as primary (could be enhanced with user preferences)
                    primary_org_id = user_orgs[0].id
                    logger.debug(f"User {user.id} using primary org: {primary_org_id}")
                    return primary_org_id
            
            # Default to org 1
            logger.debug("Using default organization (ID: 1)")
            return 1
    
    except Exception as e:
        logger.error(f"Error resolving current org: {e}")
        return 1  # Fallback to default

def apply_org_scope(query: Query, org_id: int, model_class=None) -> Query:
    """
    Apply organization scoping to a SQLAlchemy query
    
    Args:
        query: SQLAlchemy query to filter
        org_id: Organization ID to filter by
        model_class: Model class being queried (for determining column name)
    
    Returns:
        Filtered query with org scope applied
    """
    try:
        # Determine the org_id column name based on model
        if model_class:
            if hasattr(model_class, 'org_id'):
                return query.filter(model_class.org_id == org_id)
            else:
                logger.warning(f"Model {model_class.__name__} does not have org_id column")
                return query
        else:
            # Try to infer from query
            # This is a simplified approach - in production you'd be more specific
            try:
                # Attempt to add org filter (will fail if column doesn't exist)
                return query.filter_by(org_id=org_id)
            except Exception:
                logger.debug("Query does not support org_id filtering")
                return query
    
    except Exception as e:
        logger.error(f"Error applying org scope: {e}")
        return query

def validate_org_access(request: Request, org_id: int) -> bool:
    """
    Validate that current user can access specified organization
    
    Args:
        request: FastAPI request object
        org_id: Organization ID to check access for
    
    Returns:
        True if user has access, False otherwise
    """
    try:
        user = optional_user_from_key(request)
        if not user:
            # Unauthenticated users can only access default org
            return org_id == 1
        
        user_context = get_current_user_context(request)
        
        # Admins can access any org
        if 'admin' in user_context.get('roles', []):
            return True
        
        # Check membership
        session = get_session()
        if not session:
            return org_id == 1  # Fallback for no DB
        
        with session:
            return can_user_access_org(session, user.id, org_id)
    
    except Exception as e:
        logger.error(f"Error validating org access: {e}")
        return False

def require_org_access(request: Request, org_id: int):
    """
    Require access to specified organization or raise HTTP exception
    
    Args:
        request: FastAPI request object
        org_id: Organization ID to require access for
    
    Raises:
        HTTPException: If user doesn't have access
    """
    if not validate_org_access(request, org_id):
        user_context = get_current_user_context(request)
        if not user_context.get('authenticated'):
            raise HTTPException(status_code=401, detail="Authentication required")
        else:
            raise HTTPException(
                status_code=403, 
                detail=f"Access denied to organization {org_id}"
            )

def get_user_org_context(request: Request) -> dict:
    """
    Get comprehensive org context for current user
    
    Args:
        request: FastAPI request object
    
    Returns:
        Dictionary with org context information
    """
    try:
        user = optional_user_from_key(request)
        current_org_id = current_org(request)
        
        context = {
            "current_org_id": current_org_id,
            "available_orgs": [],
            "can_switch_orgs": False,
            "is_admin_override": False
        }
        
        if not user:
            return context
        
        session = get_session()
        if not session:
            return context
        
        with session:
            user_context = get_current_user_context(request)
            is_admin = 'admin' in user_context.get('roles', [])
            
            # Get user's organizations
            user_orgs = get_user_organizations(session, user.id)
            context["available_orgs"] = [org.to_dict() for org in user_orgs]
            context["can_switch_orgs"] = len(user_orgs) > 1 or is_admin
            
            # Check if current org is an admin override
            if is_admin:
                user_org_ids = [org.id for org in user_orgs]
                context["is_admin_override"] = current_org_id not in user_org_ids
            
            return context
    
    except Exception as e:
        logger.error(f"Error getting user org context: {e}")
        return {"current_org_id": 1, "available_orgs": [], "can_switch_orgs": False}

def switch_org_context(request: Request, new_org_id: int) -> dict:
    """
    Switch user's org context (for session-based systems)
    
    Args:
        request: FastAPI request object
        new_org_id: New organization ID to switch to
    
    Returns:
        Dictionary with switch results
    """
    try:
        # Validate access to new org
        if not validate_org_access(request, new_org_id):
            return {
                "success": False,
                "error": f"Access denied to organization {new_org_id}"
            }
        
        # In a session-based system, you'd update the session here
        # For API-key based access, the client needs to use headers/params
        
        return {
            "success": True,
            "new_org_id": new_org_id,
            "message": f"Switched to organization {new_org_id}",
            "method": "Use X-Org-ID header or ?org_id parameter for API requests"
        }
    
    except Exception as e:
        logger.error(f"Error switching org context: {e}")
        return {"success": False, "error": str(e)}

def get_org_scoped_query_helper(request: Request, base_query: Query, model_class) -> Query:
    """
    Helper to automatically apply org scoping to queries
    
    Args:
        request: FastAPI request object
        base_query: Base SQLAlchemy query
        model_class: Model class being queried
    
    Returns:
        Query with org scoping applied
    """
    try:
        org_id = current_org(request)
        
        # Validate user has access to this org
        require_org_access(request, org_id)
        
        # Apply scoping
        scoped_query = apply_org_scope(base_query, org_id, model_class)
        
        logger.debug(f"Applied org scope {org_id} to {model_class.__name__} query")
        return scoped_query
    
    except HTTPException:
        raise  # Re-raise HTTP exceptions
    except Exception as e:
        logger.error(f"Error in org scoped query helper: {e}")
        return base_query  # Return unscoped query as fallback

def create_org_scoped_filters(org_id: int) -> dict:
    """
    Create filter dictionaries for org scoping
    
    Args:
        org_id: Organization ID to filter by
    
    Returns:
        Dictionary of filter conditions
    """
    return {
        "org_id": org_id
    }

def log_org_access(request: Request, resource: str, action: str):
    """
    Log organization access for audit purposes
    
    Args:
        request: FastAPI request object
        resource: Resource being accessed
        action: Action being performed
    """
    try:
        user_context = get_current_user_context(request)
        org_id = current_org(request)
        
        log_data = {
            "user_id": user_context.get('user_id'),
            "org_id": org_id,
            "resource": resource,
            "action": action,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        logger.info(f"Org access: {log_data}")
        
        # In production, you might want to send this to audit service
        try:
            from p21__server_models_audit import log_audit_event, AuditKind
            session = get_session()
            if session:
                with session:
                    log_audit_event(
                        session,
                        AuditKind.AUTH_LOGIN,  # Reusing existing kind
                        f"Org access: {action} {resource} in org {org_id}",
                        log_data
                    )
        except ImportError:
            pass  # Audit service not available
        
    except Exception as e:
        logger.error(f"Error logging org access: {e}")

# Import datetime for logging
from datetime import datetime
