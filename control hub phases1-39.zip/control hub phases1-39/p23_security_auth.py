"""
Security and Authentication Utilities
Phase 23: Password hashing, API key verification, role-based dependencies
Key responsibilities: Secure password handling, API key validation, RBAC enforcement
"""

import hashlib
import secrets
import logging
from fastapi import Request, HTTPException, Depends
from typing import Optional, List, Union

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p23__server_models_auth import User, ApiKey, UserRole, Role, get_user_by_api_key
except ImportError:
    logger.warning("Auth modules not found - using mock implementations")
    def get_session():
        return None
    
    class User:
        def __init__(self, **kwargs):
            self.id = 1
            self.email = kwargs.get('email', 'mock@example.com')
            self.name = kwargs.get('name', 'Mock User')
            self.active = True
        
        def has_role(self, role):
            return role == 'admin'
        
        def get_roles(self):
            return ['admin']
    
    class Role:
        ADMIN = 'admin'
        OPS = 'ops'
        VIEWER = 'viewer'
    
    def get_user_by_api_key(session, key):
        return User() if key == 'mock_key' else None

# Password hashing functions
def hash_password(password: str) -> str:
    """
    Hash a password using SHA256
    
    Args:
        password: Plain text password
    
    Returns:
        Hexadecimal hash string
    """
    if not password:
        raise ValueError("Password cannot be empty")
    
    # Add salt to prevent rainbow table attacks
    salt = "control_hub_salt_2024"  # In production, use per-user random salts
    salted_password = f"{salt}{password}{salt}"
    
    return hashlib.sha256(salted_password.encode()).hexdigest()

def verify_password(password: str, password_hash: str) -> bool:
    """
    Verify a password against its hash
    
    Args:
        password: Plain text password to verify
        password_hash: Stored hash to compare against
    
    Returns:
        True if password matches hash
    """
    if not password or not password_hash:
        return False
    
    return hash_password(password) == password_hash

# API Key functions
def make_api_key() -> tuple:
    """
    Generate a new API key
    
    Returns:
        Tuple of (plain_key, hash) for storage
    """
    plain_key = secrets.token_urlsafe(32)  # 32 bytes = 43 characters
    key_hash = hashlib.sha256(plain_key.encode()).hexdigest()
    
    return plain_key, key_hash

def verify_api_key(api_key_header: str) -> Optional[User]:
    """
    Verify an API key and return associated user
    
    Args:
        api_key_header: API key from X-API-Key header
    
    Returns:
        User object if key is valid, None otherwise
    """
    if not api_key_header:
        return None
    
    try:
        session = get_session()
        if not session:
            logger.warning("No database session for API key verification")
            # Mock verification for testing
            return User() if api_key_header == 'mock_key' else None
        
        with session:
            user = get_user_by_api_key(session, api_key_header)
            return user if user and user.active else None
    
    except Exception as e:
        logger.error(f"Error verifying API key: {e}")
        return None

# Authentication dependency functions
def get_api_key_from_header(request: Request) -> Optional[str]:
    """Extract API key from X-API-Key header"""
    return request.headers.get("X-API-Key")

def get_admin_token_from_header(request: Request) -> Optional[str]:
    """Extract admin token from Admin-Token header (legacy support)"""
    return request.headers.get("Admin-Token")

def optional_user_from_key(request: Request) -> Optional[User]:
    """
    Get user from API key if present, without requiring authentication
    
    Args:
        request: FastAPI request object
    
    Returns:
        User object if valid API key provided, None otherwise
    """
    api_key = get_api_key_from_header(request)
    if api_key:
        return verify_api_key(api_key)
    return None

def require_api_key(request: Request) -> User:
    """
    Require valid API key authentication
    
    Args:
        request: FastAPI request object
    
    Returns:
        Authenticated user
    
    Raises:
        HTTPException: If authentication fails
    """
    api_key = get_api_key_from_header(request)
    if not api_key:
        raise HTTPException(status_code=401, detail="API key required (X-API-Key header)")
    
    user = verify_api_key(api_key)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or inactive API key")
    
    return user

def require_role(*allowed_roles: str):
    """
    Create a dependency that requires specific roles
    Supports both API keys and legacy Admin-Token
    
    Args:
        allowed_roles: Roles that are allowed access
    
    Returns:
        FastAPI dependency function
    """
    def role_checker(request: Request) -> User:
        # Check legacy Admin-Token first (backward compatibility)
        admin_token = get_admin_token_from_header(request)
        if admin_token == "change-me":
            # Legacy admin token grants admin role
            logger.debug("Legacy admin token used")
            mock_admin = User(email="admin@legacy", name="Legacy Admin")
            mock_admin.get_roles = lambda: [Role.ADMIN]
            mock_admin.has_role = lambda role: role == Role.ADMIN
            
            # Check if admin role is allowed
            if Role.ADMIN in allowed_roles:
                return mock_admin
            else:
                raise HTTPException(
                    status_code=403, 
                    detail=f"Admin role not sufficient. Required roles: {', '.join(allowed_roles)}"
                )
        
        # Check API key authentication
        api_key = get_api_key_from_header(request)
        if not api_key:
            raise HTTPException(
                status_code=401, 
                detail=f"Authentication required. Use X-API-Key header or Admin-Token. Required roles: {', '.join(allowed_roles)}"
            )
        
        user = verify_api_key(api_key)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid or inactive API key")
        
        # Check if user has any of the required roles
        user_roles = user.get_roles()
        if not any(role in user_roles for role in allowed_roles):
            raise HTTPException(
                status_code=403, 
                detail=f"Insufficient privileges. Required roles: {', '.join(allowed_roles)}. Your roles: {', '.join(user_roles)}"
            )
        
        logger.debug(f"User {user.email} authenticated with roles: {user_roles}")
        return user
    
    return Depends(role_checker)

# Convenience role dependencies
def require_admin(request: Request) -> User:
    """Require admin role"""
    return require_role(Role.ADMIN)(request)

def require_ops_or_admin(request: Request) -> User:
    """Require ops or admin role"""
    return require_role(Role.OPS, Role.ADMIN)(request)

def require_any_role(request: Request) -> User:
    """Require any valid role (authenticated user)"""
    return require_role(Role.ADMIN, Role.OPS, Role.VIEWER)(request)

# User context functions
def get_current_user_context(request: Request) -> dict:
    """
    Get current user context for templates/logging
    
    Args:
        request: FastAPI request object
    
    Returns:
        Dictionary with user context information
    """
    # Try API key first
    user = optional_user_from_key(request)
    if user:
        return {
            "authenticated": True,
            "user_id": user.id,
            "email": user.email,
            "name": user.name,
            "roles": user.get_roles(),
            "auth_method": "api_key"
        }
    
    # Check legacy admin token
    admin_token = get_admin_token_from_header(request)
    if admin_token == "change-me":
        return {
            "authenticated": True,
            "user_id": None,
            "email": "admin@legacy",
            "name": "Legacy Admin",
            "roles": [Role.ADMIN],
            "auth_method": "legacy_token"
        }
    
    return {
        "authenticated": False,
        "user_id": None,
        "email": None,
        "name": None,
        "roles": [],
        "auth_method": None
    }

# Password validation
def validate_password(password: str) -> tuple:
    """
    Validate password strength
    
    Args:
        password: Password to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not password:
        return False, "Password is required"
    
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if len(password) > 128:
        return False, "Password must be less than 128 characters"
    
    # Check for at least one letter and one number
    has_letter = any(c.isalpha() for c in password)
    has_number = any(c.isdigit() for c in password)
    
    if not has_letter:
        return False, "Password must contain at least one letter"
    
    if not has_number:
        return False, "Password must contain at least one number"
    
    return True, None

# Session management helpers
def create_user_session(user: User) -> dict:
    """
    Create user session data
    
    Args:
        user: User object
    
    Returns:
        Session data dictionary
    """
    return {
        "user_id": user.id,
        "email": user.email,
        "name": user.name,
        "roles": user.get_roles(),
        "active": user.active,
        "created_at": user.created_at.isoformat() if hasattr(user, 'created_at') else None
    }

# Authorization helpers
def check_permission(user: User, resource: str, action: str) -> bool:
    """
    Check if user has permission for specific resource/action
    
    Args:
        user: User object
        resource: Resource type (e.g., 'leads', 'sites')
        action: Action type (e.g., 'read', 'write', 'delete')
    
    Returns:
        True if user has permission
    """
    user_roles = user.get_roles()
    
    # Admin can do everything
    if Role.ADMIN in user_roles:
        return True
    
    # Ops can read/write most resources
    if Role.OPS in user_roles:
        if action in ['read', 'write']:
            return resource in ['leads', 'buyers', 'sites', 'deployments', 'exports']
        elif action == 'delete':
            return resource in ['leads', 'buyers']  # Limited delete permissions
    
    # Viewer can only read
    if Role.VIEWER in user_roles:
        return action == 'read'
    
    return False

# Authentication status check
def get_auth_status() -> dict:
    """
    Get overall authentication system status
    Useful for health checks and debugging
    """
    try:
        session = get_session()
        if not session:
            return {"status": "no_database", "users": 0, "api_keys": 0}
        
        with session:
            user_count = session.query(User).count()
            active_user_count = session.query(User).filter(User.active == True).count()
            api_key_count = session.query(ApiKey).filter(ApiKey.active == True).count()
            
            return {
                "status": "active",
                "total_users": user_count,
                "active_users": active_user_count,
                "active_api_keys": api_key_count,
                "roles_supported": Role.all_roles()
            }
    
    except Exception as e:
        logger.error(f"Error getting auth status: {e}")
        return {"status": "error", "error": str(e)}
