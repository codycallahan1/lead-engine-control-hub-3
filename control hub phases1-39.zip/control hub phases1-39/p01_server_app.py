"""
Lead Engine Control Hub - Core FastAPI Application
Phase: 1
Purpose: Create FastAPI app with health/version endpoints, static files, templates, and basic routing
Key Responsibilities: 
- Initialize FastAPI app with proper configuration
- Mount static files and Jinja2 templates
- Provide health check and version endpoints
- Serve dashboard root route
"""

import logging
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Lead Engine Control Hub",
    description="Multi-phase lead management system",
    version="1.0.0"
)

# Mount static files (will serve from /static URL path)
try:
    static_path = Path(__file__).parent / "static"
    static_path.mkdir(exist_ok=True)
    app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
    logger.info("Static files mounted at /static")
except Exception as e:
    logger.warning(f"Could not mount static files: {e}")

# Initialize Jinja2 templates
try:
    templates_path = Path(__file__).parent / "templates"
    templates_path.mkdir(exist_ok=True)
    templates = Jinja2Templates(directory=str(templates_path))
    logger.info("Jinja2 templates initialized")
except Exception as e:
    logger.warning(f"Could not initialize templates: {e}")
    templates = None

@app.on_event("startup")
async def startup_event():
    """Log application startup"""
    logger.info("=== Lead Engine Control Hub Starting ===")
    logger.info("Phase 1: Core app with health/version endpoints")
    logger.info("Server ready for requests")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    logger.info("Health check requested")
    return {"status": "ok"}

@app.get("/version")
async def get_version():
    """Version information endpoint"""
    logger.info("Version info requested")
    return {
        "app": "Lead Engine Control Hub",
        "version": "1.0.0",
        "phase": 1,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/", response_class=HTMLResponse)
async def dashboard_root(request: Request):
    """Root dashboard endpoint"""
    logger.info("Dashboard root requested")
    
    if templates is None:
        return HTMLResponse(
            "<h1>Lead Engine Control Hub</h1><p>Templates not available</p>",
            status_code=200
        )
    
    try:
        context = {
            "request": request,
            "title": "Lead Engine Control Hub",
            "app_name": "Lead Engine Control Hub",
            "phase": 1,
            "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        }
        return templates.TemplateResponse("base.html", context)
    except Exception as e:
        logger.error(f"Template rendering error: {e}")
        return HTMLResponse(
            f"<h1>Lead Engine Control Hub</h1><p>Welcome to Phase 1</p><p>Error: {e}</p>",
            status_code=200
        )

if __name__ == "__main__":
    import uvicorn
    logger.info("Starting development server...")
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)
