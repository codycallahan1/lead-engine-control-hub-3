"""
Lead Engine Control Hub - Buyer Pull API Routes
Phase 35: API keys for buyers pull API
Purpose: Authenticated endpoints for buyers to pull lead data
"""

import logging
from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Request, Header
from pydantic import BaseModel, Field

# Import API key services and auth
try:
    from p35__server_services_apikeys import (
        create_api_key, rotate_api_key, deactivate_api_key, list_buyer_api_keys,
        get_api_key_usage_stats, authenticate_buyer_request, record_api_usage,
        InvalidApiKeyError, RateLimitExceededError, ApiKeyError
    )
    from p20__server_middleware_auth import require_role
    from p24__server_services_scope import current_org
    from p02__server_db import get_session
except ImportError:
    # Fallback for development
    def create_api_key(buyer_id, org_id, name, created_by="admin", expires_days=None):
        return None, "test-key"
    def rotate_api_key(key_id, org_id, rotated_by="admin"):
        return None, "new-test-key"
    def deactivate_api_key(key_id, org_id, deactivated_by="admin"):
        return True
    def list_buyer_api_keys(buyer_id, org_id, include_inactive=False):
        return []
    def get_api_key_usage_stats(key_id, org_id, days=30):
        return {"total_requests": 0}
    def authenticate_buyer_request(api_key_header):
        return 1, 1, None
    def record_api_usage(*args, **kwargs):
        pass
    def require_role(*roles):
        return lambda: None
    def current_org(request):
        return 1
    def get_session():
        pass
    
    class InvalidApiKeyError(Exception):
        pass
    class RateLimitExceededError(Exception):
        pass
    class ApiKeyError(Exception):
        pass

logger = logging.getLogger(__name__)

# Create routers
admin_router = APIRouter(prefix="/buyers", tags=["buyer-api-keys"])
buyer_router = APIRouter(prefix="/buyerapi", tags=["buyer-pull-api"])


# Request/Response models
class CreateApiKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="Human-readable name for the key")
    expires_days: Optional[int] = Field(None, gt=0, le=365, description="Optional expiration in days")


class ApiKeyResponse(BaseModel):
    id: int
    buyer_id: int
    name: str
    key_prefix: str
    active: bool
    last_used_at: Optional[str]
    usage_count: int
    rate_limit_per_hour: int
    rate_limit_per_day: int
    created_at: str
    expires_at: Optional[str]
    is_expired: bool
    is_usable: bool


class CreateApiKeyResponse(BaseModel):
    success: bool
    message: str
    api_key: ApiKeyResponse
    plain_key: str
    warning: str


# Admin API Key Management Routes
@admin_router.post("/{buyer_id}/keys")
async def create_buyer_api_key(
    buyer_id: int,
    request: Request,
    key_data: CreateApiKeyRequest,
    _: None = Depends(require_role("admin"))
):
    """
    Create a new API key for a buyer.
    
    Only admins can create API keys. The plain key is returned once
    and should be stored securely by the buyer.
    """
    try:
        org_id = current_org(request)
        
        # Create the API key
        api_key, plain_key = create_api_key(
            buyer_id=buyer_id,
            org_id=org_id,
            name=key_data.name,
            created_by="admin",  # Could extract from request.state.user
            expires_days=key_data.expires_days
        )
        
        logger.info(f"Created API key '{key_data.name}' for buyer {buyer_id}")
        
        return CreateApiKeyResponse(
            success=True,
            message=f"API key '{key_data.name}' created successfully",
            api_key=ApiKeyResponse(**api_key.to_dict()),
            plain_key=plain_key,
            warning="Store this key securely - it will not be shown again"
        )
        
    except ApiKeyError as e:
        logger.error(f"Failed to create API key for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
        
    except Exception as e:
        logger.error(f"Error creating API key for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to create API key")


@admin_router.post("/{buyer_id}/keys/rotate")
async def rotate_buyer_api_key(
    buyer_id: int,
    key_id: int,
    request: Request,
    _: None = Depends(require_role("admin"))
):
    """
    Rotate an existing API key (generate new key, keep same record).
    
    This invalidates the old key and generates a new one.
    """
    try:
        org_id = current_org(request)
        
        api_key, new_plain_key = rotate_api_key(
            key_id=key_id,
            org_id=org_id,
            rotated_by="admin"
        )
        
        logger.info(f"Rotated API key {key_id} for buyer {buyer_id}")
        
        return {
            "success": True,
            "message": f"API key '{api_key.name}' rotated successfully",
            "api_key": api_key.to_dict(),
            "plain_key": new_plain_key,
            "warning": "The old key is now invalid. Store the new key securely."
        }
        
    except ApiKeyError as e:
        logger.error(f"Failed to rotate API key {key_id}: {str(e)}")
        raise HTTPException(status_code=404, detail=str(e))
        
    except Exception as e:
        logger.error(f"Error rotating API key {key_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to rotate API key")


@admin_router.get("/{buyer_id}/keys")
async def list_buyer_api_keys_admin(
    buyer_id: int,
    request: Request,
    include_inactive: bool = False,
    _: None = Depends(require_role("admin"))
):
    """
    List all API keys for a buyer.
    
    Admins can view all keys including inactive ones.
    """
    try:
        org_id = current_org(request)
        
        keys = list_buyer_api_keys(
            buyer_id=buyer_id,
            org_id=org_id,
            include_inactive=include_inactive
        )
        
        return {
            "buyer_id": buyer_id,
            "keys": keys,
            "total": len(keys),
            "include_inactive": include_inactive
        }
        
    except Exception as e:
        logger.error(f"Error listing API keys for buyer {buyer_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to list API keys")


@admin_router.delete("/{buyer_id}/keys/{key_id}")
async def deactivate_buyer_api_key(
    buyer_id: int,
    key_id: int,
    request: Request,
    _: None = Depends(require_role("admin"))
):
    """
    Deactivate an API key.
    
    This disables the key without deleting the record for audit purposes.
    """
    try:
        org_id = current_org(request)
        
        success = deactivate_api_key(
            key_id=key_id,
            org_id=org_id,
            deactivated_by="admin"
        )
        
        if success:
            logger.info(f"Deactivated API key {key_id} for buyer {buyer_id}")
            return {
                "success": True,
                "message": f"API key {key_id} deactivated successfully"
            }
        else:
            raise HTTPException(status_code=404, detail="API key not found")
            
    except ApiKeyError as e:
        logger.error(f"Failed to deactivate API key {key_id}: {str(e)}")
        raise HTTPException(status_code=404, detail=str(e))
        
    except Exception as e:
        logger.error(f"Error deactivating API key {key_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to deactivate API key")


@admin_router.get("/{buyer_id}/keys/{key_id}/usage")
async def get_api_key_usage(
    buyer_id: int,
    key_id: int,
    request: Request,
    days: int = 30,
    _: None = Depends(require_role("admin"))
):
    """
    Get usage statistics for an API key.
    
    Returns request counts, success rates, and recent errors.
    """
    try:
        org_id = current_org(request)
        
        stats = get_api_key_usage_stats(
            key_id=key_id,
            org_id=org_id,
            days=days
        )
        
        return stats
        
    except ApiKeyError as e:
        logger.error(f"Failed to get usage stats for key {key_id}: {str(e)}")
        raise HTTPException(status_code=404, detail=str(e))
        
    except Exception as e:
        logger.error(f"Error getting usage stats for key {key_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get usage statistics")


# Buyer Pull API Routes (authenticated with API key)
async def authenticate_buyer(
    request: Request,
    x_api_key: Optional[str] = Header(None, alias="X-API-Key")
) -> tuple:
    """
    Dependency to authenticate buyer requests using API key.
    
    Returns:
        Tuple of (buyer_id, org_id, api_key_record)
    """
    start_time = datetime.utcnow()
    
    try:
        buyer_id, org_id, api_key = authenticate_buyer_request(x_api_key)
        
        # Store authentication info in request state
        request.state.buyer_id = buyer_id
        request.state.org_id = org_id
        request.state.api_key = api_key
        request.state.auth_time = datetime.utcnow()
        
        return buyer_id, org_id, api_key
        
    except InvalidApiKeyError as e:
        # Record failed authentication attempt
        record_api_usage(
            api_key=None,  # No valid key
            endpoint=str(request.url.path),
            method=request.method,
            status_code=401,
            error_message=str(e),
            ip_address=request.client.host if hasattr(request, 'client') else None,
            user_agent=request.headers.get("user-agent")
        )
        
        raise HTTPException(status_code=401, detail=str(e))
        
    except RateLimitExceededError as e:
        # Record rate limit exceeded
        record_api_usage(
            api_key=None,
            endpoint=str(request.url.path),
            method=request.method,
            status_code=429,
            error_message=str(e),
            ip_address=request.client.host if hasattr(request, 'client') else None,
            user_agent=request.headers.get("user-agent")
        )
        
        raise HTTPException(status_code=429, detail=str(e))


@buyer_router.get("/leads")
async def get_buyer_leads(
    request: Request,
    since: Optional[str] = None,
    limit: int = 50,
    auth_data: tuple = Depends(authenticate_buyer)
):
    """
    Get leads assigned to the authenticated buyer.
    
    Returns leads that were successfully dispatched to this buyer
    since the specified timestamp.
    """
    start_time = datetime.utcnow()
    buyer_id, org_id, api_key = auth_data
    
    try:
        # Validate parameters
        if limit > 1000:
            limit = 1000
        if limit < 1:
            limit = 50
        
        # Parse since parameter
        since_date = None
        if since:
            try:
                since_date = datetime.fromisoformat(since.replace('Z', '+00:00'))
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid since parameter format")
        
        # Default to last 24 hours if no since parameter
        if not since_date:
            since_date = datetime.utcnow() - timedelta(hours=24)
        
        # Query for leads (this would integrate with existing dispatch/matching system)
        with get_session() as session:
            # This would query DispatchLog for successful dispatches to this buyer
            # For now, return mock data structure
            
            leads = []  # Would contain actual lead data
            
            # Apply org scoping and buyer filtering
            # leads = session.query(Lead).join(DispatchLog).filter(
            #     DispatchLog.buyer_id == buyer_id,
            #     DispatchLog.org_id == org_id,
            #     DispatchLog.status == "delivered",
            #     DispatchLog.created_at >= since_date
            # ).limit(limit).all()
            
            response_time_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
            
            # Record successful API usage
            record_api_usage(
                api_key=api_key,
                endpoint=request.url.path,
                method=request.method,
                status_code=200,
                response_time_ms=response_time_ms,
                records_returned=len(leads),
                ip_address=request.client.host if hasattr(request, 'client') else None,
                user_agent=request.headers.get("user-agent")
            )
            
            return {
                "buyer_id": buyer_id,
                "leads": [
                    # Would contain lead data with PII redaction applied
                ],
                "count": len(leads),
                "since": since_date.isoformat(),
                "limit": limit,
                "has_more": len(leads) == limit,
                "next_since": datetime.utcnow().isoformat() if leads else None
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving leads for buyer {buyer_id}: {str(e)}")
        
        # Record API error
        record_api_usage(
            api_key=api_key,
            endpoint=request.url.path,
            method=request.method,
            status_code=500,
            error_message=str(e),
            ip_address=request.client.host if hasattr(request, 'client') else None,
            user_agent=request.headers.get("user-agent")
        )
        
        raise HTTPException(status_code=500, detail="Failed to retrieve leads")


@buyer_router.get("/me")
async def get_buyer_info(
    request: Request,
    auth_data: tuple = Depends(authenticate_buyer)
):
    """
    Get information about the authenticated buyer.
    
    Returns buyer details and API key usage information.
    """
    start_time = datetime.utcnow()
    buyer_id, org_id, api_key = auth_data
    
    try:
        # Get buyer information (would query Buyer model)
        buyer_info = {
            "buyer_id": buyer_id,
            "org_id": org_id,
            "api_key_name": api_key.name if api_key else "Unknown",
            "api_key_usage": {
                "last_used": api_key.last_used_at.isoformat() if api_key and api_key.last_used_at else None,
                "total_usage": api_key.usage_count if api_key else 0,
                "rate_limits": {
                    "per_hour": api_key.rate_limit_per_hour if api_key else 1000,
                    "per_day": api_key.rate_limit_per_day if api_key else 10000
                }
            },
            "authenticated_at": request.state.auth_time.isoformat() if hasattr(request.state, 'auth_time') else None
        }
        
        response_time_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        
        # Record API usage
        record_api_usage(
            api_key=api_key,
            endpoint=request.url.path,
            method=request.method,
            status_code=200,
            response_time_ms=response_time_ms,
            records_returned=1,
            ip_address=request.client.host if hasattr(request, 'client') else None,
            user_agent=request.headers.get("user-agent")
        )
        
        return buyer_info
        
    except Exception as e:
        logger.error(f"Error retrieving buyer info for {buyer_id}: {str(e)}")
        
        # Record API error
        record_api_usage(
            api_key=api_key,
            endpoint=request.url.path,
            method=request.method,
            status_code=500,
            error_message=str(e),
            ip_address=request.client.host if hasattr(request, 'client') else None,
            user_agent=request.headers.get("user-agent")
        )
        
        raise HTTPException(status_code=500, detail="Failed to retrieve buyer information")


# Include routers in main app
def include_buyer_api_routes(app):
    """Include buyer API routes in the main FastAPI app."""
    app.include_router(admin_router)
    app.include_router(buyer_router)
    logger.info("Buyer API routes registered")