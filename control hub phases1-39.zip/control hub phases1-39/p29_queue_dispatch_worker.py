"""
Dispatch worker for queue system - handles lead delivery to buyer webhooks.

Phase: 29
Purpose: Background job to execute lead dispatch with retry logic.
Key responsibilities:
- Process dispatch jobs asynchronously
- Handle webhook delivery with exponential backoff
- Update dispatch logs with results
"""

import logging
from typing import Dict, Any

try:
    from p29__server_services_dispatch import dispatch_with_retries
    from p07__server_services_queue import register
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Dispatch worker: missing dependency {e}")

logger = logging.getLogger(__name__)


def dispatch_lead_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Worker function to dispatch a lead to a buyer endpoint.
    
    Args:
        payload: {
            "lead_id": int,
            "endpoint_id": int,
            "match_log_id": int (optional),
            "force": bool (optional),
            "actor": str (optional)
        }
    
    Returns:
        {"success": bool, "dispatch_log_id": int, "status": str, ...}
    """
    lead_id = payload.get('lead_id')
    endpoint_id = payload.get('endpoint_id')
    match_log_id = payload.get('match_log_id')
    force = payload.get('force', False)
    actor = payload.get('actor', 'system')
    
    if not lead_id or not endpoint_id:
        raise ValueError("lead_id and endpoint_id required in payload")
    
    logger.info(f"Processing dispatch job: lead {lead_id} -> endpoint {endpoint_id}")
    
    try:
        # Execute the dispatch with retries
        dispatch_log = dispatch_with_retries(lead_id, endpoint_id)
        
        if not dispatch_log:
            raise Exception("No dispatch log returned from dispatch_with_retries")
        
        # Prepare result
        result = {
            "success": dispatch_log.is_success(),
            "dispatch_log_id": dispatch_log.id,
            "status": dispatch_log.status,
            "attempts": dispatch_log.attempts,
            "response_code": dispatch_log.response_code,
            "response_time_ms": dispatch_log.response_time_ms,
            "last_error": dispatch_log.last_error,
            "lead_id": lead_id,
            "endpoint_id": endpoint_id
        }
        
        # Enhanced audit logging
        audit_kind = "dispatch_job_completed"
        audit_message = f"Dispatch job completed: lead {lead_id} -> endpoint {endpoint_id} ({dispatch_log.status})"
        
        if dispatch_log.is_success():
            audit_kind = "dispatch_job_success"
            audit_message = f"Lead {lead_id} successfully dispatched to endpoint {endpoint_id}"
        elif dispatch_log.status == "failed":
            audit_kind = "dispatch_job_failed"
            audit_message = f"Lead {lead_id} dispatch failed to endpoint {endpoint_id}: {dispatch_log.last_error}"
        
        audit(
            kind=audit_kind,
            message=audit_message,
            meta={
                "job_type": "dispatch_lead",
                "actor": actor,
                "force": force,
                "match_log_id": match_log_id,
                **result
            }
        )
        
        # Log completion
        if dispatch_log.is_success():
            logger.info(f"Dispatch job successful: {result}")
        else:
            logger.warning(f"Dispatch job failed: {result}")
        
        return result
    
    except Exception as e:
        logger.error(f"Dispatch job failed for lead {lead_id}: {e}")
        
        # Audit the failure
        audit(
            kind="dispatch_job_error",
            message=f"Dispatch job error for lead {lead_id}: {str(e)}",
            meta={
                "job_type": "dispatch_lead",
                "lead_id": lead_id,
                "endpoint_id": endpoint_id,
                "actor": actor,
                "error": str(e)
            }
        )
        
        return {
            "success": False,
            "error": str(e),
            "lead_id": lead_id,
            "endpoint_id": endpoint_id,
            "dispatch_log_id": None,
            "status": "error"
        }


def init_dispatch_queue():
    """Register the dispatch worker with the queue system."""
    try:
        register("dispatch_lead", dispatch_lead_worker)
        logger.info("Dispatch worker registered with queue system")
    except Exception as e:
        logger.error(f"Failed to register dispatch worker: {e}")


# Auto-register when imported
if __name__ != "__main__":
    init_dispatch_queue()


# Example job payloads for documentation
EXAMPLE_PAYLOADS = {
    "automatic_dispatch": {
        "lead_id": 123,
        "endpoint_id": 456,
        "match_log_id": 789,
        "force": False,
        "actor": "system"
    },
    "manual_force_dispatch": {
        "lead_id": 123,
        "endpoint_id": 456,
        "force": True,
        "actor": "admin@company.com"
    },
    "retry_failed_dispatch": {
        "lead_id": 123,
        "endpoint_id": 456,
        "force": True,
        "actor": "ops_team"
    }
}


def example_queue_integration():
    """
    Example of how to enqueue dispatch jobs from other services.
    
    ```python
    from p07__server_services_queue import enqueue
    
    # Automatic dispatch after matching
    job_id = enqueue("dispatch_lead", {
        "lead_id": 123,
        "endpoint_id": 456,
        "match_log_id": 789
    })
    
    # Manual force dispatch
    job_id = enqueue("dispatch_lead", {
        "lead_id": 123,
        "endpoint_id": 456,
        "force": True,
        "actor": "admin@company.com"
    })
    ```
    """
    pass