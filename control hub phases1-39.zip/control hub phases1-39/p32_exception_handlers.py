"""
Lead Engine Control Hub - Global Exception Handlers
Phase 32: Observability infrastructure
Purpose: User-friendly error pages with request correlation and audit logging
"""

import logging
from typing import Union

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from starlette.exceptions import HTTPException as StarletteHTTPException

logger = logging.getLogger(__name__)

# Try to import audit service (may not be available in early phases)
try:
    from p08__server_services_audit import audit
except ImportError:
    def audit(kind: str, message: str, meta: dict = None):
        """Fallback audit function if service not available."""
        logger.info(f"AUDIT[{kind}]: {message}", extra=meta or {})


def get_request_id(request: Request) -> str:
    """Extract request ID from request state."""
    return getattr(request.state, 'request_id', 'unknown')


def is_api_route(path: str) -> bool:
    """Determine if this is an API route (should return JSON) vs UI route (HTML)."""
    api_prefixes = [
        '/api/', '/leads', '/buyers', '/sites', '/deployments', '/webhooks',
        '/matching', '/export', '/import', '/metrics', '/jarvis', '/auth',
        '/orgs', '/privacy', '/maintenance', '/tokens', '/audit', '/dispatch',
        '/reports', '/abuse', '/settings'
    ]
    return any(path.startswith(prefix) for prefix in api_prefixes)


async def http_exception_handler(request: Request, exc: HTTPException) -> Union[JSONResponse, HTMLResponse]:
    """
    Handle HTTP exceptions with appropriate response format.
    Returns JSON for API routes, HTML for UI routes.
    """
    request_id = get_request_id(request)
    status_code = exc.status_code
    detail = exc.detail
    path = request.url.path
    
    # Log the exception
    logger.warning(
        f"HTTP {status_code}: {detail}",
        extra={
            "request_id": request_id,
            "status_code": status_code,
            "path": path,
            "event": "http_exception"
        }
    )
    
    # Return appropriate response format
    if is_api_route(path):
        # JSON response for API routes
        return JSONResponse(
            status_code=status_code,
            content={
                "error": "http_error",
                "status_code": status_code,
                "message": detail,
                "request_id": request_id
            },
            headers={"X-Request-ID": request_id}
        )
    else:
        # HTML response for UI routes
        try:
            # Try to use templates (may not be available in early phases)
            templates = Jinja2Templates(directory="templates")
            
            if status_code == 404:
                template_name = "404.html"
                title = "Page Not Found"
            elif status_code == 403:
                template_name = "403.html"
                title = "Access Denied"
            else:
                template_name = "error.html"
                title = f"Error {status_code}"
            
            return templates.TemplateResponse(
                template_name,
                {
                    "request": request,
                    "status_code": status_code,
                    "message": detail,
                    "request_id": request_id,
                    "title": title
                },
                status_code=status_code,
                headers={"X-Request-ID": request_id}
            )
        except Exception:
            # Fallback to simple HTML if templates fail
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Error {status_code}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; background: #1a1a1a; color: #fff; }}
                    .error-container {{ max-width: 600px; margin: 0 auto; text-align: center; }}
                    .error-code {{ font-size: 72px; font-weight: bold; color: #ff6b6b; margin-bottom: 20px; }}
                    .error-message {{ font-size: 18px; margin-bottom: 30px; }}
                    .request-id {{ font-size: 12px; color: #888; }}
                    a {{ color: #4dabf7; text-decoration: none; }}
                    a:hover {{ text-decoration: underline; }}
                </style>
            </head>
            <body>
                <div class="error-container">
                    <div class="error-code">{status_code}</div>
                    <div class="error-message">{detail}</div>
                    <p><a href="/">← Back to Home</a></p>
                    <div class="request-id">Request ID: {request_id}</div>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(
                content=html_content,
                status_code=status_code,
                headers={"X-Request-ID": request_id}
            )


async def general_exception_handler(request: Request, exc: Exception) -> Union[JSONResponse, HTMLResponse]:
    """
    Handle unexpected exceptions (500 errors).
    Logs full exception details but returns sanitized response to user.
    """
    request_id = get_request_id(request)
    path = request.url.path
    
    # Log the full exception details
    logger.error(
        f"Unhandled exception: {str(exc)}",
        exc_info=True,
        extra={
            "request_id": request_id,
            "path": path,
            "event": "unhandled_exception",
            "exception_type": type(exc).__name__
        }
    )
    
    # Audit 5xx errors
    audit(
        kind="server_error",
        message=f"500 error on {path}",
        meta={
            "request_id": request_id,
            "path": path,
            "exception_type": type(exc).__name__
        }
    )
    
    # Sanitized error message (don't leak internal details)
    user_message = "An internal server error occurred. Please try again later."
    
    if is_api_route(path):
        # JSON response for API routes
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal_server_error",
                "status_code": 500,
                "message": user_message,
                "request_id": request_id
            },
            headers={"X-Request-ID": request_id}
        )
    else:
        # HTML response for UI routes
        try:
            templates = Jinja2Templates(directory="templates")
            return templates.TemplateResponse(
                "500.html",
                {
                    "request": request,
                    "message": user_message,
                    "request_id": request_id,
                    "title": "Server Error"
                },
                status_code=500,
                headers={"X-Request-ID": request_id}
            )
        except Exception:
            # Fallback HTML
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Server Error</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; background: #1a1a1a; color: #fff; }}
                    .error-container {{ max-width: 600px; margin: 0 auto; text-align: center; }}
                    .error-code {{ font-size: 72px; font-weight: bold; color: #ff6b6b; margin-bottom: 20px; }}
                    .error-message {{ font-size: 18px; margin-bottom: 30px; }}
                    .request-id {{ font-size: 12px; color: #888; }}
                    a {{ color: #4dabf7; text-decoration: none; }}
                    a:hover {{ text-decoration: underline; }}
                </style>
            </head>
            <body>
                <div class="error-container">
                    <div class="error-code">500</div>
                    <div class="error-message">{user_message}</div>
                    <p><a href="/">← Back to Home</a></p>
                    <div class="request-id">Request ID: {request_id}</div>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(
                content=html_content,
                status_code=500,
                headers={"X-Request-ID": request_id}
            )


def add_exception_handlers(app: FastAPI):
    """
    Register global exception handlers with the FastAPI app.
    """
    # HTTP exceptions (4xx, 5xx status codes)
    app.add_exception_handler(HTTPException, http_exception_handler)
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    
    # General exceptions (unhandled errors -> 500)
    app.add_exception_handler(Exception, general_exception_handler)
    
    logger.info("Global exception handlers registered")
