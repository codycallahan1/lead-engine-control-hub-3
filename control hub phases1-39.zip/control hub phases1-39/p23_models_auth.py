"""
Enhanced Authentication Models for RBAC
Phase 23: User accounts, API keys, and role-based access control
Key responsibilities: User management, API key generation, role assignment
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import hashlib
import secrets

# Import base from existing models or create if needed
try:
    from p02__server_db import Base
except ImportError:
    Base = declarative_base()

class User(Base):
    """
    User account for RBAC system
    Supports login credentials and API key management
    """
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    password_hash = Column(String(64), nullable=False)  # SHA256 hash
    active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Relationships
    api_keys = relationship("ApiKey", back_populates="user", cascade="all, delete-orphan")
    roles = relationship("UserRole", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(email='{self.email}', name='{self.name}', active={self.active})>"
    
    def to_dict(self, include_sensitive=False):
        """Convert to dictionary for JSON serialization"""
        result = {
            "id": self.id,
            "email": self.email,
            "name": self.name,
            "active": self.active,
            "created_at": self.created_at.isoformat(),
            "roles": [role.role for role in self.roles] if self.roles else []
        }
        
        if include_sensitive:
            result["api_keys_count"] = len(self.api_keys) if self.api_keys else 0
        
        return result
    
    def has_role(self, role: str) -> bool:
        """Check if user has specific role"""
        return any(user_role.role == role for user_role in self.roles)
    
    def get_roles(self) -> list:
        """Get list of user roles"""
        return [user_role.role for user_role in self.roles]

class ApiKey(Base):
    """
    API key for programmatic access
    Keys are hashed for security, plain text shown only once
    """
    __tablename__ = "api_keys"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    key_hash = Column(String(64), unique=True, index=True, nullable=False)  # SHA256 hash
    label = Column(String(100), nullable=False)  # Human-readable description
    active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_used_at = Column(DateTime)  # Track usage
    
    # Relationships
    user = relationship("User", back_populates="api_keys")
    
    def __repr__(self):
        return f"<ApiKey(user_id={self.user_id}, label='{self.label}', active={self.active})>"
    
    def to_dict(self, include_key=False):
        """Convert to dictionary for JSON serialization"""
        result = {
            "id": self.id,
            "user_id": self.user_id,
            "label": self.label,
            "active": self.active,
            "created_at": self.created_at.isoformat(),
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
            "key_preview": f"{self.key_hash[:8]}..." if self.key_hash else None
        }
        
        # Only include actual key on creation
        if include_key and hasattr(self, '_plain_key'):
            result["key"] = self._plain_key
        
        return result
    
    @classmethod
    def generate_key(cls):
        """Generate a secure API key"""
        return secrets.token_urlsafe(32)  # 32 bytes = 43 characters base64
    
    @classmethod
    def hash_key(cls, plain_key: str) -> str:
        """Hash an API key for storage"""
        return hashlib.sha256(plain_key.encode()).hexdigest()
    
    @classmethod
    def create_key(cls, user_id: int, label: str):
        """Create a new API key with generated key"""
        plain_key = cls.generate_key()
        key_hash = cls.hash_key(plain_key)
        
        api_key = cls(
            user_id=user_id,
            key_hash=key_hash,
            label=label,
            active=True,
            created_at=datetime.utcnow()
        )
        
        # Store plain key temporarily for return
        api_key._plain_key = plain_key
        
        return api_key
    
    def verify_key(self, plain_key: str) -> bool:
        """Verify a plain key against this API key"""
        return self.active and self.hash_key(plain_key) == self.key_hash
    
    def mark_used(self):
        """Update last used timestamp"""
        self.last_used_at = datetime.utcnow()

class UserRole(Base):
    """
    Role assignment for users
    Supports multiple roles per user
    """
    __tablename__ = "user_roles"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    role = Column(String(50), nullable=False, index=True)
    
    # Relationships
    user = relationship("User", back_populates="roles")
    
    def __repr__(self):
        return f"<UserRole(user_id={self.user_id}, role='{self.role}')>"
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "role": self.role
        }

# Role constants
class Role:
    """Constants for system roles"""
    ADMIN = "admin"
    OPS = "ops"
    VIEWER = "viewer"
    
    @classmethod
    def all_roles(cls):
        return [cls.ADMIN, cls.OPS, cls.VIEWER]
    
    @classmethod
    def is_valid(cls, role: str) -> bool:
        return role in cls.all_roles()
    
    @classmethod
    def get_description(cls, role: str) -> str:
        descriptions = {
            cls.ADMIN: "Full system access including user management",
            cls.OPS: "Operational access to exports, deployments, and data management",
            cls.VIEWER: "Read-only access to data and metrics"
        }
        return descriptions.get(role, "Unknown role")

# Utility functions
def create_default_admin_user(session, email: str = "admin@example.com", 
                             name: str = "Admin User", password: str = "admin123"):
    """
    Create default admin user if none exists
    Used during system initialization
    """
    from p23__server_security_auth import hash_password
    
    existing_admin = session.query(User).join(UserRole).filter(
        UserRole.role == Role.ADMIN
    ).first()
    
    if existing_admin:
        return existing_admin
    
    # Create admin user
    admin_user = User(
        email=email,
        name=name,
        password_hash=hash_password(password),
        active=True,
        created_at=datetime.utcnow()
    )
    
    session.add(admin_user)
    session.flush()  # Get ID
    
    # Assign admin role
    admin_role = UserRole(user_id=admin_user.id, role=Role.ADMIN)
    session.add(admin_role)
    
    session.commit()
    return admin_user

def get_user_by_email(session, email: str):
    """Get user by email address"""
    return session.query(User).filter(User.email == email.lower()).first()

def get_user_by_api_key(session, plain_key: str):
    """Get user by API key"""
    key_hash = ApiKey.hash_key(plain_key)
    
    api_key = session.query(ApiKey).filter(
        ApiKey.key_hash == key_hash,
        ApiKey.active == True
    ).first()
    
    if api_key:
        # Update last used timestamp
        api_key.mark_used()
        session.commit()
        return api_key.user
    
    return None

def assign_role_to_user(session, user_id: int, role: str):
    """Assign a role to a user"""
    if not Role.is_valid(role):
        raise ValueError(f"Invalid role: {role}")
    
    # Check if role already exists
    existing = session.query(UserRole).filter(
        UserRole.user_id == user_id,
        UserRole.role == role
    ).first()
    
    if existing:
        return existing
    
    # Create new role assignment
    user_role = UserRole(user_id=user_id, role=role)
    session.add(user_role)
    session.commit()
    return user_role

def remove_role_from_user(session, user_id: int, role: str):
    """Remove a role from a user"""
    user_role = session.query(UserRole).filter(
        UserRole.user_id == user_id,
        UserRole.role == role
    ).first()
    
    if user_role:
        session.delete(user_role)
        session.commit()
        return True
    
    return False

# Ensure table creation helper
def create_auth_tables(engine):
    """Create authentication tables if they don't exist"""
    try:
        User.__table__.create(engine, checkfirst=True)
        ApiKey.__table__.create(engine, checkfirst=True)
        UserRole.__table__.create(engine, checkfirst=True)
        return True
    except Exception as e:
        print(f"Error creating auth tables: {e}")
        return False
