"""
Rate limiting middleware with in-memory token bucket implementation.

Phase: 31
Purpose: Protect endpoints from abuse with configurable rate limits.
Key responsibilities:
- Token bucket rate limiting per IP and route
- Different limits for different endpoint types
- Rate limit headers and 429 responses
"""

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response
from fastapi import Request
import time
import logging
from typing import Dict, Tuple, Optional
from collections import defaultdict
import threading

logger = logging.getLogger(__name__)

# Rate limit configurations (requests per minute)
RATE_LIMITS = {
    # Public endpoints - stricter limits
    "/ingest": 60,
    "/ingest/": 60,
    "/ingest/form": 60,
    "/ingest/lead": 60,
    
    # Jarvis assistant - moderate limits
    "/jarvis": 30,
    "/jarvis/": 30,
    "/jarvis/message": 30,
    "/jarvis/history": 30,
    
    # Admin/ops endpoints - relaxed limits
    "admin_ops": 120,  # Default for authenticated admin/ops routes
    
    # Default for other routes
    "default": 60
}

# Exempt routes that should never be rate limited
EXEMPT_ROUTES = {
    "/health",
    "/version",
    "/metrics/summary",
    "/docs",
    "/openapi.json",
    "/redoc"
}

# Routes that get admin/ops limits
ADMIN_ROUTES_PREFIXES = {
    "/matching",
    "/buyers",
    "/sites",
    "/dispatch",
    "/reports",
    "/maintenance",
    "/privacy",
    "/webhooks",
    "/abuse"
}


class TokenBucket:
    """Token bucket for rate limiting."""
    
    def __init__(self, capacity: int, refill_rate: float):
        """
        Initialize token bucket.
        
        Args:
            capacity: Maximum number of tokens
            refill_rate: Tokens added per second
        """
        self.capacity = capacity
        self.tokens = capacity
        self.refill_rate = refill_rate
        self.last_refill = time.time()
        self.lock = threading.Lock()
    
    def consume(self, tokens: int = 1) -> bool:
        """
        Try to consume tokens from bucket.
        
        Args:
            tokens: Number of tokens to consume
        
        Returns:
            True if tokens were consumed, False if insufficient tokens
        """
        with self.lock:
            now = time.time()
            
            # Add tokens based on time passed
            time_passed = now - self.last_refill
            tokens_to_add = time_passed * self.refill_rate
            self.tokens = min(self.capacity, self.tokens + tokens_to_add)
            self.last_refill = now
            
            # Check if we can consume the requested tokens
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            else:
                return False
    
    def get_remaining(self) -> int:
        """Get number of remaining tokens (approximate)."""
        with self.lock:
            now = time.time()
            time_passed = now - self.last_refill
            tokens_to_add = time_passed * self.refill_rate
            current_tokens = min(self.capacity, self.tokens + tokens_to_add)
            return int(current_tokens)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware using token buckets."""
    
    def __init__(self, app):
        super().__init__(app)
        # Storage: {(ip, path_key): TokenBucket}
        self.buckets: Dict[Tuple[str, str], TokenBucket] = {}
        self.buckets_lock = threading.Lock()
        
        # Cleanup old buckets periodically
        self.last_cleanup = time.time()
        self.cleanup_interval = 300  # 5 minutes
    
    async def dispatch(self, request: Request, call_next):
        """Process request with rate limiting."""
        
        path = request.url.path
        method = request.method
        
        # Skip rate limiting for exempt routes
        if self._is_exempt_route(path):
            return await call_next(request)
        
        # Get client IP
        client_ip = self._get_client_ip(request)
        
        # Determine rate limit for this path
        limit_per_minute, path_key = self._get_rate_limit(path, method)
        
        # Get or create token bucket
        bucket = self._get_bucket(client_ip, path_key, limit_per_minute)
        
        # Try to consume a token
        if not bucket.consume():
            # Rate limit exceeded
            remaining = 0
            retry_after = 60  # Suggest retry in 60 seconds
            
            logger.warning(f"Rate limit exceeded for {client_ip} on {path}")
            
            # Return appropriate response based on content type
            if self._wants_json(request):
                return JSONResponse(
                    status_code=429,
                    content={
                        "error": "rate_limit",
                        "message": "Rate limit exceeded",
                        "retry_after": retry_after
                    },
                    headers={
                        "X-RateLimit-Limit": str(limit_per_minute),
                        "X-RateLimit-Remaining": str(remaining),
                        "Retry-After": str(retry_after)
                    }
                )
            else:
                # Return simple text response for non-JSON requests
                return Response(
                    content="Rate limit exceeded. Please try again later.",
                    status_code=429,
                    headers={
                        "X-RateLimit-Limit": str(limit_per_minute),
                        "X-RateLimit-Remaining": str(remaining),
                        "Retry-After": str(retry_after),
                        "Content-Type": "text/plain"
                    }
                )
        
        # Process request normally
        response = await call_next(request)
        
        # Add rate limit headers
        remaining = bucket.get_remaining()
        response.headers["X-RateLimit-Limit"] = str(limit_per_minute)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        
        # Cleanup old buckets periodically
        self._periodic_cleanup()
        
        return response
    
    def _is_exempt_route(self, path: str) -> bool:
        """Check if route is exempt from rate limiting."""
        return path in EXEMPT_ROUTES or path.startswith("/static/")
    
    def _get_client_ip(self, request: Request) -> str:
        """Extract client IP address."""
        # Check for forwarded headers first (for reverse proxies)
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            # Take the first IP in the chain
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        # Fall back to direct client IP
        if hasattr(request, "client") and request.client:
            return request.client.host
        
        return "unknown"
    
    def _get_rate_limit(self, path: str, method: str) -> Tuple[int, str]:
        """
        Determine rate limit and path key for a given path.
        
        Returns:
            Tuple of (limit_per_minute, path_key)
        """
        # Check specific path matches first
        for route_path, limit in RATE_LIMITS.items():
            if route_path in {"admin_ops", "default"}:
                continue
            if path.startswith(route_path):
                return limit, route_path
        
        # Check if it's an admin/ops route
        for prefix in ADMIN_ROUTES_PREFIXES:
            if path.startswith(prefix):
                return RATE_LIMITS["admin_ops"], "admin_ops"
        
        # Default rate limit
        return RATE_LIMITS["default"], "default"
    
    def _get_bucket(self, client_ip: str, path_key: str, limit_per_minute: int) -> TokenBucket:
        """Get or create token bucket for client and path."""
        bucket_key = (client_ip, path_key)
        
        with self.buckets_lock:
            if bucket_key not in self.buckets:
                # Create new bucket
                # Convert per-minute limit to per-second refill rate
                refill_rate = limit_per_minute / 60.0
                capacity = min(limit_per_minute, 10)  # Allow small bursts
                
                self.buckets[bucket_key] = TokenBucket(capacity, refill_rate)
            
            return self.buckets[bucket_key]
    
    def _wants_json(self, request: Request) -> bool:
        """Determine if request expects JSON response."""
        accept = request.headers.get("accept", "")
        content_type = request.headers.get("content-type", "")
        
        return (
            "application/json" in accept or
            "application/json" in content_type or
            request.url.path.startswith("/api/") or
            request.url.path.startswith("/jarvis/")
        )
    
    def _periodic_cleanup(self):
        """Clean up old unused buckets."""
        now = time.time()
        
        if now - self.last_cleanup < self.cleanup_interval:
            return
        
        with self.buckets_lock:
            # Remove buckets that haven't been used recently
            cutoff_time = now - 3600  # 1 hour
            keys_to_remove = []
            
            for key, bucket in self.buckets.items():
                if bucket.last_refill < cutoff_time:
                    keys_to_remove.append(key)
            
            for key in keys_to_remove:
                del self.buckets[key]
            
            if keys_to_remove:
                logger.info(f"Cleaned up {len(keys_to_remove)} old rate limit buckets")
            
            self.last_cleanup = now
    
    def get_stats(self) -> Dict:
        """Get rate limiting statistics."""
        with self.buckets_lock:
            total_buckets = len(self.buckets)
            
            # Count by path type
            path_stats = defaultdict(int)
            for (ip, path_key), bucket in self.buckets.items():
                path_stats[path_key] += 1
            
            return {
                "total_active_buckets": total_buckets,
                "buckets_by_path": dict(path_stats),
                "rate_limits": RATE_LIMITS.copy(),
                "exempt_routes": list(EXEMPT_ROUTES)
            }


def create_rate_limit_middleware():
    """Factory function to create rate limit middleware."""
    return RateLimitMiddleware


# Configuration for different deployment scenarios
def get_rate_limit_config(environment: str = "production") -> Dict:
    """Get rate limit configuration for different environments."""
    
    configs = {
        "development": {
            "/ingest": 120,  # More relaxed for testing
            "/jarvis": 60,
            "admin_ops": 240,
            "default": 120
        },
        "testing": {
            "/ingest": 1000,  # Very relaxed for tests
            "/jarvis": 1000,
            "admin_ops": 1000,
            "default": 1000
        },
        "production": RATE_LIMITS.copy()
    }
    
    return configs.get(environment, RATE_LIMITS)


def apply_rate_limit_config(config: Dict):
    """Apply custom rate limit configuration."""
    global RATE_LIMITS
    RATE_LIMITS.update(config)
    logger.info(f"Applied custom rate limit configuration: {config}")
