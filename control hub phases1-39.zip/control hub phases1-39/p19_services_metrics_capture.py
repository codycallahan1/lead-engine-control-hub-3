"""
Metrics Capture Service
Phase 19: Daily snapshot creation for historical metrics tracking
Key responsibilities: Count current records, create/update daily snapshots
"""

import logging
from datetime import datetime, date, timezone
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer, Site
    from p19__server_models_metrics_snapshots import MetricsSnapshot
    # Try to import sales and deployment models from later phases
    try:
        from p14__server_models_sales import LeadSale
    except ImportError:
        LeadSale = None
    
    try:
        from p06__server_models_deployments import Deployment
    except ImportError:
        Deployment = None
        
except ImportError:
    logger.warning("Database modules not found - using mock implementations")
    def get_session():
        return None
    
    class Lead:
        pass
    class Buyer:
        pass
    class Site:
        pass
    class MetricsSnapshot:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    LeadSale = None
    Deployment = None

def get_current_counts() -> Dict[str, int]:
    """
    Get current counts of all entities
    Returns dictionary with counts for each entity type
    """
    counts = {
        "leads": 0,
        "buyers": 0,
        "sites": 0,
        "sales": 0,
        "deployments": 0
    }
    
    try:
        session = get_session()
        if not session:
            logger.warning("No database session - returning mock counts")
            return {
                "leads": 10,
                "buyers": 5,
                "sites": 3,
                "sales": 2,
                "deployments": 1
            }
        
        with session:
            # Count leads
            if Lead:
                counts["leads"] = session.query(Lead).count()
            
            # Count buyers
            if Buyer:
                counts["buyers"] = session.query(Buyer).count()
            
            # Count sites
            if Site:
                counts["sites"] = session.query(Site).count()
            
            # Count sales (if model exists)
            if LeadSale:
                counts["sales"] = session.query(LeadSale).count()
            
            # Count deployments (if model exists)
            if Deployment:
                counts["deployments"] = session.query(Deployment).count()
        
        logger.debug(f"Current counts: {counts}")
        return counts
        
    except Exception as e:
        logger.error(f"Error getting current counts: {e}")
        return counts

def capture_metrics() -> str:
    """
    Capture daily metrics snapshot
    Creates or updates today's snapshot with current counts
    Returns status message
    """
    try:
        today = date.today()
        current_time = datetime.now(timezone.utc)
        
        logger.info(f"Capturing metrics snapshot for {today}")
        
        # Get current counts
        counts = get_current_counts()
        
        session = get_session()
        if not session:
            logger.warning("No database session - metrics capture skipped")
            return "skipped_no_db"
        
        with session:
            # Check if snapshot already exists for today
            existing = session.query(MetricsSnapshot).filter(
                MetricsSnapshot.day_utc == today
            ).first()
            
            if existing:
                # Update existing snapshot
                existing.leads = counts["leads"]
                existing.buyers = counts["buyers"]
                existing.sites = counts["sites"]
                existing.sales = counts["sales"]
                existing.deployments = counts["deployments"]
                existing.created_at = current_time
                action = "updated"
                logger.info(f"Updated existing snapshot for {today}")
            else:
                # Create new snapshot
                snapshot = MetricsSnapshot(
                    day_utc=today,
                    leads=counts["leads"],
                    buyers=counts["buyers"],
                    sites=counts["sites"],
                    sales=counts["sales"],
                    deployments=counts["deployments"],
                    created_at=current_time
                )
                session.add(snapshot)
                action = "created"
                logger.info(f"Created new snapshot for {today}")
            
            session.commit()
        
        # Log summary
        logger.info(f"Metrics snapshot {action}: leads={counts['leads']}, buyers={counts['buyers']}, sites={counts['sites']}, sales={counts['sales']}, deployments={counts['deployments']}")
        
        return f"{action}_success"
        
    except Exception as e:
        logger.error(f"Error capturing metrics: {e}")
        return f"error: {str(e)}"

def get_recent_snapshots(days: int = 30) -> list:
    """
    Get recent metrics snapshots
    
    Args:
        days: Number of days to retrieve (default 30)
    
    Returns:
        List of snapshot dictionaries
    """
    try:
        session = get_session()
        if not session:
            logger.warning("No database session - returning mock snapshots")
            # Return mock data for testing
            from datetime import timedelta
            mock_snapshots = []
            for i in range(min(days, 7)):
                snapshot_date = date.today() - timedelta(days=i)
                mock_snapshots.append({
                    "day_utc": snapshot_date.isoformat(),
                    "leads": 10 + i,
                    "buyers": 5 + (i // 2),
                    "sites": 3,
                    "sales": max(0, 2 - i),
                    "deployments": 1 if i < 3 else 0
                })
            return list(reversed(mock_snapshots))
        
        with session:
            # Get snapshots ordered by day descending
            snapshots = session.query(MetricsSnapshot)\
                              .order_by(MetricsSnapshot.day_utc.desc())\
                              .limit(days)\
                              .all()
            
            # Convert to dictionaries and reverse to get chronological order
            result = [snapshot.to_dict() for snapshot in reversed(snapshots)]
            
            logger.debug(f"Retrieved {len(result)} recent snapshots")
            return result
            
    except Exception as e:
        logger.error(f"Error getting recent snapshots: {e}")
        return []

def get_snapshot_by_date(target_date: date) -> Dict[str, Any]:
    """
    Get snapshot for a specific date
    
    Args:
        target_date: Date to retrieve snapshot for
    
    Returns:
        Snapshot dictionary or None if not found
    """
    try:
        session = get_session()
        if not session:
            return None
        
        with session:
            snapshot = session.query(MetricsSnapshot).filter(
                MetricsSnapshot.day_utc == target_date
            ).first()
            
            return snapshot.to_dict() if snapshot else None
            
    except Exception as e:
        logger.error(f"Error getting snapshot for {target_date}: {e}")
        return None
