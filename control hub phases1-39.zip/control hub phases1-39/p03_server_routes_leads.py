"""
Lead Engine Control Hub - Lead Routes
Phase: 3
Purpose: FastAPI router for lead endpoints (JSON API + HTML pages)
Key Responsibilities:
- REST API endpoints for lead CRUD operations
- HTML page rendering for lead management
- Request/response handling and validation
- Error handling and HTTP status codes
"""

import logging
from typing import List
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# Import services and schemas
try:
    from p03__server_services_leads import LeadService
    from p02__server_schemas import LeadIn, LeadOut, LeadUpdate
except ImportError as e:
    logging.warning(f"Import error in leads routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 and 3 files are available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/leads", tags=["leads"])

# Initialize templates
try:
    templates_path = Path(__file__).parent / "templates"
    templates_path.mkdir(exist_ok=True)
    templates = Jinja2Templates(directory=str(templates_path))
    logger.info("Templates initialized for leads routes")
except Exception as e:
    logger.warning(f"Could not initialize templates: {e}")
    templates = None

# =============================================================================
# JSON API ENDPOINTS
# =============================================================================

@router.get("/", response_model=List[LeadOut])
async def get_all_leads(
    search: str = Query(None, description="Search leads by name or email")
):
    """
    Get all leads or search leads by name/email.
    
    Args:
        search: Optional search query for filtering leads
        
    Returns:
        List of leads matching the criteria
    """
    try:
        logger.info(f"GET /leads - search: {search}")
        
        if search:
            leads = LeadService.search_leads(search)
            logger.info(f"Search returned {len(leads)} leads")
        else:
            leads = LeadService.get_all_leads()
            logger.info(f"Retrieved {len(leads)} leads")
        
        return leads
        
    except Exception as e:
        logger.error(f"Failed to retrieve leads: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/", response_model=LeadOut, status_code=201)
async def create_lead(lead_data: LeadIn):
    """
    Create a new lead.
    
    Args:
        lead_data: Lead creation data
        
    Returns:
        Created lead object
        
    Raises:
        400: If lead with email already exists
        422: If validation fails
    """
    try:
        logger.info(f"POST /leads - creating lead: {lead_data.email}")
        
        lead = LeadService.create_lead(lead_data)
        logger.info(f"Created lead with ID: {lead.id}")
        
        return lead
        
    except ValueError as e:
        logger.warning(f"Lead creation failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to create lead: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/{lead_id}", response_model=LeadOut)
async def get_lead(lead_id: int):
    """
    Get a lead by ID.
    
    Args:
        lead_id: ID of the lead to retrieve
        
    Returns:
        Lead object
        
    Raises:
        404: If lead not found
    """
    try:
        logger.info(f"GET /leads/{lead_id}")
        
        lead = LeadService.get_lead_by_id(lead_id)
        if not lead:
            logger.warning(f"Lead not found: {lead_id}")
            raise HTTPException(status_code=404, detail="Lead not found")
        
        return lead
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retrieve lead {lead_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.patch("/{lead_id}", response_model=LeadOut)
async def update_lead(lead_id: int, lead_data: LeadUpdate):
    """
    Update a lead by ID.
    
    Args:
        lead_id: ID of the lead to update
        lead_data: Lead update data
        
    Returns:
        Updated lead object
        
    Raises:
        404: If lead not found
        400: If email conflict occurs
    """
    try:
        logger.info(f"PATCH /leads/{lead_id}")
        
        lead = LeadService.update_lead(lead_id, lead_data)
        if not lead:
            logger.warning(f"Lead not found for update: {lead_id}")
            raise HTTPException(status_code=404, detail="Lead not found")
        
        logger.info(f"Updated lead: {lead.id}")
        return lead
        
    except ValueError as e:
        logger.warning(f"Lead update failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update lead {lead_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.delete("/{lead_id}", status_code=204)
async def delete_lead(lead_id: int):
    """
    Delete a lead by ID.
    
    Args:
        lead_id: ID of the lead to delete
        
    Raises:
        404: If lead not found
    """
    try:
        logger.info(f"DELETE /leads/{lead_id}")
        
        deleted = LeadService.delete_lead(lead_id)
        if not deleted:
            logger.warning(f"Lead not found for deletion: {lead_id}")
            raise HTTPException(status_code=404, detail="Lead not found")
        
        logger.info(f"Deleted lead: {lead_id}")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete lead {lead_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# =============================================================================
# HTML PAGE ENDPOINTS
# =============================================================================

@router.get("-page", response_class=HTMLResponse)
async def leads_page(request: Request):
    """
    Render HTML page showing all leads in a table.
    
    Args:
        request: FastAPI request object
        
    Returns:
        HTML response with leads table
    """
    try:
        logger.info("GET /leads-page - rendering leads table")
        
        if not templates:
            return HTMLResponse(
                "<h1>Leads Page</h1><p>Templates not available</p>",
                status_code=200
            )
        
        # Get all leads
        leads = LeadService.get_all_leads()
        logger.info(f"Rendering {len(leads)} leads in HTML table")
        
        context = {
            "request": request,
            "title": "Leads Management",
            "leads": leads,
            "leads_count": len(leads)
        }
        
        # Try to render with a specific template, fall back to simple HTML
        try:
            return templates.TemplateResponse("leads_table.html", context)
        except Exception as template_error:
            logger.warning(f"Template error, using fallback: {template_error}")
            
            # Fallback HTML generation
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Leads Management</title>
                <link rel="stylesheet" href="/static/main.css">
            </head>
            <body>
                <nav class="main-nav">
                    <div class="nav-container">
                        <div class="nav-brand"><h1>Lead Engine Control Hub</h1></div>
                        <div class="nav-links">
                            <a href="/">Dashboard</a>
                            <a href="/leads-page">Leads</a>
                            <a href="/buyers-page">Buyers</a>
                        </div>
                    </div>
                </nav>
                
                <main class="main-content">
                    <h2>Leads Management</h2>
                    <p>Total leads: {len(leads)}</p>
                    
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Created</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            
            if leads:
                for lead in leads:
                    created_str = lead.created_at.strftime("%Y-%m-%d %H:%M") if lead.created_at else "N/A"
                    phone_str = lead.phone or "N/A"
                    html_content += f"""
                            <tr>
                                <td>{lead.id}</td>
                                <td>{lead.name}</td>
                                <td>{lead.email}</td>
                                <td>{phone_str}</td>
                                <td>{created_str}</td>
                            </tr>
                    """
            else:
                html_content += """
                            <tr>
                                <td colspan="5" style="text-align: center; color: #888;">No leads found</td>
                            </tr>
                """
            
            html_content += """
                        </tbody>
                    </table>
                </main>
            </body>
            </html>
            """
            
            return HTMLResponse(html_content, status_code=200)
        
    except Exception as e:
        logger.error(f"Failed to render leads page: {e}")
        return HTMLResponse(
            f"<h1>Error</h1><p>Failed to load leads page: {e}</p>",
            status_code=500
        )

# =============================================================================
# UTILITY ENDPOINTS
# =============================================================================

@router.get("/count/total")
async def get_leads_count():
    """
    Get total count of leads.
    
    Returns:
        JSON object with leads count
    """
    try:
        logger.info("GET /leads/count/total")
        
        count = LeadService.get_leads_count()
        logger.info(f"Leads count: {count}")
        
        return {"count": count, "entity": "leads"}
        
    except Exception as e:
        logger.error(f"Failed to get leads count: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Lead Routes Module Test ===")
    logger.info("✅ Lead routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET    /leads")
    logger.info("  POST   /leads")
    logger.info("  GET    /leads/{id}")
    logger.info("  PATCH  /leads/{id}")
    logger.info("  DELETE /leads/{id}")
    logger.info("  GET    /leads-page")