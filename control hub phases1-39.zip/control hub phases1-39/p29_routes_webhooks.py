"""
Webhook management routes for buyer endpoints and dispatch tracking.

Phase: 29
Purpose: API endpoints for managing buyer webhooks and dispatch operations.
Key responsibilities:
- CRUD operations for buyer endpoints
- Force dispatch operations
- View dispatch logs and history
"""

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, HttpUrl
from typing import List, Dict, Any, Optional
import logging
import secrets

try:
    from p02__server_db import get_session
    from p02__server_models import Buyer
    from p29__server_models_webhooks import BuyerEndpoint, DispatchLog, create_webhook_tables
    from p29__server_services_dispatch import dispatch_with_retries, get_dispatch_history
    from p24__server_services_scope import current_org
    from p08__server_services_audit import audit
    from p07__server_services_queue import enqueue
except ImportError as e:
    logging.warning(f"Webhook routes: missing dependency {e}")

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/buyers", tags=["webhooks"])


class EndpointCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    url: HttpUrl
    secret: Optional[str] = None  # Auto-generated if not provided
    timeout_s: int = Field(default=30, ge=5, le=300)
    retry_max: int = Field(default=3, ge=1, le=10)
    active: bool = True


class EndpointUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    url: Optional[HttpUrl] = None
    secret: Optional[str] = None
    timeout_s: Optional[int] = Field(None, ge=5, le=300)
    retry_max: Optional[int] = Field(None, ge=1, le=10)
    active: Optional[bool] = None


class EndpointResponse(BaseModel):
    id: int
    buyer_id: int
    name: str
    url: str
    secret_masked: str
    timeout_s: int
    retry_max: int
    active: bool
    created_at: str
    last_used_at: Optional[str]


class DispatchRequest(BaseModel):
    force: bool = False  # Force dispatch even if already dispatched


class DispatchResponse(BaseModel):
    success: bool
    dispatch_log_id: int
    status: str
    message: str
    job_id: Optional[str] = None


def require_ops_admin():
    """Placeholder for ops/admin role requirement."""
    return "admin"


@router.get("/{buyer_id}/endpoints", response_model=List[EndpointResponse])
async def list_buyer_endpoints(
    buyer_id: int,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """List webhook endpoints for a buyer."""
    
    try:
        with get_session() as db:
            create_webhook_tables()
            
            # Verify buyer exists in this org
            buyer = db.query(Buyer).filter(
                Buyer.id == buyer_id,
                Buyer.org_id == org_id
            ).first()
            
            if not buyer:
                raise HTTPException(status_code=404, detail="Buyer not found")
            
            # Get endpoints
            endpoints = db.query(BuyerEndpoint).filter(
                BuyerEndpoint.buyer_id == buyer_id,
                BuyerEndpoint.org_id == org_id
            ).order_by(BuyerEndpoint.created_at).all()
            
            response = []
            for endpoint in endpoints:
                response.append(EndpointResponse(
                    id=endpoint.id,
                    buyer_id=endpoint.buyer_id,
                    name=endpoint.name,
                    url=endpoint.url,
                    secret_masked=endpoint.get_masked_secret(),
                    timeout_s=endpoint.timeout_s,
                    retry_max=endpoint.retry_max,
                    active=endpoint.active,
                    created_at=endpoint.created_at.isoformat(),
                    last_used_at=endpoint.last_used_at.isoformat() if endpoint.last_used_at else None
                ))
            
            logger.info(f"Listed {len(response)} endpoints for buyer {buyer_id}")
            return response
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing buyer endpoints: {e}")
        raise HTTPException(status_code=500, detail="Failed to list endpoints")


@router.post("/{buyer_id}/endpoints", response_model=EndpointResponse)
async def create_buyer_endpoint(
    buyer_id: int,
    endpoint_data: EndpointCreate,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Create a new webhook endpoint for a buyer."""
    
    try:
        with get_session() as db:
            create_webhook_tables()
            
            # Verify buyer exists in this org
            buyer = db.query(Buyer).filter(
                Buyer.id == buyer_id,
                Buyer.org_id == org_id
            ).first()
            
            if not buyer:
                raise HTTPException(status_code=404, detail="Buyer not found")
            
            # Generate secret if not provided
            secret = endpoint_data.secret or secrets.token_urlsafe(32)
            
            # Create endpoint
            endpoint = BuyerEndpoint(
                org_id=org_id,
                buyer_id=buyer_id,
                name=endpoint_data.name,
                url=str(endpoint_data.url),
                secret=secret,
                timeout_s=endpoint_data.timeout_s,
                retry_max=endpoint_data.retry_max,
                active=endpoint_data.active
            )
            
            db.add(endpoint)
            db.commit()
            db.refresh(endpoint)
            
            # Audit the creation
            audit(
                kind="webhook_endpoint_created",
                message=f"Webhook endpoint '{endpoint.name}' created for buyer {buyer_id}",
                meta={
                    "endpoint_id": endpoint.id,
                    "buyer_id": buyer_id,
                    "url": endpoint.url,
                    "org_id": org_id,
                    "actor": actor
                }
            )
            
            logger.info(f"Created webhook endpoint {endpoint.id} for buyer {buyer_id}")
            
            return EndpointResponse(
                id=endpoint.id,
                buyer_id=endpoint.buyer_id,
                name=endpoint.name,
                url=endpoint.url,
                secret_masked=endpoint.get_masked_secret(),
                timeout_s=endpoint.timeout_s,
                retry_max=endpoint.retry_max,
                active=endpoint.active,
                created_at=endpoint.created_at.isoformat(),
                last_used_at=None
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating webhook endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to create endpoint")


@router.patch("/{buyer_id}/endpoints/{endpoint_id}", response_model=EndpointResponse)
async def update_buyer_endpoint(
    buyer_id: int,
    endpoint_id: int,
    endpoint_updates: EndpointUpdate,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Update a webhook endpoint."""
    
    try:
        with get_session() as db:
            endpoint = db.query(BuyerEndpoint).filter(
                BuyerEndpoint.id == endpoint_id,
                BuyerEndpoint.buyer_id == buyer_id,
                BuyerEndpoint.org_id == org_id
            ).first()
            
            if not endpoint:
                raise HTTPException(status_code=404, detail="Endpoint not found")
            
            # Track changes
            changes = {}
            
            if endpoint_updates.name is not None:
                changes["name"] = {"old": endpoint.name, "new": endpoint_updates.name}
                endpoint.name = endpoint_updates.name
            
            if endpoint_updates.url is not None:
                changes["url"] = {"old": endpoint.url, "new": str(endpoint_updates.url)}
                endpoint.url = str(endpoint_updates.url)
            
            if endpoint_updates.secret is not None:
                changes["secret"] = {"old": "****", "new": "****"}  # Never log secrets
                endpoint.secret = endpoint_updates.secret
            
            if endpoint_updates.timeout_s is not None:
                changes["timeout_s"] = {"old": endpoint.timeout_s, "new": endpoint_updates.timeout_s}
                endpoint.timeout_s = endpoint_updates.timeout_s
            
            if endpoint_updates.retry_max is not None:
                changes["retry_max"] = {"old": endpoint.retry_max, "new": endpoint_updates.retry_max}
                endpoint.retry_max = endpoint_updates.retry_max
            
            if endpoint_updates.active is not None:
                changes["active"] = {"old": endpoint.active, "new": endpoint_updates.active}
                endpoint.active = endpoint_updates.active
            
            db.commit()
            db.refresh(endpoint)
            
            # Audit the update
            audit(
                kind="webhook_endpoint_updated",
                message=f"Webhook endpoint '{endpoint.name}' updated",
                meta={
                    "endpoint_id": endpoint_id,
                    "buyer_id": buyer_id,
                    "org_id": org_id,
                    "actor": actor,
                    "changes": changes
                }
            )
            
            logger.info(f"Updated webhook endpoint {endpoint_id}")
            
            return EndpointResponse(
                id=endpoint.id,
                buyer_id=endpoint.buyer_id,
                name=endpoint.name,
                url=endpoint.url,
                secret_masked=endpoint.get_masked_secret(),
                timeout_s=endpoint.timeout_s,
                retry_max=endpoint.retry_max,
                active=endpoint.active,
                created_at=endpoint.created_at.isoformat(),
                last_used_at=endpoint.last_used_at.isoformat() if endpoint.last_used_at else None
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating webhook endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to update endpoint")


@router.delete("/{buyer_id}/endpoints/{endpoint_id}")
async def delete_buyer_endpoint(
    buyer_id: int,
    endpoint_id: int,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Delete a webhook endpoint."""
    
    try:
        with get_session() as db:
            endpoint = db.query(BuyerEndpoint).filter(
                BuyerEndpoint.id == endpoint_id,
                BuyerEndpoint.buyer_id == buyer_id,
                BuyerEndpoint.org_id == org_id
            ).first()
            
            if not endpoint:
                raise HTTPException(status_code=404, detail="Endpoint not found")
            
            endpoint_name = endpoint.name
            db.delete(endpoint)
            db.commit()
            
            # Audit the deletion
            audit(
                kind="webhook_endpoint_deleted",
                message=f"Webhook endpoint '{endpoint_name}' deleted",
                meta={
                    "endpoint_id": endpoint_id,
                    "buyer_id": buyer_id,
                    "org_id": org_id,
                    "actor": actor
                }
            )
            
            logger.info(f"Deleted webhook endpoint {endpoint_id}")
            
            return {"success": True, "message": f"Endpoint '{endpoint_name}' deleted"}
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting webhook endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete endpoint")


# Add dispatch routes to main router (not buyer-specific)
dispatch_router = APIRouter(prefix="/dispatch", tags=["dispatch"])


@dispatch_router.post("/{lead_id}", response_model=DispatchResponse)
async def force_dispatch_lead(
    lead_id: int,
    dispatch_request: DispatchRequest,
    request: Request,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Force dispatch a lead to its matched buyer endpoint."""
    
    try:
        with get_session() as db:
            # Get the lead
            from p02__server_models import Lead
            lead = db.query(Lead).filter(
                Lead.id == lead_id,
                Lead.org_id == org_id
            ).first()
            
            if not lead:
                raise HTTPException(status_code=404, detail="Lead not found")
            
            # Find the most recent successful match
            from p28__server_models_matching import MatchLog
            match = db.query(MatchLog).filter(
                MatchLog.lead_id == lead_id,
                MatchLog.org_id == org_id,
                MatchLog.status == "matched"
            ).order_by(MatchLog.created_at.desc()).first()
            
            if not match:
                raise HTTPException(status_code=400, detail="No successful match found for lead")
            
            # Find active endpoint for the matched buyer
            endpoint = db.query(BuyerEndpoint).filter(
                BuyerEndpoint.buyer_id == match.buyer_id,
                BuyerEndpoint.org_id == org_id,
                BuyerEndpoint.active == True
            ).first()
            
            if not endpoint:
                raise HTTPException(
                    status_code=400, 
                    detail=f"No active endpoint found for buyer {match.buyer_id}"
                )
            
            # Check if already dispatched (unless force=True)
            if not dispatch_request.force:
                existing_dispatch = db.query(DispatchLog).filter(
                    DispatchLog.lead_id == lead_id,
                    DispatchLog.endpoint_id == endpoint.id,
                    DispatchLog.status == "success"
                ).first()
                
                if existing_dispatch:
                    raise HTTPException(
                        status_code=409, 
                        detail="Lead already successfully dispatched. Use force=true to retry."
                    )
            
            # Enqueue dispatch job for async processing
            job_id = enqueue("dispatch_lead", {
                "lead_id": lead_id,
                "endpoint_id": endpoint.id,
                "force": dispatch_request.force,
                "actor": actor
            })
            
            logger.info(f"Enqueued force dispatch job {job_id} for lead {lead_id}")
            
            return DispatchResponse(
                success=True,
                dispatch_log_id=0,  # Will be created by worker
                status="queued",
                message=f"Dispatch queued for lead {lead_id}",
                job_id=job_id
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error force dispatching lead {lead_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to dispatch lead")


@dispatch_router.get("/logs")
async def get_dispatch_logs(
    request: Request,
    lead_id: Optional[int] = None,
    buyer_id: Optional[int] = None,
    endpoint_id: Optional[int] = None,
    limit: int = 50,
    org_id: int = Depends(current_org),
    actor: str = Depends(require_ops_admin)
):
    """Get dispatch logs with optional filtering."""
    
    try:
        logs = get_dispatch_history(lead_id, buyer_id, endpoint_id, org_id, min(limit, 100))
        
        response = []
        for log in logs:
            response.append({
                "id": log.id,
                "lead_id": log.lead_id,
                "buyer_id": log.buyer_id,
                "endpoint_id": log.endpoint_id,
                "status": log.status,
                "status_display": log.get_status_display(),
                "attempts": log.attempts,
                "response_code": log.response_code,
                "response_time_ms": log.response_time_ms,
                "last_error": log.last_error,
                "created_at": log.created_at.isoformat() if log.created_at else None,
                "completed_at": log.completed_at.isoformat() if log.completed_at else None,
                "duration_display": log.get_duration_display(),
                "metadata": log.metadata
            })
        
        return {
            "logs": response,
            "total": len(response),
            "filters": {
                "lead_id": lead_id,
                "buyer_id": buyer_id,
                "endpoint_id": endpoint_id,
                "org_id": org_id
            }
        }
    
    except Exception as e:
        logger.error(f"Error getting dispatch logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to get dispatch logs")


# Include dispatch router in the main app
# This would be done in the main app file like:
# app.include_router(dispatch_router)
