"""
App Integration Wire-up for Enhanced Authentication
Phase 23: Show how to integrate RBAC system with existing FastAPI app
Key responsibilities: Router registration, role-based protection, initialization
"""

import logging
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)

# Example of how to wire up the enhanced auth system in your main FastAPI app
# This would be integrated into p01__server-app.py

@asynccontextmanager
async def lifespan_with_auth(app):
    """
    Enhanced FastAPI lifespan context manager with auth initialization
    Handles startup and shutdown events including auth system setup
    """
    # Startup
    logger.info("Application startup - initializing services with auth")
    
    try:
        # Initialize database tables first (existing)
        try:
            from p02__server_db import create_all_tables, engine
            create_all_tables()
            logger.info("Core database tables initialized")
        except ImportError:
            logger.warning("Core database initialization skipped - modules not found")
        
        # Initialize auth tables
        try:
            from p23__server_models_auth import create_auth_tables
            from p02__server_db import engine
            create_auth_tables(engine)
            logger.info("Authentication tables initialized")
        except ImportError:
            logger.warning("Auth tables initialization skipped")
        
        # Create default admin user if none exists
        try:
            from p02__server_db import get_session
            from p23__server_models_auth import create_default_admin_user
            
            session = get_session()
            if session:
                with session:
                    admin_user = create_default_admin_user(
                        session, 
                        email="admin@controlhub.local", 
                        name="System Administrator",
                        password="admin123"  # Change in production!
                    )
                    logger.info(f"Default admin user ensured: {admin_user.email}")
        except Exception as e:
            logger.warning(f"Could not create default admin user: {e}")
        
        # Initialize other existing services (scheduler, etc.)
        try:
            from p19__server_services_scheduler import start_scheduler
            start_scheduler()
            logger.info("Scheduler started successfully")
        except ImportError:
            logger.warning("Scheduler startup skipped - modules not found")
        except Exception as e:
            logger.error(f"Failed to start scheduler: {e}")
        
        logger.info("Application startup with auth completed")
        
    except Exception as e:
        logger.error(f"Error during application startup: {e}")
        # Continue startup even if some services fail
    
    yield  # Application is running
    
    # Shutdown
    logger.info("Application shutdown - cleaning up services")
    
    try:
        from p19__server_services_scheduler import stop_scheduler
        stop_scheduler()
        logger.info("Scheduler stopped")
    except ImportError:
        pass
    except Exception as e:
        logger.error(f"Error stopping scheduler: {e}")
    
    logger.info("Application shutdown completed")

# Example FastAPI app setup with enhanced authentication
def create_app_with_auth():
    """
    Example function showing how to create FastAPI app with RBAC authentication
    This would replace or enhance the app creation in p01__server-app.py
    """
    from fastapi import FastAPI
    
    app = FastAPI(
        title="Lead Engine Control Hub",
        description="Control hub with role-based access control",
        version="1.0.0",
        lifespan=lifespan_with_auth
    )
    
    # Add existing core routes
    try:
        from p03__server_routes_leads import router as leads_router
        from p03__server_routes_buyers import router as buyers_router
        from p06__server_routes_sites import router as sites_router
        
        app.include_router(leads_router)
        app.include_router(buyers_router)
        app.include_router(sites_router)
        logger.info("Core CRUD routes registered")
    except ImportError:
        logger.warning("Core routes not available")
    
    # Add auth routes
    try:
        from p23__server_routes_auth import router as auth_router
        app.include_router(auth_router)
        logger.info("Authentication routes registered")
    except ImportError:
        logger.warning("Authentication routes not available")
    
    # Add other existing routes with role protection
    try:
        from p08__server_routes_export import router as export_router
        from p13__server_routes_webhooks import router as webhooks_router
        from p14__server_routes_matching import router as matching_router
        
        app.include_router(export_router)
        app.include_router(webhooks_router)
        app.include_router(matching_router)
        logger.info("Protected service routes registered")
    except ImportError:
        logger.warning("Some service routes not available")
    
    return app

# Role-based route protection examples
def protect_sensitive_routes():
    """
    Examples of how to update existing routes to use role-based protection
    """
    
    # Example 1: Export routes (require ops or admin)
    export_route_example = '''
    from p23__server_security_auth import require_role, Role
    
    @router.get("/leads.csv")
    async def export_leads_csv(
        request: Request,
        user: User = Depends(require_role(Role.OPS, Role.ADMIN))
    ):
        # Export logic here
        pass
    '''
    
    # Example 2: Site deployment (require ops or admin)
    deployment_route_example = '''
    @router.post("/sites/{site_id}/deploy")
    async def deploy_site(
        site_id: int,
        request: Request,
        user: User = Depends(require_role(Role.OPS, Role.ADMIN))
    ):
        # Deployment logic here
        pass
    '''
    
    # Example 3: Matching operations (admin only)
    matching_route_example = '''
    @router.post("/matching/assign/{lead_id}")
    async def assign_lead(
        lead_id: int,
        request: Request,
        user: User = Depends(require_role(Role.ADMIN))
    ):
        # Lead assignment logic here
        pass
    '''
    
    # Example 4: Webhook mutations (ops or admin)
    webhook_route_example = '''
    @router.post("/webhooks")
    async def create_webhook(
        webhook_data: WebhookCreate,
        request: Request,
        user: User = Depends(require_role(Role.OPS, Role.ADMIN))
    ):
        # Webhook creation logic here
        pass
    '''
    
    logger.info("Route protection examples documented")
    return {
        "export_protection": export_route_example,
        "deployment_protection": deployment_route_example,
        "matching_protection": matching_route_example,
        "webhook_protection": webhook_route_example
    }

# Backward compatibility check
def check_admin_token_compatibility():
    """
    Verify that existing Admin-Token functionality still works
    """
    compatibility_status = {
        "legacy_admin_token": True,  # Still supported
        "new_api_keys": True,       # New functionality
        "role_based_access": True,  # Enhanced security
        "migration_required": False # Opt-in upgrade
    }
    
    logger.info("Admin-Token backward compatibility maintained")
    return compatibility_status

# Route update guide
ROUTE_UPDATE_GUIDE = """
PHASE 23 ROUTE PROTECTION GUIDE
===============================

To add role-based protection to existing routes:

1. Import the require_role dependency:
   from p23__server_security_auth import require_role, Role

2. Add role requirement to route:
   @router.post("/sensitive-endpoint")
   async def protected_endpoint(
       request: Request,
       user: User = Depends(require_role(Role.OPS, Role.ADMIN))
   ):
       # Your existing logic here
       pass

3. Routes requiring protection:
   - /export/* (require ops|admin)
   - /sites/*/deploy (require ops|admin) 
   - /matching/* (require admin)
   - /webhooks POST/PATCH/DELETE (require ops|admin)
   - /import/* (require ops|admin)
   - /privacy/* (require ops|admin)

4. Legacy Admin-Token continues to work
   - No breaking changes to existing clients
   - Admin-Token grants admin role automatically
   - Can be used alongside new API keys

5. Testing role protection:
   # Create user and API key
   curl -X POST /auth/users -H "Admin-Token: change-me" \\
        -d '{"email":"ops@test.com","name":"Ops","password":"test123","roles":["ops"]}'
   
   # Generate API key
   curl -X POST /auth/users/2/apikeys -H "Admin-Token: change-me" \\
        -d '{"label":"test-key"}'
   
   # Test role-protected endpoint
   curl -H "X-API-Key: <api-key>" /export/leads.csv
"""

# Health check for auth system
def auth_system_health_check():
    """
    Health check for authentication system
    Returns status of auth components
    """
    try:
        from p23__server_security_auth import get_auth_status
        auth_status = get_auth_status()
        
        return {
            "status": "healthy",
            "components": {
                "user_management": "active",
                "api_keys": "active", 
                "role_based_access": "active",
                "legacy_admin_token": "supported"
            },
            "auth_system": auth_status
        }
    except Exception as e:
        return {
            "status": "degraded",
            "error": str(e),
            "components": {
                "user_management": "unknown",
                "api_keys": "unknown",
                "role_based_access": "unknown", 
                "legacy_admin_token": "supported"
            }
        }

if __name__ == "__main__":
    # Example of testing auth system setup
    import asyncio
    
    async def test_auth_setup():
        logger.info("Testing auth system setup")
        
        try:
            # Check compatibility
            compat = check_admin_token_compatibility()
            logger.info(f"Compatibility check: {compat}")
            
            # Check health
            health = auth_system_health_check()
            logger.info(f"Health check: {health}")
            
            # Print setup guide
            print(ROUTE_UPDATE_GUIDE)
            
        except Exception as e:
            logger.error(f"Test failed: {e}")
    
    # Run test
    asyncio.run(test_auth_setup())
