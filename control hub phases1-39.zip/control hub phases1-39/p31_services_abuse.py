"""
Abuse protection service with IP allow/deny lists.

Phase: 31
Purpose: Manage IP-based access control for abuse prevention.
Key responsibilities:
- Maintain in-memory allow/deny lists
- Check IP blocking status
- Provide admin interface for list management
"""

import logging
import threading
from typing import Set, Dict, Any, Optional
from datetime import datetime
import ipaddress

logger = logging.getLogger(__name__)

# In-memory storage for IP lists
_denied_ips: Set[str] = set()
_allowed_ips: Set[str] = set()
_list_lock = threading.RLock()

# Metadata for tracking changes
_metadata: Dict[str, Any] = {
    "denied_count": 0,
    "allowed_count": 0,
    "last_updated": None,
    "auto_deny_enabled": False
}


def is_blocked(ip: str) -> bool:
    """
    Check if an IP address is blocked.
    
    Args:
        ip: IP address to check
    
    Returns:
        True if IP is blocked (denied and not in allow list)
    """
    if not ip or ip == "unknown":
        return False
    
    with _list_lock:
        # Allow list takes precedence over deny list
        if ip in _allowed_ips:
            return False
        
        # Check deny list
        if ip in _denied_ips:
            return True
        
        # Check if IP is in any denied subnets (for future enhancement)
        return False


def add_to_deny_list(ip: str, actor: str = "system") -> bool:
    """
    Add IP to deny list.
    
    Args:
        ip: IP address to deny
        actor: Who added the IP (for logging)
    
    Returns:
        True if IP was added, False if already present or invalid
    """
    if not _is_valid_ip(ip):
        logger.warning(f"Invalid IP address for deny list: {ip}")
        return False
    
    with _list_lock:
        if ip in _denied_ips:
            logger.info(f"IP {ip} already in deny list")
            return False
        
        _denied_ips.add(ip)
        _metadata["denied_count"] = len(_denied_ips)
        _metadata["last_updated"] = datetime.utcnow().isoformat()
        
        logger.info(f"Added IP {ip} to deny list by {actor}")
        
        # Audit the change
        try:
            from p08__server_services_audit import audit_security_event
            audit_security_event(
                "ip_denied",
                actor,
                f"IP {ip}",
                True,
                f"IP address added to deny list"
            )
        except ImportError:
            pass
        
        return True


def remove_from_deny_list(ip: str, actor: str = "system") -> bool:
    """
    Remove IP from deny list.
    
    Args:
        ip: IP address to remove
        actor: Who removed the IP (for logging)
    
    Returns:
        True if IP was removed, False if not present
    """
    with _list_lock:
        if ip not in _denied_ips:
            logger.info(f"IP {ip} not in deny list")
            return False
        
        _denied_ips.remove(ip)
        _metadata["denied_count"] = len(_denied_ips)
        _metadata["last_updated"] = datetime.utcnow().isoformat()
        
        logger.info(f"Removed IP {ip} from deny list by {actor}")
        
        # Audit the change
        try:
            from p08__server_services_audit import audit_security_event
            audit_security_event(
                "ip_deny_removed",
                actor,
                f"IP {ip}",
                True,
                f"IP address removed from deny list"
            )
        except ImportError:
            pass
        
        return True


def add_to_allow_list(ip: str, actor: str = "system") -> bool:
    """
    Add IP to allow list (exempts from deny list).
    
    Args:
        ip: IP address to allow
        actor: Who added the IP (for logging)
    
    Returns:
        True if IP was added, False if already present or invalid
    """
    if not _is_valid_ip(ip):
        logger.warning(f"Invalid IP address for allow list: {ip}")
        return False
    
    with _list_lock:
        if ip in _allowed_ips:
            logger.info(f"IP {ip} already in allow list")
            return False
        
        _allowed_ips.add(ip)
        _metadata["allowed_count"] = len(_allowed_ips)
        _metadata["last_updated"] = datetime.utcnow().isoformat()
        
        logger.info(f"Added IP {ip} to allow list by {actor}")
        
        # Audit the change
        try:
            from p08__server_services_audit import audit_security_event
            audit_security_event(
                "ip_allowed",
                actor,
                f"IP {ip}",
                True,
                f"IP address added to allow list"
            )
        except ImportError:
            pass
        
        return True


def remove_from_allow_list(ip: str, actor: str = "system") -> bool:
    """
    Remove IP from allow list.
    
    Args:
        ip: IP address to remove
        actor: Who removed the IP (for logging)
    
    Returns:
        True if IP was removed, False if not present
    """
    with _list_lock:
        if ip not in _allowed_ips:
            logger.info(f"IP {ip} not in allow list")
            return False
        
        _allowed_ips.remove(ip)
        _metadata["allowed_count"] = len(_allowed_ips)
        _metadata["last_updated"] = datetime.utcnow().isoformat()
        
        logger.info(f"Removed IP {ip} from allow list by {actor}")
        
        # Audit the change
        try:
            from p08__server_services_audit import audit_security_event
            audit_security_event(
                "ip_allow_removed",
                actor,
                f"IP {ip}",
                True,
                f"IP address removed from allow list"
            )
        except ImportError:
            pass
        
        return True


def get_deny_list() -> Set[str]:
    """Get copy of current deny list."""
    with _list_lock:
        return _denied_ips.copy()


def get_allow_list() -> Set[str]:
    """Get copy of current allow list."""
    with _list_lock:
        return _allowed_ips.copy()


def get_status() -> Dict[str, Any]:
    """
    Get current abuse protection status.
    
    Returns:
        Dict with current status and statistics
    """
    with _list_lock:
        return {
            "denied_ips": list(_denied_ips),
            "allowed_ips": list(_allowed_ips),
            "counts": {
                "denied": len(_denied_ips),
                "allowed": len(_allowed_ips)
            },
            "metadata": _metadata.copy(),
            "features": {
                "ip_blocking": True,
                "subnet_blocking": False,  # Future enhancement
                "auto_deny": _metadata.get("auto_deny_enabled", False)
            }
        }


def clear_all_lists(actor: str = "system") -> Dict[str, int]:
    """
    Clear all IP lists (emergency function).
    
    Args:
        actor: Who cleared the lists (for logging)
    
    Returns:
        Dict with counts of cleared IPs
    """
    with _list_lock:
        denied_count = len(_denied_ips)
        allowed_count = len(_allowed_ips)
        
        _denied_ips.clear()
        _allowed_ips.clear()
        
        _metadata["denied_count"] = 0
        _metadata["allowed_count"] = 0
        _metadata["last_updated"] = datetime.utcnow().isoformat()
        
        logger.warning(f"All IP lists cleared by {actor}: {denied_count} denied, {allowed_count} allowed")
        
        # Audit the change
        try:
            from p08__server_services_audit import audit_security_event
            audit_security_event(
                "ip_lists_cleared",
                actor,
                "all IP lists",
                True,
                f"Cleared {denied_count} denied and {allowed_count} allowed IPs"
            )
        except ImportError:
            pass
        
        return {
            "denied_cleared": denied_count,
            "allowed_cleared": allowed_count
        }


def bulk_add_to_deny_list(ips: list, actor: str = "system") -> Dict[str, Any]:
    """
    Add multiple IPs to deny list.
    
    Args:
        ips: List of IP addresses to deny
        actor: Who added the IPs (for logging)
    
    Returns:
        Dict with results
    """
    results = {
        "added": [],
        "skipped": [],
        "invalid": []
    }
    
    for ip in ips:
        ip = ip.strip()
        if not ip:
            continue
        
        if not _is_valid_ip(ip):
            results["invalid"].append(ip)
            continue
        
        if add_to_deny_list(ip, actor):
            results["added"].append(ip)
        else:
            results["skipped"].append(ip)
    
    logger.info(f"Bulk deny by {actor}: {len(results['added'])} added, {len(results['skipped'])} skipped, {len(results['invalid'])} invalid")
    
    return results


def _is_valid_ip(ip: str) -> bool:
    """
    Validate IP address format.
    
    Args:
        ip: IP address string to validate
    
    Returns:
        True if valid IPv4 or IPv6 address
    """
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def auto_deny_ip(ip: str, reason: str = "automated detection") -> bool:
    """
    Automatically deny an IP based on abuse detection.
    
    Args:
        ip: IP address to auto-deny
        reason: Reason for auto-denial
    
    Returns:
        True if IP was auto-denied
    """
    if not _metadata.get("auto_deny_enabled", False):
        logger.debug(f"Auto-deny disabled, not blocking {ip}")
        return False
    
    if not _is_valid_ip(ip):
        return False
    
    # Don't auto-deny IPs in allow list
    with _list_lock:
        if ip in _allowed_ips:
            logger.info(f"Not auto-denying allowed IP {ip}")
            return False
    
    success = add_to_deny_list(ip, f"auto-deny: {reason}")
    
    if success:
        logger.warning(f"Auto-denied IP {ip}: {reason}")
        
        # Additional audit for auto-deny
        try:
            from p08__server_services_audit import audit_security_event
            audit_security_event(
                "ip_auto_denied",
                "system",
                f"IP {ip}",
                True,
                f"Automatically denied: {reason}"
            )
        except ImportError:
            pass
    
    return success


def set_auto_deny_enabled(enabled: bool, actor: str = "system"):
    """
    Enable or disable automatic IP denial.
    
    Args:
        enabled: Whether to enable auto-deny
        actor: Who changed the setting
    """
    with _list_lock:
        old_setting = _metadata.get("auto_deny_enabled", False)
        _metadata["auto_deny_enabled"] = enabled
        _metadata["last_updated"] = datetime.utcnow().isoformat()
    
    logger.info(f"Auto-deny {'enabled' if enabled else 'disabled'} by {actor}")
    
    # Audit the setting change
    try:
        from p08__server_services_audit import audit_security_event
        audit_security_event(
            "auto_deny_setting_changed",
            actor,
            "auto-deny feature",
            True,
            f"Auto-deny {'enabled' if enabled else 'disabled'} (was {'enabled' if old_setting else 'disabled'})"
        )
    except ImportError:
        pass


# Example integration with rate limiting
def check_rate_limit_violations(ip: str, violation_count: int, time_window: str = "1min"):
    """
    Example function for rate limit integration.
    
    Args:
        ip: IP address with violations
        violation_count: Number of violations
        time_window: Time window for violations
    """
    # Auto-deny IPs that exceed rate limits significantly
    if violation_count > 10:  # Configurable threshold
        auto_deny_ip(ip, f"{violation_count} rate limit violations in {time_window}")


# Predefined IP lists for common scenarios
COMMON_DENY_LISTS = {
    "tor_exit_nodes": [
        # This would be populated with known Tor exit node IPs
        # For demo purposes, using example IPs
        "192.0.2.1",
        "203.0.113.1"
    ],
    "known_attackers": [
        # This would be populated with known attacker IPs
        "198.51.100.1",
        "192.0.2.100"
    ]
}


def load_predefined_deny_list(list_name: str, actor: str = "system") -> Dict[str, Any]:
    """
    Load a predefined deny list.
    
    Args:
        list_name: Name of predefined list to load
        actor: Who loaded the list
    
    Returns:
        Dict with results
    """
    if list_name not in COMMON_DENY_LISTS:
        return {"error": f"Unknown deny list: {list_name}"}
    
    ips = COMMON_DENY_LISTS[list_name]
    results = bulk_add_to_deny_list(ips, f"{actor}:predefined:{list_name}")
    
    logger.info(f"Loaded predefined deny list '{list_name}' by {actor}")
    
    return {
        "list_name": list_name,
        "total_ips": len(ips),
        **results
    }
