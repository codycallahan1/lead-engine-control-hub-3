"""
Metrics Snapshots Database Model
Phase 19: Daily metrics capture for historical tracking
Key responsibilities: Store daily count snapshots, support time-series analysis
"""

from sqlalchemy import Column, Integer, String, DateTime, Date
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime, date

# Import base from existing models or create if needed
try:
    from p02__server_db import Base
except ImportError:
    Base = declarative_base()

class MetricsSnapshot(Base):
    """
    Daily snapshot of key metrics
    Captures counts at end of each day for historical tracking
    """
    __tablename__ = "metrics_snapshots"
    
    id = Column(Integer, primary_key=True, index=True)
    day_utc = Column(Date, unique=True, index=True, nullable=False)
    leads = Column(Integer, default=0, nullable=False)
    buyers = Column(Integer, default=0, nullable=False)
    sites = Column(Integer, default=0, nullable=False)
    sales = Column(Integer, default=0, nullable=False)
    deployments = Column(Integer, default=0, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f"<MetricsSnapshot(day={self.day_utc}, leads={self.leads}, buyers={self.buyers}, sites={self.sites})>"
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "day_utc": self.day_utc.isoformat(),
            "leads": self.leads,
            "buyers": self.buyers,
            "sites": self.sites,
            "sales": self.sales,
            "deployments": self.deployments,
            "created_at": self.created_at.isoformat()
        }

# Ensure table creation helper
def create_metrics_snapshots_table(engine):
    """Create metrics snapshots table if it doesn't exist"""
    try:
        MetricsSnapshot.__table__.create(engine, checkfirst=True)
        return True
    except Exception as e:
        print(f"Error creating metrics snapshots table: {e}")
        return False
