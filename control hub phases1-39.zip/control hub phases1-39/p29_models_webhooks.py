"""
Buyer webhook endpoint models for lead dispatch.

Phase: 29
Purpose: Define models for buyer endpoints and dispatch tracking.
Key responsibilities:
- BuyerEndpoint model for webhook configuration
- DispatchLog for tracking delivery attempts
- Support for retry logic and error tracking
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, DateTime, Float
from sqlalchemy.sql import func
import json
import logging

# Note: In final package structure, this would merge with main models.py
try:
    from p02__server_db import Base
except ImportError:
    logging.info("Webhook models: p02__server_db not found, using standalone Base")
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()

logger = logging.getLogger(__name__)


class BuyerEndpoint(Base):
    """Webhook endpoints for delivering leads to buyers."""
    
    __tablename__ = "buyer_endpoints"
    
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, nullable=False, default=1)
    buyer_id = Column(Integer, nullable=False)
    name = Column(String(255), nullable=False)  # Human-readable endpoint name
    url = Column(String(1000), nullable=False)  # Webhook URL
    secret = Column(String(255), nullable=False)  # HMAC secret for signing
    active = Column(Boolean, default=True)
    timeout_s = Column(Integer, default=30)  # Request timeout in seconds
    retry_max = Column(Integer, default=3)  # Maximum retry attempts
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    
    def __repr__(self):
        status = "✓" if self.active else "✗"
        return f"<BuyerEndpoint {self.id}: {self.name} -> Buyer {self.buyer_id} [{status}]>"
    
    def get_masked_secret(self):
        """Return masked secret for display purposes."""
        if not self.secret:
            return ""
        if len(self.secret) <= 8:
            return "****"
        return self.secret[:4] + "****" + self.secret[-4:]
    
    def get_summary(self):
        """Get human-readable endpoint summary."""
        return f"{self.name} ({self.url}) - Timeout: {self.timeout_s}s, Max retries: {self.retry_max}"


class DispatchLog(Base):
    """Log of lead dispatch attempts to buyer endpoints."""
    
    __tablename__ = "dispatch_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, nullable=False, default=1)
    lead_id = Column(Integer, nullable=False)
    buyer_id = Column(Integer, nullable=False)
    endpoint_id = Column(Integer, nullable=False)
    status = Column(String(50), nullable=False, default="pending")  # pending, success, failed, retrying
    attempts = Column(Integer, default=0)
    response_code = Column(Integer, nullable=True)  # HTTP response code
    response_time_ms = Column(Float, nullable=True)  # Response time in milliseconds
    last_error = Column(Text, nullable=True)  # Last error message
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
    metadata_json = Column(Text, nullable=True)  # Additional dispatch details
    
    def __repr__(self):
        status_emoji = {
            "pending": "⏳",
            "success": "✅",
            "failed": "❌",
            "retrying": "🔄"
        }.get(self.status, "❓")
        
        return f"<DispatchLog {self.id}: Lead {self.lead_id} -> Endpoint {self.endpoint_id} {status_emoji}>"
    
    @property
    def metadata(self):
        """Parse metadata_json into dict."""
        if not self.metadata_json:
            return {}
        try:
            return json.loads(self.metadata_json)
        except (json.JSONDecodeError, TypeError):
            return {}
    
    @metadata.setter
    def metadata(self, metadata_dict):
        """Set metadata from dict."""
        self.metadata_json = json.dumps(metadata_dict) if metadata_dict else None
    
    def get_status_display(self):
        """Get human-readable status with context."""
        status_map = {
            "pending": "Pending",
            "success": "Successfully Delivered",
            "failed": "Delivery Failed",
            "retrying": "Retrying"
        }
        
        base_status = status_map.get(self.status, self.status.title())
        
        if self.attempts > 1:
            base_status += f" (attempt {self.attempts})"
        
        if self.response_code:
            base_status += f" - HTTP {self.response_code}"
        
        return base_status
    
    def get_duration_display(self):
        """Get human-readable duration."""
        if not self.completed_at:
            return "In progress"
        
        duration = (self.completed_at - self.created_at).total_seconds()
        
        if duration < 1:
            return f"{int(duration * 1000)}ms"
        elif duration < 60:
            return f"{duration:.1f}s"
        else:
            return f"{int(duration // 60)}m {int(duration % 60)}s"
    
    def is_success(self):
        """Check if dispatch was successful."""
        return self.status == "success" and self.response_code and 200 <= self.response_code < 300
    
    def is_retryable(self):
        """Check if dispatch failure is retryable."""
        if self.status == "success":
            return False
        
        # Don't retry client errors (4xx) except for specific cases
        if self.response_code and 400 <= self.response_code < 500:
            # Retry on these specific 4xx codes
            retryable_4xx = {408, 429}  # Request Timeout, Too Many Requests
            return self.response_code in retryable_4xx
        
        # Retry on server errors (5xx) and network issues (no response code)
        return True
    
    def add_attempt(self, response_code=None, error=None, response_time_ms=None):
        """Record a dispatch attempt."""
        self.attempts += 1
        self.response_code = response_code
        self.response_time_ms = response_time_ms
        
        if error:
            self.last_error = str(error)[:1000]  # Truncate long errors
        
        # Update status based on response
        if response_code and 200 <= response_code < 300:
            self.status = "success"
            self.completed_at = func.now()
        elif self.is_retryable() and self.attempts < 3:  # Max retries hardcoded for now
            self.status = "retrying"
        else:
            self.status = "failed"
            self.completed_at = func.now()


def create_webhook_tables():
    """Create webhook tables if they don't exist."""
    try:
        from p02__server_db import engine
        Base.metadata.create_all(bind=engine, tables=[
            BuyerEndpoint.__table__,
            DispatchLog.__table__
        ])
        logger.info("Webhook tables created/verified")
    except ImportError:
        logger.warning("Cannot create webhook tables: database engine not available")


# Example endpoint configurations for documentation
EXAMPLE_ENDPOINTS = {
    "simple_webhook": {
        "name": "Primary Webhook",
        "url": "https://buyer-system.com/webhooks/leads",
        "secret": "your-webhook-secret-here",
        "timeout_s": 30,
        "retry_max": 3
    },
    "backup_webhook": {
        "name": "Backup Endpoint",
        "url": "https://backup.buyer-system.com/api/leads",
        "secret": "backup-webhook-secret",
        "timeout_s": 15,
        "retry_max": 2
    }
}

# Example payload structure for documentation
EXAMPLE_PAYLOAD = {
    "event": "lead.matched",
    "timestamp": "2025-01-15T10:30:00Z",
    "lead": {
        "id": 123,
        "name": "John Doe",
        "email": "john@example.com",
        "phone": "1234567890",
        "created_at": "2025-01-15T10:25:00Z"
    },
    "buyer": {
        "id": 456,
        "name": "Acme Corp"
    },
    "matching": {
        "rule_id": 789,
        "rule_name": "Gmail Users",
        "score": 2.5
    },
    "organization": {
        "id": 1
    }
}
