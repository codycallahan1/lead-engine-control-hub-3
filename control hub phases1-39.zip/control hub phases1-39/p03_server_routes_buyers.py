"""
Lead Engine Control Hub - Buyer Routes
Phase: 3
Purpose: FastAPI router for buyer endpoints (JSON API + HTML pages)
Key Responsibilities:
- REST API endpoints for buyer CRUD operations
- HTML page rendering for buyer management
- Request/response handling and validation
- Error handling and HTTP status codes
"""

import logging
from typing import List
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# Import services and schemas
try:
    from p03__server_services_buyers import BuyerService
    from p02__server_schemas import BuyerIn, BuyerOut, BuyerUpdate
except ImportError as e:
    logging.warning(f"Import error in buyers routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 and 3 files are available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/buyers", tags=["buyers"])

# Initialize templates
try:
    templates_path = Path(__file__).parent / "templates"
    templates_path.mkdir(exist_ok=True)
    templates = Jinja2Templates(directory=str(templates_path))
    logger.info("Templates initialized for buyers routes")
except Exception as e:
    logger.warning(f"Could not initialize templates: {e}")
    templates = None

# =============================================================================
# JSON API ENDPOINTS
# =============================================================================

@router.get("/", response_model=List[BuyerOut])
async def get_all_buyers(
    search: str = Query(None, description="Search buyers by name or email")
):
    """
    Get all buyers or search buyers by name/email.
    
    Args:
        search: Optional search query for filtering buyers
        
    Returns:
        List of buyers matching the criteria
    """
    try:
        logger.info(f"GET /buyers - search: {search}")
        
        if search:
            buyers = BuyerService.search_buyers(search)
            logger.info(f"Search returned {len(buyers)} buyers")
        else:
            buyers = BuyerService.get_all_buyers()
            logger.info(f"Retrieved {len(buyers)} buyers")
        
        return buyers
        
    except Exception as e:
        logger.error(f"Failed to retrieve buyers: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/", response_model=BuyerOut, status_code=201)
async def create_buyer(buyer_data: BuyerIn):
    """
    Create a new buyer.
    
    Args:
        buyer_data: Buyer creation data
        
    Returns:
        Created buyer object
        
    Raises:
        400: If buyer with email already exists
        422: If validation fails
    """
    try:
        logger.info(f"POST /buyers - creating buyer: {buyer_data.email}")
        
        buyer = BuyerService.create_buyer(buyer_data)
        logger.info(f"Created buyer with ID: {buyer.id}")
        
        return buyer
        
    except ValueError as e:
        logger.warning(f"Buyer creation failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to create buyer: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/{buyer_id}", response_model=BuyerOut)
async def get_buyer(buyer_id: int):
    """
    Get a buyer by ID.
    
    Args:
        buyer_id: ID of the buyer to retrieve
        
    Returns:
        Buyer object
        
    Raises:
        404: If buyer not found
    """
    try:
        logger.info(f"GET /buyers/{buyer_id}")
        
        buyer = BuyerService.get_buyer_by_id(buyer_id)
        if not buyer:
            logger.warning(f"Buyer not found: {buyer_id}")
            raise HTTPException(status_code=404, detail="Buyer not found")
        
        return buyer
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retrieve buyer {buyer_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.patch("/{buyer_id}", response_model=BuyerOut)
async def update_buyer(buyer_id: int, buyer_data: BuyerUpdate):
    """
    Update a buyer by ID.
    
    Args:
        buyer_id: ID of the buyer to update
        buyer_data: Buyer update data
        
    Returns:
        Updated buyer object
        
    Raises:
        404: If buyer not found
        400: If email conflict occurs
    """
    try:
        logger.info(f"PATCH /buyers/{buyer_id}")
        
        buyer = BuyerService.update_buyer(buyer_id, buyer_data)
        if not buyer:
            logger.warning(f"Buyer not found for update: {buyer_id}")
            raise HTTPException(status_code=404, detail="Buyer not found")
        
        logger.info(f"Updated buyer: {buyer.id}")
        return buyer
        
    except ValueError as e:
        logger.warning(f"Buyer update failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update buyer {buyer_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.delete("/{buyer_id}", status_code=204)
async def delete_buyer(buyer_id: int):
    """
    Delete a buyer by ID.
    
    Args:
        buyer_id: ID of the buyer to delete
        
    Raises:
        404: If buyer not found
    """
    try:
        logger.info(f"DELETE /buyers/{buyer_id}")
        
        deleted = BuyerService.delete_buyer(buyer_id)
        if not deleted:
            logger.warning(f"Buyer not found for deletion: {buyer_id}")
            raise HTTPException(status_code=404, detail="Buyer not found")
        
        logger.info(f"Deleted buyer: {buyer_id}")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete buyer {buyer_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# =============================================================================
# HTML PAGE ENDPOINTS
# =============================================================================

@router.get("-page", response_class=HTMLResponse)
async def buyers_page(request: Request):
    """
    Render HTML page showing all buyers in a table.
    
    Args:
        request: FastAPI request object
        
    Returns:
        HTML response with buyers table
    """
    try:
        logger.info("GET /buyers-page - rendering buyers table")
        
        if not templates:
            return HTMLResponse(
                "<h1>Buyers Page</h1><p>Templates not available</p>",
                status_code=200
            )
        
        # Get all buyers
        buyers = BuyerService.get_all_buyers()
        logger.info(f"Rendering {len(buyers)} buyers in HTML table")
        
        context = {
            "request": request,
            "title": "Buyers Management",
            "buyers": buyers,
            "buyers_count": len(buyers)
        }
        
        # Try to render with a specific template, fall back to simple HTML
        try:
            return templates.TemplateResponse("buyers_table.html", context)
        except Exception as template_error:
            logger.warning(f"Template error, using fallback: {template_error}")
            
            # Fallback HTML generation
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Buyers Management</title>
                <link rel="stylesheet" href="/static/main.css">
            </head>
            <body>
                <nav class="main-nav">
                    <div class="nav-container">
                        <div class="nav-brand"><h1>Lead Engine Control Hub</h1></div>
                        <div class="nav-links">
                            <a href="/">Dashboard</a>
                            <a href="/leads-page">Leads</a>
                            <a href="/buyers-page">Buyers</a>
                        </div>
                    </div>
                </nav>
                
                <main class="main-content">
                    <h2>Buyers Management</h2>
                    <p>Total buyers: {len(buyers)}</p>
                    
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            
            if buyers:
                for buyer in buyers:
                    created_str = buyer.created_at.strftime("%Y-%m-%d %H:%M") if buyer.created_at else "N/A"
                    html_content += f"""
                            <tr>
                                <td>{buyer.id}</td>
                                <td>{buyer.name}</td>
                                <td>{buyer.email}</td>
                                <td>{created_str}</td>
                            </tr>
                    """
            else:
                html_content += """
                            <tr>
                                <td colspan="4" style="text-align: center; color: #888;">No buyers found</td>
                            </tr>
                """
            
            html_content += """
                        </tbody>
                    </table>
                </main>
            </body>
            </html>
            """
            
            return HTMLResponse(html_content, status_code=200)
        
    except Exception as e:
        logger.error(f"Failed to render buyers page: {e}")
        return HTMLResponse(
            f"<h1>Error</h1><p>Failed to load buyers page: {e}</p>",
            status_code=500
        )

# =============================================================================
# UTILITY ENDPOINTS
# =============================================================================

@router.get("/count/total")
async def get_buyers_count():
    """
    Get total count of buyers.
    
    Returns:
        JSON object with buyers count
    """
    try:
        logger.info("GET /buyers/count/total")
        
        count = BuyerService.get_buyers_count()
        logger.info(f"Buyers count: {count}")
        
        return {"count": count, "entity": "buyers"}
        
    except Exception as e:
        logger.error(f"Failed to get buyers count: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Buyer Routes Module Test ===")
    logger.info("✅ Buyer routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET    /buyers")
    logger.info("  POST   /buyers")
    logger.info("  GET    /buyers/{id}")
    logger.info("  PATCH  /buyers/{id}")
    logger.info("  DELETE /buyers/{id}")
    logger.info("  GET    /buyers-page")