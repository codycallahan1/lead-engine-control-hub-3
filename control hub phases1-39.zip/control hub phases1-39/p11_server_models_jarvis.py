"""
Lead Engine Control Hub - Jarvis Assistant Models
Phase: 11
Purpose: SQLAlchemy models for Jarvis assistant chat history and sessions
Key Responsibilities:
- JarvisSession model for storing chat interactions
- Session management and message persistence
- Role-based message storage (user, assistant, system)
- Chat history retrieval and management
"""

import logging
from datetime import datetime
from typing import Optional

from sqlalchemy import Column, Integer, String, DateTime, Text
from sqlalchemy.sql import func

# Import Base from database module
try:
    from p02__server_db import Base
except ImportError:
    # Fallback for standalone testing
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()
    logging.warning("Using fallback Base class - ensure p02__server-db.py is available")

logger = logging.getLogger(__name__)

class JarvisSession(Base):
    """
    Jarvis session model for storing chat interactions and command history.
    
    Attributes:
        id: Primary key
        session_id: Unique session identifier for grouping messages
        timestamp: When the message was created
        role: Message role (user, assistant, system)
        message: Message content
        command: Extracted command if applicable
        metadata: Additional message metadata (JSON string)
    """
    __tablename__ = "jarvis_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(255), nullable=False, index=True)
    timestamp = Column(
        DateTime(timezone=True), 
        server_default=func.now(),
        nullable=False,
        index=True
    )
    role = Column(String(50), nullable=False, index=True)  # user, assistant, system
    message = Column(Text, nullable=False)
    command = Column(String(255), nullable=True, index=True)  # Extracted command for analytics
    metadata = Column(Text, nullable=True)  # JSON string for additional data
    
    def __repr__(self):
        return f"<JarvisSession(id={self.id}, session_id='{self.session_id}', role='{self.role}')>"
    
    def to_dict(self):
        """Convert model instance to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "session_id": self.session_id,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "role": self.role,
            "message": self.message,
            "command": self.command,
            "metadata": self.metadata
        }
    
    def is_user_message(self) -> bool:
        """Check if this is a user message"""
        return self.role == "user"
    
    def is_assistant_message(self) -> bool:
        """Check if this is an assistant message"""
        return self.role == "assistant"
    
    def is_system_message(self) -> bool:
        """Check if this is a system message"""
        return self.role == "system"
    
    def is_command(self) -> bool:
        """Check if this message contains a command"""
        return self.command is not None
    
    def get_display_time(self) -> str:
        """Get formatted display time"""
        if self.timestamp:
            return self.timestamp.strftime("%H:%M:%S")
        return "N/A"

# Message role constants
class JarvisRole:
    """Constants for Jarvis message roles"""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    
    @classmethod
    def all_roles(cls):
        """Get all valid message roles"""
        return [cls.USER, cls.ASSISTANT, cls.SYSTEM]
    
    @classmethod
    def is_valid_role(cls, role: str) -> bool:
        """Check if role is valid"""
        return role.lower() in cls.all_roles()

def create_jarvis_message(session_id: str, role: str, message: str, 
                         command: Optional[str] = None, metadata: Optional[str] = None) -> dict:
    """
    Helper function to create a Jarvis message record dictionary.
    
    Args:
        session_id: Session identifier
        role: Message role (user, assistant, system)
        message: Message content
        command: Optional command string
        metadata: Optional metadata JSON string
        
    Returns:
        Dictionary with message data for creating JarvisSession instance
    """
    return {
        "session_id": session_id,
        "role": role.lower(),
        "message": message,
        "command": command,
        "metadata": metadata
    }

def get_message_summary(message: JarvisSession) -> dict:
    """
    Get a summary of a Jarvis message for display.
    
    Args:
        message: JarvisSession instance
        
    Returns:
        Dictionary with message summary
    """
    return {
        "id": message.id,
        "session_id": message.session_id,
        "role": message.role,
        "message": message.message[:100] + "..." if len(message.message) > 100 else message.message,
        "command": message.command,
        "time": message.get_display_time(),
        "is_command": message.is_command()
    }

# Session management utilities
class JarvisSessionManager:
    """Utility class for managing Jarvis sessions"""
    
    @staticmethod
    def generate_session_id() -> str:
        """Generate a new session ID"""
        import uuid
        return str(uuid.uuid4())
    
    @staticmethod
    def is_valid_session_id(session_id: str) -> bool:
        """Validate session ID format"""
        try:
            import uuid
            uuid.UUID(session_id)
            return True
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def get_session_stats(session_id: str) -> dict:
        """Get statistics for a session (requires database access)"""
        # This would need to be implemented with database access
        return {
            "session_id": session_id,
            "total_messages": 0,
            "user_messages": 0,
            "assistant_messages": 0,
            "commands_executed": 0,
            "session_duration": "N/A"
        }

# Command extraction utilities
class JarvisCommandExtractor:
    """Utility class for extracting commands from messages"""
    
    COMMAND_PREFIXES = ["/", "!", "@jarvis "]
    
    @classmethod
    def extract_command(cls, message: str) -> Optional[str]:
        """
        Extract command from message if present.
        
        Args:
            message: User message text
            
        Returns:
            Command string without prefix, or None if no command
        """
        message = message.strip()
        
        for prefix in cls.COMMAND_PREFIXES:
            if message.lower().startswith(prefix.lower()):
                command = message[len(prefix):].strip()
                # Extract just the command word (first part)
                command_word = command.split()[0] if command else ""
                return command_word.lower() if command_word else None
        
        return None
    
    @classmethod
    def is_command_message(cls, message: str) -> bool:
        """Check if message contains a command"""
        return cls.extract_command(message) is not None
    
    @classmethod
    def get_command_args(cls, message: str) -> list:
        """
        Get command arguments from message.
        
        Args:
            message: User message text
            
        Returns:
            List of command arguments (excluding the command itself)
        """
        for prefix in cls.COMMAND_PREFIXES:
            if message.lower().startswith(prefix.lower()):
                command_part = message[len(prefix):].strip()
        for prefix in cls.COMMAND_PREFIXES:
            if message.lower().startswith(prefix.lower()):
                command_part = message[len(prefix):].strip()
                parts = command_part.split()
                return parts[1:] if len(parts) > 1 else []
        
        return []

# Model registry update for Jarvis
JARVIS_MODELS = {
    "JarvisSession": JarvisSession
}

def get_jarvis_model_by_name(model_name: str):
    """
    Get Jarvis model class by name.
    
    Args:
        model_name: Name of the model ("JarvisSession")
        
    Returns:
        Model class or None if not found
    """
    return JARVIS_MODELS.get(model_name)

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Jarvis Models Module Test ===")
    
    # Test session ID generation
    session_manager = JarvisSessionManager()
    session_id = session_manager.generate_session_id()
    logger.info(f"Generated session ID: {session_id}")
    logger.info(f"Session ID valid: {session_manager.is_valid_session_id(session_id)}")
    
    # Test message creation
    message_data = create_jarvis_message(
        session_id=session_id,
        role=JarvisRole.USER,
        message="/help with deployment",
        command="help"
    )
    logger.info(f"Created message data: {message_data}")
    
    # Test Jarvis session instance
    jarvis_message = JarvisSession(
        session_id=session_id,
        role=JarvisRole.ASSISTANT,
        message="Here are the available commands...",
        command=None
    )
    
    logger.info(f"Created Jarvis message: {jarvis_message}")
    logger.info(f"Message dict: {jarvis_message.to_dict()}")
    logger.info(f"Is user message: {jarvis_message.is_user_message()}")
    logger.info(f"Is assistant message: {jarvis_message.is_assistant_message()}")
    
    # Test command extraction
    extractor = JarvisCommandExtractor()
    test_messages = [
        "/help",
        "!status",
        "@jarvis build-site 1",
        "regular message",
        "/list-sites with filter"
    ]
    
    for test_msg in test_messages:
        command = extractor.extract_command(test_msg)
        is_command = extractor.is_command_message(test_msg)
        args = extractor.get_command_args(test_msg)
        logger.info(f"Message: '{test_msg}' -> Command: {command}, Is command: {is_command}, Args: {args}")
    
    # Test role validation
    logger.info(f"Valid roles: {JarvisRole.all_roles()}")
    logger.info(f"'user' is valid: {JarvisRole.is_valid_role('user')}")
    logger.info(f"'invalid' is valid: {JarvisRole.is_valid_role('invalid')}")
    
    logger.info("✅ Jarvis models module test completed")