"""
Notification service for lead and sales events.

Phase: 16
Purpose: Coordinate notifications for key system events
Key responsibilities: notify_new_lead, notify_sale_delivered functions with queue integration
"""

import logging
from typing import Dict, Any, List, Optional

# Import attempt with graceful fallback
try:
    from p07__server_services_queue import enqueue
    from p16__server_config_notify import get_notification_recipients, get_notification_settings
except ImportError as e:
    logging.warning(f"Import issue in notification service: {e}")
    # Fallback for development
    def enqueue(kind, payload):
        return "mock-job-id"
    def get_notification_recipients():
        return {"admin": ["admin@example.com"], "sales": ["sales@example.com"]}
    def get_notification_settings():
        return {"enabled": True, "default_from": "noreply@leadengine.example"}

logger = logging.getLogger(__name__)

def notify_new_lead(lead: Dict[str, Any]) -> List[str]:
    """
    Send notifications when a new lead is ingested.
    
    Args:
        lead: Lead data dict with id, name, email, etc.
        
    Returns:
        List of job IDs for queued notification jobs
    """
    logger.info(f"Sending new lead notifications for lead {lead.get('id')}")
    
    settings = get_notification_settings()
    if not settings.get('enabled', True):
        logger.info("Notifications are disabled, skipping new lead notification")
        return []
    
    recipients = get_notification_recipients()
    admin_emails = recipients.get('admin', [])
    
    if not admin_emails:
        logger.warning("No admin email recipients configured for new lead notifications")
        return []
    
    job_ids = []
    
    # Prepare email content
    subject = f"New Lead: {lead.get('name', 'Unknown')} ({lead.get('email', 'No email')})"
    
    body = f"""
New Lead Notification

Lead Details:
- ID: {lead.get('id', 'Unknown')}
- Name: {lead.get('name', 'Unknown')}
- Email: {lead.get('email', 'Unknown')}
- Phone: {lead.get('phone', 'Not provided')}
- Source: {lead.get('source', 'Web form')}
- Created: {lead.get('created_at', 'Unknown')}

You can view this lead in the admin panel:
{lead.get('admin_url', 'https://leadengine.example/leads')}

Best regards,
Lead Engine Control Hub
    """.strip()
    
    # Send to each admin recipient
    for email in admin_emails:
        email_payload = {
            'to': email,
            'subject': subject,
            'body': body,
            'template': 'new_lead_notification',
            'lead_id': lead.get('id'),
            'event_type': 'new_lead'
        }
        
        job_id = enqueue('email', email_payload)
        job_ids.append(job_id)
        logger.info(f"Queued new lead notification email to {email} (job: {job_id})")
    
    logger.info(f"Queued {len(job_ids)} new lead notification emails")
    return job_ids

def notify_sale_delivered(sale: Dict[str, Any]) -> List[str]:
    """
    Send notifications when a sale is delivered.
    
    Args:
        sale: Sale data dict with id, buyer_id, lead_id, price, etc.
        
    Returns:
        List of job IDs for queued notification jobs
    """
    logger.info(f"Sending sale delivered notifications for sale {sale.get('id')}")
    
    settings = get_notification_settings()
    if not settings.get('enabled', True):
        logger.info("Notifications are disabled, skipping sale delivered notification")
        return []
    
    recipients = get_notification_recipients()
    sales_emails = recipients.get('sales', [])
    admin_emails = recipients.get('admin', [])
    
    # Combine sales and admin emails, removing duplicates
    all_emails = list(set(sales_emails + admin_emails))
    
    if not all_emails:
        logger.warning("No email recipients configured for sale delivered notifications")
        return []
    
    job_ids = []
    
    # Prepare email content
    price_dollars = sale.get('price_cents', 0) / 100.0
    subject = f"Sale Delivered: ${price_dollars:.2f} (Sale #{sale.get('id')})"
    
    body = f"""
Sale Delivered Notification

Sale Details:
- Sale ID: {sale.get('id', 'Unknown')}
- Lead ID: {sale.get('lead_id', 'Unknown')}
- Buyer ID: {sale.get('buyer_id', 'Unknown')}
- Price: ${price_dollars:.2f}
- Status: {sale.get('status', 'Unknown')}
- Delivered: {sale.get('delivered_at', 'Now')}

Lead Information:
- Name: {sale.get('lead_name', 'Unknown')}
- Email: {sale.get('lead_email', 'Unknown')}

Buyer Information:
- Name: {sale.get('buyer_name', 'Unknown')}
- Email: {sale.get('buyer_email', 'Unknown')}

You can view this sale in the admin panel:
{sale.get('admin_url', 'https://leadengine.example/sales')}

Best regards,
Lead Engine Control Hub
    """.strip()
    
    # Send to each recipient
    for email in all_emails:
        email_payload = {
            'to': email,
            'subject': subject,
            'body': body,
            'template': 'sale_delivered_notification',
            'sale_id': sale.get('id'),
            'event_type': 'sale_delivered'
        }
        
        job_id = enqueue('email', email_payload)
        job_ids.append(job_id)
        logger.info(f"Queued sale delivered notification email to {email} (job: {job_id})")
    
    logger.info(f"Queued {len(job_ids)} sale delivered notification emails")
    return job_ids

def notify_system_alert(alert_type: str, message: str, severity: str = 'info') -> List[str]:
    """
    Send system alert notifications to administrators.
    
    Args:
        alert_type: Type of alert (error, warning, maintenance, etc.)
        message: Alert message content
        severity: Alert severity (info, warning, error, critical)
        
    Returns:
        List of job IDs for queued notification jobs
    """
    logger.info(f"Sending system alert notification: {alert_type} ({severity})")
    
    settings = get_notification_settings()
    if not settings.get('enabled', True):
        logger.info("Notifications are disabled, skipping system alert")
        return []
    
    # Only send system alerts to admins
    recipients = get_notification_recipients()
    admin_emails = recipients.get('admin', [])
    
    if not admin_emails:
        logger.warning("No admin email recipients configured for system alerts")
        return []
    
    # Skip low-severity alerts if configured
    min_severity = settings.get('min_alert_severity', 'info')
    severity_levels = {'info': 0, 'warning': 1, 'error': 2, 'critical': 3}
    
    if severity_levels.get(severity, 0) < severity_levels.get(min_severity, 0):
        logger.info(f"Skipping {severity} alert (below minimum {min_severity})")
        return []
    
    job_ids = []
    
    # Prepare email content
    severity_emoji = {
        'info': 'ℹ️',
        'warning': '⚠️', 
        'error': '❌',
        'critical': '🚨'
    }
    
    subject = f"{severity_emoji.get(severity, '📢')} System Alert: {alert_type}"
    
    body = f"""
System Alert Notification

Alert Type: {alert_type}
Severity: {severity.upper()}
Timestamp: {settings.get('current_time', 'Now')}

Message:
{message}

This alert was generated automatically by the Lead Engine Control Hub monitoring system.

Best regards,
Lead Engine Control Hub
    """.strip()
    
    # Send to each admin
    for email in admin_emails:
        email_payload = {
            'to': email,
            'subject': subject,
            'body': body,
            'template': 'system_alert',
            'alert_type': alert_type,
            'severity': severity,
            'event_type': 'system_alert'
        }
        
        job_id = enqueue('email', email_payload)
        job_ids.append(job_id)
        logger.info(f"Queued system alert email to {email} (job: {job_id})")
    
    logger.info(f"Queued {len(job_ids)} system alert emails")
    return job_ids

def get_notification_stats() -> Dict[str, Any]:
    """
    Get statistics about notification sending.
    
    Returns:
        Dict with notification counts and status
    """
    logger.info("Getting notification statistics")
    
    # In a real implementation, this would query the database for email job stats
    # For now, return mock statistics
    stats = {
        'total_sent': 156,
        'sent_today': 12,
        'failed_today': 1,
        'success_rate': 95.2,
        'avg_delivery_time_ms': 850,
        'notification_types': {
            'new_lead': 89,
            'sale_delivered': 45,
            'system_alert': 22
        },
        'recipients': {
            'admin_count': len(get_notification_recipients().get('admin', [])),
            'sales_count': len(get_notification_recipients().get('sales', []))
        },
        'settings': get_notification_settings()
    }
    
    logger.info(f"Notification stats: {stats['total_sent']} total sent, {stats['success_rate']}% success rate")
    return stats

# Log service initialization
logger.info("Notification service initialized with functions: notify_new_lead, notify_sale_delivered, notify_system_alert, get_notification_stats")
