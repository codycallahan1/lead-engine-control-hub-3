"""
Abuse protection management API routes.

Phase: 31
Purpose: Provide endpoints for managing IP allow/deny lists.
Key responsibilities:
- CRUD operations for IP lists
- Status and statistics endpoints
- Bulk operations for list management
"""

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import List, Dict, Any
import logging

try:
    from p31__server_services_abuse import (
        is_blocked,
        add_to_deny_list,
        remove_from_deny_list,
        add_to_allow_list,
        remove_from_allow_list,
        get_deny_list,
        get_allow_list,
        get_status,
        clear_all_lists,
        bulk_add_to_deny_list,
        set_auto_deny_enabled,
        load_predefined_deny_list
    )
    from p31__server_middleware_ratelimit import RateLimitMiddleware
except ImportError as e:
    logging.warning(f"Abuse routes: missing dependency {e}")

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/abuse", tags=["abuse"])


class IpRequest(BaseModel):
    ip: str = Field(..., description="IP address")


class BulkIpRequest(BaseModel):
    ips: List[str] = Field(..., description="List of IP addresses")


class AutoDenyRequest(BaseModel):
    enabled: bool = Field(..., description="Enable auto-deny feature")


class PredefinedListRequest(BaseModel):
    list_name: str = Field(..., description="Name of predefined list to load")


def require_admin():
    """Placeholder for admin role requirement."""
    return "admin"


@router.get("/status")
async def get_abuse_status(
    request: Request,
    actor: str = Depends(require_admin)
):
    """Get current abuse protection status and statistics."""
    
    try:
        status = get_status()
        
        # Add rate limiting stats if available
        rate_limit_stats = {}
        try:
            # Try to get rate limit middleware instance from app
            app = request.app
            for middleware in app.user_middleware:
                if isinstance(middleware.cls, type) and issubclass(middleware.cls, RateLimitMiddleware):
                    # This is a simplified approach - in reality would need better access
                    rate_limit_stats = {"middleware_active": True}
                    break
        except:
            pass
        
        return {
            "abuse_protection": status,
            "rate_limiting": rate_limit_stats,
            "server_time": status["metadata"].get("last_updated"),
            "features_enabled": {
                "ip_blocking": True,
                "rate_limiting": bool(rate_limit_stats),
                "auto_deny": status["features"]["auto_deny"]
            }
        }
    
    except Exception as e:
        logger.error(f"Error getting abuse status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get abuse status")


@router.post("/deny")
async def add_ip_to_deny_list(
    ip_request: IpRequest,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Add IP address to deny list."""
    
    try:
        success = add_to_deny_list(ip_request.ip, actor)
        
        if not success:
            # Could be invalid IP or already present
            if ip_request.ip in get_deny_list():
                return {
                    "success": True,
                    "message": f"IP {ip_request.ip} already in deny list",
                    "action": "none"
                }
            else:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Invalid IP address: {ip_request.ip}"
                )
        
        logger.info(f"Added IP {ip_request.ip} to deny list by {actor}")
        
        return {
            "success": True,
            "message": f"IP {ip_request.ip} added to deny list",
            "action": "added"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding IP to deny list: {e}")
        raise HTTPException(status_code=500, detail="Failed to add IP to deny list")


@router.delete("/deny/{ip}")
async def remove_ip_from_deny_list(
    ip: str,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Remove IP address from deny list."""
    
    try:
        success = remove_from_deny_list(ip, actor)
        
        if not success:
            raise HTTPException(
                status_code=404, 
                detail=f"IP {ip} not found in deny list"
            )
        
        logger.info(f"Removed IP {ip} from deny list by {actor}")
        
        return {
            "success": True,
            "message": f"IP {ip} removed from deny list",
            "action": "removed"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error removing IP from deny list: {e}")
        raise HTTPException(status_code=500, detail="Failed to remove IP from deny list")


@router.post("/allow")
async def add_ip_to_allow_list(
    ip_request: IpRequest,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Add IP address to allow list (exempts from deny list)."""
    
    try:
        success = add_to_allow_list(ip_request.ip, actor)
        
        if not success:
            # Could be invalid IP or already present
            if ip_request.ip in get_allow_list():
                return {
                    "success": True,
                    "message": f"IP {ip_request.ip} already in allow list",
                    "action": "none"
                }
            else:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Invalid IP address: {ip_request.ip}"
                )
        
        logger.info(f"Added IP {ip_request.ip} to allow list by {actor}")
        
        return {
            "success": True,
            "message": f"IP {ip_request.ip} added to allow list",
            "action": "added"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding IP to allow list: {e}")
        raise HTTPException(status_code=500, detail="Failed to add IP to allow list")


@router.delete("/allow/{ip}")
async def remove_ip_from_allow_list(
    ip: str,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Remove IP address from allow list."""
    
    try:
        success = remove_from_allow_list(ip, actor)
        
        if not success:
            raise HTTPException(
                status_code=404, 
                detail=f"IP {ip} not found in allow list"
            )
        
        logger.info(f"Removed IP {ip} from allow list by {actor}")
        
        return {
            "success": True,
            "message": f"IP {ip} removed from allow list",
            "action": "removed"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error removing IP from allow list: {e}")
        raise HTTPException(status_code=500, detail="Failed to remove IP from allow list")


@router.get("/check/{ip}")
async def check_ip_status(
    ip: str,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Check if an IP address is blocked."""
    
    try:
        blocked = is_blocked(ip)
        in_deny_list = ip in get_deny_list()
        in_allow_list = ip in get_allow_list()
        
        return {
            "ip": ip,
            "blocked": blocked,
            "in_deny_list": in_deny_list,
            "in_allow_list": in_allow_list,
            "explanation": (
                "Allowed (in allow list)" if in_allow_list
                else "Blocked (in deny list)" if in_deny_list
                else "Not blocked"
            )
        }
    
    except Exception as e:
        logger.error(f"Error checking IP status: {e}")
        raise HTTPException(status_code=500, detail="Failed to check IP status")


@router.post("/bulk-deny")
async def bulk_add_to_deny(
    bulk_request: BulkIpRequest,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Add multiple IP addresses to deny list."""
    
    if len(bulk_request.ips) > 100:
        raise HTTPException(
            status_code=400, 
            detail="Too many IPs (max 100 per request)"
        )
    
    try:
        results = bulk_add_to_deny_list(bulk_request.ips, actor)
        
        logger.info(f"Bulk deny by {actor}: {len(results['added'])} added")
        
        return {
            "success": True,
            "total_requested": len(bulk_request.ips),
            **results
        }
    
    except Exception as e:
        logger.error(f"Error in bulk deny operation: {e}")
        raise HTTPException(status_code=500, detail="Bulk deny operation failed")


@router.post("/clear-all")
async def clear_all_ip_lists(
    request: Request,
    actor: str = Depends(require_admin)
):
    """Clear all IP lists (emergency function)."""
    
    try:
        results = clear_all_lists(actor)
        
        logger.warning(f"All IP lists cleared by {actor}")
        
        return {
            "success": True,
            "message": "All IP lists cleared",
            **results
        }
    
    except Exception as e:
        logger.error(f"Error clearing IP lists: {e}")
        raise HTTPException(status_code=500, detail="Failed to clear IP lists")


@router.post("/auto-deny")
async def set_auto_deny_setting(
    auto_deny_request: AutoDenyRequest,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Enable or disable automatic IP denial."""
    
    try:
        set_auto_deny_enabled(auto_deny_request.enabled, actor)
        
        action = "enabled" if auto_deny_request.enabled else "disabled"
        logger.info(f"Auto-deny {action} by {actor}")
        
        return {
            "success": True,
            "message": f"Auto-deny {action}",
            "auto_deny_enabled": auto_deny_request.enabled
        }
    
    except Exception as e:
        logger.error(f"Error setting auto-deny: {e}")
        raise HTTPException(status_code=500, detail="Failed to set auto-deny setting")


@router.post("/load-predefined")
async def load_predefined_deny_list_endpoint(
    predefined_request: PredefinedListRequest,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Load a predefined deny list."""
    
    try:
        results = load_predefined_deny_list(predefined_request.list_name, actor)
        
        if "error" in results:
            raise HTTPException(status_code=400, detail=results["error"])
        
        logger.info(f"Loaded predefined list '{predefined_request.list_name}' by {actor}")
        
        return {
            "success": True,
            "message": f"Loaded predefined list: {predefined_request.list_name}",
            **results
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error loading predefined list: {e}")
        raise HTTPException(status_code=500, detail="Failed to load predefined list")


@router.get("/lists")
async def get_all_lists(
    request: Request,
    actor: str = Depends(require_admin)
):
    """Get all IP lists (admin view)."""
    
    try:
        return {
            "deny_list": list(get_deny_list()),
            "allow_list": list(get_allow_list()),
            "counts": {
                "denied": len(get_deny_list()),
                "allowed": len(get_allow_list())
            }
        }
    
    except Exception as e:
        logger.error(f"Error getting IP lists: {e}")
        raise HTTPException(status_code=500, detail="Failed to get IP lists")
