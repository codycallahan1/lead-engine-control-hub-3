"""
Error handling middleware with custom error pages and request IDs.

Phase: 17
Purpose: Centralized error handling with custom templates and request tracking
Key responsibilities: add_exception_handlers function, request ID injection, error page rendering
"""

import logging
import uuid
from typing import Any
from fastapi import Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

logger = logging.getLogger(__name__)

# Template setup - would be wired from main app
templates = Jinja2Templates(directory=".")

class RequestIDMiddleware(BaseHTTPMiddleware):
    """
    Middleware to add unique request IDs to all responses.
    
    Generates a UUID for each request and adds it to response headers
    for tracking and debugging purposes.
    """
    
    async def dispatch(self, request: Request, call_next):
        # Generate unique request ID
        request_id = str(uuid.uuid4())
        
        # Add request ID to request state for access in handlers
        request.state.request_id = request_id
        
        # Log the incoming request
        logger.info(f"Request {request_id}: {request.method} {request.url}")
        
        try:
            # Process the request
            response = await call_next(request)
            
            # Add request ID to response headers
            response.headers["X-Request-ID"] = request_id
            
            # Log the response
            logger.info(f"Request {request_id}: {response.status_code}")
            
            return response
            
        except Exception as e:
            # Log unexpected errors with request ID
            logger.error(f"Request {request_id}: Unhandled exception: {e}")
            
            # Create error response with request ID
            error_response = JSONResponse(
                status_code=500,
                content={"error": "Internal server error", "request_id": request_id}
            )
            error_response.headers["X-Request-ID"] = request_id
            
            return error_response

def add_exception_handlers(app):
    """
    Add custom exception handlers to the FastAPI app.
    
    Configures handlers for common HTTP errors with custom templates
    and proper error logging.
    
    Args:
        app: FastAPI application instance
    """
    logger.info("Adding custom exception handlers")
    
    @app.exception_handler(404)
    async def not_found_handler(request: Request, exc: HTTPException):
        """Handle 404 Not Found errors with custom template."""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        logger.warning(f"Request {request_id}: 404 Not Found - {request.url}")
        
        # Check if request accepts HTML
        accept_header = request.headers.get('accept', '')
        
        if 'text/html' in accept_header:
            # Return HTML error page
            try:
                context = {
                    "request": request,
                    "request_id": request_id,
                    "path": str(request.url.path),
                    "method": request.method
                }
                
                response = templates.TemplateResponse(
                    "p17__server-templates-404.html", 
                    context,
                    status_code=404
                )
                response.headers["X-Request-ID"] = request_id
                return response
                
            except Exception as template_error:
                logger.error(f"Error rendering 404 template: {template_error}")
                # Fallback HTML
                fallback_html = f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Page Not Found</title>
                    <style>
                        body {{ font-family: Arial, sans-serif; background: #1a1a1a; color: white; 
                               padding: 2rem; text-align: center; }}
                        .error-container {{ max-width: 600px; margin: 0 auto; }}
                        .error-code {{ font-size: 4rem; color: #3b82f6; margin-bottom: 1rem; }}
                        .error-message {{ font-size: 1.5rem; margin-bottom: 2rem; }}
                        .error-details {{ color: #666; margin-bottom: 2rem; }}
                        .btn {{ background: #3b82f6; color: white; padding: 0.5rem 1rem; 
                               text-decoration: none; border-radius: 4px; }}
                    </style>
                </head>
                <body>
                    <div class="error-container">
                        <div class="error-code">404</div>
                        <div class="error-message">Page Not Found</div>
                        <div class="error-details">
                            The page "{request.url.path}" could not be found.
                            <br>Request ID: {request_id}
                        </div>
                        <a href="/" class="btn">Return Home</a>
                    </div>
                </body>
                </html>
                """
                response = HTMLResponse(content=fallback_html, status_code=404)
                response.headers["X-Request-ID"] = request_id
                return response
        else:
            # Return JSON error response
            response = JSONResponse(
                status_code=404,
                content={
                    "error": "Not Found",
                    "message": f"The requested resource '{request.url.path}' was not found",
                    "request_id": request_id,
                    "status_code": 404
                }
            )
            response.headers["X-Request-ID"] = request_id
            return response
    
    @app.exception_handler(500)
    async def internal_error_handler(request: Request, exc: Exception):
        """Handle 500 Internal Server Error with custom template."""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        # Log the full error details
        logger.error(f"Request {request_id}: Internal server error: {exc}", exc_info=True)
        
        # Check if request accepts HTML
        accept_header = request.headers.get('accept', '')
        
        if 'text/html' in accept_header:
            # Return HTML error page
            try:
                context = {
                    "request": request,
                    "request_id": request_id,
                    "path": str(request.url.path),
                    "method": request.method
                }
                
                response = templates.TemplateResponse(
                    "p17__server-templates-500.html",
                    context,
                    status_code=500
                )
                response.headers["X-Request-ID"] = request_id
                return response
                
            except Exception as template_error:
                logger.error(f"Error rendering 500 template: {template_error}")
                # Fallback HTML
                fallback_html = f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Internal Server Error</title>
                    <style>
                        body {{ font-family: Arial, sans-serif; background: #1a1a1a; color: white; 
                               padding: 2rem; text-align: center; }}
                        .error-container {{ max-width: 600px; margin: 0 auto; }}
                        .error-code {{ font-size: 4rem; color: #ef4444; margin-bottom: 1rem; }}
                        .error-message {{ font-size: 1.5rem; margin-bottom: 2rem; }}
                        .error-details {{ color: #666; margin-bottom: 2rem; }}
                        .btn {{ background: #3b82f6; color: white; padding: 0.5rem 1rem; 
                               text-decoration: none; border-radius: 4px; }}
                    </style>
                </head>
                <body>
                    <div class="error-container">
                        <div class="error-code">500</div>
                        <div class="error-message">Internal Server Error</div>
                        <div class="error-details">
                            An unexpected error occurred while processing your request.
                            <br>Request ID: {request_id}
                            <br>Please try again later or contact support if the problem persists.
                        </div>
                        <a href="/" class="btn">Return Home</a>
                    </div>
                </body>
                </html>
                """
                response = HTMLResponse(content=fallback_html, status_code=500)
                response.headers["X-Request-ID"] = request_id
                return response
        else:
            # Return JSON error response (hide internal details)
            response = JSONResponse(
                status_code=500,
                content={
                    "error": "Internal Server Error",
                    "message": "An unexpected error occurred while processing your request",
                    "request_id": request_id,
                    "status_code": 500
                }
            )
            response.headers["X-Request-ID"] = request_id
            return response
    
    @app.exception_handler(403)
    async def forbidden_handler(request: Request, exc: HTTPException):
        """Handle 403 Forbidden errors."""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        logger.warning(f"Request {request_id}: 403 Forbidden - {request.url}")
        
        accept_header = request.headers.get('accept', '')
        
        if 'text/html' in accept_header:
            # Simple HTML response for forbidden
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Access Forbidden</title>
                <style>
                    body {{ font-family: Arial, sans-serif; background: #1a1a1a; color: white; 
                           padding: 2rem; text-align: center; }}
                    .error-container {{ max-width: 600px; margin: 0 auto; }}
                    .error-code {{ font-size: 4rem; color: #f59e0b; margin-bottom: 1rem; }}
                    .error-message {{ font-size: 1.5rem; margin-bottom: 2rem; }}
                    .error-details {{ color: #666; margin-bottom: 2rem; }}
                    .btn {{ background: #3b82f6; color: white; padding: 0.5rem 1rem; 
                           text-decoration: none; border-radius: 4px; }}
                </style>
            </head>
            <body>
                <div class="error-container">
                    <div class="error-code">403</div>
                    <div class="error-message">Access Forbidden</div>
                    <div class="error-details">
                        You don't have permission to access this resource.
                        <br>Request ID: {request_id}
                    </div>
                    <a href="/" class="btn">Return Home</a>
                </div>
            </body>
            </html>
            """
            response = HTMLResponse(content=html_content, status_code=403)
            response.headers["X-Request-ID"] = request_id
            return response
        else:
            response = JSONResponse(
                status_code=403,
                content={
                    "error": "Forbidden",
                    "message": "You don't have permission to access this resource",
                    "request_id": request_id,
                    "status_code": 403
                }
            )
            response.headers["X-Request-ID"] = request_id
            return response
    
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        """Handle other HTTP exceptions."""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        logger.warning(f"Request {request_id}: HTTP {exc.status_code} - {exc.detail}")
        
        accept_header = request.headers.get('accept', '')
        
        if 'text/html' in accept_header and exc.status_code not in [404, 500, 403]:
            # Generic HTML error page for other HTTP errors
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Error {exc.status_code}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; background: #1a1a1a; color: white; 
                           padding: 2rem; text-align: center; }}
                    .error-container {{ max-width: 600px; margin: 0 auto; }}
                    .error-code {{ font-size: 4rem; color: #ef4444; margin-bottom: 1rem; }}
                    .error-message {{ font-size: 1.5rem; margin-bottom: 2rem; }}
                    .error-details {{ color: #666; margin-bottom: 2rem; }}
                    .btn {{ background: #3b82f6; color: white; padding: 0.5rem 1rem; 
                           text-decoration: none; border-radius: 4px; }}
                </style>
            </head>
            <body>
                <div class="error-container">
                    <div class="error-code">{exc.status_code}</div>
                    <div class="error-message">Error</div>
                    <div class="error-details">
                        {exc.detail}
                        <br>Request ID: {request_id}
                    </div>
                    <a href="/" class="btn">Return Home</a>
                </div>
            </body>
            </html>
            """
            response = HTMLResponse(content=html_content, status_code=exc.status_code)
            response.headers["X-Request-ID"] = request_id
            return response
        else:
            response = JSONResponse(
                status_code=exc.status_code,
                content={
                    "error": exc.__class__.__name__,
                    "message": exc.detail,
                    "request_id": request_id,
                    "status_code": exc.status_code
                }
            )
            response.headers["X-Request-ID"] = request_id
            return response
    
    logger.info("Exception handlers registered successfully")

def get_request_id(request: Request) -> str:
    """
    Get the request ID from the request state.
    
    Args:
        request: FastAPI request object
        
    Returns:
        Request ID string
    """
    return getattr(request.state, 'request_id', 'unknown')

# Log middleware initialization
logger.info("Error handling middleware initialized with RequestIDMiddleware and exception handlers")

        