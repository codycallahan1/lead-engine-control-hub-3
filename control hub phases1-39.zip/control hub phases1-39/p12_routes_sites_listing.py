"""
Enhanced sites routes with pagination, filtering, and sorting.

Phase: 12
Purpose: Extended GET /sites endpoint with query params and pagination support
Key responsibilities: Paginated sites listing with search and sort capabilities
"""

import logging
from typing import Dict, Any, List
from fastapi import APIRouter, Request, HTTPException, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# Import attempt with graceful fallback
try:
    from p02__server_db import get_session
    from p02__server_models import Site
    from p02__server_schemas import SiteOut
    from p12__server_utils_query import parse_query_params, apply_query
except ImportError as e:
    logging.warning(f"Import issue in sites listing routes: {e}")
    # Fallback for development
    def get_session():
        return None
    class Site:
        pass
    class SiteOut:
        pass
    def parse_query_params(request):
        return {}
    def apply_query(query, params, search_cols, sort_cols):
        return query, 0

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/sites", tags=["sites"])

# Template setup - would be wired from main app
templates = Jinja2Templates(directory=".")

@router.get("", response_model=Dict[str, Any])
async def list_sites_paginated(request: Request):
    """
    List sites with pagination, search, and sorting.
    
    Query params:
    - page: Page number (default 1)
    - per_page: Items per page (default 20, max 100)
    - sort: Sort field with optional - prefix for desc (created_at, -created_at, name, -name)
    - q: Search term for name/domain
    """
    logger.info("GET /sites - paginated listing requested")
    
    params = parse_query_params(request)
    
    with get_session() as session:
        # Base query
        base_query = session.query(Site)
        
        # Define searchable and sortable columns
        searchable_cols = ['name', 'domain']
        sortable_cols = ['created_at', 'name', 'domain', 'status']
        
        # Apply filters, sorting, and pagination
        query, total_count = apply_query(
            base_query, 
            params, 
            searchable_cols, 
            sortable_cols
        )
        
        # Execute query
        sites = query.all()
        
        # Convert to Pydantic models
        site_items = [SiteOut.from_orm(site) for site in sites]
        
        result = {
            "items": site_items,
            "page": params['page'],
            "per_page": params['per_page'],
            "total": total_count,
            "total_pages": (total_count + params['per_page'] - 1) // params['per_page']
        }
        
        logger.info(f"Returned {len(site_items)} sites (page {params['page']}/{result['total_pages']})")
        return result

@router.get("-page", response_class=HTMLResponse)
async def sites_page(request: Request):
    """
    Server-side rendered sites page with search, sort, and pagination controls.
    """
    logger.info("GET /sites-page - HTML page requested")
    
    params = parse_query_params(request)
    
    with get_session() as session:
        base_query = session.query(Site)
        searchable_cols = ['name', 'domain']
        sortable_cols = ['created_at', 'name', 'domain', 'status']
        
        query, total_count = apply_query(
            base_query, 
            params, 
            searchable_cols, 
            sortable_cols
        )
        
        sites = query.all()
        total_pages = (total_count + params['per_page'] - 1) // params['per_page']
        
        # Calculate pagination info
        has_prev = params['page'] > 1
        has_next = params['page'] < total_pages
        
        context = {
            "request": request,
            "sites": sites,
            "page": params['page'],
            "per_page": params['per_page'],
            "total": total_count,
            "total_pages": total_pages,
            "has_prev": has_prev,
            "has_next": has_next,
            "prev_page": params['page'] - 1 if has_prev else None,
            "next_page": params['page'] + 1 if has_next else None,
            "current_sort": params['sort'],
            "current_search": params['q']
        }
        
        try:
            return templates.TemplateResponse("p12__server-templates-sites.html", context)
        except Exception as e:
            logger.error(f"Template error: {e}")
            return f"<html><body><h1>Sites Page</h1><p>Found {len(sites)} sites</p></body></html>"
