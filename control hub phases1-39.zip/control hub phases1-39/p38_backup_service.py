"""
Backup & Restore service for SQLite database and templates.
Phase 38: Backup & Restore (SQLite & Templates)
Purpose: downloadable DB snapshot and template pack; admin-only restore
"""

import os
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# In-memory flag to prevent backup/restore conflicts
_retention_sweep_running = False


def set_retention_sweep_flag(running: bool):
    """Set the retention sweep running flag to prevent conflicts."""
    global _retention_sweep_running
    _retention_sweep_running = running


def is_retention_sweep_running() -> bool:
    """Check if retention sweep is currently running."""
    return _retention_sweep_running


def snapshot_sqlite() -> str:
    """
    Create a timestamped snapshot of the SQLite database.
    Returns the filename (not full path for security).
    """
    if is_retention_sweep_running():
        raise RuntimeError("Cannot backup while retention sweep is running")
    
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"controlhub_backup_{timestamp}.db"
    
    # Ensure backup directory exists
    backup_dir = Path("./server/backups")
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    backup_path = backup_dir / filename
    source_db = "./controlhub.db"
    
    logger.info(f"Creating SQLite backup: {filename}")
    
    try:
        # Use SQLite backup API for consistent snapshot
        source_conn = sqlite3.connect(source_db)
        backup_conn = sqlite3.connect(str(backup_path))
        
        source_conn.backup(backup_conn)
        
        source_conn.close()
        backup_conn.close()
        
        # Verify the backup
        if not verify_integrity(str(backup_path)):
            os.remove(backup_path)
            raise RuntimeError("Backup failed integrity check")
            
        logger.info(f"SQLite backup created successfully: {filename}")
        return str(backup_path)
        
    except Exception as e:
        logger.error(f"Failed to create SQLite backup: {e}")
        if backup_path.exists():
            os.remove(backup_path)
        raise


def snapshot_templates() -> str:
    """
    Create a ZIP archive of all template files.
    Returns the zip file path.
    """
    if is_retention_sweep_running():
        raise RuntimeError("Cannot backup while retention sweep is running")
    
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"templates_backup_{timestamp}.zip"
    
    backup_dir = Path("./server/backups")
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    zip_path = backup_dir / filename
    
    logger.info(f"Creating templates backup: {filename}")
    
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Look for template files with p*__*template* pattern
            current_dir = Path(".")
            
            template_files = []
            for file_path in current_dir.glob("p*__*template*"):
                if file_path.is_file():
                    template_files.append(file_path)
            
            # Also include any .html files that match our pattern
            for file_path in current_dir.glob("p*__*.html"):
                if file_path.is_file() and file_path not in template_files:
                    template_files.append(file_path)
            
            # Add CSS files
            for file_path in current_dir.glob("p*__*.css"):
                if file_path.is_file():
                    template_files.append(file_path)
            
            # Add JS files
            for file_path in current_dir.glob("p*__*.js"):
                if file_path.is_file():
                    template_files.append(file_path)
            
            if not template_files:
                logger.warning("No template files found matching pattern")
            
            for file_path in template_files:
                zipf.write(file_path, file_path.name)
                logger.debug(f"Added to templates backup: {file_path.name}")
        
        logger.info(f"Templates backup created successfully: {filename}")
        return str(zip_path)
        
    except Exception as e:
        logger.error(f"Failed to create templates backup: {e}")
        if zip_path.exists():
            os.remove(zip_path)
        raise


def restore_sqlite(uploaded_file_path: str) -> Tuple[bool, str]:
    """
    Restore SQLite database from uploaded file.
    Returns (success, message).
    """
    if is_retention_sweep_running():
        return False, "Cannot restore while retention sweep is running"
    
    logger.info("Starting SQLite restore process")
    
    try:
        # Verify the uploaded file
        if not verify_integrity(uploaded_file_path):
            return False, "Uploaded file failed integrity check"
        
        # Create backup of current database before restore
        current_backup = None
        try:
            current_backup = snapshot_sqlite()
            logger.info(f"Current database backed up to: {Path(current_backup).name}")
        except Exception as e:
            logger.warning(f"Could not backup current database: {e}")
        
        # Replace the current database
        target_db = "./controlhub.db"
        
        # Copy uploaded file to replace current database
        shutil.copy2(uploaded_file_path, target_db)
        
        # Verify the restored database
        if not verify_integrity(target_db):
            # Restore from backup if available
            if current_backup and os.path.exists(current_backup):
                shutil.copy2(current_backup, target_db)
                return False, "Restored database failed verification, reverted to previous version"
            else:
                return False, "Restored database failed verification and no backup available"
        
        logger.info("SQLite database restored successfully")
        return True, "Database restored successfully. Server restart recommended for full effect."
        
    except Exception as e:
        logger.error(f"Failed to restore SQLite database: {e}")
        return False, f"Restore failed: {str(e)}"


def verify_integrity(db_path: str) -> bool:
    """
    Verify SQLite database integrity.
    Returns True if database is valid.
    """
    try:
        if not os.path.exists(db_path):
            return False
        
        # Check file size
        file_size = os.path.getsize(db_path)
        if file_size < 1024:  # Less than 1KB is suspicious
            logger.warning(f"Database file suspiciously small: {file_size} bytes")
            return False
        
        # Try to connect and run integrity check
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Basic connectivity test
        cursor.execute("SELECT 1")
        
        # SQLite integrity check
        cursor.execute("PRAGMA integrity_check")
        result = cursor.fetchone()
        
        conn.close()
        
        if result and result[0] == "ok":
            logger.debug(f"Database integrity check passed: {db_path}")
            return True
        else:
            logger.error(f"Database integrity check failed: {result}")
            return False
            
    except Exception as e:
        logger.error(f"Database integrity check error: {e}")
        return False


def get_backup_list() -> list:
    """
    Get list of available backup files.
    Returns list of dicts with filename and metadata.
    """
    backup_dir = Path("./server/backups")
    if not backup_dir.exists():
        return []
    
    backups = []
    
    for file_path in backup_dir.glob("controlhub_backup_*.db"):
        try:
            stat = file_path.stat()
            backups.append({
                "filename": file_path.name,
                "size_bytes": stat.st_size,
                "created_at": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "type": "database"
            })
        except Exception as e:
            logger.warning(f"Could not read backup file info: {file_path.name}: {e}")
    
    for file_path in backup_dir.glob("templates_backup_*.zip"):
        try:
            stat = file_path.stat()
            backups.append({
                "filename": file_path.name,
                "size_bytes": stat.st_size,
                "created_at": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "type": "templates"
            })
        except Exception as e:
            logger.warning(f"Could not read backup file info: {file_path.name}: {e}")
    
    # Sort by creation time, newest first
    backups.sort(key=lambda x: x["created_at"], reverse=True)
    
    return backups


def cleanup_old_backups(keep_count: int = 10):
    """
    Remove old backup files, keeping only the most recent ones.
    """
    backup_dir = Path("./server/backups")
    if not backup_dir.exists():
        return
    
    # Get all backup files sorted by creation time
    all_backups = []
    
    for pattern in ["controlhub_backup_*.db", "templates_backup_*.zip"]:
        for file_path in backup_dir.glob(pattern):
            try:
                stat = file_path.stat()
                all_backups.append((file_path, stat.st_ctime))
            except Exception:
                continue
    
    # Sort by creation time, newest first
    all_backups.sort(key=lambda x: x[1], reverse=True)
    
    # Remove files beyond keep_count
    for file_path, _ in all_backups[keep_count:]:
        try:
            os.remove(file_path)
            logger.info(f"Cleaned up old backup: {file_path.name}")
        except Exception as e:
            logger.warning(f"Could not remove old backup {file_path.name}: {e}")
