"""
Sales tracking models for buyer-lead assignments.

Phase: 14
Purpose: SQLAlchemy models for tracking lead sales to buyers
Key responsibilities: LeadSale table definition with status tracking
"""

import logging
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship

# Import attempt with graceful fallback
try:
    from p02__server_db import Base
except ImportError as e:
    logging.warning(f"Import issue in sales models: {e}")
    # Fallback for development
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()

logger = logging.getLogger(__name__)

class LeadSale(Base):
    """
    Record of a lead being sold to a buyer.
    
    Tracks the sale transaction including price, status, and timestamps.
    Status flow: created -> delivered -> (potentially) refunded
    """
    __tablename__ = "lead_sales"
    
    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False, index=True)
    buyer_id = Column(Integer, ForeignKey("buyers.id"), nullable=False, index=True)
    price_cents = Column(Integer, nullable=False, default=1000)  # Price in cents (e.g., 1000 = $10.00)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    status = Column(String(20), nullable=False, default="created", index=True)
    # Status values: created, delivered, refunded
    
    # Relationships (would be defined when integrated with existing models)
    # lead = relationship("Lead", back_populates="sales")
    # buyer = relationship("Buyer", back_populates="purchases")
    
    def __repr__(self):
        return f"<LeadSale(id={self.id}, lead_id={self.lead_id}, buyer_id={self.buyer_id}, price_cents={self.price_cents}, status='{self.status}')>"
    
    @property
    def price_dollars(self) -> float:
        """Convert price from cents to dollars for display."""
        return self.price_cents / 100.0
    
    def can_be_refunded(self) -> bool:
        """Check if this sale can be refunded."""
        return self.status in ["created", "delivered"]
    
    def mark_delivered(self):
        """Mark the sale as delivered."""
        if self.status == "created":
            self.status = "delivered"
            logger.info(f"LeadSale {self.id} marked as delivered")
        else:
            logger.warning(f"Cannot mark LeadSale {self.id} as delivered - current status: {self.status}")
    
    def mark_refunded(self):
        """Mark the sale as refunded."""
        if self.can_be_refunded():
            self.status = "refunded"
            logger.info(f"LeadSale {self.id} marked as refunded")
        else:
            logger.warning(f"Cannot refund LeadSale {self.id} - current status: {self.status}")

# Log model creation
logger.info("Sales models defined: LeadSale")
