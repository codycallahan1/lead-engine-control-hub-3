"""
Lead Engine Control Hub - Credit System Models
Phase 33: Buyer credits and spend controls
Purpose: Track buyer credit balances and spending ledger
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship

# Import base from existing models (would be consolidated in final structure)
try:
    from p02__server_models import Base
except ImportError:
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()


class BuyerCredit(Base):
    """
    Tracks credit balance and limits for each buyer.
    
    Supports different renewal periods (monthly, quarterly, etc.)
    and enforces spending caps per period.
    """
    __tablename__ = "buyer_credits"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    buyer_id = Column(Integer, ForeignKey("buyers.id"), nullable=False, index=True)
    
    # Credit amounts in cents for precision
    balance_cents = Column(Integer, nullable=False, default=0)
    cap_cents = Column(Integer, nullable=False, default=100000)  # $1000 default cap
    
    # Renewal configuration
    renewal_period = Column(String(20), nullable=False, default="monthly")  # monthly, quarterly, annually
    renewed_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    buyer = relationship("Buyer", back_populates="credit")
    spend_ledger = relationship("SpendLedger", back_populates="buyer_credit", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<BuyerCredit buyer_id={self.buyer_id} balance=${self.balance_cents/100:.2f} cap=${self.cap_cents/100:.2f}>"
    
    @property
    def balance_dollars(self):
        """Convert balance to dollars for display."""
        return self.balance_cents / 100
    
    @property
    def cap_dollars(self):
        """Convert cap to dollars for display."""
        return self.cap_cents / 100
    
    def has_sufficient_credit(self, amount_cents: int) -> bool:
        """Check if buyer has sufficient credit for a transaction."""
        return self.balance_cents >= amount_cents
    
    def is_within_cap(self, additional_cents: int = 0) -> bool:
        """Check if adding amount would exceed cap."""
        return (self.balance_cents + additional_cents) <= self.cap_cents


class SpendLedger(Base):
    """
    Immutable ledger of all credit transactions.
    
    Records both charges (negative amounts) and top-ups (positive amounts)
    with full audit trail and context.
    """
    __tablename__ = "spend_ledger"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    buyer_id = Column(Integer, ForeignKey("buyers.id"), nullable=False, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=True, index=True)  # Null for top-ups
    
    # Transaction details
    amount_cents = Column(Integer, nullable=False)  # Positive for credits, negative for charges
    kind = Column(String(20), nullable=False, index=True)  # charge, topup, refund, adjustment
    note = Column(Text, nullable=True)
    
    # Audit fields
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    created_by = Column(String(100), nullable=True)  # User or system identifier
    
    # Relationships
    buyer_credit = relationship("BuyerCredit", back_populates="spend_ledger")
    buyer = relationship("Buyer")
    lead = relationship("Lead")
    
    def __repr__(self):
        return f"<SpendLedger buyer_id={self.buyer_id} amount=${self.amount_cents/100:.2f} kind={self.kind}>"
    
    @property
    def amount_dollars(self):
        """Convert amount to dollars for display."""
        return self.amount_cents / 100
    
    @property
    def is_charge(self):
        """Check if this is a charge (negative amount)."""
        return self.amount_cents < 0
    
    @property
    def is_credit(self):
        """Check if this is a credit (positive amount)."""
        return self.amount_cents > 0


# Migration helper - add CPL field to existing Buyer model
def add_buyer_cpl_field():
    """
    Migration function to add cost-per-lead field to Buyer model.
    In a real application, this would be handled by Alembic or similar.
    """
    # This would add: cpl_cents = Column(Integer, nullable=True, default=1000)  # $10 default
    pass


# Indexes for performance
# CREATE INDEX idx_buyer_credits_org_buyer ON buyer_credits(org_id, buyer_id);
# CREATE INDEX idx_spend_ledger_org_buyer_date ON spend_ledger(org_id, buyer_id, created_at);
# CREATE INDEX idx_spend_ledger_kind_date ON spend_ledger(kind, created_at);
