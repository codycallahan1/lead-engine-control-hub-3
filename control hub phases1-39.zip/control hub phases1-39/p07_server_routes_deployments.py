"""
Lead Engine Control Hub - Deployment Routes
Phase: 7
Purpose: FastAPI router for deployment endpoints (JSON API + HTML pages)
Key Responsibilities:
- REST API endpoints for deployment listing and status
- HTML page rendering for deployment history
- Combine deployment data with site information
- Display deployment logs and status information
"""

import logging
from typing import List, Optional
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# Import services
try:
    from p07__server_services_builder import list_deployments, get_deployment_by_id
    from p06__server_services_sites import SiteService
    from p02__server_db import get_session
    from p06__server_models_deployments import Deployment
except ImportError as e:
    logging.warning(f"Import error in deployment routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2, 6, and 7 files are available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/deployments", tags=["deployments"])

# Initialize templates
try:
    templates_path = Path(__file__).parent / "templates"
    templates_path.mkdir(exist_ok=True)
    templates = Jinja2Templates(directory=str(templates_path))
    logger.info("Templates initialized for deployment routes")
except Exception as e:
    logger.warning(f"Could not initialize templates: {e}")
    templates = None

# =============================================================================
# JSON API ENDPOINTS
# =============================================================================

@router.get("/")
async def get_deployments(
    limit: int = Query(50, ge=1, le=200, description="Maximum number of deployments to return"),
    status: Optional[str] = Query(None, description="Filter by deployment status")
):
    """
    Get list of deployments with optional filtering.
    
    Args:
        limit: Maximum number of deployments to return
        status: Optional status filter
        
    Returns:
        List of deployment objects with site information
    """
    try:
        logger.info(f"GET /deployments - limit: {limit}, status: {status}")
        
        # Get deployments from database with site information
        deployments_with_sites = []
        
        with get_session() as db:
            query = db.query(Deployment)
            
            # Apply status filter if provided
            if status:
                query = query.filter(Deployment.status == status.lower())
            
            deployments = query.order_by(Deployment.created_at.desc()).limit(limit).all()
            
            for deployment in deployments:
                deployment_dict = deployment.to_dict()
                
                # Add site information
                if deployment.site:
                    deployment_dict.update({
                        "site_name": deployment.site.name,
                        "site_domain": deployment.site.domain,
                        "site_status": deployment.site.status
                    })
                else:
                    deployment_dict.update({
                        "site_name": "Unknown",
                        "site_domain": "Unknown",
                        "site_status": "Unknown"
                    })
                
                deployments_with_sites.append(deployment_dict)
        
        logger.info(f"Retrieved {len(deployments_with_sites)} deployments")
        return deployments_with_sites
        
    except Exception as e:
        logger.error(f"Failed to retrieve deployments: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/{deployment_id}")
async def get_deployment(deployment_id: int):
    """
    Get a specific deployment by ID.
    
    Args:
        deployment_id: Deployment identifier
        
    Returns:
        Deployment object with site information
        
    Raises:
        404: If deployment not found
    """
    try:
        logger.info(f"GET /deployments/{deployment_id}")
        
        deployment = get_deployment_by_id(deployment_id)
        if not deployment:
            logger.warning(f"Deployment not found: {deployment_id}")
            raise HTTPException(status_code=404, detail="Deployment not found")
        
        deployment_dict = deployment.to_dict()
        
        # Add site information
        if deployment.site:
            deployment_dict.update({
                "site_name": deployment.site.name,
                "site_domain": deployment.site.domain,
                "site_status": deployment.site.status
            })
        
        return deployment_dict
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retrieve deployment {deployment_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/{deployment_id}/logs")
async def get_deployment_logs(deployment_id: int):
    """
    Get deployment logs for a specific deployment.
    
    Args:
        deployment_id: Deployment identifier
        
    Returns:
        JSON object with log content
        
    Raises:
        404: If deployment not found
    """
    try:
        logger.info(f"GET /deployments/{deployment_id}/logs")
        
        deployment = get_deployment_by_id(deployment_id)
        if not deployment:
            raise HTTPException(status_code=404, detail="Deployment not found")
        
        return {
            "deployment_id": deployment.id,
            "site_id": deployment.site_id,
            "status": deployment.status,
            "logs": deployment.log_output or "No logs available",
            "error": deployment.error_message,
            "created_at": deployment.created_at.isoformat() if deployment.created_at else None,
            "completed_at": deployment.completed_at.isoformat() if deployment.completed_at else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retrieve deployment logs {deployment_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# =============================================================================
# HTML PAGE ENDPOINTS
# =============================================================================

@router.get("-page", response_class=HTMLResponse)
async def deployments_page(request: Request):
    """
    Render HTML page showing deployment history with status information.
    
    Args:
        request: FastAPI request object
        
    Returns:
        HTML response with deployments table
    """
    try:
        logger.info("GET /deployments-page - rendering deployments table")
        
        if not templates:
            return HTMLResponse(
                "<h1>Deployments Page</h1><p>Templates not available</p>",
                status_code=200
            )
        
        # Get deployments with site information
        deployments_data = []
        
        with get_session() as db:
            deployments = db.query(Deployment).order_by(
                Deployment.created_at.desc()
            ).limit(50).all()
            
            for deployment in deployments:
                deployment_info = {
                    "id": deployment.id,
                    "site_id": deployment.site_id,
                    "site_name": deployment.site.name if deployment.site else "Unknown",
                    "site_domain": deployment.site.domain if deployment.site else "Unknown",
                    "status": deployment.status,
                    "created_at": deployment.created_at,
                    "started_at": deployment.started_at,
                    "completed_at": deployment.completed_at,
                    "duration": deployment.get_duration_seconds(),
                    "has_logs": bool(deployment.log_output),
                    "has_error": bool(deployment.error_message),
                    "error_message": deployment.error_message
                }
                deployments_data.append(deployment_info)
        
        logger.info(f"Rendering {len(deployments_data)} deployments in HTML table")
        
        context = {
            "request": request,
            "title": "Deployment History",
            "deployments": deployments_data,
            "deployments_count": len(deployments_data)
        }
        
        # Try to render with a specific template, fall back to simple HTML
        try:
            return templates.TemplateResponse("deployments.html", context)
        except Exception as template_error:
            logger.warning(f"Template error, using fallback: {template_error}")
            
            # Fallback HTML generation
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Deployment History</title>
                <link rel="stylesheet" href="/static/main.css">
                <style>
                    .status-badge {{ 
                        padding: 0.25rem 0.75rem; 
                        border-radius: 12px; 
                        font-size: 0.8rem; 
                        font-weight: 600; 
                        text-transform: uppercase; 
                    }}
                    .status-pending {{ background-color: rgba(255, 152, 0, 0.2); color: #ff9800; border: 1px solid #ff9800; }}
                    .status-running {{ background-color: rgba(33, 150, 243, 0.2); color: #2196f3; border: 1px solid #2196f3; }}
                    .status-completed {{ background-color: rgba(76, 175, 80, 0.2); color: #4caf50; border: 1px solid #4caf50; }}
                    .status-failed {{ background-color: rgba(244, 67, 54, 0.2); color: #f44336; border: 1px solid #f44336; }}
                    .btn-logs {{ background-color: #607d8b; font-size: 0.8rem; padding: 0.4rem 0.8rem; }}
                    .btn-logs:hover {{ background-color: #546e7a; }}
                    .duration {{ color: #b0b0b0; font-size: 0.9rem; }}
                </style>
            </head>
            <body>
                <nav class="main-nav">
                    <div class="nav-container">
                        <div class="nav-brand"><h1>Lead Engine Control Hub</h1></div>
                        <div class="nav-links">
                            <a href="/">Dashboard</a>
                            <a href="/sites-page">Sites</a>
                            <a href="/deployments-page">Deployments</a>
                        </div>
                    </div>
                </nav>
                
                <main class="main-content">
                    <h2>Deployment History</h2>
                    <p>Total deployments: {len(deployments_data)}</p>
                    
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Site</th>
                                <th>Domain</th>
                                <th>Status</th>
                                <th>Duration</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            
            if deployments_data:
                for deployment in deployments_data:
                    created_str = deployment["created_at"].strftime("%Y-%m-%d %H:%M") if deployment["created_at"] else "N/A"
                    duration_str = f"{deployment['duration']:.1f}s" if deployment["duration"] else "N/A"
                    status_class = f"status-{deployment['status']}"
                    
                    html_content += f"""
                            <tr>
                                <td>{deployment['id']}</td>
                                <td>{deployment['site_name']}</td>
                                <td>{deployment['site_domain']}</td>
                                <td><span class="status-badge {status_class}">{deployment['status']}</span></td>
                                <td class="duration">{duration_str}</td>
                                <td>{created_str}</td>
                                <td>
                                    <button class="btn btn-logs" onclick="viewLogs({deployment['id']})">
                                        View Logs
                                    </button>
                                </td>
                            </tr>
                    """
            else:
                html_content += """
                            <tr>
                                <td colspan="7" style="text-align: center; color: #888;">No deployments found</td>
                            </tr>
                """
            
            html_content += """
                        </tbody>
                    </table>
                </main>
                
                <script>
                    function viewLogs(deploymentId) {
                        // Open logs in a new window/modal
                        window.open('/deployments/' + deploymentId + '/logs', '_blank', 'width=800,height=600');
                    }
                    
                    // Auto-refresh every 10 seconds
                    setInterval(function() {
                        location.reload();
                    }, 10000);
                </script>
            </body>
            </html>
            """
            
            return HTMLResponse(html_content, status_code=200)
        
    except Exception as e:
        logger.error(f"Failed to render deployments page: {e}")
        return HTMLResponse(
            f"<h1>Error</h1><p>Failed to load deployments page: {e}</p>",
            status_code=500
        )

# =============================================================================
# UTILITY ENDPOINTS
# =============================================================================

@router.get("/count/by-status")
async def get_deployment_counts_by_status():
    """
    Get deployment counts grouped by status.
    
    Returns:
        JSON object with status counts
    """
    try:
        logger.info("GET /deployments/count/by-status")
        
        with get_session() as db:
            from sqlalchemy import func
            
            counts = db.query(
                Deployment.status,
                func.count(Deployment.id).label('count')
            ).group_by(Deployment.status).all()
            
            status_counts = {status: count for status, count in counts}
            
        logger.info(f"Deployment counts by status: {status_counts}")
        return status_counts
        
    except Exception as e:
        logger.error(f"Failed to get deployment counts: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Deployment Routes Module Test ===")
    logger.info("✅ Deployment routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET  /deployments")
    logger.info("  GET  /deployments/{id}")
    logger.info("  GET  /deployments/{id}/logs")
    logger.info("  GET  /deployments-page")
    logger.info("  GET  /deployments/count/by-status")
    logger.info("")
    logger.info("Integration notes:")
    logger.info("- Add 'from p07__server_routes_deployments import router as deployments_router' to main app")
    logger.info("- Add 'app.include_router(deployments_router)' to wire in the endpoints")
    logger.info("- Auto-refresh enabled on deployments page every 10 seconds")