"""
Lead Engine Control Hub - CSV Import Routes
Phase 36: CSV importers (leads & buyers)
Purpose: REST API endpoints for bulk CSV data import
"""

import logging
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Request, File, UploadFile, Query
from fastapi.responses import JSONResponse

# Import CSV services and auth
try:
    from p36__server_services_csv import (
        process_lead_import, process_buyer_import, get_sample_csv_headers,
        validate_csv_headers, CsvImportError, FileTooLargeError, InvalidHeaderError
    )
    from p20__server_middleware_auth import require_role
    from p24__server_services_scope import current_org
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    def process_lead_import(content, org_id, dry_run=False):
        return {"total_rows": 0, "valid_rows": 0, "invalid_rows": 0}
    def process_buyer_import(content, org_id, dry_run=False):
        return {"total_rows": 0, "valid_rows": 0, "invalid_rows": 0}
    def get_sample_csv_headers():
        return {"leads": ["name", "email"], "buyers": ["name", "email"]}
    def validate_csv_headers(content, import_type):
        return {"valid": True, "headers": []}
    def require_role(*roles):
        return lambda: None
    def current_org(request):
        return 1
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")
    
    class CsvImportError(Exception):
        pass
    class FileTooLargeError(Exception):
        pass
    class InvalidHeaderError(Exception):
        pass

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/import", tags=["csv-import"])


@router.get("/headers")
async def get_import_headers():
    """
    Get sample CSV headers for different import types.
    
    Returns expected column names and formats for leads and buyers.
    """
    try:
        headers = get_sample_csv_headers()
        
        return {
            "import_types": {
                "leads": {
                    "required_columns": headers["leads"][:2],  # name, email
                    "optional_columns": headers["leads"][2:],  # phone, source
                    "description": "Import lead records from CSV",
                    "example_row": {
                        "name": "John Doe",
                        "email": "john.doe@example.com", 
                        "phone": "555-123-4567",
                        "source": "website"
                    }
                },
                "buyers": {
                    "required_columns": headers["buyers"][:2],  # name, email
                    "optional_columns": headers["buyers"][2:],  # cpl_cents
                    "description": "Import buyer records from CSV",
                    "example_row": {
                        "name": "Acme Corp",
                        "email": "leads@acme.com",
                        "cpl_cents": "1000"
                    }
                }
            },
            "general_requirements": {
                "encoding": "UTF-8 or Latin-1",
                "max_file_size": "10 MB",
                "format": "Comma-separated values (.csv)",
                "headers": "First row must contain column names"
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting import headers: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve import information")


@router.post("/leads/validate")
async def validate_leads_csv(
    request: Request,
    file: UploadFile = File(...),
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Validate a leads CSV file without importing.
    
    Checks file format, headers, and sample data for issues.
    """
    try:
        org_id = current_org(request)
        
        # Check file type
        if not file.filename.lower().endswith('.csv'):
            raise HTTPException(status_code=400, detail="File must be a CSV (.csv)")
        
        # Read file content
        content = await file.read()
        
        # Validate headers first
        header_check = validate_csv_headers(content, 'leads')
        if not header_check['valid']:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid CSV headers: {header_check.get('error', 'Unknown error')}"
            )
        
        # Run dry-run import for full validation
        result = process_lead_import(content, org_id, dry_run=True)
        
        # Add header information to result
        result['headers'] = header_check
        result['filename'] = file.filename
        result['file_size_bytes'] = len(content)
        
        logger.info(f"Validated leads CSV: {result['valid_rows']} valid, {result['invalid_rows']} invalid")
        
        return result
        
    except HTTPException:
        raise
    except (FileTooLargeError, InvalidHeaderError) as e:
        logger.warning(f"CSV validation failed: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except CsvImportError as e:
        logger.warning(f"CSV import error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error validating leads CSV: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to validate CSV file")


@router.post("/leads")
async def import_leads_csv(
    request: Request,
    file: UploadFile = File(...),
    dry_run: bool = Query(False, description="If true, validate only without creating records"),
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Import leads from CSV file.
    
    Processes the file and creates lead records. Use dry_run=true to validate first.
    """
    try:
        org_id = current_org(request)
        
        # Check file type
        if not file.filename.lower().endswith('.csv'):
            raise HTTPException(status_code=400, detail="File must be a CSV (.csv)")
        
        # Read file content
        content = await file.read()
        
        # Process import
        result = process_lead_import(content, org_id, dry_run=dry_run)
        
        # Add request metadata
        result['filename'] = file.filename
        result['file_size_bytes'] = len(content)
        result['processed_at'] = "2025-08-11T12:00:00Z"  # Would use actual timestamp
        result['processed_by'] = "admin"  # Could extract from request.state.user
        
        # Audit the import
        audit(
            kind="leads_import_started" if not dry_run else "leads_import_validated",
            message=f"Leads CSV {'imported' if not dry_run else 'validated'}: {result['valid_rows']} valid rows",
            meta={
                'org_id': org_id,
                'filename': file.filename,
                'total_rows': result['total_rows'],
                'valid_rows': result['valid_rows'],
                'invalid_rows': result['invalid_rows'],
                'dry_run': dry_run
            }
        )
        
        if dry_run:
            logger.info(f"Validated leads CSV '{file.filename}': {result['valid_rows']} valid, {result['invalid_rows']} invalid")
        else:
            logger.info(f"Imported leads CSV '{file.filename}': {result['created']} created, {result['invalid_rows']} rejected")
        
        return result
        
    except HTTPException:
        raise
    except (FileTooLargeError, InvalidHeaderError) as e:
        logger.warning(f"CSV import failed: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except CsvImportError as e:
        logger.warning(f"CSV import error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error importing leads CSV: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to import CSV file")


@router.post("/buyers/validate")
async def validate_buyers_csv(
    request: Request,
    file: UploadFile = File(...),
    _: None = Depends(require_role("admin"))
):
    """
    Validate a buyers CSV file without importing.
    
    Only admins can import buyers. Checks format and data validity.
    """
    try:
        org_id = current_org(request)
        
        # Check file type
        if not file.filename.lower().endswith('.csv'):
            raise HTTPException(status_code=400, detail="File must be a CSV (.csv)")
        
        # Read file content
        content = await file.read()
        
        # Validate headers first
        header_check = validate_csv_headers(content, 'buyers')
        if not header_check['valid']:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid CSV headers: {header_check.get('error', 'Unknown error')}"
            )
        
        # Run dry-run import for full validation
        result = process_buyer_import(content, org_id, dry_run=True)
        
        # Add header information to result
        result['headers'] = header_check
        result['filename'] = file.filename
        result['file_size_bytes'] = len(content)
        
        logger.info(f"Validated buyers CSV: {result['valid_rows']} valid, {result['invalid_rows']} invalid")
        
        return result
        
    except HTTPException:
        raise
    except (FileTooLargeError, InvalidHeaderError) as e:
        logger.warning(f"CSV validation failed: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except CsvImportError as e:
        logger.warning(f"CSV import error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error validating buyers CSV: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to validate CSV file")


@router.post("/buyers")
async def import_buyers_csv(
    request: Request,
    file: UploadFile = File(...),
    dry_run: bool = Query(False, description="If true, validate only without creating records"),
    _: None = Depends(require_role("admin"))
):
    """
    Import buyers from CSV file.
    
    Only admins can import buyers. Processes file and creates buyer records.
    """
    try:
        org_id = current_org(request)
        
        # Check file type
        if not file.filename.lower().endswith('.csv'):
            raise HTTPException(status_code=400, detail="File must be a CSV (.csv)")
        
        # Read file content
        content = await file.read()
        
        # Process import
        result = process_buyer_import(content, org_id, dry_run=dry_run)
        
        # Add request metadata
        result['filename'] = file.filename
        result['file_size_bytes'] = len(content)
        result['processed_at'] = "2025-08-11T12:00:00Z"  # Would use actual timestamp
        result['processed_by'] = "admin"  # Could extract from request.state.user
        
        # Audit the import
        audit(
            kind="buyers_import_started" if not dry_run else "buyers_import_validated",
            message=f"Buyers CSV {'imported' if not dry_run else 'validated'}: {result['valid_rows']} valid rows",
            meta={
                'org_id': org_id,
                'filename': file.filename,
                'total_rows': result['total_rows'],
                'valid_rows': result['valid_rows'],
                'invalid_rows': result['invalid_rows'],
                'dry_run': dry_run
            }
        )
        
        if dry_run:
            logger.info(f"Validated buyers CSV '{file.filename}': {result['valid_rows']} valid, {result['invalid_rows']} invalid")
        else:
            logger.info(f"Imported buyers CSV '{file.filename}': {result['created']} created, {result['invalid_rows']} rejected")
        
        return result
        
    except HTTPException:
        raise
    except (FileTooLargeError, InvalidHeaderError) as e:
        logger.warning(f"CSV import failed: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except CsvImportError as e:
        logger.warning(f"CSV import error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error importing buyers CSV: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to import CSV file")


@router.get("/history")
async def get_import_history(
    request: Request,
    limit: int = Query(20, ge=1, le=100),
    import_type: Optional[str] = Query(None, regex="^(leads|buyers)$"),
    _: None = Depends(require_role("ops", "admin"))
):
    """
    Get history of CSV imports for the organization.
    
    Returns recent import attempts with status and statistics.
    """
    try:
        org_id = current_org(request)
        
        # This would query audit logs or import history table
        # For now, return mock structure
        
        history = {
            "org_id": org_id,
            "imports": [
                # Would contain actual import history from audit logs
            ],
            "total": 0,
            "limit": limit,
            "filters": {
                "import_type": import_type
            }
        }
        
        return history
        
    except Exception as e:
        logger.error(f"Error retrieving import history: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve import history")


@router.get("/templates")
async def download_csv_templates():
    """
    Download CSV template files for leads and buyers.
    
    Returns sample CSV content for each import type.
    """
    try:
        headers = get_sample_csv_headers()
        
        # Generate sample CSV content
        leads_csv = "name,email,phone,source\n"
        leads_csv += "John Doe,john.doe@example.com,555-123-4567,website\n"
        leads_csv += "Jane Smith,jane.smith@example.com,,referral\n"
        
        buyers_csv = "name,email,cpl_cents\n"
        buyers_csv += "Acme Corp,leads@acme.com,1000\n"
        buyers_csv += "Best Buy Co,buyers@bestbuy.com,1500\n"
        
        return {
            "templates": {
                "leads": {
                    "filename": "leads_template.csv",
                    "content": leads_csv,
                    "description": "Template for importing lead records"
                },
                "buyers": {
                    "filename": "buyers_template.csv", 
                    "content": buyers_csv,
                    "description": "Template for importing buyer records"
                }
            },
            "instructions": {
                "encoding": "Save files as UTF-8 CSV",
                "required_columns": "Do not remove required columns",
                "data_format": "Follow the example data format exactly",
                "file_size": "Maximum file size is 10MB"
            }
        }
        
    except Exception as e:
        logger.error(f"Error generating CSV templates: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to generate templates")


@router.delete("/cleanup")
async def cleanup_failed_imports(
    request: Request,
    days: int = Query(7, ge=1, le=90, description="Clean up failed imports older than N days"),
    _: None = Depends(require_role("admin"))
):
    """
    Clean up failed import attempts and temporary data.
    
    Removes old validation results and error logs to free up space.
    """
    try:
        org_id = current_org(request)
        
        # This would clean up:
        # - Temporary validation results
        # - Error logs older than specified days
        # - Incomplete import attempts
        
        cleanup_result = {
            "org_id": org_id,
            "cleaned_up": {
                "validation_cache": 0,
                "error_logs": 0,
                "temp_files": 0
            },
            "cutoff_date": f"2025-08-{11-days:02d}T12:00:00Z",
            "space_freed_mb": 0
        }
        
        logger.info(f"Cleaned up import data for org {org_id} older than {days} days")
        audit(
            kind="import_cleanup",
            message=f"Cleaned up import data older than {days} days",
            meta={
                'org_id': org_id,
                'days': days,
                'cleanup_result': cleanup_result
            }
        )
        
        return cleanup_result
        
    except Exception as e:
        logger.error(f"Error during import cleanup: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to clean up import data")


# Include router in main app
def include_import_routes(app):
    """Include CSV import routes in the main FastAPI app."""
    app.include_router(router)
    logger.info("CSV import routes registered")
