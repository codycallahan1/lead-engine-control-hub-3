"""
Maintenance routes for backup and read-only mode management.

Phase: 27
Purpose: Provide endpoints for system maintenance operations.
Key responsibilities:
- Trigger database backups
- Manage read-only mode toggle
- List backup files and statistics
"""

from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from pydantic import BaseModel
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

try:
    from p27__server_services_backup import (
        backup_sqlite, 
        list_backups, 
        rotate_keep, 
        get_backup_stats,
        restore_check
    )
    from p27__server_middleware_readonly import set_readonly_mode, get_readonly_mode
    from p08__server_services_audit import audit_system_event
except ImportError as e:
    logging.warning(f"Maintenance routes: missing dependency {e}")

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/maintenance", tags=["maintenance"])


class ReadOnlyRequest(BaseModel):
    enabled: bool
    reason: Optional[str] = "Manual toggle"


class BackupResponse(BaseModel):
    success: bool
    filename: str
    path: str
    size_bytes: int
    created_at: str
    message: str


class MaintenanceStatus(BaseModel):
    read_only_mode: bool
    backup_stats: Dict[str, Any]
    system_info: Dict[str, Any]
    uptime_seconds: Optional[int] = None


def require_ops_admin():
    """Placeholder for ops/admin role requirement."""
    return "admin"


def require_admin():
    """Placeholder for admin-only requirement."""
    return "admin"


@router.post("/backup", response_model=BackupResponse)
async def create_backup(
    background_tasks: BackgroundTasks,
    request: Request,
    actor: str = Depends(require_ops_admin)
):
    """Create a new database backup."""
    
    try:
        logger.info(f"Creating database backup requested by {actor}")
        
        # Create backup
        backup_path = backup_sqlite()
        
        # Schedule cleanup in background
        background_tasks.add_task(rotate_keep)
        
        # Get backup file info
        from pathlib import Path
        backup_file = Path(backup_path)
        file_stat = backup_file.stat()
        
        # Audit the backup
        audit_system_event(
            "backup_created",
            "database",
            "success",
            {
                "backup_path": backup_path,
                "size_bytes": file_stat.st_size,
                "actor": actor
            }
        )
        
        logger.info(f"Backup created successfully: {backup_path}")
        
        return BackupResponse(
            success=True,
            filename=backup_file.name,
            path=backup_path,
            size_bytes=file_stat.st_size,
            created_at=datetime.fromtimestamp(file_stat.st_ctime).isoformat(),
            message="Backup created successfully"
        )
    
    except Exception as e:
        logger.error(f"Backup creation failed: {e}")
        
        # Audit the failure
        audit_system_event(
            "backup_failed",
            "database",
            "failed",
            {
                "error": str(e),
                "actor": actor
            }
        )
        
        raise HTTPException(status_code=500, detail=f"Backup failed: {str(e)}")


@router.get("/backups")
async def list_backup_files(
    request: Request,
    actor: str = Depends(require_ops_admin)
):
    """List all backup files with metadata."""
    
    try:
        backups = list_backups()
        stats = get_backup_stats()
        
        return {
            "backups": backups,
            "stats": stats,
            "count": len(backups)
        }
    
    except Exception as e:
        logger.error(f"Failed to list backups: {e}")
        raise HTTPException(status_code=500, detail="Failed to list backups")


@router.post("/readonly")
async def toggle_readonly_mode(
    readonly_request: ReadOnlyRequest,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Toggle read-only mode on/off."""
    
    try:
        current_state = get_readonly_mode()
        new_state = readonly_request.enabled
        
        if current_state == new_state:
            return {
                "success": True,
                "message": f"Read-only mode already {'enabled' if new_state else 'disabled'}",
                "read_only_mode": new_state
            }
        
        # Toggle the mode
        set_readonly_mode(new_state)
        
        action = "enabled" if new_state else "disabled"
        logger.info(f"Read-only mode {action} by {actor}: {readonly_request.reason}")
        
        # Audit the change
        audit_system_event(
            f"readonly_mode_{action}",
            "maintenance",
            "success",
            {
                "actor": actor,
                "reason": readonly_request.reason,
                "previous_state": current_state,
                "new_state": new_state
            }
        )
        
        return {
            "success": True,
            "message": f"Read-only mode {action}",
            "read_only_mode": new_state,
            "reason": readonly_request.reason
        }
    
    except Exception as e:
        logger.error(f"Failed to toggle read-only mode: {e}")
        
        audit_system_event(
            "readonly_mode_toggle_failed",
            "maintenance",
            "failed",
            {
                "actor": actor,
                "error": str(e)
            }
        )
        
        raise HTTPException(status_code=500, detail="Failed to toggle read-only mode")


@router.get("/status", response_model=MaintenanceStatus)
async def get_maintenance_status(
    request: Request,
    actor: str = Depends(require_ops_admin)
):
    """Get current maintenance status and system info."""
    
    try:
        # Get backup statistics
        backup_stats = get_backup_stats()
        
        # Get system information
        import platform
        import psutil
        import os
        
        system_info = {
            "platform": platform.system(),
            "python_version": platform.python_version(),
            "hostname": platform.node(),
            "pid": os.getpid(),
            "memory_usage_mb": round(psutil.Process().memory_info().rss / 1024 / 1024, 2),
            "disk_usage": {}
        }
        
        # Add disk usage for current directory
        try:
            disk_usage = psutil.disk_usage('.')
            system_info["disk_usage"] = {
                "total_gb": round(disk_usage.total / (1024**3), 2),
                "used_gb": round(disk_usage.used / (1024**3), 2),
                "free_gb": round(disk_usage.free / (1024**3), 2),
                "usage_percent": round((disk_usage.used / disk_usage.total) * 100, 1)
            }
        except:
            pass
        
        return MaintenanceStatus(
            read_only_mode=get_readonly_mode(),
            backup_stats=backup_stats,
            system_info=system_info
        )
    
    except Exception as e:
        logger.error(f"Failed to get maintenance status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get system status")


@router.get("/backups/{filename}/check")
async def check_backup_restore(
    filename: str,
    request: Request,
    actor: str = Depends(require_admin)
):
    """Check if a backup file can be restored (dry run)."""
    
    try:
        from pathlib import Path
        backup_path = Path("./backups") / filename
        
        if not backup_path.exists():
            raise HTTPException(status_code=404, detail="Backup file not found")
        
        # Perform restore check
        check_result = restore_check(str(backup_path))
        
        # Audit the check
        audit_system_event(
            "backup_restore_checked",
            "database",
            "success" if not check_result["errors"] else "warning",
            {
                "backup_file": filename,
                "actor": actor,
                "check_result": check_result
            }
        )
        
        return {
            "backup_file": filename,
            "restore_check": check_result,
            "recommendation": (
                "Ready for restore" if check_result["backup_valid"] and not check_result["errors"]
                else "Not recommended for restore"
            )
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Backup restore check failed: {e}")
        raise HTTPException(status_code=500, detail="Restore check failed")


@router.post("/cleanup")
async def cleanup_old_backups(
    request: Request,
    keep_count: int = 7,
    keep_days: int = 30,
    actor: str = Depends(require_admin)
):
    """Clean up old backup files based on retention policy."""
    
    try:
        logger.info(f"Cleaning up old backups: keep {keep_count} files, {keep_days} days max")
        
        # Perform cleanup
        cleanup_result = rotate_keep(keep_count, keep_days)
        
        # Audit the cleanup
        audit_system_event(
            "backup_cleanup",
            "maintenance",
            "success",
            {
                "actor": actor,
                "keep_count": keep_count,
                "keep_days": keep_days,
                **cleanup_result
            }
        )
        
        logger.info(f"Backup cleanup completed: {cleanup_result}")
        
        return {
            "success": True,
            "message": f"Cleanup completed: removed {cleanup_result['removed']} backups",
            **cleanup_result
        }
    
    except Exception as e:
        logger.error(f"Backup cleanup failed: {e}")
        
        audit_system_event(
            "backup_cleanup_failed",
            "maintenance",
            "failed",
            {
                "actor": actor,
                "error": str(e)
            }
        )
        
        raise HTTPException(status_code=500, detail="Cleanup failed")
