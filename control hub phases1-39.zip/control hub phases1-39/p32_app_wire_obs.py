"""
Lead Engine Control Hub - Observability Wiring Example
Phase 32: Observability infrastructure
Purpose: Demonstrate how to enable JSON logging, middleware, and exception handlers
"""

import os
import logging
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Import observability components
try:
    from p32__server_logging_json import setup_logging
    from p32__server_middleware_requestid import add_request_id_middleware
    from p32__server_exception_handlers import add_exception_handlers
except ImportError:
    # Fallback if modules not available
    def setup_logging(log_format=None):
        logging.basicConfig(level=logging.INFO)
    
    def add_request_id_middleware(app):
        logging.info("Request ID middleware not available")
    
    def add_exception_handlers(app):
        logging.info("Exception handlers not available")


def create_app_with_observability() -> FastAPI:
    """
    Create FastAPI app with full observability stack enabled.
    This shows the proper order of middleware and handler registration.
    """
    
    # 1. Setup structured logging FIRST (before any other logging)
    log_format = os.getenv("LOG_FORMAT", "json")  # Default to JSON in production
    setup_logging(log_format)
    
    logger = logging.getLogger(__name__)
    logger.info("Starting Lead Engine Control Hub with observability")
    
    # 2. Create FastAPI app
    app = FastAPI(
        title="Lead Engine Control Hub",
        description="Phase 32: Full observability with request tracking",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc"
    )
    
    # 3. Add exception handlers EARLY (before other middleware)
    add_exception_handlers(app)
    
    # 4. Add request ID middleware (should be one of the first middleware)
    add_request_id_middleware(app)
    
    # 5. Add other middleware in proper order
    # NOTE: Middleware is executed in reverse order of addition for requests
    # So add most general middleware last
    
    # CORS (if needed) - should be after request ID but before auth
    # app.add_middleware(CORSMiddleware, ...)
    
    # Auth middleware (if present) - after CORS
    # app.add_middleware(AuthMiddleware, ...)
    
    # Rate limiting (if present) - after auth
    # app.add_middleware(RateLimitMiddleware, ...)
    
    # 6. Mount static files and templates
    try:
        app.mount("/static", StaticFiles(directory="static"), name="static")
        logger.info("Static files mounted at /static")
    except Exception as e:
        logger.warning(f"Could not mount static files: {e}")
    
    # 7. Setup templates
    try:
        templates = Jinja2Templates(directory="templates")
        logger.info("Templates configured")
    except Exception as e:
        logger.warning(f"Could not setup templates: {e}")
    
    # 8. Add routes (import and include routers here)
    # This is where you would add your actual route modules
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint - always returns 200."""
        return {"status": "ok", "phase": 32}
    
    @app.get("/version")
    async def version():
        """Version endpoint with observability info."""
        return {
            "app": "Lead Engine Control Hub",
            "version": "1.0.0",
            "phase": 32,
            "observability": {
                "request_tracking": True,
                "structured_logging": log_format == "json",
                "exception_handling": True
            }
        }
    
    # 9. Database initialization (if needed)
    try:
        # from p02__server_db import create_all_tables
        # create_all_tables()
        logger.info("Database initialization would happen here")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
    
    # 10. Start background services (if needed)
    try:
        # from p19__server_services_scheduler import start_scheduler
        # start_scheduler()
        logger.info("Background services would start here")
    except Exception as e:
        logger.error(f"Background services failed to start: {e}")
    
    logger.info("Application initialization complete")
    return app


def configure_logging_from_env():
    """
    Configure logging based on environment variables.
    Call this before creating the app if you need custom configuration.
    """
    
    # Environment variables for logging configuration
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    log_format = os.getenv("LOG_FORMAT", "json").lower()
    log_file = os.getenv("LOG_FILE")
    
    # Setup logging
    setup_logging(log_format)
    
    # Adjust log level
    if log_level in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
        logging.getLogger().setLevel(getattr(logging, log_level))
    
    logging.info(f"Logging configured: level={log_level}, format={log_format}, file={log_file or 'console'}")


# Example usage patterns:

# For development (text logs):
# export LOG_FORMAT=text
# export LOG_LEVEL=DEBUG
# uvicorn p32__server_app_wire_obs:app --reload

# For production (JSON logs):
# export LOG_FORMAT=json
# export LOG_LEVEL=INFO
# export LOG_FILE=/var/log/control-hub/app.log
# uvicorn p32__server_app_wire_obs:app --workers 4

# Create the app instance
app = create_app_with_observability()

if __name__ == "__main__":
    import uvicorn
    
    # Configure logging from environment
    configure_logging_from_env()
    
    # Run the application
    uvicorn.run(
        "p32__server_app_wire_obs:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_config=None  # Use our custom logging setup
    )
