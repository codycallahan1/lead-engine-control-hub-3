"""
Lead Engine Control Hub - Export Routes
Phase: 8
Purpose: Data export endpoints for leads with CSV and JSON formats
Key Responsibilities:
- CSV export with proper headers and formatting
- JSON export with structured data
- Streaming responses for large datasets
- Audit logging for all export operations
"""

import logging
import csv
import json
from datetime import datetime
from io import StringIO
from typing import List

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

# Import services and audit
try:
    from p03__server_services_leads import LeadService
    from p08__server_services_audit import audit, AuditEvents, AuditContext
except ImportError as e:
    logging.warning(f"Import error in export routes: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 3 and 8 files are available")

logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/export", tags=["export"])

# =============================================================================
# CSV EXPORT ENDPOINTS
# =============================================================================

@router.get("/leads.csv")
async def export_leads_csv():
    """
    Export all leads to CSV format with streaming response.
    
    Returns:
        StreamingResponse with CSV content
        
    Raises:
        500: If export operation fails
    """
    try:
        logger.info("GET /export/leads.csv - starting CSV export")
        
        with AuditContext(AuditEvents.LEADS_EXPORTED, "Exporting leads to CSV format") as audit_ctx:
            # Get all leads
            leads = LeadService.get_all_leads()
            leads_count = len(leads)
            
            audit_ctx.add_meta("format", "csv")
            audit_ctx.add_meta("count", leads_count)
            audit_ctx.add_meta("export_timestamp", datetime.utcnow().isoformat())
            
            logger.info(f"Exporting {leads_count} leads to CSV")
            
            # Create CSV content
            def generate_csv():
                """Generator function for streaming CSV content"""
                output = StringIO()
                writer = csv.writer(output)
                
                # Write CSV header
                header = ['id', 'name', 'email', 'phone', 'created_at']
                writer.writerow(header)
                yield output.getvalue()
                output.seek(0)
                output.truncate(0)
                
                # Write lead data
                for lead in leads:
                    row = [
                        lead.id,
                        lead.name,
                        lead.email,
                        lead.phone or '',  # Handle None values
                        lead.created_at.isoformat() if lead.created_at else ''
                    ]
                    writer.writerow(row)
                    yield output.getvalue()
                    output.seek(0)
                    output.truncate(0)
            
            # Generate filename with timestamp
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"leads_export_{timestamp}.csv"
            
            audit_ctx.add_meta("filename", filename)
            
            # Return streaming response
            return StreamingResponse(
                generate_csv(),
                media_type="text/csv",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
    
    except Exception as e:
        logger.error(f"Failed to export leads to CSV: {e}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

@router.get("/buyers.csv")
async def export_buyers_csv():
    """
    Export all buyers to CSV format with streaming response.
    
    Returns:
        StreamingResponse with CSV content
        
    Raises:
        500: If export operation fails
    """
    try:
        logger.info("GET /export/buyers.csv - starting CSV export")
        
        with AuditContext(AuditEvents.BUYERS_EXPORTED, "Exporting buyers to CSV format") as audit_ctx:
            # Import buyers service
            from p03__server_services_buyers import BuyerService
            
            # Get all buyers
            buyers = BuyerService.get_all_buyers()
            buyers_count = len(buyers)
            
            audit_ctx.add_meta("format", "csv")
            audit_ctx.add_meta("count", buyers_count)
            audit_ctx.add_meta("export_timestamp", datetime.utcnow().isoformat())
            
            logger.info(f"Exporting {buyers_count} buyers to CSV")
            
            # Create CSV content
            def generate_csv():
                """Generator function for streaming CSV content"""
                output = StringIO()
                writer = csv.writer(output)
                
                # Write CSV header
                header = ['id', 'name', 'email', 'created_at']
                writer.writerow(header)
                yield output.getvalue()
                output.seek(0)
                output.truncate(0)
                
                # Write buyer data
                for buyer in buyers:
                    row = [
                        buyer.id,
                        buyer.name,
                        buyer.email,
                        buyer.created_at.isoformat() if buyer.created_at else ''
                    ]
                    writer.writerow(row)
                    yield output.getvalue()
                    output.seek(0)
                    output.truncate(0)
            
            # Generate filename with timestamp
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"buyers_export_{timestamp}.csv"
            
            audit_ctx.add_meta("filename", filename)
            
            # Return streaming response
            return StreamingResponse(
                generate_csv(),
                media_type="text/csv",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
    
    except Exception as e:
        logger.error(f"Failed to export buyers to CSV: {e}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

# =============================================================================
# JSON EXPORT ENDPOINTS
# =============================================================================

@router.get("/leads.json")
async def export_leads_json():
    """
    Export all leads to JSON format with streaming response.
    
    Returns:
        StreamingResponse with JSON content
        
    Raises:
        500: If export operation fails
    """
    try:
        logger.info("GET /export/leads.json - starting JSON export")
        
        with AuditContext(AuditEvents.LEADS_EXPORTED, "Exporting leads to JSON format") as audit_ctx:
            # Get all leads
            leads = LeadService.get_all_leads()
            leads_count = len(leads)
            
            audit_ctx.add_meta("format", "json")
            audit_ctx.add_meta("count", leads_count)
            audit_ctx.add_meta("export_timestamp", datetime.utcnow().isoformat())
            
            logger.info(f"Exporting {leads_count} leads to JSON")
            
            # Convert leads to dictionaries
            def generate_json():
                """Generator function for streaming JSON content"""
                yield '[\n'
                
                for i, lead in enumerate(leads):
                    lead_dict = {
                        "id": lead.id,
                        "name": lead.name,
                        "email": lead.email,
                        "phone": lead.phone,
                        "created_at": lead.created_at.isoformat() if lead.created_at else None
                    }
                    
                    # Add comma except for last item
                    separator = ',' if i < len(leads) - 1 else ''
                    yield f'  {json.dumps(lead_dict, indent=2).replace(chr(10), chr(10) + "  ")}{separator}\n'
                
                yield ']'
            
            # Generate filename with timestamp
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"leads_export_{timestamp}.json"
            
            audit_ctx.add_meta("filename", filename)
            
            # Return streaming response
            return StreamingResponse(
                generate_json(),
                media_type="application/json",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
    
    except Exception as e:
        logger.error(f"Failed to export leads to JSON: {e}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

@router.get("/buyers.json")
async def export_buyers_json():
    """
    Export all buyers to JSON format with streaming response.
    
    Returns:
        StreamingResponse with JSON content
        
    Raises:
        500: If export operation fails
    """
    try:
        logger.info("GET /export/buyers.json - starting JSON export")
        
        with AuditContext(AuditEvents.BUYERS_EXPORTED, "Exporting buyers to JSON format") as audit_ctx:
            # Import buyers service
            from p03__server_services_buyers import BuyerService
            
            # Get all buyers
            buyers = BuyerService.get_all_buyers()
            buyers_count = len(buyers)
            
            audit_ctx.add_meta("format", "json")
            audit_ctx.add_meta("count", buyers_count)
            audit_ctx.add_meta("export_timestamp", datetime.utcnow().isoformat())
            
            logger.info(f"Exporting {buyers_count} buyers to JSON")
            
            # Convert buyers to dictionaries
            def generate_json():
                """Generator function for streaming JSON content"""
                yield '[\n'
                
                for i, buyer in enumerate(buyers):
                    buyer_dict = {
                        "id": buyer.id,
                        "name": buyer.name,
                        "email": buyer.email,
                        "created_at": buyer.created_at.isoformat() if buyer.created_at else None
                    }
                    
                    # Add comma except for last item
                    separator = ',' if i < len(buyers) - 1 else ''
                    yield f'  {json.dumps(buyer_dict, indent=2).replace(chr(10), chr(10) + "  ")}{separator}\n'
                
                yield ']'
            
            # Generate filename with timestamp
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"buyers_export_{timestamp}.json"
            
            audit_ctx.add_meta("filename", filename)
            
            # Return streaming response
            return StreamingResponse(
                generate_json(),
                media_type="application/json",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
    
    except Exception as e:
        logger.error(f"Failed to export buyers to JSON: {e}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

# =============================================================================
# EXPORT STATUS AND UTILITY ENDPOINTS
# =============================================================================

@router.get("/formats")
async def get_export_formats():
    """
    Get available export formats and their descriptions.
    
    Returns:
        JSON object with available export formats
    """
    try:
        logger.info("GET /export/formats - listing available formats")
        
        formats = {
            "csv": {
                "description": "Comma-separated values format",
                "mime_type": "text/csv",
                "endpoints": {
                    "leads": "/export/leads.csv",
                    "buyers": "/export/buyers.csv"
                }
            },
            "json": {
                "description": "JavaScript Object Notation format",
                "mime_type": "application/json",
                "endpoints": {
                    "leads": "/export/leads.json",
                    "buyers": "/export/buyers.json"
                }
            }
        }
        
        return {
            "available_formats": formats,
            "entities": ["leads", "buyers"],
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get export formats: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/status")
async def get_export_status():
    """
    Get export system status and statistics.
    
    Returns:
        JSON object with export system status
    """
    try:
        logger.info("GET /export/status - checking export system status")
        
        # Get record counts
        leads_count = LeadService.get_leads_count()
        
        try:
            from p03__server_services_buyers import BuyerService
            buyers_count = BuyerService.get_buyers_count()
        except Exception:
            buyers_count = 0
        
        status = {
            "system_healthy": True,
            "available_entities": {
                "leads": {
                    "count": leads_count,
                    "formats": ["csv", "json"]
                },
                "buyers": {
                    "count": buyers_count,
                    "formats": ["csv", "json"]
                }
            },
            "supported_formats": ["csv", "json"],
            "streaming_enabled": True,
            "audit_enabled": True,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return status
        
    except Exception as e:
        logger.error(f"Failed to get export status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Export Routes Module Test ===")
    logger.info("✅ Export routes module loaded successfully")
    logger.info("Available endpoints:")
    logger.info("  GET  /export/leads.csv     - Export leads to CSV")
    logger.info("  GET  /export/leads.json    - Export leads to JSON")
    logger.info("  GET  /export/buyers.csv    - Export buyers to CSV") 
    logger.info("  GET  /export/buyers.json   - Export buyers to JSON")
    logger.info("  GET  /export/formats       - Get available formats")
    logger.info("  GET  /export/status        - Get export system status")
    logger.info("")
    logger.info("Integration notes:")
    logger.info("- Add 'from p08__server_routes_export import router as export_router' to main app")
    logger.info("- Add 'app.include_router(export_router)' to wire in the endpoints")
    logger.info("- All exports include audit logging with metadata")
    logger.info("- Streaming responses handle large datasets efficiently")