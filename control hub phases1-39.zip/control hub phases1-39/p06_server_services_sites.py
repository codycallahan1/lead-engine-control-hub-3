"""
Lead Engine Control Hub - Site Services
Phase: 6
Purpose: Service layer for site operations (CRUD) using database sessions
Key Responsibilities:
- Site creation, retrieval, update, and deletion
- Domain uniqueness validation (case-insensitive)
- Business logic for site management
- Database session handling and error logging
"""

import logging
from typing import List, Optional

from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

# Import database and models
try:
    from p02__server_db import get_session
    from p02__server_models import Site
    from p02__server_schemas import SiteIn, SiteOut, SiteUpdate
except ImportError as e:
    logging.warning(f"Import error in sites service: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 files are available")

logger = logging.getLogger(__name__)

class SiteService:
    """Service class for Site operations"""
    
    @staticmethod
    def get_all_sites() -> List[Site]:
        """
        Retrieve all sites from the database.
        
        Returns:
            List of Site objects ordered by creation date
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                sites = db.query(Site).order_by(Site.created_at.desc()).all()
                logger.info(f"Retrieved {len(sites)} sites")
                return sites
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve sites: {e}")
            raise
    
    @staticmethod
    def get_site_by_id(site_id: int) -> Optional[Site]:
        """
        Retrieve a site by ID.
        
        Args:
            site_id: ID of the site to retrieve
            
        Returns:
            Site object or None if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                site = db.query(Site).filter(Site.id == site_id).first()
                if site:
                    logger.info(f"Retrieved site: {site}")
                else:
                    logger.info(f"Site not found with ID: {site_id}")
                return site
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve site {site_id}: {e}")
            raise
    
    @staticmethod
    def get_site_by_domain(domain: str) -> Optional[Site]:
        """
        Retrieve a site by domain (case-insensitive).
        
        Args:
            domain: Domain name to search for
            
        Returns:
            Site object or None if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                site = db.query(Site).filter(Site.domain.ilike(domain.lower())).first()
                if site:
                    logger.info(f"Retrieved site by domain: {site}")
                else:
                    logger.info(f"Site not found with domain: {domain}")
                return site
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve site by domain {domain}: {e}")
            raise
    
    @staticmethod
    def create_site(site_data: SiteIn) -> Site:
        """
        Create a new site with domain uniqueness validation.
        
        Args:
            site_data: Site input data
            
        Returns:
            Created Site object
            
        Raises:
            ValueError: If domain already exists (case-insensitive)
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                # Check for existing domain (case-insensitive)
                existing_site = db.query(Site).filter(
                    Site.domain.ilike(site_data.domain.lower())
                ).first()
                
                if existing_site:
                    logger.warning(f"Site creation failed - domain already exists: {site_data.domain}")
                    raise ValueError(f"Site with domain {site_data.domain} already exists")
                
                # Create new site instance
                site = Site(
                    name=site_data.name,
                    domain=site_data.domain.lower(),  # Store domain in lowercase
                    status=site_data.status
                )
                
                db.add(site)
                db.flush()  # Flush to get the ID before commit
                db.refresh(site)  # Refresh to get all fields including created_at
                
                logger.info(f"Created site: {site}")
                return site
                
        except ValueError:
            # Re-raise validation errors
            raise
        except IntegrityError as e:
            logger.error(f"Site creation failed - integrity constraint: {e}")
            raise ValueError(f"Site with domain {site_data.domain} already exists")
        except SQLAlchemyError as e:
            logger.error(f"Failed to create site: {e}")
            raise
    
    @staticmethod
    def update_site(site_id: int, site_data: SiteUpdate) -> Optional[Site]:
        """
        Update an existing site.
        
        Args:
            site_id: ID of the site to update
            site_data: Site update data
            
        Returns:
            Updated Site object or None if not found
            
        Raises:
            ValueError: If domain update conflicts with existing site
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                site = db.query(Site).filter(Site.id == site_id).first()
                
                if not site:
                    logger.info(f"Site not found for update: {site_id}")
                    return None
                
                # Check for domain conflicts if domain is being updated
                update_data = site_data.dict(exclude_unset=True)
                if 'domain' in update_data:
                    new_domain = update_data['domain'].lower()
                    existing_site = db.query(Site).filter(
                        Site.domain.ilike(new_domain),
                        Site.id != site_id
                    ).first()
                    
                    if existing_site:
                        logger.warning(f"Site update failed - domain conflict: {new_domain}")
                        raise ValueError(f"Site with domain {new_domain} already exists")
                    
                    update_data['domain'] = new_domain
                
                # Update only provided fields
                for field, value in update_data.items():
                    setattr(site, field, value)
                
                db.flush()  # Flush to check for constraint violations
                db.refresh(site)  # Refresh to get updated fields
                
                logger.info(f"Updated site: {site}")
                return site
                
        except ValueError:
            # Re-raise validation errors
            raise
        except IntegrityError as e:
            logger.error(f"Site update failed - integrity constraint: {e}")
            domain = site_data.domain if site_data.domain else "unknown"
            raise ValueError(f"Site with domain {domain} already exists")
        except SQLAlchemyError as e:
            logger.error(f"Failed to update site {site_id}: {e}")
            raise
    
    @staticmethod
    def delete_site(site_id: int) -> bool:
        """
        Delete a site by ID.
        
        Args:
            site_id: ID of the site to delete
            
        Returns:
            True if deleted, False if not found
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                site = db.query(Site).filter(Site.id == site_id).first()
                
                if not site:
                    logger.info(f"Site not found for deletion: {site_id}")
                    return False
                
                db.delete(site)
                logger.info(f"Deleted site: {site}")
                return True
                
        except SQLAlchemyError as e:
            logger.error(f"Failed to delete site {site_id}: {e}")
            raise
    
    @staticmethod
    def search_sites(query: str) -> List[Site]:
        """
        Search sites by name or domain.
        
        Args:
            query: Search query string
            
        Returns:
            List of matching Site objects
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                search_pattern = f"%{query}%"
                sites = db.query(Site).filter(
                    (Site.name.ilike(search_pattern)) |
                    (Site.domain.ilike(search_pattern))
                ).order_by(Site.created_at.desc()).all()
                
                logger.info(f"Search for '{query}' returned {len(sites)} sites")
                return sites
                
        except SQLAlchemyError as e:
            logger.error(f"Failed to search sites with query '{query}': {e}")
            raise
    
    @staticmethod
    def get_sites_by_status(status: str) -> List[Site]:
        """
        Get sites filtered by status.
        
        Args:
            status: Status to filter by
            
        Returns:
            List of Site objects with matching status
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                sites = db.query(Site).filter(
                    Site.status == status.lower()
                ).order_by(Site.created_at.desc()).all()
                
                logger.info(f"Retrieved {len(sites)} sites with status '{status}'")
                return sites
                
        except SQLAlchemyError as e:
            logger.error(f"Failed to get sites by status '{status}': {e}")
            raise
    
    @staticmethod
    def get_sites_count() -> int:
        """
        Get total count of sites.
        
        Returns:
            Number of sites in database
            
        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with get_session() as db:
                count = db.query(Site).count()
                logger.info(f"Site count: {count}")
                return count
        except SQLAlchemyError as e:
            logger.error(f"Failed to get sites count: {e}")
            raise

# Convenience functions for direct usage
def list_sites() -> List[Site]:
    """Get all sites"""
    return SiteService.get_all_sites()

def get_site(site_id: int) -> Optional[Site]:
    """Get site by ID"""
    return SiteService.get_site_by_id(site_id)

def create_site(site_data: SiteIn) -> Site:
    """Create new site"""
    return SiteService.create_site(site_data)

def update_site(site_id: int, site_data: SiteUpdate) -> Optional[Site]:
    """Update existing site"""
    return SiteService.update_site(site_id, site_data)

def delete_site(site_id: int) -> bool:
    """Delete site"""
    return SiteService.delete_site(site_id)

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Site Services Module Test ===")
    
    try:
        # Test getting all sites (should be empty initially)
        sites = SiteService.get_all_sites()
        logger.info(f"Current sites count: {len(sites)}")
        
        # Test getting count
        count = SiteService.get_sites_count()
        logger.info(f"Sites count from service: {count}")
        
        logger.info("✅ Site services module test completed")
        
    except Exception as e:
        logger.error(f"Site services test failed: {e}")
        logger.info("Note: This is expected if database/models are not available")