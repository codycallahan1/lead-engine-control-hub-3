"""
Lead Engine Control Hub - Retention Management Routes
Phase 37: Data retention, archiving & soft delete
Purpose: REST API endpoints for retention policy and archive management
"""

import logging
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Request, Query
from pydantic import BaseModel, Field

# Import retention services and auth
try:
    from p37__server_services_archive import (
        get_retention_policy, create_default_retention_policy, run_retention_sweep,
        list_archive_files, cleanup_old_archives, schedule_next_sweep,
        enqueue_retention_sweep, verify_archive_integrity,
        RetentionSweepError, ArchiveError
    )
    from p37__server_models_retention import RetentionPolicy
    from p20__server_middleware_auth import require_role
    from p24__server_services_scope import current_org
    from p02__server_db import get_session
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    def get_retention_policy(org_id):
        return None
    def create_default_retention_policy(org_id, created_by="admin"):
        return None
    def run_retention_sweep(org_id, sweep_type="manual", initiated_by="admin"):
        return None
    def list_archive_files(org_id, data_type=None, days=30):
        return []
    def cleanup_old_archives(org_id, keep_days=90):
        return {"files_deleted": 0}
    def schedule_next_sweep(org_id):
        return None
    def enqueue_retention_sweep(org_id, sweep_type="scheduled"):
        pass
    def verify_archive_integrity(manifest_id):
        return True
    def require_role(*roles):
        return lambda: None
    def current_org(request):
        return 1
    def get_session():
        pass
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")
    
    class RetentionSweepError(Exception):
        pass
    class ArchiveError(Exception):
        pass
    class RetentionPolicy:
        pass

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/retention", tags=["retention"])


# Request/Response models
class RetentionPolicyRequest(BaseModel):
    leads_days: Optional[int] = Field(None, ge=1, le=3650, description="Days to retain leads")
    buyers_days: Optional[int] = Field(None, ge=1, le=3650, description="Days to retain buyers")
    logs_days: Optional[int] = Field(None, ge=1, le=365, description="Days to retain logs")
    audit_days: Optional[int] = Field(None, ge=1, le=3650, description="Days to retain audit records")
    archive_enabled: Optional[bool] = Field(None, description="Enable archiving before deletion")
    hard_delete_after_days: Optional[int] = Field(None, ge=1, le=3650, description="Hard delete after N days")
    require_manual_approval: Optional[bool] = Field(None, description="Require manual approval for sweeps")


class RetentionPolicyResponse(BaseModel):
    org_id: int
    leads_days: Optional[int]
    buyers_days: Optional[int]
    logs_days: Optional[int]
    audit_days: Optional[int]
    archive_enabled: bool
    hard_delete_after_days: Optional[int]
    require_manual_approval: bool
    last_sweep_at: Optional[str]
    next_sweep_at: Optional[str]
    updated_at: Optional[str]
    updated_by: Optional[str]


class RunSweepRequest(BaseModel):
    sweep_type: str = Field("manual", regex="^(manual|test|emergency)$")
    data_types: Optional[list] = Field(None, description="Specific data types to sweep")


# Routes
@router.get("/policy", response_model=RetentionPolicyResponse)
async def get_retention_policy_route(
    request: Request,
    _: None = Depends(require_role("admin"))
):
    """
    Get current retention policy for the organization.
    
    Returns current settings or creates default policy if none exists.
    """
    try:
        org_id = current_org(request)
        policy = get_retention_policy(org_id)
        
        if not policy:
            # Create default policy
            policy = create_default_retention_policy(org_id, "admin")
        
        return RetentionPolicyResponse(**policy.to_dict())
        
    except Exception as e:
        logger.error(f"Error retrieving retention policy: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve retention policy")


@router.put("/policy")
async def update_retention_policy(
    request: Request,
    policy_data: RetentionPolicyRequest,
    _: None = Depends(require_role("admin"))
):
    """
    Update retention policy for the organization.
    
    Only admins can modify retention policies.
    Changes affect future retention sweeps.
    """
    try:
        org_id = current_org(request)
        
        with get_session() as session:
            policy = session.query(RetentionPolicy).filter_by(org_id=org_id).first()
            
            if not policy:
                # Create new policy
                policy = RetentionPolicy(org_id=org_id)
                session.add(policy)
            
            # Track changes for audit
            changes = {}
            
            # Update fields that were provided
            update_fields = policy_data.dict(exclude_unset=True)
            for field, value in update_fields.items():
                if hasattr(policy, field):
                    old_value = getattr(policy, field)
                    if old_value != value:
                        changes[field] = {"from": old_value, "to": value}
                        setattr(policy, field, value)
            
            # Update metadata
            from datetime import datetime
            policy.updated_at = datetime.utcnow()
            policy.updated_by = "admin"  # Could extract from request.state.user
            
            session.commit()
            session.refresh(policy)
            
            # Audit the changes
            if changes:
                audit(
                    kind="retention_policy_updated",
                    message=f"Retention policy updated for org {org_id}",
                    meta={
                        "org_id": org_id,
                        "changes": changes,
                        "updated_by": "admin"
                    }
                )
            
            logger.info(f"Updated retention policy for org {org_id}: {changes}")
            
            return {
                "success": True,
                "message": "Retention policy updated successfully",
                "changes": changes,
                "policy": policy.to_dict()
            }
            
    except Exception as e:
        logger.error(f"Error updating retention policy: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to update retention policy")


@router.post("/run")
async def run_retention_sweep_route(
    request: Request,
    sweep_data: RunSweepRequest,
    _: None = Depends(require_role("admin"))
):
    """
    Trigger a manual retention sweep.
    
    Processes expired data according to current retention policy.
    Returns sweep results and archive information.
    """
    try:
        org_id = current_org(request)
        
        # Validate sweep type
        if sweep_data.sweep_type not in ["manual", "test", "emergency"]:
            raise HTTPException(status_code=400, detail="Invalid sweep type")
        
        # Run the sweep
        sweep_log = run_retention_sweep(
            org_id=org_id,
            sweep_type=sweep_data.sweep_type,
            initiated_by="admin"
        )
        
        logger.info(f"Manual retention sweep completed for org {org_id}")
        
        return {
            "success": True,
            "message": f"Retention sweep completed successfully",
            "sweep_log": sweep_log.to_dict(),
            "summary": {
                "total_records_processed": sweep_log.total_records_processed,
                "archive_files_created": sweep_log.archive_files_created,
                "archive_size_mb": round(sweep_log.archive_size_mb, 2),
                "duration_seconds": sweep_log.duration_seconds
            }
        }
        
    except RetentionSweepError as e:
        logger.error(f"Retention sweep failed: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error running retention sweep: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to run retention sweep")


@router.get("/archives")
async def list_archives(
    request: Request,
    data_type: Optional[str] = Query(None, regex="^(leads|buyers|logs|audit)$"),
    days: int = Query(30, ge=1, le=365, description="Days to look back"),
    _: None = Depends(require_role("admin"))
):
    """
    List archive files for the organization.
    
    Returns information about archived data files including
    file sizes, record counts, and verification status.
    """
    try:
        org_id = current_org(request)
        
        archives = list_archive_files(
            org_id=org_id,
            data_type=data_type,
            days=days
        )
        
        # Calculate summary statistics
        total_files = len(archives)
        total_records = sum(archive.get("record_count", 0) for archive in archives)
        total_size_mb = sum(archive.get("file_size_mb", 0) for archive in archives)
        
        # Group by data type
        by_data_type = {}
        for archive in archives:
            dt = archive.get("data_type", "unknown")
            if dt not in by_data_type:
                by_data_type[dt] = {"files": 0, "records": 0, "size_mb": 0}
            
            by_data_type[dt]["files"] += 1
            by_data_type[dt]["records"] += archive.get("record_count", 0)
            by_data_type[dt]["size_mb"] += archive.get("file_size_mb", 0)
        
        return {
            "org_id": org_id,
            "archives": archives,
            "summary": {
                "total_files": total_files,
                "total_records": total_records,
                "total_size_mb": round(total_size_mb, 2),
                "by_data_type": by_data_type,
                "period_days": days,
                "filtered_by": data_type
            }
        }
        
    except Exception as e:
        logger.error(f"Error listing archives: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to list archives")


@router.post("/archives/cleanup")
async def cleanup_archives(
    request: Request,
    keep_days: int = Query(90, ge=30, le=365, description="Keep archives newer than N days"),
    _: None = Depends(require_role("admin"))
):
    """
    Clean up old archive files to free disk space.
    
    Removes archive files older than specified days.
    This action cannot be undone.
    """
    try:
        org_id = current_org(request)
        
        # Run cleanup
        cleanup_stats = cleanup_old_archives(org_id, keep_days)
        
        logger.info(f"Archive cleanup completed for org {org_id}: {cleanup_stats}")
        
        return {
            "success": True,
            "message": f"Cleaned up archives older than {keep_days} days",
            "cleanup_stats": cleanup_stats
        }
        
    except Exception as e:
        logger.error(f"Error during archive cleanup: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to clean up archives")


@router.post("/archives/{manifest_id}/verify")
async def verify_archive(
    manifest_id: int,
    request: Request,
    _: None = Depends(require_role("admin"))
):
    """
    Verify the integrity of an archived file.
    
    Checks file hash and record count against stored manifest.
    """
    try:
        org_id = current_org(request)
        
        # Verify archive integrity
        is_valid = verify_archive_integrity(manifest_id)
        
        if is_valid:
            logger.info(f"Archive verification successful for manifest {manifest_id}")
            return {
                "success": True,
                "message": "Archive verification successful",
                "manifest_id": manifest_id,
                "status": "verified"
            }
        else:
            logger.warning(f"Archive verification failed for manifest {manifest_id}")
            return {
                "success": False,
                "message": "Archive verification failed",
                "manifest_id": manifest_id,
                "status": "failed"
            }
        
    except ArchiveError as e:
        logger.error(f"Archive verification error: {str(e)}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error verifying archive: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to verify archive")


@router.get("/status")
async def get_retention_status(
    request: Request,
    _: None = Depends(require_role("admin"))
):
    """
    Get overall retention status for the organization.
    
    Returns policy information, sweep history, and archive summaries.
    """
    try:
        org_id = current_org(request)
        
        # Get retention policy
        policy = get_retention_policy(org_id)
        
        if not policy:
            return {
                "org_id": org_id,
                "policy_configured": False,
                "message": "No retention policy configured. Default policy will be created on first sweep."
            }
        
        # Get recent archives
        recent_archives = list_archive_files(org_id, days=7)
        
        # Calculate status
        from datetime import datetime
        now = datetime.utcnow()
        
        status = {
            "org_id": org_id,
            "policy_configured": True,
            "policy": policy.to_dict(),
            "sweep_status": {
                "last_sweep": policy.last_sweep_at.isoformat() if policy.last_sweep_at else None,
                "next_sweep": policy.next_sweep_at.isoformat() if policy.next_sweep_at else None,
                "sweep_overdue": policy.is_sweep_due if hasattr(policy, 'is_sweep_due') else False
            },
            "recent_activity": {
                "archives_last_7_days": len(recent_archives),
                "total_records_archived": sum(a.get("record_count", 0) for a in recent_archives),
                "total_size_mb": round(sum(a.get("file_size_mb", 0) for a in recent_archives), 2)
            }
        }
        
        return status
        
    except Exception as e:
        logger.error(f"Error getting retention status: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get retention status")


@router.post("/schedule")
async def schedule_retention_sweep(
    request: Request,
    _: None = Depends(require_role("admin"))
):
    """
    Schedule the next retention sweep.
    
    Updates the next sweep time and queues the job.
    """
    try:
        org_id = current_org(request)
        
        # Schedule next sweep
        next_sweep_time = schedule_next_sweep(org_id)
        
        # Enqueue sweep job
        enqueue_retention_sweep(org_id, "scheduled")
        
        logger.info(f"Retention sweep scheduled for org {org_id}: {next_sweep_time}")
        
        return {
            "success": True,
            "message": "Retention sweep scheduled successfully",
            "next_sweep_at": next_sweep_time.isoformat(),
            "job_queued": True
        }
        
    except Exception as e:
        logger.error(f"Error scheduling retention sweep: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to schedule retention sweep")


# Include router in main app
def include_retention_routes(app):
    """Include retention routes in the main FastAPI app."""
    app.include_router(router)
    logger.info("Retention management routes registered")
