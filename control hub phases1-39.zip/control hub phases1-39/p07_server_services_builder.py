"""
Lead Engine Control Hub - Deployment Builder Service
Phase: 7
Purpose: Handle deployment creation and processing with job queue integration
Key Responsibilities:
- Create deployment records in database
- Process deployment jobs with simulated build steps
- Update deployment status through workflow
- Initialize queue handlers for deployment processing
"""

import logging
import time
from datetime import datetime
from typing import Dict, Any, Optional

# Import database and models
try:
    from p02__server_db import get_session
    from p06__server_models_deployments import Deployment, DeploymentStatus
    from p06__server_services_sites import SiteService
    from p07__server_services_queue import register_handler, get_queue_stats
except ImportError as e:
    logging.warning(f"Import error in builder service: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2, 6, and 7 files are available")

logger = logging.getLogger(__name__)

def create_deployment(site_id: int, metadata: Optional[str] = None) -> Deployment:
    """
    Create a new deployment record in pending status.
    
    Args:
        site_id: ID of the site to deploy
        metadata: Optional deployment metadata
        
    Returns:
        Created Deployment object
        
    Raises:
        ValueError: If site not found
        Exception: If database operation fails
    """
    try:
        # Verify site exists
        site = SiteService.get_site_by_id(site_id)
        if not site:
            raise ValueError(f"Site not found: {site_id}")
        
        with get_session() as db:
            # Create deployment record
            deployment = Deployment(
                site_id=site_id,
                status=DeploymentStatus.PENDING,
                metadata=metadata or f'{{"site_name": "{site.name}", "domain": "{site.domain}"}}'
            )
            
            db.add(deployment)
            db.flush()  # Get ID before commit
            db.refresh(deployment)
            
            logger.info(f"Created deployment {deployment.id} for site {site_id} ({site.name})")
            return deployment
            
    except Exception as e:
        logger.error(f"Failed to create deployment for site {site_id}: {e}")
        raise

def deployment_worker(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process a deployment job. Simulates build process and updates deployment status.
    
    Args:
        payload: Job payload containing deployment information
        
    Returns:
        Job result dictionary
        
    Raises:
        Exception: If deployment processing fails
    """
    site_id = payload.get("site_id")
    deployment_id = payload.get("deployment_id")
    
    if not site_id:
        raise ValueError("Missing site_id in deployment payload")
    
    logger.info(f"Starting deployment worker for site {site_id}")
    
    try:
        # Get site information
        site = SiteService.get_site_by_id(site_id)
        if not site:
            raise ValueError(f"Site not found: {site_id}")
        
        # Find deployment record if deployment_id provided
        deployment = None
        if deployment_id:
            with get_session() as db:
                deployment = db.query(Deployment).filter(Deployment.id == deployment_id).first()
        
        # Update deployment to running status
        if deployment:
            with get_session() as db:
                db_deployment = db.query(Deployment).filter(Deployment.id == deployment.id).first()
                if db_deployment:
                    db_deployment.status = DeploymentStatus.RUNNING
                    db_deployment.started_at = datetime.utcnow()
                    db_deployment.log_output = f"Starting deployment for {site.name} ({site.domain})\n"
        
        # Simulate deployment steps
        build_steps = [
            ("Initializing deployment environment", 1.0),
            ("Fetching source code", 1.5),
            ("Installing dependencies", 2.0),
            ("Building application", 2.5),
            ("Running tests", 1.0),
            ("Optimizing assets", 1.5),
            ("Deploying to hosting provider", 2.0),
            ("Configuring DNS", 1.0),
            ("Verifying deployment", 1.0)
        ]
        
        log_output = f"Deployment started at {datetime.utcnow().isoformat()}\n"
        log_output += f"Site: {site.name}\n"
        log_output += f"Domain: {site.domain}\n"
        log_output += f"Status: {site.status}\n\n"
        
        total_steps = len(build_steps)
        
        for i, (step_name, duration) in enumerate(build_steps, 1):
            logger.info(f"Deployment step {i}/{total_steps}: {step_name}")
            log_output += f"[{datetime.utcnow().strftime('%H:%M:%S')}] Step {i}/{total_steps}: {step_name}\n"
            
            # Simulate work
            time.sleep(duration)
            
            log_output += f"[{datetime.utcnow().strftime('%H:%M:%S')}] ✓ {step_name} completed\n"
            
            # Update deployment log periodically
            if deployment and i % 3 == 0:  # Update every 3 steps
                with get_session() as db:
                    db_deployment = db.query(Deployment).filter(Deployment.id == deployment.id).first()
                    if db_deployment:
                        db_deployment.log_output = log_output
        
        # Mark deployment as completed
        if deployment:
            with get_session() as db:
                db_deployment = db.query(Deployment).filter(Deployment.id == deployment.id).first()
                if db_deployment:
                    db_deployment.status = DeploymentStatus.COMPLETED
                    db_deployment.completed_at = datetime.utcnow()
                    db_deployment.log_output = log_output + f"\n[{datetime.utcnow().strftime('%H:%M:%S')}] 🎉 Deployment completed successfully!\n"
        
        result = {
            "success": True,
            "site_id": site_id,
            "site_name": site.name,
            "domain": site.domain,
            "deployment_id": deployment.id if deployment else None,
            "steps_completed": total_steps,
            "message": f"Successfully deployed {site.name} to {site.domain}"
        }
        
        logger.info(f"Deployment completed successfully for site {site_id}")
        return result
        
    except Exception as e:
        error_msg = f"Deployment failed for site {site_id}: {str(e)}"
        logger.error(error_msg)
        
        # Mark deployment as failed
        if deployment:
            with get_session() as db:
                db_deployment = db.query(Deployment).filter(Deployment.id == deployment.id).first()
                if db_deployment:
                    db_deployment.status = DeploymentStatus.FAILED
                    db_deployment.completed_at = datetime.utcnow()
                    db_deployment.error_message = str(e)
                    if db_deployment.log_output:
                        db_deployment.log_output += f"\n[{datetime.utcnow().strftime('%H:%M:%S')}] ❌ Deployment failed: {str(e)}\n"
                    else:
                        db_deployment.log_output = f"Deployment failed: {str(e)}\n"
        
        raise

def trigger_deployment(site_id: int) -> Dict[str, Any]:
    """
    Trigger a new deployment for a site.
    
    Args:
        site_id: ID of the site to deploy
        
    Returns:
        Dictionary with deployment and job information
        
    Raises:
        Exception: If deployment trigger fails
    """
    try:
        # Create deployment record
        deployment = create_deployment(site_id)
        
        # Import queue functions
        from p07__server_services_queue import enqueue_job
        
        # Enqueue deployment job
        job_id = enqueue_job("deployment", {
            "site_id": site_id,
            "deployment_id": deployment.id
        })
        
        logger.info(f"Triggered deployment {deployment.id} for site {site_id}, job {job_id}")
        
        return {
            "deployment_id": deployment.id,
            "job_id": job_id,
            "site_id": site_id,
            "status": "queued"
        }
        
    except Exception as e:
        logger.error(f"Failed to trigger deployment for site {site_id}: {e}")
        raise

def get_deployment_by_id(deployment_id: int) -> Optional[Deployment]:
    """
    Get deployment by ID.
    
    Args:
        deployment_id: Deployment identifier
        
    Returns:
        Deployment object or None if not found
    """
    try:
        with get_session() as db:
            deployment = db.query(Deployment).filter(Deployment.id == deployment_id).first()
            return deployment
    except Exception as e:
        logger.error(f"Failed to get deployment {deployment_id}: {e}")
        return None

def list_deployments(limit: int = 50) -> list:
    """
    List recent deployments.
    
    Args:
        limit: Maximum number of deployments to return
        
    Returns:
        List of deployment dictionaries
    """
    try:
        with get_session() as db:
            deployments = db.query(Deployment).order_by(
                Deployment.created_at.desc()
            ).limit(limit).all()
            
            return [deployment.to_dict() for deployment in deployments]
            
    except Exception as e:
        logger.error(f"Failed to list deployments: {e}")
        return []

def init_queue() -> None:
    """
    Initialize the job queue with deployment handler.
    Call this during application startup.
    """
    try:
        register_handler("deployment", deployment_worker)
        logger.info("Registered deployment handler with job queue")
        
        # Log queue stats
        stats = get_queue_stats()
        logger.info(f"Queue initialization complete. Stats: {stats}")
        
    except Exception as e:
        logger.error(f"Failed to initialize deployment queue: {e}")
        raise

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Builder Service Module Test ===")
    
    try:
        # Initialize queue
        init_queue()
        
        # Test deployment worker directly
        test_payload = {
            "site_id": 1,
            "deployment_id": None
        }
        
        logger.info("Testing deployment worker...")
        # Note: This will fail without a real site in the database
        # result = deployment_worker(test_payload)
        # logger.info(f"Deployment result: {result}")
        
        logger.info("✅ Builder service module test completed")
        
    except Exception as e:
        logger.error(f"Builder service test failed: {e}")
        logger.info("Note: This is expected if database/models are not available")