"""
Lead Engine Control Hub - Jarvis Assistant Service
Phase: 11
Purpose: Jarvis AI assistant service with command processing and chat history
Key Responsibilities:
- Chat message persistence and history management
- Command processing and execution
- Integration with existing services (queue, builder, diagnostics)
- No external API calls - all processing is internal
"""

import logging
import json
from datetime import datetime
from typing import Dict, Any, List, Optional, Callable

# Import database and models
try:
    from p02__server_db import get_session
    from p11__server_models_jarvis import JarvisSession, JarvisRole, JarvisCommandExtractor, JarvisSessionManager
except ImportError as e:
    logging.warning(f"Import error in Jarvis service: {e}")
    # Fallback for development - will be resolved in final package structure
    logging.info("Using fallback imports - ensure all Phase 2 and 11 files are available")

logger = logging.getLogger(__name__)

class JarvisService:
    """
    Jarvis assistant service for handling chat interactions and commands.
    Provides an intelligent assistant interface without external API dependencies.
    """
    
    def __init__(self):
        self.command_handlers = {}
        self.session_manager = JarvisSessionManager()
        self.command_extractor = JarvisCommandExtractor()
        
        # Register built-in commands
        self._register_builtin_commands()
    
    def save_message(self, session_id: str, role: str, message: str, 
                    command: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None) -> JarvisSession:
        """
        Save a message to the chat history.
        
        Args:
            session_id: Session identifier
            role: Message role (user, assistant, system)
            message: Message content
            command: Optional command string
            metadata: Optional metadata dictionary
            
        Returns:
            Created JarvisSession instance
            
        Raises:
            Exception: If database operation fails
        """
        try:
            with get_session() as db:
                # Convert metadata to JSON string if provided
                metadata_str = json.dumps(metadata) if metadata else None
                
                jarvis_message = JarvisSession(
                    session_id=session_id,
                    role=role.lower(),
                    message=message,
                    command=command,
                    metadata=metadata_str
                )
                
                db.add(jarvis_message)
                db.flush()
                db.refresh(jarvis_message)
                
                logger.info(f"Saved Jarvis message: {jarvis_message.id} (session: {session_id})")
                return jarvis_message
                
        except Exception as e:
            logger.error(f"Failed to save Jarvis message: {e}")
            raise
    
    def load_history(self, session_id: str, limit: int = 50) -> List[JarvisSession]:
        """
        Load chat history for a session.
        
        Args:
            session_id: Session identifier
            limit: Maximum number of messages to return
            
        Returns:
            List of JarvisSession instances ordered by timestamp
            
        Raises:
            Exception: If database operation fails
        """
        try:
            with get_session() as db:
                messages = db.query(JarvisSession).filter(
                    JarvisSession.session_id == session_id
                ).order_by(JarvisSession.timestamp.asc()).limit(limit).all()
                
                logger.info(f"Loaded {len(messages)} messages for session {session_id}")
                return messages
                
        except Exception as e:
            logger.error(f"Failed to load Jarvis history: {e}")
            raise
    
    def handle_message(self, session_id: str, message: str, 
                      require_admin_cb: Optional[Callable[[], bool]] = None) -> Dict[str, Any]:
        """
        Process a user message and generate an appropriate response.
        
        Args:
            session_id: Session identifier
            message: User message content
            require_admin_cb: Optional callback to check admin permissions
            
        Returns:
            Dictionary with response information
        """
        try:
            logger.info(f"Processing Jarvis message for session {session_id}: {message[:50]}...")
            
            # Extract command if present
            command = self.command_extractor.extract_command(message)
            
            # Save user message
            self.save_message(session_id, JarvisRole.USER, message, command)
            
            # Process the message
            if command:
                response = self._handle_command(session_id, command, message, require_admin_cb)
            else:
                response = self._handle_chat_message(session_id, message)
            
            # Save assistant response
            assistant_message = self.save_message(
                session_id, 
                JarvisRole.ASSISTANT, 
                response["content"],
                metadata={"response_type": response.get("type", "chat")}
            )
            
            return {
                "role": "assistant",
                "content": response["content"],
                "session_id": session_id,
                "message_id": assistant_message.id,
                "type": response.get("type", "chat"),
                "timestamp": assistant_message.timestamp.isoformat() if assistant_message.timestamp else None
            }
            
        except Exception as e:
            logger.error(f"Failed to handle Jarvis message: {e}")
            
            # Save error message
            error_response = f"I encountered an error processing your request: {str(e)}"
            try:
                error_message = self.save_message(session_id, JarvisRole.SYSTEM, error_response)
                return {
                    "role": "assistant",
                    "content": error_response,
                    "session_id": session_id,
                    "message_id": error_message.id,
                    "type": "error"
                }
            except:
                # Fallback if even error saving fails
                return {
                    "role": "assistant",
                    "content": "I'm experiencing technical difficulties. Please try again later.",
                    "session_id": session_id,
                    "type": "error"
                }
    
    def _handle_command(self, session_id: str, command: str, full_message: str, 
                       require_admin_cb: Optional[Callable[[], bool]] = None) -> Dict[str, Any]:
        """
        Handle a command message.
        
        Args:
            session_id: Session identifier
            command: Extracted command
            full_message: Full user message
            require_admin_cb: Optional admin check callback
            
        Returns:
            Dictionary with command response
        """
        logger.info(f"Handling command: {command}")
        
        # Get command arguments
        args = self.command_extractor.get_command_args(full_message)
        
        # Check if command handler exists
        if command in self.command_handlers:
            handler = self.command_handlers[command]
            
            # Check admin requirement if callback provided
            if hasattr(handler, '_requires_admin') and handler._requires_admin:
                if require_admin_cb and not require_admin_cb():
                    return {
                        "content": "Sorry, this command requires administrator privileges.",
                        "type": "error"
                    }
            
            try:
                result = handler(session_id, args)
                return {
                    "content": result,
                    "type": "command_response"
                }
            except Exception as e:
                logger.error(f"Command handler failed for '{command}': {e}")
                return {
                    "content": f"Command failed: {str(e)}",
                    "type": "error"
                }
        else:
            # Unknown command
            available_commands = list(self.command_handlers.keys())
            return {
                "content": f"Unknown command '{command}'. Available commands: {', '.join(available_commands)}. Type '/help' for more information.",
                "type": "error"
            }
    
    def _handle_chat_message(self, session_id: str, message: str) -> Dict[str, Any]:
        """
        Handle a regular chat message (non-command).
        
        Args:
            session_id: Session identifier
            message: User message content
            
        Returns:
            Dictionary with chat response
        """
        # Simple pattern-based responses (no external AI)
        message_lower = message.lower()
        
        # Greeting responses
        if any(greeting in message_lower for greeting in ["hello", "hi", "hey", "howdy"]):
            return {
                "content": "Hello! I'm Jarvis, your Lead Engine Control Hub assistant. I can help you manage your leads, sites, and deployments. Type '/help' to see available commands.",
                "type": "greeting"
            }
        
        # Help requests
        if any(help_word in message_lower for help_word in ["help", "assist", "support"]):
            return {
                "content": "I'm here to help! I can assist with:\n\n• Managing leads and buyers\n• Site deployments\n• System diagnostics\n• Data exports\n\nType '/help' for a complete list of commands, or just ask me about specific topics.",
                "type": "help"
            }
        
        # Status requests
        if any(status_word in message_lower for status_word in ["status", "health", "how are"]):
            try:
                # Get quick system status
                from p10__server_services_diagnostics import run_quick_health_check
                health = run_quick_health_check()
                status = health.get("status", "unknown")
                return {
                    "content": f"System status: {status.upper()}. All core services are operational. Type '/status' for detailed information.",
                    "type": "status"
                }
            except:
                return {
                    "content": "I'm functioning normally! Type '/status' for detailed system information.",
                    "type": "status"
                }
        
        # Default response for unrecognized messages
        return {
            "content": "I'm not sure how to respond to that. I'm designed to help with system management tasks. Type '/help' to see what I can do, or try asking about leads, sites, or deployments.",
            "type": "chat"
        }
    
    def _register_builtin_commands(self):
        """Register built-in command handlers."""
        
        def help_command(session_id: str, args: List[str]) -> str:
            """Show available commands and help information."""
            help_text = """Available Commands:

**System & Information:**
• `/help` - Show this help message
• `/status` - Show system status and health
• `/diagnostics` - Run system diagnostics
• `/version` - Show application version

**Lead & Buyer Management:**
• `/list-leads [limit]` - List recent leads
• `/list-buyers [limit]` - List recent buyers
• `/export-leads [format]` - Export leads (csv/json)

**Site & Deployment Management:**
• `/list-sites` - List all sites
• `/build-site <id>` - Trigger site deployment
• `/deployment-status <id>` - Check deployment status

**System Operations:**
• `/repair <component>` - Attempt to repair system components

**Tips:**
- Commands can be prefixed with `/`, `!`, or `@jarvis`
- Most commands have optional parameters
- Type `/help <command>` for specific command details"""
            
            return help_text
        
        def status_command(session_id: str, args: List[str]) -> str:
            """Get system status information."""
            try:
                from p10__server_services_diagnostics import run_quick_health_check
                health = run_quick_health_check()
                
                status = health.get("status", "unknown").upper()
                runtime = health.get("runtime_ms", 0)
                components = health.get("components", {})
                
                result = f"🤖 **System Status: {status}**\n\n"
                result += f"**Health Check:** Completed in {runtime}ms\n\n"
                result += "**Components:**\n"
                
                for component, comp_status in components.items():
                    icon = "✅" if comp_status == "ok" else "⚠️" if comp_status == "warning" else "❌"
                    result += f"• {component.title()}: {icon} {comp_status.upper()}\n"
                
                return result
                
            except Exception as e:
                return f"Unable to retrieve system status: {str(e)}"
        
        def list_sites_command(session_id: str, args: List[str]) -> str:
            """List all sites."""
            try:
                from p06__server_services_sites import SiteService
                sites = SiteService.get_all_sites()
                
                if not sites:
                    return "No sites found. Create your first site to get started!"
                
                result = f"**Sites ({len(sites)} total):**\n\n"
                for site in sites[:10]:  # Limit to 10 for chat display
                    status_icon = "🟢" if site.status == "active" else "🟡" if site.status == "pending" else "🔴"
                    result += f"• **{site.name}** ({site.id})\n"
                    result += f"  Domain: {site.domain} {status_icon}\n"
                    result += f"  Status: {site.status}\n\n"
                
                if len(sites) > 10:
                    result += f"... and {len(sites) - 10} more sites."
                
                return result
                
            except Exception as e:
                return f"Unable to retrieve sites: {str(e)}"
        
        def build_site_command(session_id: str, args: List[str]) -> str:
            """Trigger site deployment."""
            if not args:
                return "Please specify a site ID. Usage: `/build-site <site_id>`"
            
            try:
                site_id = int(args[0])
                
                # Import deployment services
                from p07__server_services_builder import trigger_deployment
                from p06__server_services_sites import SiteService
                
                # Verify site exists
                site = SiteService.get_site_by_id(site_id)
                if not site:
                    return f"Site with ID {site_id} not found."
                
                # Trigger deployment
                result = trigger_deployment(site_id)
                
                return f"🚀 **Deployment triggered for {site.name}**\n\n" \
                       f"• Site: {site.domain}\n" \
                       f"• Deployment ID: {result['deployment_id']}\n" \
                       f"• Job ID: {result['job_id']}\n" \
                       f"• Status: {result['status']}\n\n" \
                       f"Use `/deployment-status {result['deployment_id']}` to check progress."
                
            except ValueError:
                return "Invalid site ID. Please provide a numeric site ID."
            except Exception as e:
                return f"Deployment failed: {str(e)}"
        
        def diagnostics_command(session_id: str, args: List[str]) -> str:
            """Run system diagnostics."""
            try:
                from p10__server_services_diagnostics import run_full_diagnostics
                
                diagnostics = run_full_diagnostics()
                status = diagnostics.get("status", "unknown").upper()
                runtime = diagnostics.get("runtime_ms", 0)
                components = diagnostics.get("components", {})
                
                result = f"🔍 **System Diagnostics: {status}**\n\n"
                result += f"**Scan completed in {runtime}ms**\n\n"
                
                for component, details in components.items():
                    comp_status = details.get("status", "unknown")
                    icon = "✅" if comp_status == "ok" else "⚠️" if comp_status == "warning" else "❌"
                    result += f"**{component.title()}:** {icon} {comp_status.upper()}\n"
                    
                    if comp_status != "ok" and "message" in details:
                        result += f"  └ {details['message']}\n"
                
                return result
                
            except Exception as e:
                return f"Diagnostics failed: {str(e)}"
        
        # Register commands
        self.command_handlers = {
            "help": help_command,
            "status": status_command,
            "list-sites": list_sites_command,
            "build-site": build_site_command,
            "diagnostics": diagnostics_command
        }
        
        # Mark admin-only commands
        build_site_command._requires_admin = True
        
        logger.info(f"Registered {len(self.command_handlers)} Jarvis commands")

# Global Jarvis service instance
_jarvis_service = JarvisService()

def save_message(session_id: str, role: str, message: str, 
                command: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None) -> JarvisSession:
    """Save a message (convenience function)."""
    return _jarvis_service.save_message(session_id, role, message, command, metadata)

def load_history(session_id: str, limit: int = 50) -> List[JarvisSession]:
    """Load chat history (convenience function)."""
    return _jarvis_service.load_history(session_id, limit)

def handle_message(session_id: str, message: str, 
                  require_admin_cb: Optional[Callable[[], bool]] = None) -> Dict[str, Any]:
    """Handle a user message (convenience function)."""
    return _jarvis_service.handle_message(session_id, message, require_admin_cb)

def get_jarvis_service() -> JarvisService:
    """Get the global Jarvis service instance."""
    return _jarvis_service

if __name__ == "__main__":
    # Standalone testing
    logging.basicConfig(level=logging.INFO)
    
    logger.info("=== Jarvis Service Module Test ===")
    
    try:
        # Test session and message handling
        session_id = JarvisSessionManager.generate_session_id()
        logger.info(f"Generated test session: {session_id}")
        
        # Test command handling
        test_messages = [
            "Hello Jarvis!",
            "/help",
            "/status",
            "/list-sites",
            "What can you do?",
            "/unknown-command"
        ]
        
        for message in test_messages:
            logger.info(f"\n--- Testing message: {message} ---")
            response = handle_message(session_id, message)
            logger.info(f"Response: {response['content'][:100]}...")
            logger.info(f"Type: {response.get('type', 'unknown')}")
        
        # Test history loading
        history = load_history(session_id)
        logger.info(f"\nLoaded {len(history)} messages from history")
        
        logger.info("✅ Jarvis service module test completed")
        
    except Exception as e:
        logger.error(f"Jarvis service test failed: {e}")
        logger.info("Note: This is expected if database/models are not available")