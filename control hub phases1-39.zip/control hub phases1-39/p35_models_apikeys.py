"""
Lead Engine Control Hub - Buyer API Keys Models
Phase 35: API keys for buyers pull API
Purpose: Secure authentication for buyer lead pulling endpoints
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Text
from sqlalchemy.orm import relationship

# Import base from existing models (would be consolidated in final structure)
try:
    from p02__server_models import Base
except ImportError:
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()


class BuyerApiKey(Base):
    """
    API keys for buyers to authenticate with pull API endpoints.
    
    Stores hashed keys for security and tracks usage metadata.
    Keys are scoped to specific buyers and organizations.
    """
    __tablename__ = "buyer_api_keys"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    buyer_id = Column(Integer, ForeignKey("buyers.id"), nullable=False, index=True)
    
    # Key identification
    name = Column(String(100), nullable=False)  # Human-readable name
    key_hash = Column(String(64), nullable=False, unique=True, index=True)  # SHA-256 hash
    key_prefix = Column(String(8), nullable=False)  # First 8 chars for identification
    
    # Status and permissions
    active = Column(Boolean, nullable=False, default=True)
    permissions = Column(Text, nullable=True)  # JSON string of permissions
    
    # Usage tracking
    last_used_at = Column(DateTime, nullable=True, index=True)
    last_used_ip = Column(String(45), nullable=True)  # IPv4 or IPv6
    usage_count = Column(Integer, nullable=False, default=0)
    
    # Rate limiting
    rate_limit_per_hour = Column(Integer, nullable=False, default=1000)
    rate_limit_per_day = Column(Integer, nullable=False, default=10000)
    
    # Audit fields
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    created_by = Column(String(100), nullable=True)
    expires_at = Column(DateTime, nullable=True, index=True)  # Optional expiration
    
    # Relationships
    buyer = relationship("Buyer", back_populates="api_keys")
    organization = relationship("Organization")
    
    def __repr__(self):
        return f"<BuyerApiKey buyer_id={self.buyer_id} name='{self.name}' active={self.active}>"
    
    @property
    def is_expired(self):
        """Check if key has expired."""
        if not self.expires_at:
            return False
        return datetime.utcnow() > self.expires_at
    
    @property
    def is_usable(self):
        """Check if key can be used (active and not expired)."""
        return self.active and not self.is_expired
    
    @property
    def masked_key_prefix(self):
        """Return safely displayable key prefix."""
        return f"{self.key_prefix}..."
    
    def record_usage(self, ip_address: str = None):
        """Record usage of this API key."""
        self.last_used_at = datetime.utcnow()
        self.usage_count += 1
        if ip_address:
            self.last_used_ip = ip_address
    
    def to_dict(self, include_sensitive=False):
        """Convert to dictionary for API responses."""
        data = {
            "id": self.id,
            "buyer_id": self.buyer_id,
            "name": self.name,
            "key_prefix": self.masked_key_prefix,
            "active": self.active,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
            "usage_count": self.usage_count,
            "rate_limit_per_hour": self.rate_limit_per_hour,
            "rate_limit_per_day": self.rate_limit_per_day,
            "created_at": self.created_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "is_expired": self.is_expired,
            "is_usable": self.is_usable
        }
        
        if include_sensitive:
            # Only include in creation response
            data["key_hash"] = self.key_hash
        
        return data


class ApiKeyUsageLog(Base):
    """
    Log of API key usage for monitoring and rate limiting.
    
    Records each API call made with buyer keys for security
    and compliance monitoring.
    """
    __tablename__ = "api_key_usage_logs"
    
    id = Column(Integer, primary_key=True)
    org_id = Column(Integer, ForeignKey("organizations.id"), nullable=False, index=True)
    buyer_id = Column(Integer, ForeignKey("buyers.id"), nullable=False, index=True)
    api_key_id = Column(Integer, ForeignKey("buyer_api_keys.id"), nullable=False, index=True)
    
    # Request details
    endpoint = Column(String(200), nullable=False, index=True)
    method = Column(String(10), nullable=False)
    status_code = Column(Integer, nullable=False, index=True)
    
    # Response details
    response_time_ms = Column(Integer, nullable=True)
    records_returned = Column(Integer, nullable=True)
    error_message = Column(Text, nullable=True)
    
    # Client details
    ip_address = Column(String(45), nullable=True, index=True)
    user_agent = Column(Text, nullable=True)
    
    # Timestamp
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    
    # Relationships
    api_key = relationship("BuyerApiKey")
    buyer = relationship("Buyer")
    
    def __repr__(self):
        return f"<ApiKeyUsageLog key_id={self.api_key_id} endpoint='{self.endpoint}' status={self.status_code}>"
    
    @property
    def was_successful(self):
        """Check if request was successful."""
        return 200 <= self.status_code < 300
    
    def to_dict(self):
        """Convert to dictionary for API responses."""
        return {
            "id": self.id,
            "buyer_id": self.buyer_id,
            "api_key_id": self.api_key_id,
            "endpoint": self.endpoint,
            "method": self.method,
            "status_code": self.status_code,
            "response_time_ms": self.response_time_ms,
            "records_returned": self.records_returned,
            "error_message": self.error_message,
            "ip_address": self.ip_address,
            "created_at": self.created_at.isoformat(),
            "was_successful": self.was_successful
        }


class ApiRateLimit(Base):
    """
    Rate limiting state for API keys.
    
    Tracks current usage counts within time windows
    for implementing rate limits.
    """
    __tablename__ = "api_rate_limits"
    
    id = Column(Integer, primary_key=True)
    api_key_id = Column(Integer, ForeignKey("buyer_api_keys.id"), nullable=False, unique=True, index=True)
    
    # Hourly limits
    hourly_count = Column(Integer, nullable=False, default=0)
    hourly_reset_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    # Daily limits
    daily_count = Column(Integer, nullable=False, default=0)
    daily_reset_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    # Last request
    last_request_at = Column(DateTime, nullable=True)
    
    # Relationships
    api_key = relationship("BuyerApiKey", back_populates="rate_limit")
    
    def __repr__(self):
        return f"<ApiRateLimit key_id={self.api_key_id} hourly={self.hourly_count} daily={self.daily_count}>"
    
    def is_rate_limited(self, hourly_limit: int, daily_limit: int) -> tuple[bool, str]:
        """
        Check if requests should be rate limited.
        
        Returns:
            Tuple of (is_limited, reason)
        """
        now = datetime.utcnow()
        
        # Reset hourly counter if needed
        if now >= self.hourly_reset_at:
            self.hourly_count = 0
            self.hourly_reset_at = now.replace(minute=0, second=0, microsecond=0)
            self.hourly_reset_at = self.hourly_reset_at.replace(hour=self.hourly_reset_at.hour + 1)
        
        # Reset daily counter if needed
        if now >= self.daily_reset_at:
            self.daily_count = 0
            self.daily_reset_at = now.replace(hour=0, minute=0, second=0, microsecond=0)
            from datetime import timedelta
            self.daily_reset_at = self.daily_reset_at + timedelta(days=1)
        
        # Check limits
        if self.hourly_count >= hourly_limit:
            return True, f"Hourly limit of {hourly_limit} requests exceeded"
        
        if self.daily_count >= daily_limit:
            return True, f"Daily limit of {daily_limit} requests exceeded"
        
        return False, "Within limits"
    
    def record_request(self):
        """Record a new request."""
        self.hourly_count += 1
        self.daily_count += 1
        self.last_request_at = datetime.utcnow()
    
    def get_limits_info(self) -> dict:
        """Get current limit status."""
        return {
            "hourly_count": self.hourly_count,
            "hourly_reset_at": self.hourly_reset_at.isoformat(),
            "daily_count": self.daily_count,
            "daily_reset_at": self.daily_reset_at.isoformat(),
            "last_request_at": self.last_request_at.isoformat() if self.last_request_at else None
        }


# Add relationship to Buyer model (would be added to existing Buyer class)
def add_api_keys_relationship_to_buyer():
    """
    Migration to add api_keys relationship to existing Buyer model.
    """
    # This would add to the Buyer class:
    # api_keys = relationship("BuyerApiKey", back_populates="buyer", cascade="all, delete-orphan")
    pass


# Indexes for performance
# CREATE INDEX idx_buyer_api_keys_org_buyer ON buyer_api_keys(org_id, buyer_id);
# CREATE INDEX idx_buyer_api_keys_hash ON buyer_api_keys(key_hash);
# CREATE INDEX idx_buyer_api_keys_active ON buyer_api_keys(active, expires_at);
# CREATE INDEX idx_api_key_usage_logs_key_created ON api_key_usage_logs(api_key_id, created_at);
# CREATE INDEX idx_api_key_usage_logs_endpoint_status ON api_key_usage_logs(endpoint, status_code);
# CREATE INDEX idx_api_rate_limits_key ON api_rate_limits(api_key_id);
