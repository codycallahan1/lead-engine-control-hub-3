"""
Read-only mode middleware for maintenance operations.

Phase: 27
Purpose: Block mutating operations when system is in maintenance mode.
Key responsibilities:
- Check read-only mode setting from database
- Block POST/PATCH/DELETE operations during maintenance
- Allow essential admin endpoints to function
"""

from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response, JSONResponse
import logging
from typing import Set

logger = logging.getLogger(__name__)

# HTTP methods that modify data
MUTATING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

# Paths that are always allowed even in read-only mode
ALLOWED_PATHS = {
    "/health",
    "/version",
    "/metrics/summary",
    "/maintenance/readonly",  # Allow toggling read-only mode
    "/maintenance/status",
    "/maintenance/backup",    # Allow creating backups
    "/docs",
    "/openapi.json",
    "/static"
}

# Path prefixes that are always allowed
ALLOWED_PREFIXES = {
    "/static/",
    "/docs",
    "/redoc"
}


class ReadOnlyMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce read-only mode during maintenance."""
    
    def __init__(self, app, check_readonly_func=None):
        super().__init__(app)
        self.check_readonly = check_readonly_func or self._default_readonly_check
        
    async def dispatch(self, request: Request, call_next):
        """Check if request should be blocked in read-only mode."""
        
        # Skip check for non-mutating methods
        if request.method not in MUTATING_METHODS:
            return await call_next(request)
        
        # Skip check for always-allowed paths
        path = request.url.path
        if self._is_path_allowed(path):
            return await call_next(request)
        
        # Check if system is in read-only mode
        try:
            is_readonly = await self._check_readonly_mode(request)
            
            if is_readonly:
                logger.warning(f"Blocked {request.method} {path} - system in read-only mode")
                
                # Return appropriate response based on content type
                if self._wants_json(request):
                    return JSONResponse(
                        status_code=503,
                        content={
                            "error": "Service Unavailable",
                            "detail": "System is in read-only mode for maintenance",
                            "maintenance": True,
                            "allowed_methods": ["GET", "HEAD", "OPTIONS"]
                        },
                        headers={
                            "Retry-After": "300",  # Suggest retry in 5 minutes
                            "X-Maintenance-Mode": "true"
                        }
                    )
                else:
                    # Return HTML error page for browser requests
                    html_content = self._get_maintenance_html()
                    return Response(
                        content=html_content,
                        status_code=503,
                        media_type="text/html",
                        headers={
                            "Retry-After": "300",
                            "X-Maintenance-Mode": "true"
                        }
                    )
        
        except Exception as e:
            logger.error(f"Error checking read-only mode: {e}")
            # On error, allow the request to proceed (fail open)
        
        return await call_next(request)
    
    def _is_path_allowed(self, path: str) -> bool:
        """Check if path is always allowed even in read-only mode."""
        
        # Exact path matches
        if path in ALLOWED_PATHS:
            return True
        
        # Prefix matches
        for prefix in ALLOWED_PREFIXES:
            if path.startswith(prefix):
                return True
        
        return False
    
    def _wants_json(self, request: Request) -> bool:
        """Determine if request expects JSON response."""
        accept = request.headers.get("accept", "")
        content_type = request.headers.get("content-type", "")
        
        return (
            "application/json" in accept or
            "application/json" in content_type or
            "/api/" in request.url.path
        )
    
    async def _check_readonly_mode(self, request: Request) -> bool:
        """Check if system is currently in read-only mode."""
        return await self.check_readonly(request)
    
    async def _default_readonly_check(self, request: Request) -> bool:
        """Default implementation: check database setting."""
        try:
            from p02__server_db import get_session
            
            with get_session() as db:
                # Try to get read-only setting from app settings table
                try:
                    # This would be added in Phase 20+ with app settings
                    result = db.execute(
                        "SELECT value FROM app_settings WHERE key = 'read_only_mode'"
                    ).fetchone()
                    
                    if result:
                        return result[0].lower() in ('true', '1', 'yes', 'on')
                
                except Exception:
                    # Settings table might not exist or query might fail
                    pass
                
                # Fallback: check for maintenance file
                import os
                return os.path.exists("./MAINTENANCE_MODE")
        
        except Exception as e:
            logger.debug(f"Read-only check failed: {e}")
            return False
    
    def _get_maintenance_html(self) -> str:
        """Generate maintenance mode HTML page."""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>System Maintenance</title>
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
                    background: #1a1a1a;
                    color: #fff;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    margin: 0;
                    padding: 20px;
                }
                .container {
                    text-align: center;
                    max-width: 500px;
                    background: #2a2a2a;
                    padding: 40px;
                    border-radius: 10px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                }
                .icon {
                    font-size: 64px;
                    color: #ff9800;
                    margin-bottom: 20px;
                }
                h1 {
                    color: #fff;
                    margin-bottom: 16px;
                }
                p {
                    color: #ccc;
                    line-height: 1.6;
                    margin-bottom: 24px;
                }
                .status {
                    background: #333;
                    padding: 12px;
                    border-radius: 6px;
                    margin-top: 20px;
                    font-family: monospace;
                    font-size: 14px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">🔧</div>
                <h1>System Maintenance</h1>
                <p>
                    The Lead Engine Control Hub is currently in read-only mode for maintenance.
                    Data modifications are temporarily disabled.
                </p>
                <p>
                    You can still view data, but creating, updating, or deleting records is not available.
                </p>
                <div class="status">
                    Status: Read-Only Mode Active<br>
                    Please try again in a few minutes.
                </div>
            </div>
        </body>
        </html>
        """


def create_readonly_middleware(app, readonly_check_func=None):
    """Factory function to create read-only middleware."""
    return ReadOnlyMiddleware(app, readonly_check_func)


# Simple in-memory read-only state for testing
_readonly_state = {"enabled": False}


async def simple_readonly_check(request: Request) -> bool:
    """Simple in-memory read-only check for testing."""
    return _readonly_state["enabled"]


def set_readonly_mode(enabled: bool):
    """Set read-only mode (for testing)."""
    _readonly_state["enabled"] = enabled
    logger.info(f"Read-only mode {'enabled' if enabled else 'disabled'}")


def get_readonly_mode() -> bool:
    """Get current read-only mode state."""
    return _readonly_state["enabled"]
