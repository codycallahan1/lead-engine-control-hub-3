"""
Audit service with privacy-specific helpers.

Phase: 26 (Updated from Phase 8)
Purpose: Enhanced audit logging with privacy operation support.
Key responsibilities:
- General audit logging functionality
- Privacy-specific audit helpers for email and privacy operations
- Structured logging for compliance
"""

import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


def audit(kind: str, message: str, meta: Optional[Dict[str, Any]] = None):
    """
    Log structured audit event.
    
    Args:
        kind: Type of audit event (e.g., 'leads_exported', 'privacy_lead_erased')
        message: Human-readable description
        meta: Additional metadata dictionary
    """
    try:
        audit_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "kind": kind,
            "message": message,
            "meta": meta or {}
        }
        
        # Log as structured data
        logger.info(f"AUDIT: {json.dumps(audit_entry)}")
        
        # Also attempt to store in database if audit table exists
        try:
            from p02__server_db import get_session
            
            # Try to import audit model - might not exist in all phases
            try:
                from p21__server_models_audit import Audit
                
                with get_session() as db:
                    audit_record = Audit(
                        kind=kind,
                        message=message,
                        meta_json=json.dumps(meta) if meta else None
                    )
                    db.add(audit_record)
                    db.commit()
                    
            except ImportError:
                # Audit model not available yet, just log
                pass
                
        except Exception as e:
            logger.warning(f"Failed to store audit record in database: {e}")
    
    except Exception as e:
        logger.error(f"Audit logging failed: {e}")


def audit_email(kind: str, to: str, subject: str, success: bool, attempts: int = 1, error: Optional[str] = None):
    """
    Audit email-related operations.
    
    Args:
        kind: Email operation type ('notification_sent', 'webhook_delivery', etc.)
        to: Recipient email address
        subject: Email subject
        success: Whether operation succeeded
        attempts: Number of attempts made
        error: Error message if failed
    """
    meta = {
        "email_to": to,
        "subject": subject,
        "success": success,
        "attempts": attempts,
        "delivery_method": "mock_provider"
    }
    
    if error:
        meta["error"] = error
    
    status = "success" if success else "failed"
    message = f"Email {status}: {subject} to {to}"
    
    if attempts > 1:
        message += f" (attempt {attempts})"
    
    audit(f"email_{kind}", message, meta)


def audit_privacy(kind: str, lead_id: int, actor: str, success: bool, details: str):
    """
    Audit privacy-related operations for compliance.
    
    Args:
        kind: Privacy operation ('lead_exported', 'lead_erased', 'erasure_eligibility_checked')
        lead_id: ID of affected lead
        actor: Who performed the operation
        success: Whether operation succeeded
        details: Additional details about the operation
    """
    meta = {
        "lead_id": lead_id,
        "actor": actor,
        "success": success,
        "operation_type": "privacy_request",
        "compliance_framework": "gdpr_lite"
    }
    
    status = "success" if success else "failed"
    message = f"Privacy {kind} {status} for lead {lead_id} by {actor}: {details}"
    
    audit(f"privacy_{kind}", message, meta)


def audit_data_operation(kind: str, table: str, count: int, actor: str, details: Optional[Dict] = None):
    """
    Audit bulk data operations like imports, exports, deletions.
    
    Args:
        kind: Operation type ('import', 'export', 'bulk_delete')
        table: Database table affected
        count: Number of records affected
        actor: Who performed the operation
        details: Additional operation details
    """
    meta = {
        "table": table,
        "record_count": count,
        "actor": actor,
        "data_operation": True
    }
    
    if details:
        meta.update(details)
    
    message = f"Data {kind}: {count} records in {table} by {actor}"
    
    audit(f"data_{kind}", message, meta)


def audit_security_event(kind: str, actor: str, resource: str, success: bool, details: str):
    """
    Audit security-related events.
    
    Args:
        kind: Security event type ('access_denied', 'privilege_escalation', 'auth_failure')
        actor: Who attempted the action
        resource: What resource was accessed
        success: Whether access was granted
        details: Additional security details
    """
    meta = {
        "actor": actor,
        "resource": resource,
        "success": success,
        "security_event": True,
        "risk_level": "high" if not success else "low"
    }
    
    status = "granted" if success else "denied"
    message = f"Security: {kind} - access {status} for {actor} to {resource}: {details}"
    
    audit(f"security_{kind}", message, meta)


def audit_system_event(kind: str, component: str, status: str, details: Optional[Dict] = None):
    """
    Audit system-level events like startup, shutdown, errors.
    
    Args:
        kind: System event type ('startup', 'shutdown', 'error', 'maintenance')
        component: System component affected
        status: Event status ('success', 'failed', 'warning')
        details: Additional system details
    """
    meta = {
        "component": component,
        "status": status,
        "system_event": True
    }
    
    if details:
        meta.update(details)
    
    message = f"System {kind}: {component} - {status}"
    
    audit(f"system_{kind}", message, meta)


# Helper function for backward compatibility
def audit_lead_exported(format_type: str, count: int, actor: str = "system"):
    """Legacy helper for lead export auditing."""
    audit_data_operation(
        "export", 
        "leads", 
        count, 
        actor, 
        {"format": format_type}
    )


def audit_webhook_delivery(webhook_url: str, event: str, success: bool, response_code: Optional[int] = None):
    """Audit webhook delivery attempts."""
    meta = {
        "webhook_url": webhook_url,
        "event_type": event,
        "success": success,
        "delivery_method": "http_post"
    }
    
    if response_code:
        meta["response_code"] = response_code
    
    status = "delivered" if success else "failed"
    message = f"Webhook {status}: {event} to {webhook_url}"
    
    audit("webhook_delivery", message, meta)
