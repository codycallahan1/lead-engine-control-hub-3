"""
App Initialization Wire-up for Scheduler
Phase 19: Show how to integrate scheduler startup with FastAPI app
Key responsibilities: Demonstrate proper initialization order, error handling
"""

import logging
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)

# Example of how to wire up the scheduler in your main FastAPI app
# This would be integrated into p01__server-app.py

@asynccontextmanager
async def lifespan(app):
    """
    FastAPI lifespan context manager
    Handles startup and shutdown events
    """
    # Startup
    logger.info("Application startup - initializing services")
    
    try:
        # Initialize database tables first
        try:
            from p02__server_db import create_all_tables
            create_all_tables()
            logger.info("Database tables initialized")
        except ImportError:
            logger.warning("Database initialization skipped - modules not found")
        
        # Create metrics snapshots table
        try:
            from p02__server_db import engine
            from p19__server_models_metrics_snapshots import create_metrics_snapshots_table
            create_metrics_snapshots_table(engine)
            logger.info("Metrics snapshots table initialized")
        except ImportError:
            logger.warning("Metrics snapshots table initialization skipped")
        
        # Start scheduler after database is ready
        try:
            from p19__server_services_scheduler import start_scheduler
            start_scheduler()
            logger.info("Scheduler started successfully")
        except ImportError:
            logger.warning("Scheduler startup skipped - modules not found")
        except Exception as e:
            logger.error(f"Failed to start scheduler: {e}")
            # Don't fail app startup if scheduler fails
        
        logger.info("Application startup completed")
        
    except Exception as e:
        logger.error(f"Error during application startup: {e}")
        # Continue startup even if some services fail
    
    yield  # Application is running
    
    # Shutdown
    logger.info("Application shutdown - cleaning up services")
    
    try:
        from p19__server_services_scheduler import stop_scheduler
        stop_scheduler()
        logger.info("Scheduler stopped")
    except ImportError:
        pass
    except Exception as e:
        logger.error(f"Error stopping scheduler: {e}")
    
    logger.info("Application shutdown completed")

# Example FastAPI app setup with scheduler
def create_app_with_scheduler():
    """
    Example function showing how to create FastAPI app with scheduler
    This would replace or enhance the app creation in p01__server-app.py
    """
    from fastapi import FastAPI
    
    app = FastAPI(
        title="Lead Engine Control Hub",
        description="Control hub with automated metrics capture",
        version="1.0.0",
        lifespan=lifespan
    )
    
    # Add your existing routes here
    # app.include_router(leads_router)
    # app.include_router(buyers_router)
    # etc.
    
    # Add metrics snapshots routes
    try:
        from p19__server_routes_metrics_snapshots import router as snapshots_router
        app.include_router(snapshots_router)
        logger.info("Metrics snapshots routes registered")
    except ImportError:
        logger.warning("Metrics snapshots routes not available")
    
    return app

# Health check that includes scheduler status
def enhanced_health_check():
    """
    Enhanced health check that includes scheduler status
    This could be added to existing health endpoint
    """
    try:
        from p19__server_services_scheduler import get_scheduler_status
        scheduler_status = get_scheduler_status()
        
        return {
            "status": "ok",
            "services": {
                "scheduler": {
                    "running": scheduler_status.get("running", False),
                    "tasks": scheduler_status.get("tasks_count", 0)
                }
            },
            "timestamp": logger.manager.start_time if hasattr(logger.manager, 'start_time') else None
        }
    except Exception as e:
        return {
            "status": "degraded",
            "error": str(e),
            "services": {
                "scheduler": {
                    "running": False,
                    "error": str(e)
                }
            }
        }

# Manual metrics capture function for testing
def manual_metrics_capture():
    """
    Function to manually trigger metrics capture
    Useful for testing or one-time operations
    """
    try:
        from p19__server_services_metrics_capture import capture_metrics
        result = capture_metrics()
        logger.info(f"Manual metrics capture result: {result}")
        return result
    except ImportError:
        logger.error("Metrics capture service not available")
        return "error_import"
    except Exception as e:
        logger.error(f"Manual metrics capture failed: {e}")
        return f"error: {str(e)}"

# Integration instructions as comments
"""
To integrate scheduler into your existing p01__server-app.py:

1. Add the lifespan function to your app:
   app = FastAPI(..., lifespan=lifespan)

2. Include the metrics snapshots router:
   from p19__server_routes_metrics_snapshots import router as snapshots_router
   app.include_router(snapshots_router)

3. Optionally enhance your health check:
   @app.get("/health")
   async def health():
       return enhanced_health_check()

4. For manual testing:
   # Run this in Python shell or script
   result = manual_metrics_capture()
   print(f"Capture result: {result}")

The scheduler will automatically:
- Start when the app starts
- Capture metrics daily at 00:05 UTC
- Stop cleanly when the app shuts down
- Log all operations for monitoring
"""

if __name__ == "__main__":
    # Example of running manual capture for testing
    import asyncio
    
    async def test_setup():
        # Simulate app startup without FastAPI
        logger.info("Testing scheduler setup")
        
        try:
            from p19__server_services_scheduler import start_scheduler, get_scheduler_status
            start_scheduler()
            
            # Wait a moment for scheduler to initialize
            await asyncio.sleep(1)
            
            status = get_scheduler_status()
            logger.info(f"Scheduler status: {status}")
            
            # Test manual capture
            result = manual_metrics_capture()
            logger.info(f"Manual capture result: {result}")
            
        except Exception as e:
            logger.error(f"Test failed: {e}")
    
    # Run test
    asyncio.run(test_setup())
