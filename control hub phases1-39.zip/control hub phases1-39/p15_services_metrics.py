"""
Enhanced metrics service with time-series data for visualization.

Phase: 15
Purpose: Service layer for computing metrics and time trends for charts
Key responsibilities: time bucket calculations, aggregate counts, chart data preparation
"""

import logging
from typing import List, Dict, Any
from datetime import datetime, timedelta
from collections import defaultdict

# Import attempt with graceful fallback
try:
    from p02__server_db import get_session
    from p02__server_models import Lead, Buyer, Site
    from p14__server_models_sales import LeadSale
    from p06__server_models_deployments import Deployment  # Assuming this exists from Phase 6
except ImportError as e:
    logging.warning(f"Import issue in metrics service: {e}")
    # Fallback for development
    def get_session():
        return None
    class Lead:
        pass
    class Buyer:
        pass
    class Site:
        pass
    class LeadSale:
        pass
    class Deployment:
        pass

logger = logging.getLogger(__name__)

def compute_time_buckets(table_name: str, days: int = 14) -> List[Dict[str, Any]]:
    """
    Compute daily counts for a table over the specified number of days.
    
    Args:
        table_name: Name of the table/model to count ('leads', 'sales', 'deployments')
        days: Number of days to include in the time series
        
    Returns:
        List of dicts with 'date' and 'count' keys, ordered chronologically
    """
    logger.info(f"Computing time buckets for {table_name} over {days} days")
    
    # Calculate date range
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days-1)
    
    # Initialize all dates with zero counts
    date_counts = {}
    current_date = start_date
    while current_date <= end_date:
        date_counts[current_date] = 0
        current_date += timedelta(days=1)
    
    with get_session() as session:
        try:
            # Select the appropriate model based on table name
            if table_name == 'leads':
                model = Lead
            elif table_name == 'sales':
                model = LeadSale
            elif table_name == 'deployments':
                model = Deployment
            elif table_name == 'buyers':
                model = Buyer
            elif table_name == 'sites':
                model = Site
            else:
                logger.warning(f"Unknown table name: {table_name}")
                return []
            
            # Query records within the date range
            records = session.query(model).filter(
                model.created_at >= datetime.combine(start_date, datetime.min.time()),
                model.created_at <= datetime.combine(end_date, datetime.max.time())
            ).all()
            
            # Count records by date
            for record in records:
                if record.created_at:
                    record_date = record.created_at.date()
                    if record_date in date_counts:
                        date_counts[record_date] += 1
            
            logger.info(f"Found {len(records)} {table_name} records in date range")
            
        except Exception as e:
            logger.error(f"Error querying {table_name}: {e}")
            # Return empty data on error
            pass
    
    # Convert to list format for charts
    result = []
    for date in sorted(date_counts.keys()):
        result.append({
            'date': date.strftime('%Y-%m-%d'),
            'date_short': date.strftime('%m-%d'),
            'count': date_counts[date]
        })
    
    logger.info(f"Computed {len(result)} time buckets for {table_name}")
    return result

def aggregate_counts() -> Dict[str, int]:
    """
    Get aggregate counts for all major entities.
    
    Returns:
        Dict with counts for leads, buyers, sites, sales, deployments
    """
    logger.info("Computing aggregate counts")
    
    counts = {
        'leads': 0,
        'buyers': 0,
        'sites': 0,
        'sales': 0,
        'deployments': 0
    }
    
    with get_session() as session:
        try:
            counts['leads'] = session.query(Lead).count()
            counts['buyers'] = session.query(Buyer).count()
            counts['sites'] = session.query(Site).count()
            counts['sales'] = session.query(LeadSale).count()
            counts['deployments'] = session.query(Deployment).count()
            
            logger.info(f"Aggregate counts: {counts}")
            
        except Exception as e:
            logger.error(f"Error computing aggregate counts: {e}")
            # Return zeros on error
            pass
    
    return counts

def get_chart_data() -> Dict[str, Any]:
    """
    Get all data needed for metrics charts in a single call.
    
    Returns:
        Dict with time series data for leads and sales, plus aggregate counts
    """
    logger.info("Getting comprehensive chart data")
    
    # Get time series data
    leads_trend = compute_time_buckets('leads', days=14)
    sales_trend = compute_time_buckets('sales', days=14)
    
    # Get aggregate counts
    totals = aggregate_counts()
    
    # Calculate some additional metrics
    with get_session() as session:
        try:
            # Revenue calculations
            delivered_sales = session.query(LeadSale).filter(
                LeadSale.status.in_(['created', 'delivered'])
            ).all()
            
            total_revenue_cents = sum(sale.price_cents for sale in delivered_sales)
            total_revenue_dollars = total_revenue_cents / 100.0
            
            # Recent activity (last 7 days)
            seven_days_ago = datetime.now() - timedelta(days=7)
            recent_leads = session.query(Lead).filter(
                Lead.created_at >= seven_days_ago
            ).count()
            recent_sales = session.query(LeadSale).filter(
                LeadSale.created_at >= seven_days_ago
            ).count()
            
            totals.update({
                'total_revenue_dollars': total_revenue_dollars,
                'recent_leads_7d': recent_leads,
                'recent_sales_7d': recent_sales
            })
            
        except Exception as e:
            logger.error(f"Error computing additional metrics: {e}")
            totals.update({
                'total_revenue_dollars': 0.0,
                'recent_leads_7d': 0,
                'recent_sales_7d': 0
            })
    
    chart_data = {
        'totals': totals,
        'trends': {
            'leads': leads_trend,
            'sales': sales_trend
        },
        'max_values': {
            'leads': max((day['count'] for day in leads_trend), default=0),
            'sales': max((day['count'] for day in sales_trend), default=0)
        }
    }
    
    logger.info("Chart data compilation complete")
    return chart_data

def get_conversion_metrics() -> Dict[str, Any]:
    """
    Calculate conversion rates and funnel metrics.
    
    Returns:
        Dict with conversion rates and funnel data
    """
    logger.info("Computing conversion metrics")
    
    with get_session() as session:
        try:
            # Lead to sale conversion
            total_leads = session.query(Lead).count()
            total_sales = session.query(LeadSale).count()
            
            conversion_rate = (total_sales / max(total_leads, 1)) * 100
            
            # Sale status breakdown
            created_sales = session.query(LeadSale).filter(LeadSale.status == 'created').count()
            delivered_sales = session.query(LeadSale).filter(LeadSale.status == 'delivered').count()
            refunded_sales = session.query(LeadSale).filter(LeadSale.status == 'refunded').count()
            
            delivery_rate = (delivered_sales / max(total_sales, 1)) * 100
            refund_rate = (refunded_sales / max(total_sales, 1)) * 100
            
            metrics = {
                'conversion_rate': round(conversion_rate, 2),
                'delivery_rate': round(delivery_rate, 2),
                'refund_rate': round(refund_rate, 2),
                'funnel': {
                    'leads': total_leads,
                    'sales': total_sales,
                    'delivered': delivered_sales,
                    'refunded': refunded_sales
                }
            }
            
            logger.info(f"Conversion metrics: {metrics}")
            return metrics
            
        except Exception as e:
            logger.error(f"Error computing conversion metrics: {e}")
            return {
                'conversion_rate': 0.0,
                'delivery_rate': 0.0,
                'refund_rate': 0.0,
                'funnel': {'leads': 0, 'sales': 0, 'delivered': 0, 'refunded': 0}
            }

# Log service initialization
logger.info("Enhanced metrics service initialized with functions: compute_time_buckets, aggregate_counts, get_chart_data, get_conversion_metrics")
