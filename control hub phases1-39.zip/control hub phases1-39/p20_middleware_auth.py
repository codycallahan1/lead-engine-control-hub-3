"""
Authentication Middleware for Role-Based Access Control
Phase 20: Token validation and role resolution middleware
Key responsibilities: Extract tokens from headers, validate permissions, set request state
"""

import logging
from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, Union
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p20__server_models_api_tokens import ApiToken, TokenRole
except ImportError:
    logger.warning("Auth modules not found - using mock implementations")
    def get_session():
        return None
    
    class ApiToken:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
        
        def has_permission(self, role):
            return getattr(self, 'role', None) == 'admin'
    
    class TokenRole:
        ADMIN = 'admin'
        VIEWER = 'viewer'

class AuthenticationMiddleware(BaseHTTPMiddleware):
    """
    Middleware to extract and validate API tokens
    Sets request.state.role and request.state.token_info
    """
    
    async def dispatch(self, request: Request, call_next):
        # Extract token from headers
        token_info = await self.extract_token_info(request)
        
        # Set request state
        request.state.role = token_info.get('role')
        request.state.token_info = token_info
        request.state.is_authenticated = token_info.get('valid', False)
        
        # Continue processing
        response = await call_next(request)
        return response
    
    async def extract_token_info(self, request: Request) -> dict:
        """
        Extract and validate token from request headers
        
        Returns:
            Dictionary with token information
        """
        # Check for Admin-Token header (legacy support)
        admin_token = request.headers.get('Admin-Token')
        viewer_token = request.headers.get('Viewer-Token')
        
        # Legacy admin token check
        if admin_token == 'change-me':
            return {
                'valid': True,
                'role': TokenRole.ADMIN,
                'source': 'legacy',
                'token_id': None,
                'token_name': 'Legacy Admin Token'
            }
        
        # Check database tokens
        if admin_token:
            token_info = await self.validate_database_token(admin_token)
            if token_info['valid']:
                return token_info
        
        if viewer_token:
            token_info = await self.validate_database_token(viewer_token)
            if token_info['valid']:
                return token_info
        
        # No valid token found
        return {
            'valid': False,
            'role': None,
            'source': None,
            'token_id': None,
            'token_name': None
        }
    
    async def validate_database_token(self, token: str) -> dict:
        """
        Validate token against database
        
        Args:
            token: Token string to validate
        
        Returns:
            Dictionary with validation results
        """
        try:
            session = get_session()
            if not session:
                logger.warning("No database session - token validation skipped")
                return {'valid': False, 'role': None, 'source': 'no_db'}
            
            with session:
                api_token = session.query(ApiToken).filter(
                    ApiToken.token == token,
                    ApiToken.active == True
                ).first()
                
                if api_token:
                    logger.debug(f"Valid token found: {api_token.name} ({api_token.role})")
                    return {
                        'valid': True,
                        'role': api_token.role,
                        'source': 'database',
                        'token_id': api_token.id,
                        'token_name': api_token.name
                    }
                else:
                    logger.debug("Invalid or inactive token")
                    return {'valid': False, 'role': None, 'source': 'invalid'}
        
        except Exception as e:
            logger.error(f"Error validating token: {e}")
            return {'valid': False, 'role': None, 'source': 'error'}

# Dependency functions for route protection
def get_current_user_info(request: Request) -> dict:
    """Get current user information from request state"""
    return getattr(request.state, 'token_info', {})

def require_authentication(request: Request) -> dict:
    """Require any valid authentication"""
    if not getattr(request.state, 'is_authenticated', False):
        raise HTTPException(status_code=401, detail="Authentication required")
    return get_current_user_info(request)

def require_admin(request: Request) -> dict:
    """Require admin role"""
    token_info = require_authentication(request)
    
    if token_info.get('role') != TokenRole.ADMIN:
        raise HTTPException(status_code=403, detail="Admin privileges required")
    
    return token_info

def require_viewer(request: Request) -> dict:
    """Require viewer role or higher"""
    token_info = require_authentication(request)
    
    if token_info.get('role') not in [TokenRole.ADMIN, TokenRole.VIEWER]:
        raise HTTPException(status_code=403, detail="Viewer privileges or higher required")
    
    return token_info

# Alternative dependency using headers directly (for backward compatibility)
async def get_admin_token(admin_token: Optional[str] = None) -> str:
    """Legacy admin token dependency"""
    if not admin_token or admin_token != 'change-me':
        raise HTTPException(status_code=403, detail="Admin token required")
    return admin_token

async def get_viewer_token(viewer_token: Optional[str] = None) -> str:
    """Viewer token dependency"""
    if not viewer_token:
        raise HTTPException(status_code=403, detail="Viewer token required")
    
    # Validate token against database
    try:
        session = get_session()
        if session:
            with session:
                api_token = session.query(ApiToken).filter(
                    ApiToken.token == viewer_token,
                    ApiToken.active == True
                ).first()
                
                if not api_token or not api_token.is_viewer():
                    raise HTTPException(status_code=403, detail="Invalid or insufficient token")
        
        return viewer_token
    except Exception as e:
        logger.error(f"Error validating viewer token: {e}")
        raise HTTPException(status_code=500, detail="Token validation error")

# Utility functions for manual token operations
async def create_token_in_db(name: str, role: str, session=None) -> ApiToken:
    """
    Create a new API token in the database
    
    Args:
        name: Human-readable token name
        role: Token role ('admin' or 'viewer')
        session: Database session (optional)
    
    Returns:
        Created ApiToken instance
    """
    if not session:
        session = get_session()
    
    if not session:
        raise RuntimeError("No database session available")
    
    # Validate inputs
    from p20__server_models_api_tokens import validate_token_data
    is_valid, error_msg = validate_token_data(name, role)
    if not is_valid:
        raise ValueError(error_msg)
    
    # Create token
    with session:
        api_token = ApiToken.create_token(name, role)
        session.add(api_token)
        session.commit()
        session.refresh(api_token)
        
        logger.info(f"Created API token: {name} ({role})")
        return api_token

async def revoke_token_in_db(token_id: int, session=None) -> bool:
    """
    Revoke (deactivate) an API token
    
    Args:
        token_id: ID of token to revoke
        session: Database session (optional)
    
    Returns:
        True if token was revoked, False if not found
    """
    if not session:
        session = get_session()
    
    if not session:
        raise RuntimeError("No database session available")
    
    with session:
        api_token = session.query(ApiToken).filter(ApiToken.id == token_id).first()
        
        if api_token:
            api_token.active = False
            session.commit()
            logger.info(f"Revoked API token: {api_token.name}")
            return True
        else:
            logger.warning(f"Token ID {token_id} not found for revocation")
            return False

# Helper to add middleware to FastAPI app
def add_auth_middleware(app):
    """Add authentication middleware to FastAPI app"""
    app.add_middleware(AuthenticationMiddleware)
    logger.info("Authentication middleware added")
