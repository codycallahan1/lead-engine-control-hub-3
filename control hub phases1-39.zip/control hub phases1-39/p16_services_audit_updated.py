"""
Enhanced audit service with email-specific logging.

Phase: 16
Purpose: Audit logging service with email notification tracking
Key responsibilities: audit function and email-specific audit_email helper
"""

import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

def audit(kind: str, message: str, meta: Optional[Dict[str, Any]] = None) -> None:
    """
    Log structured audit information.
    
    Creates a standardized audit log entry with consistent formatting
    for compliance and monitoring purposes.
    
    Args:
        kind: Type of audit event (e.g., "leads_exported", "email_sent")
        message: Human-readable audit message
        meta: Optional metadata dict with additional context
    """
    timestamp = datetime.utcnow().isoformat() + 'Z'
    
    audit_entry = {
        'timestamp': timestamp,
        'kind': kind,
        'message': message,
        'meta': meta or {}
    }
    
    # Log as structured JSON for easy parsing
    audit_line = f"AUDIT: {json.dumps(audit_entry, separators=(',', ':'))}"
    logger.info(audit_line)

def audit_email(
    kind: str, 
    to: str, 
    subject: str, 
    success: bool, 
    attempts: int, 
    error: Optional[str] = None
) -> None:
    """
    Log email-specific audit information.
    
    Specialized audit function for email delivery events with
    standardized email metadata tracking.
    
    Args:
        kind: Email event type (e.g., "email_new_lead", "email_sale_delivered")
        to: Recipient email address
        subject: Email subject line
        success: Whether the email was successfully delivered
        attempts: Number of delivery attempts made
        error: Error message if delivery failed
    """
    # Sanitize email for logging (mask part of address for privacy)
    masked_email = _mask_email(to)
    
    # Build audit message
    status = "delivered" if success else "failed"
    message = f"Email {status} to {masked_email}: '{subject[:50]}{'...' if len(subject) > 50 else ''}'"
    
    if not success and error:
        message += f" - {error}"
    
    # Build metadata
    meta = {
        'email_recipient': masked_email,
        'email_subject_length': len(subject),
        'delivery_success': success,
        'delivery_attempts': attempts,
        'event_category': 'email_notification'
    }
    
    if error:
        meta['error_message'] = error
    
    # Log the audit entry
    audit(kind=kind, message=message, meta=meta)
    
    # Also log email delivery metrics
    _log_email_metrics(success, attempts, error)

def audit_export(format_type: str, count: int, user_id: Optional[str] = None) -> None:
    """
    Log data export audit information.
    
    Args:
        format_type: Export format (csv, json, xlsx, etc.)
        count: Number of records exported
        user_id: Optional user identifier
    """
    message = f"Data exported: {count} records in {format_type.upper()} format"
    
    meta = {
        'export_format': format_type,
        'record_count': count,
        'event_category': 'data_export'
    }
    
    if user_id:
        meta['user_id'] = user_id
    
    audit(kind=f"export_{format_type}", message=message, meta=meta)

def audit_sale_event(event_type: str, sale_id: int, details: Dict[str, Any]) -> None:
    """
    Log sale-related audit information.
    
    Args:
        event_type: Type of sale event (created, delivered, refunded)
        sale_id: Sale identifier
        details: Additional sale details
    """
    message = f"Sale {event_type}: Sale #{sale_id}"
    
    if event_type == "delivered":
        price = details.get('price_cents', 0) / 100.0
        message += f" (${price:.2f})"
    
    meta = {
        'sale_id': sale_id,
        'sale_event': event_type,
        'event_category': 'sales',
        **details
    }
    
    audit(kind=f"sale_{event_type}", message=message, meta=meta)

def audit_webhook_delivery(webhook_id: int, url: str, event: str, success: bool, response_code: Optional[int] = None) -> None:
    """
    Log webhook delivery audit information.
    
    Args:
        webhook_id: Webhook configuration ID
        url: Webhook URL (will be masked for privacy)
        event: Event type that triggered the webhook
        success: Whether delivery was successful
        response_code: HTTP response code from webhook endpoint
    """
    masked_url = _mask_url(url)
    status = "delivered" if success else "failed"
    message = f"Webhook {status}: {event} event to {masked_url}"
    
    if response_code:
        message += f" (HTTP {response_code})"
    
    meta = {
        'webhook_id': webhook_id,
        'webhook_url_masked': masked_url,
        'webhook_event': event,
        'delivery_success': success,
        'event_category': 'webhook_delivery'
    }
    
    if response_code:
        meta['http_response_code'] = response_code
    
    audit(kind=f"webhook_{event}", message=message, meta=meta)

def audit_system_event(event_type: str, component: str, details: str) -> None:
    """
    Log system-level audit information.
    
    Args:
        event_type: Type of system event (startup, shutdown, error, etc.)
        component: System component involved
        details: Event details
    """
    message = f"System {event_type}: {component} - {details}"
    
    meta = {
        'system_component': component,
        'system_event': event_type,
        'event_category': 'system'
    }
    
    audit(kind=f"system_{event_type}", message=message, meta=meta)

def _mask_email(email: str) -> str:
    """
    Mask email address for privacy in logs.
    
    Args:
        email: Email address to mask
        
    Returns:
        Masked email address
    """
    if '@' not in email:
        return email
    
    local, domain = email.split('@', 1)
    
    if len(local) <= 2:
        masked_local = '*' * len(local)
    else:
        masked_local = local[0] + '*' * (len(local) - 2) + local[-1]
    
    return f"{masked_local}@{domain}"

def _mask_url(url: str) -> str:
    """
    Mask URL for privacy in logs.
    
    Args:
        url: URL to mask
        
    Returns:
        Masked URL showing only scheme and domain
    """
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}/***"
    except:
        # Fallback masking
        if '://' in url:
            scheme_and_domain = url.split('/', 3)[:3]
            return '/'.join(scheme_and_domain) + '/***'
        return url

def _log_email_metrics(success: bool, attempts: int, error: Optional[str]) -> None:
    """
    Log email delivery metrics for monitoring.
    
    Args:
        success: Whether email was delivered successfully
        attempts: Number of attempts made
        error: Error message if failed
    """
    # In a real implementation, this might send metrics to a monitoring system
    # For now, just log structured metrics
    metrics = {
        'email_delivery_success': success,
        'email_delivery_attempts': attempts,
        'timestamp': datetime.utcnow().isoformat()
    }
    
    if error:
        metrics['email_delivery_error'] = error
    
    logger.info(f"EMAIL_METRICS: {json.dumps(metrics, separators=(',', ':'))}")

# Log service initialization
logger.info("Enhanced audit service initialized with functions: audit, audit_email, audit_export, audit_sale_event, audit_webhook_delivery, audit_system_event")
