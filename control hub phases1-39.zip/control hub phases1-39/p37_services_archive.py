"""
Lead Engine Control Hub - Archive Service
Phase 37: Data retention, archiving & soft delete
Purpose: Archive expired data and manage retention sweeps
"""

import json
import logging
import os
import gzip
import hashlib
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import and_, text

# Import models and database utilities
try:
    from p37__server_models_retention import RetentionPolicy, RetentionSweepLog, ArchiveManifest
    from p02__server_db import get_session
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    class RetentionPolicy:
        pass
    class RetentionSweepLog:
        pass
    class ArchiveManifest:
        pass
    def get_session():
        pass
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")

logger = logging.getLogger(__name__)


class ArchiveError(Exception):
    """Base exception for archive operations."""
    pass


class RetentionSweepError(Exception):
    """Exception for retention sweep operations."""
    pass


def get_archive_base_path(org_id: int) -> str:
    """
    Get base archive path for an organization.
    
    Args:
        org_id: Organization identifier
    
    Returns:
        Base path for archive files
    """
    # Create archives directory structure
    base_path = os.path.join(".", "server", "archives", f"org_{org_id}")
    os.makedirs(base_path, exist_ok=True)
    return base_path


def find_expired_records(data_type: str, before_date: datetime, org_id: int) -> List[int]:
    """
    Find records that are expired and ready for archiving.
    
    Args:
        data_type: Type of data (leads, buyers, logs, audit)
        before_date: Records created before this date are expired
        org_id: Organization identifier
    
    Returns:
        List of record IDs to archive
    """
    with get_session() as session:
        # This would query the appropriate table based on data_type
        # For now, return mock data structure
        
        # Example queries that would be implemented:
        # if data_type == "leads":
        #     query = session.query(Lead.id).filter(
        #         and_(
        #             Lead.org_id == org_id,
        #             Lead.created_at < before_date,
        #             Lead.deleted_at.is_(None)  # Only active records
        #         )
        #     )
        
        # Simulate finding some expired records
        expired_ids = []
        
        logger.info(f"Found {len(expired_ids)} expired {data_type} records for org {org_id}")
        return expired_ids


def export_records_to_jsonl(data_type: str, record_ids: List[int], 
                           org_id: int) -> Tuple[List[Dict], int, datetime, datetime]:
    """
    Export records to JSONL format for archiving.
    
    Args:
        data_type: Type of data to export
        record_ids: List of record IDs to export
        org_id: Organization identifier
    
    Returns:
        Tuple of (records_list, count, earliest_date, latest_date)
    """
    if not record_ids:
        return [], 0, None, None
    
    with get_session() as session:
        records = []
        earliest_date = None
        latest_date = None
        
        # This would query and serialize the actual records
        # For now, return mock data structure
        
        # Example implementation:
        # if data_type == "leads":
        #     query_results = session.query(Lead).filter(
        #         and_(Lead.id.in_(record_ids), Lead.org_id == org_id)
        #     ).all()
        #     
        #     for lead in query_results:
        #         record = {
        #             "id": lead.id,
        #             "name": lead.name,
        #             "email": lead.email,
        #             "phone": lead.phone,
        #             "created_at": lead.created_at.isoformat(),
        #             "archived_at": datetime.utcnow().isoformat()
        #         }
        #         records.append(record)
        
        logger.info(f"Exported {len(records)} {data_type} records for archiving")
        
        return records, len(records), earliest_date, latest_date


def create_archive_file(records: List[Dict], data_type: str, org_id: int, 
                       date_suffix: str = None) -> Tuple[str, int, str]:
    """
    Create an archive file from records.
    
    Args:
        records: List of record dictionaries
        data_type: Type of data being archived
        org_id: Organization identifier
        date_suffix: Optional date suffix for filename
    
    Returns:
        Tuple of (file_path, file_size_bytes, file_hash)
    """
    if not records:
        raise ArchiveError("No records to archive")
    
    # Generate filename
    if not date_suffix:
        date_suffix = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    
    filename = f"{data_type}_{date_suffix}.jsonl.gz"
    
    # Get archive directory
    archive_dir = get_archive_base_path(org_id)
    date_dir = os.path.join(archive_dir, datetime.utcnow().strftime("%Y-%m-%d"))
    os.makedirs(date_dir, exist_ok=True)
    
    file_path = os.path.join(date_dir, filename)
    
    # Write compressed JSONL file
    hash_sha256 = hashlib.sha256()
    
    try:
        with gzip.open(file_path, 'wt', encoding='utf-8') as f:
            for record in records:
                json_line = json.dumps(record, separators=(',', ':'))
                f.write(json_line + '\n')
                hash_sha256.update((json_line + '\n').encode('utf-8'))
        
        # Get file size
        file_size = os.path.getsize(file_path)
        file_hash = hash_sha256.hexdigest()
        
        logger.info(f"Created archive file: {filename} ({file_size} bytes, {len(records)} records)")
        
        return file_path, file_size, file_hash
        
    except Exception as e:
        # Clean up partial file on error
        if os.path.exists(file_path):
            os.remove(file_path)
        raise ArchiveError(f"Failed to create archive file: {str(e)}")


def soft_delete_records(data_type: str, record_ids: List[int], org_id: int, 
                       deleted_by: str = "retention_sweep") -> int:
    """
    Soft delete records after successful archiving.
    
    Args:
        data_type: Type of data to soft delete
        record_ids: List of record IDs to soft delete
        org_id: Organization identifier
        deleted_by: Who initiated the deletion
    
    Returns:
        Number of records soft deleted
    """
    if not record_ids:
        return 0
    
    with get_session() as session:
        deleted_count = 0
        
        # This would update the appropriate table based on data_type
        # Example implementation:
        # if data_type == "leads":
        #     result = session.query(Lead).filter(
        #         and_(Lead.id.in_(record_ids), Lead.org_id == org_id)
        #     ).update({
        #         'deleted_at': datetime.utcnow(),
        #         'deleted_by': deleted_by,
        #         'deletion_reason': 'retention_policy'
        #     }, synchronize_session=False)
        #     deleted_count = result
        
        session.commit()
        
        logger.info(f"Soft deleted {deleted_count} {data_type} records")
        return deleted_count


def archive_data_type(data_type: str, before_date: datetime, org_id: int,
                     sweep_log: RetentionSweepLog) -> Tuple[int, List[str]]:
    """
    Archive all expired records of a specific data type.
    
    Args:
        data_type: Type of data to archive
        before_date: Archive records before this date
        org_id: Organization identifier
        sweep_log: Sweep log to update with results
    
    Returns:
        Tuple of (records_processed, archive_file_paths)
    """
    try:
        # Find expired records
        expired_ids = find_expired_records(data_type, before_date, org_id)
        
        if not expired_ids:
            logger.info(f"No expired {data_type} records found for org {org_id}")
            return 0, []
        
        # Export records
        records, count, earliest_date, latest_date = export_records_to_jsonl(
            data_type, expired_ids, org_id
        )
        
        if not records:
            logger.warning(f"No records exported for {data_type} despite finding {len(expired_ids)} expired IDs")
            return 0, []
        
        # Create archive file
        file_path, file_size, file_hash = create_archive_file(
            records, data_type, org_id
        )
        
        # Create archive manifest
        with get_session() as session:
            manifest = ArchiveManifest(
                org_id=org_id,
                sweep_log_id=sweep_log.id,
                file_path=file_path,
                file_name=os.path.basename(file_path),
                file_size_bytes=file_size,
                file_hash=file_hash,
                data_type=data_type,
                record_count=count,
                date_range_start=earliest_date,
                date_range_end=latest_date,
                compression_type="gzip",
                format_type="jsonl",
                verification_status="pending"
            )
            
            session.add(manifest)
            session.commit()
            session.refresh(manifest)
        
        # Soft delete original records
        deleted_count = soft_delete_records(data_type, expired_ids, org_id)
        
        logger.info(f"Archived {count} {data_type} records to {file_path}")
        
        return count, [file_path]
        
    except Exception as e:
        logger.error(f"Error archiving {data_type}: {str(e)}")
        raise ArchiveError(f"Failed to archive {data_type}: {str(e)}")


def run_retention_sweep(org_id: int, sweep_type: str = "scheduled", 
                       initiated_by: str = "system") -> RetentionSweepLog:
    """
    Run a complete retention sweep for an organization.
    
    Args:
        org_id: Organization identifier
        sweep_type: Type of sweep (scheduled, manual, test)
        initiated_by: Who initiated the sweep
    
    Returns:
        RetentionSweepLog with results
    """
    with get_session() as session:
        # Get retention policy
        policy = session.query(RetentionPolicy).filter_by(org_id=org_id).first()
        
        if not policy:
            raise RetentionSweepError(f"No retention policy found for org {org_id}")
        
        # Create sweep log
        sweep_log = RetentionSweepLog(
            org_id=org_id,
            policy_id=policy.id,
            sweep_type=sweep_type,
            target_before_date=datetime.utcnow() - timedelta(days=30),  # Example calculation
            status="running",
            initiated_by=initiated_by
        )
        
        session.add(sweep_log)
        session.commit()
        session.refresh(sweep_log)
    
    try:
        start_time = datetime.utcnow()
        all_archive_paths = []
        
        # Archive different data types based on policy
        data_types_to_archive = []
        
        if policy.leads_days:
            before_date = datetime.utcnow() - timedelta(days=policy.leads_days)
            leads_count, leads_paths = archive_data_type("leads", before_date, org_id, sweep_log)
            sweep_log.leads_processed = leads_count
            all_archive_paths.extend(leads_paths)
            
        if policy.buyers_days:
            before_date = datetime.utcnow() - timedelta(days=policy.buyers_days)
            buyers_count, buyers_paths = archive_data_type("buyers", before_date, org_id, sweep_log)
            sweep_log.buyers_processed = buyers_count
            all_archive_paths.extend(buyers_paths)
            
        if policy.logs_days:
            before_date = datetime.utcnow() - timedelta(days=policy.logs_days)
            logs_count, logs_paths = archive_data_type("logs", before_date, org_id, sweep_log)
            sweep_log.logs_processed = logs_count
            all_archive_paths.extend(logs_paths)
            
        if policy.audit_days:
            before_date = datetime.utcnow() - timedelta(days=policy.audit_days)
            audit_count, audit_paths = archive_data_type("audit", before_date, org_id, sweep_log)
            sweep_log.audit_records_processed = audit_count
            all_archive_paths.extend(audit_paths)
        
        # Update sweep log with results
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        total_size = sum(
            os.path.getsize(path) for path in all_archive_paths if os.path.exists(path)
        )
        
        with get_session() as session:
            sweep_log = session.merge(sweep_log)
            sweep_log.status = "completed"
            sweep_log.completed_at = end_time
            sweep_log.duration_seconds = int(duration)
            sweep_log.archive_files_created = len(all_archive_paths)
            sweep_log.archive_size_bytes = total_size
            sweep_log.archive_paths = json.dumps(all_archive_paths)
            
            # Update policy last sweep time
            policy.last_sweep_at = end_time
            policy.next_sweep_at = end_time + timedelta(days=1)  # Schedule next sweep
            
            session.commit()
            session.refresh(sweep_log)
        
        # Audit the sweep
        audit(
            kind="retention_sweep_completed",
            message=f"Retention sweep completed for org {org_id}",
            meta={
                "org_id": org_id,
                "sweep_type": sweep_type,
                "total_records": sweep_log.total_records_processed,
                "archive_files": len(all_archive_paths),
                "archive_size_mb": round(total_size / (1024 * 1024), 2),
                "duration_seconds": duration,
                "initiated_by": initiated_by
            }
        )
        
        logger.info(f"Retention sweep completed for org {org_id}: {sweep_log.total_records_processed} records processed")
        
        return sweep_log
        
    except Exception as e:
        # Mark sweep as failed
        with get_session() as session:
            sweep_log = session.merge(sweep_log)
            sweep_log.status = "failed"
            sweep_log.error_message = str(e)
            sweep_log.completed_at = datetime.utcnow()
            session.commit()
        
        logger.error(f"Retention sweep failed for org {org_id}: {str(e)}")
        raise RetentionSweepError(f"Retention sweep failed: {str(e)}")


def verify_archive_integrity(manifest_id: int) -> bool:
    """
    Verify the integrity of an archived file.
    
    Args:
        manifest_id: Archive manifest ID to verify
    
    Returns:
        True if verification successful
    """
    with get_session() as session:
        manifest = session.query(ArchiveManifest).filter_by(id=manifest_id).first()
        
        if not manifest:
            raise ArchiveError(f"Archive manifest {manifest_id} not found")
        
        file_path = manifest.file_path
        
        if not os.path.exists(file_path):
            manifest.verification_status = "failed"
            manifest.verified_at = datetime.utcnow()
            session.commit()
            return False
        
        try:
            # Verify file hash
            hash_sha256 = hashlib.sha256()
            record_count = 0
            
            with gzip.open(file_path, 'rt', encoding='utf-8') as f:
                for line in f:
                    hash_sha256.update((line).encode('utf-8'))
                    record_count += 1
            
            calculated_hash = hash_sha256.hexdigest()
            
            # Check hash matches
            if calculated_hash != manifest.file_hash:
                logger.error(f"Hash mismatch for archive {manifest_id}: expected {manifest.file_hash}, got {calculated_hash}")
                manifest.verification_status = "failed"
                manifest.verified_at = datetime.utcnow()
                session.commit()
                return False
            
            # Check record count matches
            if record_count != manifest.record_count:
                logger.error(f"Record count mismatch for archive {manifest_id}: expected {manifest.record_count}, got {record_count}")
                manifest.verification_status = "failed"
                manifest.verified_at = datetime.utcnow()
                session.commit()
                return False
            
            # Verification successful
            manifest.verification_status = "verified"
            manifest.verified_at = datetime.utcnow()
            session.commit()
            
            logger.info(f"Archive verification successful for manifest {manifest_id}")
            return True
            
        except Exception as e:
            logger.error(f"Archive verification failed for manifest {manifest_id}: {str(e)}")
            manifest.verification_status = "failed"
            manifest.verified_at = datetime.utcnow()
            session.commit()
            return False


def list_archive_files(org_id: int, data_type: str = None, days: int = 30) -> List[Dict]:
    """
    List archive files for an organization.
    
    Args:
        org_id: Organization identifier
        data_type: Filter by data type (optional)
        days: Number of days to look back
    
    Returns:
        List of archive file information
    """
    with get_session() as session:
        query = session.query(ArchiveManifest).filter_by(org_id=org_id)
        
        if data_type:
            query = query.filter_by(data_type=data_type)
        
        # Filter by date range
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        query = query.filter(ArchiveManifest.created_at >= cutoff_date)
        
        manifests = query.order_by(ArchiveManifest.created_at.desc()).all()
        
        return [manifest.to_dict() for manifest in manifests]


def cleanup_old_archives(org_id: int, keep_days: int = 90) -> Dict[str, int]:
    """
    Clean up old archive files to free disk space.
    
    Args:
        org_id: Organization identifier
        keep_days: Keep archives newer than this many days
    
    Returns:
        Dictionary with cleanup statistics
    """
    cutoff_date = datetime.utcnow() - timedelta(days=keep_days)
    
    with get_session() as session:
        old_manifests = session.query(ArchiveManifest).filter(
            and_(
                ArchiveManifest.org_id == org_id,
                ArchiveManifest.created_at < cutoff_date
            )
        ).all()
        
        files_deleted = 0
        bytes_freed = 0
        manifests_removed = 0
        
        for manifest in old_manifests:
            # Delete physical file if it exists
            if os.path.exists(manifest.file_path):
                try:
                    file_size = os.path.getsize(manifest.file_path)
                    os.remove(manifest.file_path)
                    files_deleted += 1
                    bytes_freed += file_size
                    logger.info(f"Deleted old archive file: {manifest.file_name}")
                except OSError as e:
                    logger.error(f"Failed to delete archive file {manifest.file_path}: {str(e)}")
            
            # Remove manifest record
            session.delete(manifest)
            manifests_removed += 1
        
        session.commit()
        
        cleanup_stats = {
            "files_deleted": files_deleted,
            "bytes_freed": bytes_freed,
            "mb_freed": round(bytes_freed / (1024 * 1024), 2),
            "manifests_removed": manifests_removed,
            "cutoff_date": cutoff_date.isoformat()
        }
        
        logger.info(f"Archive cleanup for org {org_id}: {cleanup_stats}")
        
        audit(
            kind="archive_cleanup",
            message=f"Cleaned up old archives for org {org_id}",
            meta={
                "org_id": org_id,
                "cleanup_stats": cleanup_stats
            }
        )
        
        return cleanup_stats


def get_retention_policy(org_id: int) -> Optional[RetentionPolicy]:
    """
    Get retention policy for an organization.
    
    Args:
        org_id: Organization identifier
    
    Returns:
        RetentionPolicy or None if not found
    """
    with get_session() as session:
        return session.query(RetentionPolicy).filter_by(org_id=org_id).first()


def create_default_retention_policy(org_id: int, created_by: str = "system") -> RetentionPolicy:
    """
    Create default retention policy for an organization.
    
    Args:
        org_id: Organization identifier
        created_by: Who created the policy
    
    Returns:
        Created RetentionPolicy
    """
    with get_session() as session:
        policy = RetentionPolicy(
            org_id=org_id,
            leads_days=365,  # 1 year
            buyers_days=1095,  # 3 years
            logs_days=90,  # 90 days
            audit_days=2555,  # 7 years for compliance
            archive_enabled=True,
            hard_delete_after_days=None,  # Never hard delete
            require_manual_approval=False,
            updated_by=created_by
        )
        
        session.add(policy)
        session.commit()
        session.refresh(policy)
        
        logger.info(f"Created default retention policy for org {org_id}")
        
        audit(
            kind="retention_policy_created",
            message=f"Default retention policy created for org {org_id}",
            meta={
                "org_id": org_id,
                "policy": policy.to_dict(),
                "created_by": created_by
            }
        )
        
        return policy


def schedule_next_sweep(org_id: int) -> datetime:
    """
    Schedule the next retention sweep for an organization.
    
    Args:
        org_id: Organization identifier
    
    Returns:
        Next sweep datetime
    """
    with get_session() as session:
        policy = session.query(RetentionPolicy).filter_by(org_id=org_id).first()
        
        if not policy:
            # Create default policy if none exists
            policy = create_default_retention_policy(org_id)
        
        # Schedule next sweep for tomorrow at 2 AM
        next_sweep = datetime.utcnow().replace(hour=2, minute=0, second=0, microsecond=0)
        next_sweep += timedelta(days=1)
        
        policy.next_sweep_at = next_sweep
        session.commit()
        
        logger.info(f"Next retention sweep for org {org_id} scheduled for {next_sweep}")
        
        return next_sweep


def enqueue_retention_sweep(org_id: int, sweep_type: str = "scheduled"):
    """
    Enqueue a retention sweep job.
    
    This would integrate with the existing queue system from earlier phases.
    
    Args:
        org_id: Organization identifier
        sweep_type: Type of sweep to run
    """
    try:
        # This would use the queue system from Phase 7
        # from p07__server_services_queue import enqueue
        # 
        # job_id = enqueue("retention_sweep", {
        #     "org_id": org_id,
        #     "sweep_type": sweep_type
        # })
        
        logger.info(f"Enqueued retention sweep job for org {org_id}")
        
        # For now, just log that the job would be enqueued
        audit(
            kind="retention_sweep_queued",
            message=f"Retention sweep queued for org {org_id}",
            meta={
                "org_id": org_id,
                "sweep_type": sweep_type
            }
        )
        
    except Exception as e:
        logger.error(f"Failed to enqueue retention sweep for org {org_id}: {str(e)}")
        raise RetentionSweepError(f"Failed to queue sweep: {str(e)}")


# Queue worker integration (would be added to existing queue system)
def retention_sweep_worker(payload: Dict[str, Any]):
    """
    Worker function to process retention sweep jobs.
    
    This would be registered with the queue system.
    
    Args:
        payload: Job payload with org_id and sweep_type
    """
    org_id = payload.get("org_id")
    sweep_type = payload.get("sweep_type", "scheduled")
    
    if not org_id:
        raise ValueError("org_id required in retention sweep payload")
    
    try:
        sweep_log = run_retention_sweep(org_id, sweep_type, "queue_worker")
        logger.info(f"Retention sweep worker completed for org {org_id}: {sweep_log.total_records_processed} records")
        
    except Exception as e:
        logger.error(f"Retention sweep worker failed for org {org_id}: {str(e)}")
        raise


# Integration helper for queue system
def register_retention_sweep_worker():
    """
    Register retention sweep worker with the queue system.
    
    This would be called during application startup.
    """
    try:
        # This would integrate with existing queue system
        # from p07__server_services_queue import register
        # register("retention_sweep", retention_sweep_worker)
        
        logger.info("Retention sweep worker registered with queue system")
        
    except Exception as e:
        logger.error(f"Failed to register retention sweep worker: {str(e)}")
