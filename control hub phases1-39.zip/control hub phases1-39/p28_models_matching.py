"""
Lead-to-Buyer matching models for configurable routing rules.

Phase: 28
Purpose: Define models for matching rules and execution logs.
Key responsibilities:
- MatchingRule model with conditions and scoring
- MatchLog for tracking match decisions
- Support org-scoped rule evaluation
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, DateTime, ForeignKey, Float
from sqlalchemy.sql import func
import json
import logging

# Note: In final package structure, this would merge with main models.py
try:
    from p02__server_db import Base
except ImportError:
    logging.info("Matching models: p02__server_db not found, using standalone Base")
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()

logger = logging.getLogger(__name__)


class MatchingRule(Base):
    """Rules for automatically matching leads to buyers."""
    
    __tablename__ = "matching_rules"
    
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, nullable=False, default=1)  # Organization scoping
    name = Column(String(255), nullable=False)  # Human-readable rule name
    priority = Column(Integer, nullable=False, default=10)  # Lower = higher priority
    weight = Column(Float, nullable=False, default=1.0)  # Score multiplier
    conditions_json = Column(Text, nullable=False)  # JSON conditions dict
    buyer_id = Column(Integer, nullable=False)  # Target buyer
    active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    def __repr__(self):
        status = "✓" if self.active else "✗"
        return f"<MatchingRule {self.id}: {self.name} -> Buyer {self.buyer_id} [{status}]>"
    
    @property
    def conditions(self):
        """Parse conditions_json into dict."""
        if not self.conditions_json:
            return {}
        try:
            return json.loads(self.conditions_json)
        except (json.JSONDecodeError, TypeError):
            logger.warning(f"Invalid conditions JSON in rule {self.id}")
            return {}
    
    @conditions.setter
    def conditions(self, conditions_dict):
        """Set conditions from dict."""
        self.conditions_json = json.dumps(conditions_dict) if conditions_dict else "{}"
    
    def evaluate_lead(self, lead):
        """
        Evaluate if this rule matches a lead and return score.
        
        Args:
            lead: Lead object with name, email, phone attributes
        
        Returns:
            float: Match score (0.0 = no match, > 0.0 = match strength)
        """
        if not self.active:
            return 0.0
        
        conditions = self.conditions
        if not conditions:
            return 0.0
        
        score = 0.0
        
        # Email domain matching
        if "email_domain" in conditions and lead.email:
            email_domain = lead.email.split("@")[-1].lower()
            if email_domain in [d.lower() for d in conditions["email_domain"]]:
                score += 1.0
        
        # Phone prefix matching
        if "phone_prefix" in conditions and lead.phone:
            phone_clean = ''.join(filter(str.isdigit, lead.phone))
            for prefix in conditions["phone_prefix"]:
                if phone_clean.startswith(prefix):
                    score += 1.0
                    break
        
        # Name contains matching (case insensitive)
        if "name_contains" in conditions and lead.name:
            name_lower = lead.name.lower()
            for term in conditions["name_contains"]:
                if term.lower() in name_lower:
                    score += 1.0
        
        # Apply weight multiplier
        return score * self.weight
    
    def get_summary(self):
        """Get human-readable summary of rule conditions."""
        conditions = self.conditions
        if not conditions:
            return "No conditions"
        
        parts = []
        
        if "email_domain" in conditions:
            domains = ", ".join(conditions["email_domain"])
            parts.append(f"Email domain: {domains}")
        
        if "phone_prefix" in conditions:
            prefixes = ", ".join(conditions["phone_prefix"])
            parts.append(f"Phone prefix: {prefixes}")
        
        if "name_contains" in conditions:
            terms = ", ".join(conditions["name_contains"])
            parts.append(f"Name contains: {terms}")
        
        return " | ".join(parts) if parts else "No conditions"


class MatchLog(Base):
    """Log of lead-to-buyer matching decisions."""
    
    __tablename__ = "match_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, nullable=False, default=1)
    lead_id = Column(Integer, nullable=False)
    buyer_id = Column(Integer, nullable=True)  # Null if no match
    rule_id = Column(Integer, nullable=True)  # Null if no rule matched
    score = Column(Float, nullable=False, default=0.0)
    status = Column(String(50), nullable=False, default="pending")  # pending, matched, failed
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    metadata_json = Column(Text, nullable=True)  # Additional match details
    
    def __repr__(self):
        match_info = f"Buyer {self.buyer_id}" if self.buyer_id else "No match"
        return f"<MatchLog {self.id}: Lead {self.lead_id} -> {match_info} (score: {self.score})>"
    
    @property
    def metadata(self):
        """Parse metadata_json into dict."""
        if not self.metadata_json:
            return {}
        try:
            return json.loads(self.metadata_json)
        except (json.JSONDecodeError, TypeError):
            return {}
    
    @metadata.setter
    def metadata(self, metadata_dict):
        """Set metadata from dict."""
        self.metadata_json = json.dumps(metadata_dict) if metadata_dict else None
    
    def get_status_display(self):
        """Get human-readable status."""
        status_map = {
            "pending": "Pending",
            "matched": "Successfully Matched",
            "failed": "Match Failed",
            "no_match": "No Matching Rules"
        }
        return status_map.get(self.status, self.status.title())


def create_matching_tables():
    """Create matching tables if they don't exist."""
    try:
        from p02__server_db import engine
        Base.metadata.create_all(bind=engine, tables=[
            MatchingRule.__table__,
            MatchLog.__table__
        ])
        logger.info("Matching tables created/verified")
    except ImportError:
        logger.warning("Cannot create matching tables: database engine not available")


# Example rule conditions for documentation
EXAMPLE_CONDITIONS = {
    "gmail_users": {
        "email_domain": ["gmail.com", "googlemail.com"]
    },
    "us_phone_numbers": {
        "phone_prefix": ["1"]
    },
    "enterprise_leads": {
        "email_domain": ["company.com", "enterprise.net"],
        "name_contains": ["CEO", "VP", "Director"]
    },
    "combined_rule": {
        "email_domain": ["target.com"],
        "phone_prefix": ["1", "44"],
        "name_contains": ["manager"]
    }
}
