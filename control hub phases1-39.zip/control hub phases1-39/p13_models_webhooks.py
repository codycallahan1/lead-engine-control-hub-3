"""
Webhook models for outbound webhook delivery system.

Phase: 13
Purpose: SQLAlchemy models for webhooks and delivery logs
Key responsibilities: Webhook and WebhookDelivery table definitions
"""

import logging
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship

# Import attempt with graceful fallback
try:
    from p02__server_db import Base
except ImportError as e:
    logging.warning(f"Import issue in webhook models: {e}")
    # Fallback for development
    from sqlalchemy.ext.declarative import declarative_base
    Base = declarative_base()

logger = logging.getLogger(__name__)

class Webhook(Base):
    """
    Webhook configuration for outbound events.
    
    Stores webhook endpoints that should receive notifications
    when specific events occur in the system.
    """
    __tablename__ = "webhooks"
    
    id = Column(Integer, primary_key=True, index=True)
    url = Column(String(512), nullable=False, index=True)
    event = Column(String(100), nullable=False, index=True)  # lead_ingested, leads_exported, etc.
    active = Column(Boolean, default=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_status = Column(String(20), nullable=True)  # success, failed, pending
    last_response_ms = Column(Integer, nullable=True)  # response time in milliseconds
    
    # Relationship to deliveries
    deliveries = relationship("WebhookDelivery", back_populates="webhook", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Webhook(id={self.id}, url='{self.url}', event='{self.event}', active={self.active})>"

class WebhookDelivery(Base):
    """
    Log of webhook delivery attempts.
    
    Records each attempt to deliver a webhook, including the payload,
    response code, timing, and success/failure status.
    """
    __tablename__ = "webhook_deliveries"
    
    id = Column(Integer, primary_key=True, index=True)
    webhook_id = Column(Integer, ForeignKey("webhooks.id"), nullable=False, index=True)
    event = Column(String(100), nullable=False, index=True)
    payload_json = Column(Text, nullable=False)  # JSON string of the payload sent
    status = Column(String(20), nullable=False, index=True)  # queued, success, failed
    response_code = Column(Integer, nullable=True)  # HTTP response code (200, 404, etc.)
    response_ms = Column(Integer, nullable=True)  # response time in milliseconds
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    
    # Relationship back to webhook
    webhook = relationship("Webhook", back_populates="deliveries")
    
    def __repr__(self):
        return f"<WebhookDelivery(id={self.id}, webhook_id={self.webhook_id}, event='{self.event}', status='{self.status}')>"

# Log model creation
logger.info("Webhook models defined: Webhook, WebhookDelivery")
