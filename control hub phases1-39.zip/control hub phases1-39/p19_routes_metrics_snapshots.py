"""
Metrics Snapshots API Routes
Phase 19: Endpoints for historical metrics data
Key responsibilities: Serve snapshot data, support time-series queries
"""

import logging
from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import JSONResponse
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

# Import services with try/except for flat file structure
try:
    from p19__server_services_metrics_capture import get_recent_snapshots, get_snapshot_by_date
    from p19__server_services_scheduler import get_scheduler_status
except ImportError:
    logger.warning("Metrics services not found - using mock implementations")
    def get_recent_snapshots(days=30):
        return []
    def get_snapshot_by_date(target_date):
        return None
    def get_scheduler_status():
        return {"running": False, "tasks_count": 0, "next_runs": {}}

router = APIRouter(prefix="/metrics", tags=["metrics"])

@router.get("/snapshots")
async def get_metrics_snapshots(
    days: int = Query(30, ge=1, le=365, description="Number of days to retrieve")
) -> Dict[str, Any]:
    """
    Get historical metrics snapshots
    
    Public endpoint - no authentication required for read access
    Returns snapshots in chronological order (oldest first)
    """
    try:
        logger.info(f"Retrieving metrics snapshots for last {days} days")
        
        snapshots = get_recent_snapshots(days)
        
        # Calculate summary statistics if we have data
        summary = {
            "total_snapshots": len(snapshots),
            "date_range": {
                "start": snapshots[0]["day_utc"] if snapshots else None,
                "end": snapshots[-1]["day_utc"] if snapshots else None
            }
        }
        
        # Add growth calculations if we have multiple snapshots
        if len(snapshots) > 1:
            first = snapshots[0]
            last = snapshots[-1]
            summary["growth"] = {
                "leads": last["leads"] - first["leads"],
                "buyers": last["buyers"] - first["buyers"],
                "sites": last["sites"] - first["sites"],
                "sales": last["sales"] - first["sales"],
                "deployments": last["deployments"] - first["deployments"]
            }
        
        logger.info(f"Returned {len(snapshots)} snapshots")
        
        return {
            "snapshots": snapshots,
            "summary": summary,
            "query": {
                "days": days,
                "requested_at": logger.manager.start_time if hasattr(logger.manager, 'start_time') else None
            }
        }
        
    except Exception as e:
        logger.error(f"Error retrieving metrics snapshots: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve snapshots: {str(e)}")

@router.get("/snapshots/latest")
async def get_latest_snapshot() -> Dict[str, Any]:
    """
    Get the most recent metrics snapshot
    """
    try:
        snapshots = get_recent_snapshots(1)
        
        if not snapshots:
            raise HTTPException(status_code=404, detail="No snapshots found")
        
        latest = snapshots[0]
        logger.info(f"Retrieved latest snapshot for {latest['day_utc']}")
        
        return {
            "snapshot": latest,
            "is_latest": True
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving latest snapshot: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve latest snapshot: {str(e)}")

@router.get("/snapshots/scheduler-status")
async def get_scheduler_metrics_status() -> Dict[str, Any]:
    """
    Get scheduler status for metrics capture
    Useful for monitoring and debugging
    """
    try:
        status = get_scheduler_status()
        
        # Add metrics-specific information
        status["metrics_capture"] = {
            "enabled": "capture_metrics" in status.get("next_runs", {}),
            "next_run": status.get("next_runs", {}).get("capture_metrics", {}).get("next_run"),
            "last_run": status.get("next_runs", {}).get("capture_metrics", {}).get("last_run")
        }
        
        logger.debug("Retrieved scheduler status for metrics")
        
        return status
        
    except Exception as e:
        logger.error(f"Error retrieving scheduler status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve scheduler status: {str(e)}")

@router.get("/snapshots/summary")
async def get_snapshots_summary(
    days: int = Query(7, ge=1, le=90, description="Number of days for summary")
) -> Dict[str, Any]:
    """
    Get summary statistics from recent snapshots
    Optimized endpoint for dashboard widgets
    """
    try:
        snapshots = get_recent_snapshots(days)
        
        if not snapshots:
            return {
                "period_days": days,
                "snapshots_count": 0,
                "message": "No snapshots available"
            }
        
        # Calculate totals and averages
        totals = {
            "leads": sum(s["leads"] for s in snapshots),
            "buyers": sum(s["buyers"] for s in snapshots),
            "sites": sum(s["sites"] for s in snapshots),
            "sales": sum(s["sales"] for s in snapshots),
            "deployments": sum(s["deployments"] for s in snapshots)
        }
        
        averages = {
            "leads": totals["leads"] / len(snapshots),
            "buyers": totals["buyers"] / len(snapshots),
            "sites": totals["sites"] / len(snapshots),
            "sales": totals["sales"] / len(snapshots),
            "deployments": totals["deployments"] / len(snapshots)
        }
        
        # Get latest values
        latest = snapshots[-1]
        
        summary = {
            "period_days": days,
            "snapshots_count": len(snapshots),
            "latest_values": {
                "leads": latest["leads"],
                "buyers": latest["buyers"],
                "sites": latest["sites"],
                "sales": latest["sales"],
                "deployments": latest["deployments"],
                "date": latest["day_utc"]
            },
            "averages": averages,
            "date_range": {
                "start": snapshots[0]["day_utc"],
                "end": snapshots[-1]["day_utc"]
            }
        }
        
        logger.info(f"Generated summary for {days} days with {len(snapshots)} snapshots")
        
        return summary
        
    except Exception as e:
        logger.error(f"Error generating snapshots summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate summary: {str(e)}")
