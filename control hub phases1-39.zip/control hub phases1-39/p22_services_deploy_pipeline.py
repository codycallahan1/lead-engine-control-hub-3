"""
Deployment Pipeline v2 Service
Phase 22: Multi-step deployment orchestration with retry logic
Key responsibilities: State machine for deploy steps, retry handling, step logging
"""

import logging
import time
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from enum import Enum

logger = logging.getLogger(__name__)

# Mock imports for flat file structure
try:
    from p02__server_db import get_session
    from p02__server_models import Site
    from p06__server_models_deployments import Deployment
    from p22__server_models_deploy_steps import DeploymentStep
    from p10__server_providers_domains_mock import purchase as purchase_domain
    from p10__server_providers_dns_mock import create_record as create_dns_record
    from p10__server_providers_hosting_mock import deploy as deploy_hosting
    from p21__server_models_audit import log_audit_event, AuditKind
except ImportError:
    logger.warning("Pipeline modules not found - using mock implementations")
    def get_session():
        return None
    
    class Site:
        def __init__(self, **kwargs):
            self.id = 1
            self.name = "Mock Site"
            self.domain = "mock.example.com"
    
    class Deployment:
        def __init__(self, **kwargs):
            self.id = 1
            self.site_id = 1
            self.status = "pending"
    
    class DeploymentStep:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    
    def purchase_domain(domain):
        return {"success": True, "message": "Mock domain purchase"}
    
    def create_dns_record(domain, record_type, value):
        return {"success": True, "message": "Mock DNS record created"}
    
    def deploy_hosting(domain, directory, region):
        return {"success": True, "message": "Mock hosting deployment"}
    
    def log_audit_event(session, kind, message, meta=None):
        logger.info(f"AUDIT: {kind} - {message}")

class DeploymentStepType(str, Enum):
    """Enum for deployment step types"""
    PURCHASE_DOMAIN = "purchase_domain"
    CREATE_DNS = "create_dns"
    DEPLOY_HOSTING = "deploy_hosting"

class DeploymentStepStatus(str, Enum):
    """Enum for deployment step status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"

class DeploymentPipeline:
    """
    Deployment pipeline orchestrator
    Manages multi-step deployment process with retries
    """
    
    def __init__(self, max_retries: int = 2):
        self.max_retries = max_retries
        self.retry_delays = [1, 2, 4]  # Exponential backoff in seconds
    
    def run_pipeline(self, site: Site, deployment: Deployment) -> Dict[str, Any]:
        """
        Execute the complete deployment pipeline
        
        Args:
            site: Site object to deploy
            deployment: Deployment record to update
        
        Returns:
            Dictionary with pipeline results
        """
        logger.info(f"Starting deployment pipeline for site {site.id}: {site.domain}")
        
        pipeline_start = datetime.utcnow()
        steps_completed = 0
        total_steps = 3
        
        try:
            session = get_session()
            if not session:
                logger.warning("No database session - using mock pipeline")
                return self._mock_pipeline_run(site, deployment)
            
            with session:
                # Step 1: Purchase Domain
                step1_result = self._execute_step_with_retry(
                    session, deployment.id, DeploymentStepType.PURCHASE_DOMAIN,
                    lambda: purchase_domain(site.domain),
                    {"domain": site.domain}
                )
                
                if not step1_result["success"]:
                    return self._complete_pipeline(session, deployment, "failed", 
                                                 steps_completed, total_steps, pipeline_start)
                
                steps_completed += 1
                
                # Step 2: Create DNS Records
                step2_result = self._execute_step_with_retry(
                    session, deployment.id, DeploymentStepType.CREATE_DNS,
                    lambda: create_dns_record(site.domain, "A", "192.168.1.100"),
                    {"domain": site.domain, "record_type": "A", "value": "192.168.1.100"}
                )
                
                if not step2_result["success"]:
                    return self._complete_pipeline(session, deployment, "failed", 
                                                 steps_completed, total_steps, pipeline_start)
                
                steps_completed += 1
                
                # Step 3: Deploy to Hosting
                step3_result = self._execute_step_with_retry(
                    session, deployment.id, DeploymentStepType.DEPLOY_HOSTING,
                    lambda: deploy_hosting(site.domain, "/var/www", "us-east-1"),
                    {"domain": site.domain, "directory": "/var/www", "region": "us-east-1"}
                )
                
                if not step3_result["success"]:
                    return self._complete_pipeline(session, deployment, "failed", 
                                                 steps_completed, total_steps, pipeline_start)
                
                steps_completed += 1
                
                # All steps completed successfully
                return self._complete_pipeline(session, deployment, "completed", 
                                             steps_completed, total_steps, pipeline_start)
        
        except Exception as e:
            logger.error(f"Pipeline execution error: {e}")
            session = get_session()
            if session:
                with session:
                    return self._complete_pipeline(session, deployment, "failed", 
                                                 steps_completed, total_steps, pipeline_start, 
                                                 error=str(e))
            return {"success": False, "error": str(e)}
    
    def _execute_step_with_retry(self, session, deployment_id: int, step_type: DeploymentStepType, 
                               step_function, step_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a single deployment step with retry logic
        
        Args:
            session: Database session
            deployment_id: ID of the deployment
            step_type: Type of step being executed
            step_function: Function to execute for this step
            step_params: Parameters for the step
        
        Returns:
            Dictionary with step execution results
        """
        step_start = datetime.utcnow()
        attempts = 0
        last_error = None
        
        # Create initial step record
        step_record = DeploymentStep(
            deployment_id=deployment_id,
            step=step_type.value,
            status=DeploymentStepStatus.PENDING.value,
            detail_json=json.dumps(step_params),
            started_at=step_start
        )
        session.add(step_record)
        session.commit()
        session.refresh(step_record)
        
        logger.info(f"Starting step: {step_type.value} (ID: {step_record.id})")
        
        while attempts <= self.max_retries:
            try:
                attempts += 1
                
                # Update step status to running (or retrying)
                step_record.status = (DeploymentStepStatus.RETRYING.value if attempts > 1 
                                    else DeploymentStepStatus.RUNNING.value)
                session.commit()
                
                logger.info(f"Executing {step_type.value} (attempt {attempts}/{self.max_retries + 1})")
                
                # Execute the step function
                result = step_function()
                
                if result.get("success"):
                    # Step succeeded
                    step_record.status = DeploymentStepStatus.COMPLETED.value
                    step_record.finished_at = datetime.utcnow()
                    
                    # Update detail with result
                    detail = json.loads(step_record.detail_json)
                    detail.update({
                        "result": result,
                        "attempts": attempts,
                        "success": True
                    })
                    step_record.detail_json = json.dumps(detail)
                    
                    session.commit()
                    
                    # Log audit event
                    log_audit_event(
                        session,
                        AuditKind.DEPLOYMENT_COMPLETED,
                        f"Deployment step {step_type.value} completed successfully",
                        {
                            "deployment_id": deployment_id,
                            "step": step_type.value,
                            "attempts": attempts,
                            "result": result
                        }
                    )
                    
                    logger.info(f"Step {step_type.value} completed successfully")
                    return {"success": True, "result": result, "attempts": attempts}
                
                else:
                    # Step failed, but we might retry
                    last_error = result.get("message", "Unknown error")
                    logger.warning(f"Step {step_type.value} failed (attempt {attempts}): {last_error}")
                    
                    if attempts <= self.max_retries:
                        # Wait before retry
                        retry_delay = self.retry_delays[min(attempts - 1, len(self.retry_delays) - 1)]
                        logger.info(f"Retrying {step_type.value} in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                    
            except Exception as e:
                last_error = str(e)
                logger.error(f"Step {step_type.value} exception (attempt {attempts}): {last_error}")
                
                if attempts <= self.max_retries:
                    retry_delay = self.retry_delays[min(attempts - 1, len(self.retry_delays) - 1)]
                    logger.info(f"Retrying {step_type.value} in {retry_delay} seconds...")
                    time.sleep(retry_delay)
        
        # All attempts exhausted - step failed
        step_record.status = DeploymentStepStatus.FAILED.value
        step_record.finished_at = datetime.utcnow()
        
        # Update detail with failure info
        detail = json.loads(step_record.detail_json)
        detail.update({
            "error": last_error,
            "attempts": attempts,
            "success": False,
            "max_retries_reached": True
        })
        step_record.detail_json = json.dumps(detail)
        
        session.commit()
        
        # Log audit event for failure
        log_audit_event(
            session,
            AuditKind.DEPLOYMENT_FAILED,
            f"Deployment step {step_type.value} failed after {attempts} attempts",
            {
                "deployment_id": deployment_id,
                "step": step_type.value,
                "attempts": attempts,
                "error": last_error
            }
        )
        
        logger.error(f"Step {step_type.value} failed permanently after {attempts} attempts")
        return {"success": False, "error": last_error, "attempts": attempts}
    
    def _complete_pipeline(self, session, deployment: Deployment, status: str, 
                          steps_completed: int, total_steps: int, pipeline_start: datetime,
                          error: str = None) -> Dict[str, Any]:
        """
        Complete the pipeline and update deployment status
        
        Args:
            session: Database session
            deployment: Deployment record
            status: Final deployment status
            steps_completed: Number of steps completed
            total_steps: Total number of steps
            pipeline_start: When pipeline started
            error: Error message if pipeline failed
        
        Returns:
            Dictionary with pipeline completion results
        """
        pipeline_duration = (datetime.utcnow() - pipeline_start).total_seconds()
        
        # Update deployment status
        deployment.status = status
        session.commit()
        
        # Log final audit event
        audit_kind = (AuditKind.DEPLOYMENT_COMPLETED if status == "completed" 
                     else AuditKind.DEPLOYMENT_FAILED)
        
        audit_message = (f"Deployment pipeline {status}: {steps_completed}/{total_steps} steps completed "
                        f"in {pipeline_duration:.1f}s")
        
        audit_meta = {
            "deployment_id": deployment.id,
            "site_id": deployment.site_id,
            "status": status,
            "steps_completed": steps_completed,
            "total_steps": total_steps,
            "duration_seconds": pipeline_duration
        }
        
        if error:
            audit_meta["error"] = error
        
        log_audit_event(session, audit_kind, audit_message, audit_meta)
        
        logger.info(f"Pipeline completed: {status} ({steps_completed}/{total_steps} steps, {pipeline_duration:.1f}s)")
        
        return {
            "success": status == "completed",
            "status": status,
            "steps_completed": steps_completed,
            "total_steps": total_steps,
            "duration_seconds": pipeline_duration,
            "error": error
        }
    
    def _mock_pipeline_run(self, site: Site, deployment: Deployment) -> Dict[str, Any]:
        """
        Mock pipeline execution for testing without database
        """
        logger.info(f"Mock pipeline execution for {site.domain}")
        
        # Simulate pipeline steps with delays
        steps = ["purchase_domain", "create_dns", "deploy_hosting"]
        
        for i, step in enumerate(steps):
            logger.info(f"Mock step {i+1}/{len(steps)}: {step}")
            time.sleep(0.5)  # Simulate work
        
        return {
            "success": True,
            "status": "completed",
            "steps_completed": len(steps),
            "total_steps": len(steps),
            "duration_seconds": 1.5,
            "mock": True
        }

# Factory function for pipeline instance
def create_deployment_pipeline(max_retries: int = 2) -> DeploymentPipeline:
    """Create a new deployment pipeline instance"""
    return DeploymentPipeline(max_retries=max_retries)

# Convenience function for single deployment
def execute_deployment(site_id: int, deployment_id: int) -> Dict[str, Any]:
    """
    Execute deployment pipeline for a site
    
    Args:
        site_id: ID of site to deploy
        deployment_id: ID of deployment record
    
    Returns:
        Pipeline execution results
    """
    try:
        session = get_session()
        if not session:
            logger.warning("No database session for deployment execution")
            return {"success": False, "error": "No database connection"}
        
        with session:
            # Get site and deployment records
            site = session.query(Site).filter(Site.id == site_id).first()
            deployment = session.query(Deployment).filter(Deployment.id == deployment_id).first()
            
            if not site:
                return {"success": False, "error": f"Site {site_id} not found"}
            
            if not deployment:
                return {"success": False, "error": f"Deployment {deployment_id} not found"}
            
            # Create and run pipeline
            pipeline = create_deployment_pipeline()
            return pipeline.run_pipeline(site, deployment)
    
    except Exception as e:
        logger.error(f"Error executing deployment: {e}")
        return {"success": False, "error": str(e)}
