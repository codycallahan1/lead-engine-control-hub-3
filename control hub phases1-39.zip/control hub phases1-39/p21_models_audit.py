"""
Audit Log Database Model (Updated)
Phase 21: Ensure audit log table structure for UI and retention
Key responsibilities: Store structured audit events, support querying and retention
"""

from sqlalchemy import Column, Integer, String, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import json

# Import base from existing models or create if needed
try:
    from p02__server_db import Base
except ImportError:
    Base = declarative_base()

class Audit(Base):
    """
    Audit log table for tracking system events
    Stores structured logs with metadata for compliance and debugging
    """
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    ts = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    kind = Column(String(100), nullable=False, index=True)  # Event type
    message = Column(Text, nullable=False)  # Human-readable message
    meta_json = Column(Text)  # JSON metadata
    
    def __repr__(self):
        return f"<Audit(kind='{self.kind}', ts='{self.ts}', message='{self.message[:50]}...')>"
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        meta = None
        if self.meta_json:
            try:
                meta = json.loads(self.meta_json)
            except json.JSONDecodeError:
                meta = {"raw": self.meta_json}
        
        return {
            "id": self.id,
            "timestamp": self.ts.isoformat(),
            "kind": self.kind,
            "message": self.message,
            "metadata": meta
        }
    
    @classmethod
    def create_entry(cls, kind: str, message: str, meta: dict = None):
        """
        Create a new audit log entry
        
        Args:
            kind: Event type/category
            message: Human-readable description
            meta: Optional metadata dictionary
        
        Returns:
            Audit instance
        """
        meta_json = None
        if meta:
            try:
                meta_json = json.dumps(meta)
            except (TypeError, ValueError):
                meta_json = json.dumps({"error": "Failed to serialize metadata"})
        
        return cls(
            ts=datetime.utcnow(),
            kind=kind,
            message=message,
            meta_json=meta_json
        )
    
    def get_metadata(self) -> dict:
        """Get parsed metadata as dictionary"""
        if not self.meta_json:
            return {}
        
        try:
            return json.loads(self.meta_json)
        except json.JSONDecodeError:
            return {"raw": self.meta_json}

# Common audit event kinds
class AuditKind:
    """Constants for common audit event types"""
    
    # Authentication events
    AUTH_LOGIN = "auth_login"
    AUTH_LOGOUT = "auth_logout"
    AUTH_FAILED = "auth_failed"
    TOKEN_CREATED = "token_created"
    TOKEN_REVOKED = "token_revoked"
    
    # Data operations
    LEAD_CREATED = "lead_created"
    LEAD_UPDATED = "lead_updated"
    LEAD_DELETED = "lead_deleted"
    LEADS_IMPORTED = "leads_imported"
    LEADS_EXPORTED = "leads_exported"
    
    BUYER_CREATED = "buyer_created"
    BUYER_UPDATED = "buyer_updated"
    BUYER_DELETED = "buyer_deleted"
    BUYERS_IMPORTED = "buyers_imported"
    BUYERS_EXPORTED = "buyers_exported"
    
    # Site operations
    SITE_CREATED = "site_created"
    SITE_DEPLOYED = "site_deployed"
    DEPLOYMENT_COMPLETED = "deployment_completed"
    DEPLOYMENT_FAILED = "deployment_failed"
    
    # Sales operations
    SALE_CREATED = "sale_created"
    SALE_DELIVERED = "sale_delivered"
    SALE_REFUNDED = "sale_refunded"
    
    # System operations
    SYSTEM_STARTUP = "system_startup"
    SYSTEM_SHUTDOWN = "system_shutdown"
    BACKUP_CREATED = "backup_created"
    DATA_PURGED = "data_purged"
    
    # Email operations
    EMAIL_SENT = "email_sent"
    EMAIL_FAILED = "email_failed"
    
    # Webhook operations
    WEBHOOK_TRIGGERED = "webhook_triggered"
    WEBHOOK_DELIVERED = "webhook_delivered"
    WEBHOOK_FAILED = "webhook_failed"
    
    @classmethod
    def all_kinds(cls) -> list:
        """Get all defined audit kinds"""
        return [
            value for name, value in cls.__dict__.items()
            if not name.startswith('_') and isinstance(value, str)
        ]

# App settings model for retention policy
class AppSetting(Base):
    """
    Application settings table
    Stores key-value configuration that persists across restarts
    """
    __tablename__ = "app_settings"
    
    key = Column(String(100), primary_key=True)
    value = Column(Text, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<AppSetting(key='{self.key}', value='{self.value[:50]}...')>"
    
    @classmethod
    def get_setting(cls, session, key: str, default_value: str = None):
        """Get a setting value"""
        setting = session.query(cls).filter(cls.key == key).first()
        return setting.value if setting else default_value
    
    @classmethod
    def set_setting(cls, session, key: str, value: str):
        """Set a setting value"""
        setting = session.query(cls).filter(cls.key == key).first()
        
        if setting:
            setting.value = value
            setting.updated_at = datetime.utcnow()
        else:
            setting = cls(key=key, value=value)
            session.add(setting)
        
        session.commit()
        return setting

# Ensure table creation helpers
def create_audit_tables(engine):
    """Create audit and settings tables if they don't exist"""
    try:
        Audit.__table__.create(engine, checkfirst=True)
        AppSetting.__table__.create(engine, checkfirst=True)
        return True
    except Exception as e:
        print(f"Error creating audit tables: {e}")
        return False

# Utility functions for audit logging
def log_audit_event(session, kind: str, message: str, meta: dict = None):
    """
    Log an audit event to the database
    
    Args:
        session: Database session
        kind: Event type (use AuditKind constants)
        message: Human-readable description
        meta: Optional metadata dictionary
    """
    try:
        audit_entry = Audit.create_entry(kind, message, meta)
        session.add(audit_entry)
        session.commit()
        return audit_entry
    except Exception as e:
        print(f"Failed to log audit event: {e}")
        return None

def get_audit_retention_days(session) -> int:
    """Get current audit retention policy in days"""
    try:
        days_str = AppSetting.get_setting(session, "audit_retention_days", "30")
        return int(days_str)
    except (ValueError, TypeError):
        return 30  # Default to 30 days

def set_audit_retention_days(session, days: int):
    """Set audit retention policy"""
    if days < 1:
        raise ValueError("Retention days must be at least 1")
    
    AppSetting.set_setting(session, "audit_retention_days", str(days))
    
    # Log the change
    log_audit_event(
        session,
        AuditKind.SYSTEM_STARTUP,  # Using existing kind for settings changes
        f"Audit retention policy updated to {days} days",
        {"old_setting": get_audit_retention_days(session), "new_setting": days}
    )
