"""
Privacy service for GDPR-lite compliance operations.

Phase: 26
Purpose: Handle lead data export and erasure with audit trails.
Key responsibilities:
- Export complete lead data including related records
- Safely erase lead PII while maintaining referential integrity
- Enforce business rules for data retention
"""

import logging
from typing import Dict, Any, Optional
from datetime import datetime

try:
    from p02__server_db import get_session
    from p02__server_models import Lead
    from p14__server_models_sales import LeadSale
    from p08__server_services_audit import audit
except ImportError as e:
    logging.warning(f"Privacy service: missing dependency {e}")

logger = logging.getLogger(__name__)


def export_lead_data(lead_id: int, org_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Export complete data for a lead including related records.
    
    Args:
        lead_id: ID of lead to export
        org_id: Organization ID for scoping (optional)
    
    Returns:
        Complete lead data including sales, deployments, etc.
    """
    logger.info(f"Exporting data for lead {lead_id}")
    
    try:
        with get_session() as db:
            # Get the lead
            lead_query = db.query(Lead).filter(Lead.id == lead_id)
            if org_id is not None:
                lead_query = lead_query.filter(Lead.org_id == org_id)
            
            lead = lead_query.first()
            if not lead:
                raise ValueError(f"Lead {lead_id} not found")
            
            # Build export data
            export_data = {
                "lead": {
                    "id": lead.id,
                    "org_id": getattr(lead, 'org_id', None),
                    "name": lead.name,
                    "email": lead.email,
                    "phone": lead.phone,
                    "created_at": lead.created_at.isoformat() if lead.created_at else None,
                    "updated_at": getattr(lead, 'updated_at', None),
                    "erased_at": getattr(lead, 'erased_at', None)
                },
                "related_data": {
                    "sales": [],
                    "webhook_deliveries": [],
                    "audit_logs": []
                },
                "export_metadata": {
                    "exported_at": datetime.utcnow().isoformat(),
                    "export_type": "privacy_request",
                    "data_retention_notice": "This export contains all personal data associated with the lead."
                }
            }
            
            # Get related sales if sales model exists
            try:
                sales = db.query(LeadSale).filter(LeadSale.lead_id == lead_id).all()
                for sale in sales:
                    export_data["related_data"]["sales"].append({
                        "id": sale.id,
                        "buyer_id": sale.buyer_id,
                        "price_cents": sale.price_cents,
                        "status": sale.status,
                        "created_at": sale.created_at.isoformat() if sale.created_at else None
                    })
            except Exception as e:
                logger.debug(f"No sales data available: {e}")
            
            # Get audit logs related to this lead
            try:
                from p21__server_models_audit import Audit
                audit_logs = db.query(Audit).filter(
                    Audit.meta_json.contains(f'"lead_id":{lead_id}')
                ).limit(100).all()
                
                for log in audit_logs:
                    export_data["related_data"]["audit_logs"].append({
                        "id": log.id,
                        "timestamp": log.ts.isoformat() if log.ts else None,
                        "kind": log.kind,
                        "message": log.message,
                        "meta": log.meta_json
                    })
            except Exception as e:
                logger.debug(f"No audit data available: {e}")
            
            logger.info(f"Successfully exported data for lead {lead_id}")
            return export_data
    
    except Exception as e:
        logger.error(f"Failed to export data for lead {lead_id}: {e}")
        raise


def erase_lead(lead_id: int, actor: str, org_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Erase/anonymize a lead's personal data.
    
    Args:
        lead_id: ID of lead to erase
        actor: Who initiated the erasure (for audit)
        org_id: Organization ID for scoping (optional)
    
    Returns:
        Result of erasure operation
    
    Raises:
        ValueError: If lead cannot be erased due to business rules
    """
    logger.info(f"Erasing lead {lead_id} (requested by {actor})")
    
    try:
        with get_session() as db:
            # Get the lead
            lead_query = db.query(Lead).filter(Lead.id == lead_id)
            if org_id is not None:
                lead_query = lead_query.filter(Lead.org_id == org_id)
            
            lead = lead_query.first()
            if not lead:
                raise ValueError(f"Lead {lead_id} not found")
            
            # Check if already erased
            if hasattr(lead, 'erased_at') and lead.erased_at:
                return {
                    "success": True,
                    "message": "Lead was already erased",
                    "erased_at": lead.erased_at.isoformat()
                }
            
            # Check business rules - cannot erase if has non-refunded sales
            try:
                active_sales = db.query(LeadSale).filter(
                    LeadSale.lead_id == lead_id,
                    LeadSale.status.in_(['created', 'delivered'])
                ).count()
                
                if active_sales > 0:
                    error_msg = f"Cannot erase lead {lead_id}: has {active_sales} active sales"
                    logger.warning(error_msg)
                    
                    audit_privacy("lead_erase_blocked", lead_id, actor, False, error_msg)
                    
                    raise ValueError("Lead has active sales and cannot be erased. Refund sales first.")
            
            except Exception as e:
                if "active sales" in str(e):
                    raise
                logger.debug(f"No sales check available: {e}")
            
            # Store original data for audit
            original_data = {
                "name": lead.name,
                "email": lead.email,
                "phone": lead.phone
            }
            
            # Perform erasure - redact PII but keep record for referential integrity
            lead.name = f"[ERASED-{lead.id}]"
            lead.email = f"erased-{lead.id}@privacy.local"
            lead.phone = None
            
            # Add erasure timestamp if column exists
            if hasattr(lead, 'erased_at'):
                lead.erased_at = datetime.utcnow()
            
            db.commit()
            
            result = {
                "success": True,
                "message": f"Lead {lead_id} has been erased",
                "erased_at": datetime.utcnow().isoformat(),
                "redacted_fields": ["name", "email", "phone"]
            }
            
            # Audit successful erasure
            audit_privacy(
                "lead_erased", 
                lead_id, 
                actor, 
                True, 
                f"Lead data erased: {list(original_data.keys())}"
            )
            
            logger.info(f"Successfully erased lead {lead_id}")
            return result
    
    except ValueError:
        raise
    except Exception as e:
        error_msg = f"Failed to erase lead {lead_id}: {str(e)}"
        logger.error(error_msg)
        
        # Audit failed erasure
        audit_privacy("lead_erase_failed", lead_id, actor, False, error_msg)
        
        raise Exception(error_msg)


def audit_privacy(kind: str, lead_id: int, actor: str, success: bool, message: str):
    """Log privacy-related actions to audit trail."""
    try:
        audit(
            kind=f"privacy_{kind}",
            message=message,
            meta={
                "lead_id": lead_id,
                "actor": actor,
                "success": success,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    except Exception as e:
        logger.error(f"Failed to audit privacy action: {e}")


def check_erasure_eligibility(lead_id: int, org_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Check if a lead can be erased without violating business rules.
    
    Returns:
        {"eligible": bool, "blockers": [list of reasons], "warnings": [list]}
    """
    try:
        with get_session() as db:
            lead_query = db.query(Lead).filter(Lead.id == lead_id)
            if org_id is not None:
                lead_query = lead_query.filter(Lead.org_id == org_id)
            
            lead = lead_query.first()
            if not lead:
                return {"eligible": False, "blockers": ["Lead not found"], "warnings": []}
            
            blockers = []
            warnings = []
            
            # Check if already erased
            if hasattr(lead, 'erased_at') and lead.erased_at:
                warnings.append("Lead is already erased")
            
            # Check for active sales
            try:
                active_sales = db.query(LeadSale).filter(
                    LeadSale.lead_id == lead_id,
                    LeadSale.status.in_(['created', 'delivered'])
                ).count()
                
                if active_sales > 0:
                    blockers.append(f"Lead has {active_sales} active sales")
            except Exception:
                pass  # Sales table might not exist
            
            # Check for recent activity (within 30 days)
            from datetime import timedelta
            if lead.created_at and lead.created_at > datetime.utcnow() - timedelta(days=30):
                warnings.append("Lead was created recently (within 30 days)")
            
            return {
                "eligible": len(blockers) == 0,
                "blockers": blockers,
                "warnings": warnings
            }
    
    except Exception as e:
        logger.error(f"Error checking erasure eligibility for lead {lead_id}: {e}")
        return {"eligible": False, "blockers": [f"Error: {str(e)}"], "warnings": []}
