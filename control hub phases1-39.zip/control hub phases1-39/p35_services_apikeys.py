"""
Lead Engine Control Hub - Buyer API Key Service
Phase 35: API keys for buyers pull API
Purpose: Core business logic for buyer API key management and authentication
"""

import hashlib
import logging
import secrets
from datetime import datetime, timedelta
from typing import Optional, Tuple
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

# Import models and database utilities
try:
    from p35__server_models_apikeys import BuyerApiKey, ApiKeyUsageLog, ApiRateLimit
    from p02__server_db import get_session
    from p08__server_services_audit import audit
except ImportError:
    # Fallback for development
    class BuyerApiKey:
        pass
    class ApiKeyUsageLog:
        pass
    class ApiRateLimit:
        pass
    def get_session():
        pass
    def audit(kind: str, message: str, meta: dict = None):
        logging.info(f"AUDIT[{kind}]: {message}")

logger = logging.getLogger(__name__)


class ApiKeyError(Exception):
    """Base exception for API key operations."""
    pass


class InvalidApiKeyError(ApiKeyError):
    """Raised when API key is invalid or not found."""
    pass


class RateLimitExceededError(ApiKeyError):
    """Raised when API key rate limit is exceeded."""
    pass


def generate_api_key() -> Tuple[str, str, str]:
    """
    Generate a new API key with hash and prefix.
    
    Returns:
        Tuple of (plain_key, hash, prefix)
    """
    # Generate 32 random bytes (256 bits)
    random_bytes = secrets.token_bytes(32)
    
    # Create base64-like string but URL safe
    plain_key = secrets.token_urlsafe(32)
    
    # Create hash for storage (with org salt for additional security)
    key_hash = hashlib.sha256(plain_key.encode()).hexdigest()
    
    # Extract prefix for identification
    prefix = plain_key[:8]
    
    return plain_key, key_hash, prefix


def hash_api_key(plain_key: str) -> str:
    """
    Hash an API key for secure storage.
    
    Args:
        plain_key: Plain text API key
    
    Returns:
        SHA-256 hash of the key
    """
    return hashlib.sha256(plain_key.encode()).hexdigest()


def create_api_key(buyer_id: int, org_id: int, name: str, 
                  created_by: str = "admin", expires_days: Optional[int] = None) -> Tuple[BuyerApiKey, str]:
    """
    Create a new API key for a buyer.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        name: Human-readable name for the key
        created_by: Who created the key
        expires_days: Optional expiration in days
    
    Returns:
        Tuple of (BuyerApiKey instance, plain key)
    """
    with get_session() as session:
        # Generate key
        plain_key, key_hash, prefix = generate_api_key()
        
        # Calculate expiration
        expires_at = None
        if expires_days:
            expires_at = datetime.utcnow() + timedelta(days=expires_days)
        
        # Create key record
        api_key = BuyerApiKey(
            org_id=org_id,
            buyer_id=buyer_id,
            name=name,
            key_hash=key_hash,
            key_prefix=prefix,
            active=True,
            created_by=created_by,
            expires_at=expires_at
        )
        
        try:
            session.add(api_key)
            session.commit()
            session.refresh(api_key)
            
            # Create rate limit record
            rate_limit = ApiRateLimit(
                api_key_id=api_key.id,
                hourly_reset_at=datetime.utcnow().replace(minute=0, second=0, microsecond=0) + timedelta(hours=1),
                daily_reset_at=datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
            )
            session.add(rate_limit)
            session.commit()
            
            logger.info(f"Created API key '{name}' for buyer {buyer_id}")
            audit(
                kind="api_key_created",
                message=f"API key '{name}' created for buyer {buyer_id}",
                meta={
                    "buyer_id": buyer_id,
                    "org_id": org_id,
                    "key_id": api_key.id,
                    "key_name": name,
                    "created_by": created_by,
                    "expires_at": expires_at.isoformat() if expires_at else None
                }
            )
            
            return api_key, plain_key
            
        except IntegrityError as e:
            session.rollback()
            logger.error(f"Failed to create API key: {str(e)}")
            raise ApiKeyError(f"Failed to create API key: {str(e)}")


def verify_api_key(plain_key: str) -> Optional[BuyerApiKey]:
    """
    Verify an API key and return the associated record.
    
    Args:
        plain_key: Plain text API key to verify
    
    Returns:
        BuyerApiKey instance if valid, None otherwise
    """
    if not plain_key:
        return None
    
    try:
        key_hash = hash_api_key(plain_key)
        
        with get_session() as session:
            api_key = session.query(BuyerApiKey).filter_by(key_hash=key_hash).first()
            
            if not api_key:
                return None
            
            # Check if key is usable
            if not api_key.is_usable:
                logger.warning(f"Attempt to use inactive/expired API key {api_key.id}")
                return None
            
            return api_key
            
    except Exception as e:
        logger.error(f"Error verifying API key: {str(e)}")
        return None


def authenticate_buyer_request(api_key_header: str) -> Tuple[int, int, BuyerApiKey]:
    """
    Authenticate a buyer API request using API key.
    
    Args:
        api_key_header: Value from X-API-Key header
    
    Returns:
        Tuple of (buyer_id, org_id, api_key_record)
    
    Raises:
        InvalidApiKeyError: If key is invalid
        RateLimitExceededError: If rate limit exceeded
    """
    if not api_key_header:
        raise InvalidApiKeyError("API key required")
    
    # Verify key
    api_key = verify_api_key(api_key_header)
    if not api_key:
        raise InvalidApiKeyError("Invalid API key")
    
    # Check rate limits
    with get_session() as session:
        # Get or create rate limit record
        rate_limit = session.query(ApiRateLimit).filter_by(api_key_id=api_key.id).first()
        if not rate_limit:
            rate_limit = ApiRateLimit(
                api_key_id=api_key.id,
                hourly_reset_at=datetime.utcnow().replace(minute=0, second=0, microsecond=0) + timedelta(hours=1),
                daily_reset_at=datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
            )
            session.add(rate_limit)
        
        # Check if rate limited
        is_limited, reason = rate_limit.is_rate_limited(
            api_key.rate_limit_per_hour,
            api_key.rate_limit_per_day
        )
        
        if is_limited:
            logger.warning(f"Rate limit exceeded for API key {api_key.id}: {reason}")
            raise RateLimitExceededError(reason)
        
        # Record the request
        rate_limit.record_request()
        session.commit()
    
    return api_key.buyer_id, api_key.org_id, api_key


def record_api_usage(api_key: BuyerApiKey, endpoint: str, method: str, 
                    status_code: int, response_time_ms: Optional[int] = None,
                    records_returned: Optional[int] = None, error_message: Optional[str] = None,
                    ip_address: Optional[str] = None, user_agent: Optional[str] = None):
    """
    Record API key usage for monitoring and analytics.
    
    Args:
        api_key: API key record
        endpoint: Endpoint that was called
        method: HTTP method
        status_code: Response status code
        response_time_ms: Response time in milliseconds
        records_returned: Number of records returned
        error_message: Error message if request failed
        ip_address: Client IP address
        user_agent: Client user agent
    """
    try:
        with get_session() as session:
            # Update API key last used
            api_key.record_usage(ip_address)
            session.merge(api_key)
            
            # Create usage log
            usage_log = ApiKeyUsageLog(
                org_id=api_key.org_id,
                buyer_id=api_key.buyer_id,
                api_key_id=api_key.id,
                endpoint=endpoint,
                method=method,
                status_code=status_code,
                response_time_ms=response_time_ms,
                records_returned=records_returned,
                error_message=error_message,
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            session.add(usage_log)
            session.commit()
            
    except Exception as e:
        logger.error(f"Failed to record API usage: {str(e)}")


def rotate_api_key(key_id: int, org_id: int, rotated_by: str = "admin") -> Tuple[BuyerApiKey, str]:
    """
    Rotate an existing API key (generate new key, deactivate old).
    
    Args:
        key_id: API key ID to rotate
        org_id: Organization ID for authorization
        rotated_by: Who performed the rotation
    
    Returns:
        Tuple of (new BuyerApiKey, new plain key)
    
    Raises:
        ApiKeyError: If key not found or rotation fails
    """
    with get_session() as session:
        # Find existing key
        old_key = session.query(BuyerApiKey).filter_by(
            id=key_id, 
            org_id=org_id
        ).first()
        
        if not old_key:
            raise ApiKeyError("API key not found")
        
        # Generate new key
        plain_key, key_hash, prefix = generate_api_key()
        
        # Update existing key record
        old_key.key_hash = key_hash
        old_key.key_prefix = prefix
        old_key.active = True  # Ensure it's active
        old_key.last_used_at = None  # Reset usage tracking
        old_key.usage_count = 0
        
        # Reset rate limits
        rate_limit = session.query(ApiRateLimit).filter_by(api_key_id=old_key.id).first()
        if rate_limit:
            rate_limit.hourly_count = 0
            rate_limit.daily_count = 0
            rate_limit.hourly_reset_at = datetime.utcnow().replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
            rate_limit.daily_reset_at = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
        
        session.commit()
        session.refresh(old_key)
        
        logger.info(f"Rotated API key {key_id} for buyer {old_key.buyer_id}")
        audit(
            kind="api_key_rotated",
            message=f"API key '{old_key.name}' rotated for buyer {old_key.buyer_id}",
            meta={
                "buyer_id": old_key.buyer_id,
                "org_id": org_id,
                "key_id": key_id,
                "key_name": old_key.name,
                "rotated_by": rotated_by
            }
        )
        
        return old_key, plain_key


def deactivate_api_key(key_id: int, org_id: int, deactivated_by: str = "admin") -> bool:
    """
    Deactivate an API key.
    
    Args:
        key_id: API key ID to deactivate
        org_id: Organization ID for authorization
        deactivated_by: Who deactivated the key
    
    Returns:
        True if deactivated successfully
    
    Raises:
        ApiKeyError: If key not found
    """
    with get_session() as session:
        api_key = session.query(BuyerApiKey).filter_by(
            id=key_id,
            org_id=org_id
        ).first()
        
        if not api_key:
            raise ApiKeyError("API key not found")
        
        api_key.active = False
        session.commit()
        
        logger.info(f"Deactivated API key {key_id} for buyer {api_key.buyer_id}")
        audit(
            kind="api_key_deactivated",
            message=f"API key '{api_key.name}' deactivated for buyer {api_key.buyer_id}",
            meta={
                "buyer_id": api_key.buyer_id,
                "org_id": org_id,
                "key_id": key_id,
                "key_name": api_key.name,
                "deactivated_by": deactivated_by
            }
        )
        
        return True


def list_buyer_api_keys(buyer_id: int, org_id: int, include_inactive: bool = False) -> list:
    """
    List all API keys for a buyer.
    
    Args:
        buyer_id: Buyer identifier
        org_id: Organization identifier
        include_inactive: Whether to include inactive keys
    
    Returns:
        List of API key dictionaries
    """
    with get_session() as session:
        query = session.query(BuyerApiKey).filter_by(
            buyer_id=buyer_id,
            org_id=org_id
        )
        
        if not include_inactive:
            query = query.filter_by(active=True)
        
        keys = query.order_by(BuyerApiKey.created_at.desc()).all()
        
        return [key.to_dict() for key in keys]


def get_api_key_usage_stats(key_id: int, org_id: int, days: int = 30) -> dict:
    """
    Get usage statistics for an API key.
    
    Args:
        key_id: API key identifier
        org_id: Organization identifier
        days: Number of days to include in stats
    
    Returns:
        Dictionary with usage statistics
    """
    with get_session() as session:
        # Verify key exists and belongs to org
        api_key = session.query(BuyerApiKey).filter_by(
            id=key_id,
            org_id=org_id
        ).first()
        
        if not api_key:
            raise ApiKeyError("API key not found")
        
        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)
        
        # Get usage logs
        usage_logs = session.query(ApiKeyUsageLog).filter(
            ApiKeyUsageLog.api_key_id == key_id,
            ApiKeyUsageLog.created_at >= start_date
        ).all()
        
        # Calculate statistics
        total_requests = len(usage_logs)
        successful_requests = len([log for log in usage_logs if log.was_successful])
        failed_requests = total_requests - successful_requests
        
        # Get rate limit info
        rate_limit = session.query(ApiRateLimit).filter_by(api_key_id=key_id).first()
        
        return {
            "key_id": key_id,
            "period_days": days,
            "total_requests": total_requests,
            "successful_requests": successful_requests,
            "failed_requests": failed_requests,
            "success_rate": (successful_requests / total_requests) if total_requests > 0 else 0,
            "current_rate_limits": rate_limit.get_limits_info() if rate_limit else None,
            "most_used_endpoints": {},  # Could be calculated from logs
            "recent_errors": [
                log.to_dict() for log in usage_logs 
                if not log.was_successful
            ][-10:]  # Last 10 errors
        }
