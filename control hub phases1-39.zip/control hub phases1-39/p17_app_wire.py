"""
Application wiring example for error handling and rate limiting middleware.

Phase: 17
Purpose: Demonstrate how to wire error handlers and rate limiting into FastAPI app
Key responsibilities: show middleware integration order and configuration
"""

import logging
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Import attempt with graceful fallback
try:
    from p17__server_middleware_errors import add_exception_handlers, RequestIDMiddleware
    from p17__server_middleware_ratelimit import RateLimitMiddleware
except ImportError as e:
    logging.warning(f"Import issue in app wiring: {e}")
    # Fallback for development
    def add_exception_handlers(app):
        pass
    class RequestIDMiddleware:
        def __init__(self, app):
            pass
    class RateLimitMiddleware:
        def __init__(self, app):
            pass

logger = logging.getLogger(__name__)

def create_app() -> FastAPI:
    """
    Create and configure FastAPI application with middleware and error handlers.
    
    This is a complete example showing how to wire together all the middleware
    and error handling components from Phase 17.
    
    Returns:
        Configured FastAPI application
    """
    logger.info("Creating FastAPI application with Phase 17 enhancements")
    
    # Create FastAPI app
    app = FastAPI(
        title="Lead Engine Control Hub",
        description="Central command center for lead management and site deployment",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc"
    )
    
    # Add middleware in reverse order (last added = first executed)
    
    # 1. Rate limiting middleware (outermost - applied first)
    app.add_middleware(RateLimitMiddleware)
    logger.info("Added rate limiting middleware")
    
    # 2. Request ID middleware (inner - applied after rate limiting)
    app.add_middleware(RequestIDMiddleware)
    logger.info("Added request ID middleware")
    
    # 3. CORS middleware (if needed - would go here)
    # app.add_middleware(CORSMiddleware, ...)
    
    # Add exception handlers
    add_exception_handlers(app)
    logger.info("Added custom exception handlers")
    
    # Mount static files (after middleware to avoid rate limiting static assets)
    try:
        app.mount("/static", StaticFiles(directory="static"), name="static")
        logger.info("Mounted static files at /static")
    except Exception as e:
        logger.warning(f"Could not mount static files: {e}")
    
    # Setup templates
    try:
        templates = Jinja2Templates(directory="templates")
        logger.info("Configured Jinja2 templates")
    except Exception as e:
        logger.warning(f"Could not setup templates: {e}")
    
    return app

def wire_existing_app(app: FastAPI) -> None:
    """
    Wire Phase 17 enhancements into an existing FastAPI application.
    
    Use this function if you already have a FastAPI app and want to add
    the error handling and rate limiting features.
    
    Args:
        app: Existing FastAPI application to enhance
    """
    logger.info("Wiring Phase 17 enhancements into existing app")
    
    # Add middleware (order matters!)
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(RequestIDMiddleware)
    
    # Add exception handlers
    add_exception_handlers(app)
    
    logger.info("Phase 17 enhancements added to existing app")

def configure_rate_limits(app: FastAPI, custom_limits: dict = None) -> None:
    """
    Configure custom rate limits for specific endpoints.
    
    Args:
        app: FastAPI application
        custom_limits: Dict of path -> (rate_per_min, burst) overrides
    """
    if custom_limits is None:
        custom_limits = {
            # Public endpoints - more restrictive
            '/ingest/lead': (20, 5),      # 20/min, burst 5
            '/ingest/form': (30, 10),     # 30/min, burst 10
            
            # Admin endpoints - moderate limits
            '/webhooks': (30, 5),         # 30/min, burst 5
            '/matching': (20, 3),         # 20/min, burst 3
            '/export': (10, 2),           # 10/min, burst 2
            
            # High-frequency endpoints - relaxed limits
            '/health': (300, 30),         # 300/min, burst 30
            '/metrics/summary': (180, 20), # 180/min, burst 20
            
            # Dashboard and UI - normal limits
            '/leads-page': (60, 10),      # 60/min, burst 10
            '/buyers-page': (60, 10),     # 60/min, burst 10
            '/sites-page': (60, 10),      # 60/min, burst 10
        }
    
    # Apply custom limits to middleware
    # Note: This would need to be done during app creation in practice
    logger.info(f"Custom rate limits configured for {len(custom_limits)} paths")

# Example usage and integration patterns
EXAMPLE_APP_INITIALIZATION = """
# Example 1: Create new app with Phase 17 features
from p17__server_app_wire import create_app

app = create_app()

# Add your routes here
@app.get("/")
async def root():
    return {"message": "Hello World"}

# Example 2: Enhance existing app
from fastapi import FastAPI
from p17__server_app_wire import wire_existing_app

app = FastAPI()
wire_existing_app(app)

# Your existing routes...

# Example 3: Custom rate limits
from p17__server_app_wire import configure_rate_limits

custom_limits = {
    '/api/v1/users': (100, 20),  # 100/min, burst 20
    '/api/v1/data': (50, 10),    # 50/min, burst 10
}
configure_rate_limits(app, custom_limits)
"""

# Development and testing helpers
def get_middleware_order(app: FastAPI) -> list:
    """
    Get the order of middleware in the app for debugging.
    
    Args:
        app: FastAPI application
        
    Returns:
        List of middleware class names in execution order
    """
    middleware_stack = []
    
    if hasattr(app, 'user_middleware'):
        for middleware in app.user_middleware:
            middleware_stack.append(middleware.cls.__name__)
    
    logger.info(f"Middleware stack: {' -> '.join(middleware_stack)}")
    return middleware_stack

def test_error_pages(app: FastAPI) -> dict:
    """
    Add test routes for error pages (development only).
    
    Args:
        app: FastAPI application
        
    Returns:
        Dict of test route paths
    """
    test_routes = {}
    
    @app.get("/test/404")
    async def test_404():
        """Test 404 error page"""
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Test 404 page")
    
    @app.get("/test/500")
    async def test_500():
        """Test 500 error page"""
        raise Exception("Test 500 error page")
    
    @app.get("/test/403")
    async def test_403():
        """Test 403 error page"""
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Test 403 page")
    
    test_routes = {
        "404": "/test/404",
        "500": "/test/500", 
        "403": "/test/403"
    }
    
    logger.info(f"Added test error routes: {list(test_routes.values())}")
    return test_routes

# Configuration constants
MIDDLEWARE_CONFIG = {
    "request_id": {
        "enabled": True,
        "header_name": "X-Request-ID"
    },
    "rate_limit": {
        "enabled": True,
        "default_rate": 60,      # requests per minute
        "default_burst": 10,     # burst capacity
        "cleanup_interval": 300   # cleanup old buckets every 5 minutes
    },
    "error_handling": {
        "enabled": True,
        "show_request_id": True,
        "log_errors": True
    }
}

# Log initialization
logger.info("App wiring module initialized with middleware configuration examples")
logger.info("Usage: Import create_app() or wire_existing_app() to add Phase 17 features")
