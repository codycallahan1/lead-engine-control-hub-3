"""
Notification settings management routes.

Phase: 16
Purpose: Admin routes for viewing and updating notification configuration
Key responsibilities: GET/POST notification settings with admin authentication
"""

import logging
from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Request, HTTPException, Header, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, EmailStr

# Import attempt with graceful fallback
try:
    from p16__server_config_notify import (
        get_notification_recipients, 
        get_notification_settings,
        update_notification_recipients,
        update_notification_settings,
        get_email_templates
    )
    from p16__server_services_notify import get_notification_stats
except ImportError as e:
    logging.warning(f"Import issue in notification settings routes: {e}")
    # Fallback for development
    def get_notification_recipients():
        return {"admin": ["admin@example.com"], "sales": ["sales@example.com"]}
    def get_notification_settings():
        return {"enabled": True, "default_from": "noreply@example.com"}
    def update_notification_recipients(type, emails):
        return True
    def update_notification_settings(settings):
        return True
    def get_email_templates():
        return {}
    def get_notification_stats():
        return {"total_sent": 0}

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/settings", tags=["settings", "notifications"])

# Template setup - would be wired from main app
templates = Jinja2Templates(directory=".")

def verify_admin_token(admin_token: Optional[str] = Header(None)):
    """
    Simple admin token verification for settings access.
    """
    if admin_token != "change-me":
        raise HTTPException(status_code=401, detail="Invalid or missing Admin-Token header")
    return True

# Pydantic models for request validation
class NotificationRecipientsUpdate(BaseModel):
    admin: Optional[List[EmailStr]] = None
    sales: Optional[List[EmailStr]] = None
    support: Optional[List[EmailStr]] = None

class NotificationSettingsUpdate(BaseModel):
    enabled: Optional[bool] = None
    default_from: Optional[EmailStr] = None
    reply_to: Optional[EmailStr] = None
    min_alert_severity: Optional[str] = None
    batch_size: Optional[int] = None
    retry_attempts: Optional[int] = None

@router.get("/notify", response_model=Dict[str, Any])
async def get_notification_settings_api():
    """
    Get current notification settings and recipients.
    
    Returns configuration for notification system including
    recipients, settings, and available templates.
    """
    logger.info("GET /settings/notify - notification settings requested")
    
    try:
        recipients = get_notification_recipients()
        settings = get_notification_settings()
        templates = get_email_templates()
        stats = get_notification_stats()
        
        response = {
            'recipients': recipients,
            'settings': settings,
            'templates': templates,
            'stats': stats,
            'status': 'active' if settings.get('enabled', True) else 'disabled'
        }
        
        logger.info("Notification settings returned successfully")
        return response
        
    except Exception as e:
        logger.error(f"Failed to get notification settings: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve notification settings")

@router.post("/notify", response_model=Dict[str, Any], dependencies=[Depends(verify_admin_token)])
async def update_notification_settings_api(update: NotificationSettingsUpdate):
    """
    Update notification system settings.
    
    Requires Admin-Token header for authorization.
    """
    logger.info("POST /settings/notify - updating notification settings")
    
    try:
        # Convert Pydantic model to dict, excluding None values
        settings_data = update.dict(exclude_unset=True)
        
        if not settings_data:
            raise HTTPException(status_code=400, detail="No settings provided for update")
        
        # Validate severity if provided
        if 'min_alert_severity' in settings_data:
            valid_severities = ['info', 'warning', 'error', 'critical']
            if settings_data['min_alert_severity'] not in valid_severities:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Invalid severity. Must be one of: {', '.join(valid_severities)}"
                )
        
        # Validate batch_size if provided
        if 'batch_size' in settings_data:
            if not (1 <= settings_data['batch_size'] <= 1000):
                raise HTTPException(status_code=400, detail="Batch size must be between 1 and 1000")
        
        # Validate retry_attempts if provided
        if 'retry_attempts' in settings_data:
            if not (0 <= settings_data['retry_attempts'] <= 10):
                raise HTTPException(status_code=400, detail="Retry attempts must be between 0 and 10")
        
        # Apply updates
        success = update_notification_settings(settings_data)
        
        if not success:
            raise HTTPException(status_code=500, detail="Failed to update notification settings")
        
        logger.info(f"Notification settings updated: {list(settings_data.keys())}")
        
        # Return updated settings
        updated_settings = get_notification_settings()
        return {
            'success': True,
            'message': 'Notification settings updated successfully',
            'updated_fields': list(settings_data.keys()),
            'settings': updated_settings
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update notification settings: {e}")
        raise HTTPException(status_code=500, detail="Failed to update notification settings")

@router.post("/notify/recipients", response_model=Dict[str, Any], dependencies=[Depends(verify_admin_token)])
async def update_notification_recipients_api(recipients: NotificationRecipientsUpdate):
    """
    Update notification recipients.
    
    Requires Admin-Token header for authorization.
    """
    logger.info("POST /settings/notify/recipients - updating notification recipients")
    
    try:
        recipients_data = recipients.dict(exclude_unset=True)
        
        if not recipients_data:
            raise HTTPException(status_code=400, detail="No recipients provided for update")
        
        updated_types = []
        
        # Update each recipient type that was provided
        for recipient_type, emails in recipients_data.items():
            if emails is not None:  # Allow empty lists to clear recipients
                email_strings = [str(email) for email in emails]
                success = update_notification_recipients(recipient_type, email_strings)
                
                if success:
                    updated_types.append(recipient_type)
                    logger.info(f"Updated {recipient_type} recipients: {len(email_strings)} emails")
                else:
                    logger.error(f"Failed to update {recipient_type} recipients")
                    raise HTTPException(
                        status_code=500, 
                        detail=f"Failed to update {recipient_type} recipients"
                    )
        
        if not updated_types:
            raise HTTPException(status_code=500, detail="Failed to update any recipient types")
        
        # Return updated recipients
        updated_recipients = get_notification_recipients()
        return {
            'success': True,
            'message': f'Updated {", ".join(updated_types)} recipients',
            'updated_types': updated_types,
            'recipients': updated_recipients
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update notification recipients: {e}")
        raise HTTPException(status_code=500, detail="Failed to update notification recipients")

@router.get("/notify-page", response_class=HTMLResponse)
async def notification_settings_page(request: Request):
    """
    Server-side rendered notification settings management page.
    """
    logger.info("GET /settings/notify-page - HTML notification settings page requested")
    
    try:
        recipients = get_notification_recipients()
        settings = get_notification_settings()
        templates = get_email_templates()
        stats = get_notification_stats()
        
        context = {
            "request": request,
            "recipients": recipients,
            "settings": settings,
            "templates": templates,
            "stats": stats,
            "severity_options": [
                {"value": "info", "label": "Info"},
                {"value": "warning", "label": "Warning"},
                {"value": "error", "label": "Error"},
                {"value": "critical", "label": "Critical"}
            ]
        }
        
        try:
            return templates.TemplateResponse("p16__server-templates-notify-settings.html", context)
        except Exception as e:
            logger.error(f"Template error: {e}")
            # Fallback HTML response
            return HTMLResponse(f"""
            <html>
            <head><title>Notification Settings</title></head>
            <body style="font-family: Arial, sans-serif; padding: 2rem; background: #1a1a1a; color: white;">
                <h1>Notification Settings</h1>
                <div style="background: #2d2d2d; padding: 1.5rem; border-radius: 8px; margin: 1rem 0;">
                    <h3>Current Status</h3>
                    <p><strong>Enabled:</strong> {settings.get('enabled', False)}</p>
                    <p><strong>From Email:</strong> {settings.get('default_from', 'Not set')}</p>
                    <p><strong>Admin Recipients:</strong> {len(recipients.get('admin', []))}</p>
                    <p><strong>Sales Recipients:</strong> {len(recipients.get('sales', []))}</p>
                    <p><strong>Total Sent:</strong> {stats.get('total_sent', 0)}</p>
                </div>
                <p>Full settings interface requires template support.</p>
            </body>
            </html>
            """)
            
    except Exception as e:
        logger.error(f"Failed to load notification settings page: {e}")
        raise HTTPException(status_code=500, detail="Failed to load notification settings page")

@router.post("/notify/test", response_model=Dict[str, Any], dependencies=[Depends(verify_admin_token)])
async def test_notification_system():
    """
    Send test notifications to verify the system is working.
    
    Requires Admin-Token header for authorization.
    """
    logger.info("POST /settings/notify/test - sending test notifications")
    
    try:
        from p16__server_services_notify import notify_system_alert
        
        # Send a test system alert
        job_ids = notify_system_alert(
            alert_type="test_notification",
            message="This is a test notification to verify the email system is working correctly.",
            severity="info"
        )
        
        return {
            'success': True,
            'message': f'Test notifications queued successfully',
            'job_ids': job_ids,
            'job_count': len(job_ids)
        }
        
    except Exception as e:
        logger.error(f"Failed to send test notifications: {e}")
        raise HTTPException(status_code=500, detail="Failed to send test notifications")

# Log router initialization
logger.info("Notification settings routes initialized: GET /notify, POST /notify, POST /recipients, GET /notify-page, POST /test")
